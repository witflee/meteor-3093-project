(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var EJSON = Package.ejson.EJSON;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Retry = Package.retry.Retry;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var DDPCommon;

var require = meteorInstall({"node_modules":{"meteor":{"ddp-common":{"namespace.js":function module(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-common/namespace.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**
 * @namespace DDPCommon
 * @summary Namespace for DDPCommon-related methods/classes. Shared between 
 * `ddp-client` and `ddp-server`, where the ddp-client is the implementation
 * of a ddp client for both client AND server; and the ddp server is the
 * implementation of the livedata server and stream server. Common 
 * functionality shared between both can be shared under this namespace
 */
DDPCommon = {};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"heartbeat.js":function module(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-common/heartbeat.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Heartbeat options:
//   heartbeatInterval: interval to send pings, in milliseconds.
//   heartbeatTimeout: timeout to close the connection if a reply isn't
//     received, in milliseconds.
//   sendPing: function to call to send a ping on the connection.
//   onTimeout: function to call to close the connection.

DDPCommon.Heartbeat = class Heartbeat {
  constructor(options) {
    this.heartbeatInterval = options.heartbeatInterval;
    this.heartbeatTimeout = options.heartbeatTimeout;
    this._sendPing = options.sendPing;
    this._onTimeout = options.onTimeout;
    this._seenPacket = false;
    this._heartbeatIntervalHandle = null;
    this._heartbeatTimeoutHandle = null;
  }
  stop() {
    this._clearHeartbeatIntervalTimer();
    this._clearHeartbeatTimeoutTimer();
  }
  start() {
    this.stop();
    this._startHeartbeatIntervalTimer();
  }
  _startHeartbeatIntervalTimer() {
    this._heartbeatIntervalHandle = Meteor.setInterval(() => this._heartbeatIntervalFired(), this.heartbeatInterval);
  }
  _startHeartbeatTimeoutTimer() {
    this._heartbeatTimeoutHandle = Meteor.setTimeout(() => this._heartbeatTimeoutFired(), this.heartbeatTimeout);
  }
  _clearHeartbeatIntervalTimer() {
    if (this._heartbeatIntervalHandle) {
      Meteor.clearInterval(this._heartbeatIntervalHandle);
      this._heartbeatIntervalHandle = null;
    }
  }
  _clearHeartbeatTimeoutTimer() {
    if (this._heartbeatTimeoutHandle) {
      Meteor.clearTimeout(this._heartbeatTimeoutHandle);
      this._heartbeatTimeoutHandle = null;
    }
  }

  // The heartbeat interval timer is fired when we should send a ping.
  _heartbeatIntervalFired() {
    // don't send ping if we've seen a packet since we last checked,
    // *or* if we have already sent a ping and are awaiting a timeout.
    // That shouldn't happen, but it's possible if
    // `this.heartbeatInterval` is smaller than
    // `this.heartbeatTimeout`.
    if (!this._seenPacket && !this._heartbeatTimeoutHandle) {
      this._sendPing();
      // Set up timeout, in case a pong doesn't arrive in time.
      this._startHeartbeatTimeoutTimer();
    }
    this._seenPacket = false;
  }

  // The heartbeat timeout timer is fired when we sent a ping, but we
  // timed out waiting for the pong.
  _heartbeatTimeoutFired() {
    this._heartbeatTimeoutHandle = null;
    this._onTimeout();
  }
  messageReceived() {
    // Tell periodic checkin that we have seen a packet, and thus it
    // does not need to send a ping this cycle.
    this._seenPacket = true;
    // If we were waiting for a pong, we got it.
    if (this._heartbeatTimeoutHandle) {
      this._clearHeartbeatTimeoutTimer();
    }
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-common/utils.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
"use strict";

module.export({
  hasOwn: () => hasOwn,
  slice: () => slice,
  keys: () => keys,
  isEmpty: () => isEmpty,
  last: () => last
});
const hasOwn = Object.prototype.hasOwnProperty;
const slice = Array.prototype.slice;
function keys(obj) {
  return Object.keys(Object(obj));
}
function isEmpty(obj) {
  if (obj == null) {
    return true;
  }
  if (Array.isArray(obj) || typeof obj === "string") {
    return obj.length === 0;
  }
  for (const key in obj) {
    if (hasOwn.call(obj, key)) {
      return false;
    }
  }
  return true;
}
function last(array, n, guard) {
  if (array == null) {
    return;
  }
  if (n == null || guard) {
    return array[array.length - 1];
  }
  return slice.call(array, Math.max(array.length - n, 0));
}
DDPCommon.SUPPORTED_DDP_VERSIONS = ['1', 'pre2', 'pre1'];
DDPCommon.parseDDP = function (stringMessage) {
  try {
    var msg = JSON.parse(stringMessage);
  } catch (e) {
    Meteor._debug("Discarding message with invalid JSON", stringMessage);
    return null;
  }
  // DDP messages must be objects.
  if (msg === null || typeof msg !== 'object') {
    Meteor._debug("Discarding non-object DDP message", stringMessage);
    return null;
  }

  // massage msg to get it into "abstract ddp" rather than "wire ddp" format.

  // switch between "cleared" rep of unsetting fields and "undefined"
  // rep of same
  if (hasOwn.call(msg, 'cleared')) {
    if (!hasOwn.call(msg, 'fields')) {
      msg.fields = {};
    }
    msg.cleared.forEach(clearKey => {
      msg.fields[clearKey] = undefined;
    });
    delete msg.cleared;
  }
  ['fields', 'params', 'result'].forEach(field => {
    if (hasOwn.call(msg, field)) {
      msg[field] = EJSON._adjustTypesFromJSONValue(msg[field]);
    }
  });
  return msg;
};
DDPCommon.stringifyDDP = function (msg) {
  const copy = EJSON.clone(msg);

  // swizzle 'changed' messages from 'fields undefined' rep to 'fields
  // and cleared' rep
  if (hasOwn.call(msg, 'fields')) {
    const cleared = [];
    Object.keys(msg.fields).forEach(key => {
      const value = msg.fields[key];
      if (typeof value === "undefined") {
        cleared.push(key);
        delete copy.fields[key];
      }
    });
    if (!isEmpty(cleared)) {
      copy.cleared = cleared;
    }
    if (isEmpty(copy.fields)) {
      delete copy.fields;
    }
  }

  // adjust types to basic
  ['fields', 'params', 'result'].forEach(field => {
    if (hasOwn.call(copy, field)) {
      copy[field] = EJSON._adjustTypesToJSONValue(copy[field]);
    }
  });
  if (msg.id && typeof msg.id !== 'string') {
    throw new Error("Message id is not a string");
  }
  return JSON.stringify(copy);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"method_invocation.js":function module(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-common/method_invocation.js                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Instance name is this because it is usually referred to as this inside a
// method definition
/**
 * @summary The state for a single invocation of a method, referenced by this
 * inside a method definition.
 * @param {Object} options
 * @instanceName this
 * @showInstanceName true
 */
DDPCommon.MethodInvocation = class MethodInvocation {
  constructor(options) {
    // true if we're running not the actual method, but a stub (that is,
    // if we're on a client (which may be a browser, or in the future a
    // server connecting to another server) and presently running a
    // simulation of a server-side method for latency compensation
    // purposes). not currently true except in a client such as a browser,
    // since there's usually no point in running stubs unless you have a
    // zero-latency connection to the user.

    /**
     * @summary Access inside a method invocation.  Boolean value, true if this invocation is a stub.
     * @locus Anywhere
     * @name  isSimulation
     * @memberOf DDPCommon.MethodInvocation
     * @instance
     * @type {Boolean}
     */
    this.isSimulation = options.isSimulation;

    // call this function to allow other method invocations (from the
    // same client) to continue running without waiting for this one to
    // complete.
    this._unblock = options.unblock || function () {};
    this._calledUnblock = false;

    // used to know when the function apply was called by callAsync
    this._isFromCallAsync = options.isFromCallAsync;

    // current user id

    /**
     * @summary The id of the user that made this method call, or `null` if no user was logged in.
     * @locus Anywhere
     * @name  userId
     * @memberOf DDPCommon.MethodInvocation
     * @instance
     */
    this.userId = options.userId;

    // sets current user id in all appropriate server contexts and
    // reruns subscriptions
    this._setUserId = options.setUserId || function () {};

    // On the server, the connection this method call came in on.

    /**
     * @summary Access inside a method invocation. The [connection](#meteor_onconnection) that this method was received on. `null` if the method is not associated with a connection, eg. a server initiated method call. Calls to methods made from a server method which was in turn initiated from the client share the same `connection`.
     * @locus Server
     * @name  connection
     * @memberOf DDPCommon.MethodInvocation
     * @instance
     */
    this.connection = options.connection;

    // The seed for randomStream value generation
    this.randomSeed = options.randomSeed;

    // This is set by RandomStream.get; and holds the random stream state
    this.randomStream = null;
  }

  /**
   * @summary Call inside a method invocation.  Allow subsequent method from this client to begin running in a new fiber.
   * @locus Server
   * @memberOf DDPCommon.MethodInvocation
   * @instance
   */
  unblock() {
    this._calledUnblock = true;
    this._unblock();
  }

  /**
   * @summary Set the logged in user.
   * @locus Server
   * @memberOf DDPCommon.MethodInvocation
   * @instance
   * @param {String | null} userId The value that should be returned by `userId` on this connection.
   */
  setUserId(userId) {
    if (this._calledUnblock) {
      throw new Error("Can't call setUserId in a method after calling unblock");
    }
    this.userId = userId;
    this._setUserId(userId);
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"random_stream.js":function module(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-common/random_stream.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// RandomStream allows for generation of pseudo-random values, from a seed.
//
// We use this for consistent 'random' numbers across the client and server.
// We want to generate probably-unique IDs on the client, and we ideally want
// the server to generate the same IDs when it executes the method.
//
// For generated values to be the same, we must seed ourselves the same way,
// and we must keep track of the current state of our pseudo-random generators.
// We call this state the scope. By default, we use the current DDP method
// invocation as our scope.  DDP now allows the client to specify a randomSeed.
// If a randomSeed is provided it will be used to seed our random sequences.
// In this way, client and server method calls will generate the same values.
//
// We expose multiple named streams; each stream is independent
// and is seeded differently (but predictably from the name).
// By using multiple streams, we support reordering of requests,
// as long as they occur on different streams.
//
// @param options {Optional Object}
//   seed: Array or value - Seed value(s) for the generator.
//                          If an array, will be used as-is
//                          If a value, will be converted to a single-value array
//                          If omitted, a random array will be used as the seed.
DDPCommon.RandomStream = class RandomStream {
  constructor(options) {
    this.seed = [].concat(options.seed || randomToken());
    this.sequences = Object.create(null);
  }

  // Get a random sequence with the specified name, creating it if does not exist.
  // New sequences are seeded with the seed concatenated with the name.
  // By passing a seed into Random.create, we use the Alea generator.
  _sequence(name) {
    var self = this;
    var sequence = self.sequences[name] || null;
    if (sequence === null) {
      var sequenceSeed = self.seed.concat(name);
      for (var i = 0; i < sequenceSeed.length; i++) {
        if (typeof sequenceSeed[i] === "function") {
          sequenceSeed[i] = sequenceSeed[i]();
        }
      }
      self.sequences[name] = sequence = Random.createWithSeeds.apply(null, sequenceSeed);
    }
    return sequence;
  }
};

// Returns a random string of sufficient length for a random seed.
// This is a placeholder function; a similar function is planned
// for Random itself; when that is added we should remove this function,
// and call Random's randomToken instead.
function randomToken() {
  return Random.hexString(20);
}
;

// Returns the random stream with the specified name, in the specified
// scope. If a scope is passed, then we use that to seed a (not
// cryptographically secure) PRNG using the fast Alea algorithm.  If
// scope is null (or otherwise falsey) then we use a generated seed.
//
// However, scope will normally be the current DDP method invocation,
// so we'll use the stream with the specified name, and we should get
// consistent values on the client and server sides of a method call.
DDPCommon.RandomStream.get = function (scope, name) {
  if (!name) {
    name = "default";
  }
  if (!scope) {
    // There was no scope passed in; the sequence won't actually be
    // reproducible. but make it fast (and not cryptographically
    // secure) anyways, so that the behavior is similar to what you'd
    // get by passing in a scope.
    return Random.insecure;
  }
  var randomStream = scope.randomStream;
  if (!randomStream) {
    scope.randomStream = randomStream = new DDPCommon.RandomStream({
      seed: scope.randomSeed
    });
  }
  return randomStream._sequence(name);
};

// Creates a randomSeed for passing to a method call.
// Note that we take enclosing as an argument,
// though we expect it to be DDP._CurrentMethodInvocation.get()
// However, we often evaluate makeRpcSeed lazily, and thus the relevant
// invocation may not be the one currently in scope.
// If enclosing is null, we'll use Random and values won't be repeatable.
DDPCommon.makeRpcSeed = function (enclosing, methodName) {
  var stream = DDPCommon.RandomStream.get(enclosing, '/rpc/' + methodName);
  return stream.hexString(20);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/ddp-common/namespace.js");
require("/node_modules/meteor/ddp-common/heartbeat.js");
require("/node_modules/meteor/ddp-common/utils.js");
require("/node_modules/meteor/ddp-common/method_invocation.js");
require("/node_modules/meteor/ddp-common/random_stream.js");

/* Exports */
Package._define("ddp-common", {
  DDPCommon: DDPCommon
});

})();

//# sourceURL=meteor://💻app/packages/ddp-common.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZGRwLWNvbW1vbi9uYW1lc3BhY2UuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2RkcC1jb21tb24vaGVhcnRiZWF0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9kZHAtY29tbW9uL3V0aWxzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9kZHAtY29tbW9uL21ldGhvZF9pbnZvY2F0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9kZHAtY29tbW9uL3JhbmRvbV9zdHJlYW0uanMiXSwibmFtZXMiOlsiRERQQ29tbW9uIiwiSGVhcnRiZWF0IiwiY29uc3RydWN0b3IiLCJvcHRpb25zIiwiaGVhcnRiZWF0SW50ZXJ2YWwiLCJoZWFydGJlYXRUaW1lb3V0IiwiX3NlbmRQaW5nIiwic2VuZFBpbmciLCJfb25UaW1lb3V0Iiwib25UaW1lb3V0IiwiX3NlZW5QYWNrZXQiLCJfaGVhcnRiZWF0SW50ZXJ2YWxIYW5kbGUiLCJfaGVhcnRiZWF0VGltZW91dEhhbmRsZSIsInN0b3AiLCJfY2xlYXJIZWFydGJlYXRJbnRlcnZhbFRpbWVyIiwiX2NsZWFySGVhcnRiZWF0VGltZW91dFRpbWVyIiwic3RhcnQiLCJfc3RhcnRIZWFydGJlYXRJbnRlcnZhbFRpbWVyIiwiTWV0ZW9yIiwic2V0SW50ZXJ2YWwiLCJfaGVhcnRiZWF0SW50ZXJ2YWxGaXJlZCIsIl9zdGFydEhlYXJ0YmVhdFRpbWVvdXRUaW1lciIsInNldFRpbWVvdXQiLCJfaGVhcnRiZWF0VGltZW91dEZpcmVkIiwiY2xlYXJJbnRlcnZhbCIsImNsZWFyVGltZW91dCIsIm1lc3NhZ2VSZWNlaXZlZCIsIm1vZHVsZSIsImV4cG9ydCIsImhhc093biIsInNsaWNlIiwia2V5cyIsImlzRW1wdHkiLCJsYXN0IiwiT2JqZWN0IiwicHJvdG90eXBlIiwiaGFzT3duUHJvcGVydHkiLCJBcnJheSIsIm9iaiIsImlzQXJyYXkiLCJsZW5ndGgiLCJrZXkiLCJjYWxsIiwiYXJyYXkiLCJuIiwiZ3VhcmQiLCJNYXRoIiwibWF4IiwiU1VQUE9SVEVEX0REUF9WRVJTSU9OUyIsInBhcnNlRERQIiwic3RyaW5nTWVzc2FnZSIsIm1zZyIsIkpTT04iLCJwYXJzZSIsImUiLCJfZGVidWciLCJmaWVsZHMiLCJjbGVhcmVkIiwiZm9yRWFjaCIsImNsZWFyS2V5IiwidW5kZWZpbmVkIiwiZmllbGQiLCJFSlNPTiIsIl9hZGp1c3RUeXBlc0Zyb21KU09OVmFsdWUiLCJzdHJpbmdpZnlERFAiLCJjb3B5IiwiY2xvbmUiLCJ2YWx1ZSIsInB1c2giLCJfYWRqdXN0VHlwZXNUb0pTT05WYWx1ZSIsImlkIiwiRXJyb3IiLCJzdHJpbmdpZnkiLCJNZXRob2RJbnZvY2F0aW9uIiwiaXNTaW11bGF0aW9uIiwiX3VuYmxvY2siLCJ1bmJsb2NrIiwiX2NhbGxlZFVuYmxvY2siLCJfaXNGcm9tQ2FsbEFzeW5jIiwiaXNGcm9tQ2FsbEFzeW5jIiwidXNlcklkIiwiX3NldFVzZXJJZCIsInNldFVzZXJJZCIsImNvbm5lY3Rpb24iLCJyYW5kb21TZWVkIiwicmFuZG9tU3RyZWFtIiwiUmFuZG9tU3RyZWFtIiwic2VlZCIsImNvbmNhdCIsInJhbmRvbVRva2VuIiwic2VxdWVuY2VzIiwiY3JlYXRlIiwiX3NlcXVlbmNlIiwibmFtZSIsInNlbGYiLCJzZXF1ZW5jZSIsInNlcXVlbmNlU2VlZCIsImkiLCJSYW5kb20iLCJjcmVhdGVXaXRoU2VlZHMiLCJhcHBseSIsImhleFN0cmluZyIsImdldCIsInNjb3BlIiwiaW5zZWN1cmUiLCJtYWtlUnBjU2VlZCIsImVuY2xvc2luZyIsIm1ldGhvZE5hbWUiLCJzdHJlYW0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FBLFNBQVMsR0FBRyxDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7QUNSZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUFBLFNBQVMsQ0FBQ0MsU0FBUyxHQUFHLE1BQU1BLFNBQVMsQ0FBQztFQUNwQ0MsV0FBV0EsQ0FBQ0MsT0FBTyxFQUFFO0lBQ25CLElBQUksQ0FBQ0MsaUJBQWlCLEdBQUdELE9BQU8sQ0FBQ0MsaUJBQWlCO0lBQ2xELElBQUksQ0FBQ0MsZ0JBQWdCLEdBQUdGLE9BQU8sQ0FBQ0UsZ0JBQWdCO0lBQ2hELElBQUksQ0FBQ0MsU0FBUyxHQUFHSCxPQUFPLENBQUNJLFFBQVE7SUFDakMsSUFBSSxDQUFDQyxVQUFVLEdBQUdMLE9BQU8sQ0FBQ00sU0FBUztJQUNuQyxJQUFJLENBQUNDLFdBQVcsR0FBRyxLQUFLO0lBRXhCLElBQUksQ0FBQ0Msd0JBQXdCLEdBQUcsSUFBSTtJQUNwQyxJQUFJLENBQUNDLHVCQUF1QixHQUFHLElBQUk7RUFDckM7RUFFQUMsSUFBSUEsQ0FBQSxFQUFHO0lBQ0wsSUFBSSxDQUFDQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQ25DLElBQUksQ0FBQ0MsMkJBQTJCLENBQUMsQ0FBQztFQUNwQztFQUVBQyxLQUFLQSxDQUFBLEVBQUc7SUFDTixJQUFJLENBQUNILElBQUksQ0FBQyxDQUFDO0lBQ1gsSUFBSSxDQUFDSSw0QkFBNEIsQ0FBQyxDQUFDO0VBQ3JDO0VBRUFBLDRCQUE0QkEsQ0FBQSxFQUFHO0lBQzdCLElBQUksQ0FBQ04sd0JBQXdCLEdBQUdPLE1BQU0sQ0FBQ0MsV0FBVyxDQUNoRCxNQUFNLElBQUksQ0FBQ0MsdUJBQXVCLENBQUMsQ0FBQyxFQUNwQyxJQUFJLENBQUNoQixpQkFDUCxDQUFDO0VBQ0g7RUFFQWlCLDJCQUEyQkEsQ0FBQSxFQUFHO0lBQzVCLElBQUksQ0FBQ1QsdUJBQXVCLEdBQUdNLE1BQU0sQ0FBQ0ksVUFBVSxDQUM5QyxNQUFNLElBQUksQ0FBQ0Msc0JBQXNCLENBQUMsQ0FBQyxFQUNuQyxJQUFJLENBQUNsQixnQkFDUCxDQUFDO0VBQ0g7RUFFQVMsNEJBQTRCQSxDQUFBLEVBQUc7SUFDN0IsSUFBSSxJQUFJLENBQUNILHdCQUF3QixFQUFFO01BQ2pDTyxNQUFNLENBQUNNLGFBQWEsQ0FBQyxJQUFJLENBQUNiLHdCQUF3QixDQUFDO01BQ25ELElBQUksQ0FBQ0Esd0JBQXdCLEdBQUcsSUFBSTtJQUN0QztFQUNGO0VBRUFJLDJCQUEyQkEsQ0FBQSxFQUFHO0lBQzVCLElBQUksSUFBSSxDQUFDSCx1QkFBdUIsRUFBRTtNQUNoQ00sTUFBTSxDQUFDTyxZQUFZLENBQUMsSUFBSSxDQUFDYix1QkFBdUIsQ0FBQztNQUNqRCxJQUFJLENBQUNBLHVCQUF1QixHQUFHLElBQUk7SUFDckM7RUFDRjs7RUFFQTtFQUNBUSx1QkFBdUJBLENBQUEsRUFBRztJQUN4QjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSSxDQUFFLElBQUksQ0FBQ1YsV0FBVyxJQUFJLENBQUUsSUFBSSxDQUFDRSx1QkFBdUIsRUFBRTtNQUN4RCxJQUFJLENBQUNOLFNBQVMsQ0FBQyxDQUFDO01BQ2hCO01BQ0EsSUFBSSxDQUFDZSwyQkFBMkIsQ0FBQyxDQUFDO0lBQ3BDO0lBQ0EsSUFBSSxDQUFDWCxXQUFXLEdBQUcsS0FBSztFQUMxQjs7RUFFQTtFQUNBO0VBQ0FhLHNCQUFzQkEsQ0FBQSxFQUFHO0lBQ3ZCLElBQUksQ0FBQ1gsdUJBQXVCLEdBQUcsSUFBSTtJQUNuQyxJQUFJLENBQUNKLFVBQVUsQ0FBQyxDQUFDO0VBQ25CO0VBRUFrQixlQUFlQSxDQUFBLEVBQUc7SUFDaEI7SUFDQTtJQUNBLElBQUksQ0FBQ2hCLFdBQVcsR0FBRyxJQUFJO0lBQ3ZCO0lBQ0EsSUFBSSxJQUFJLENBQUNFLHVCQUF1QixFQUFFO01BQ2hDLElBQUksQ0FBQ0csMkJBQTJCLENBQUMsQ0FBQztJQUNwQztFQUNGO0FBQ0YsQ0FBQyxDOzs7Ozs7Ozs7OztBQ3hGRCxZQUFZOztBQUFaWSxNQUFNLENBQUNDLE1BQU0sQ0FBQztFQUFDQyxNQUFNLEVBQUNBLENBQUEsS0FBSUEsTUFBTTtFQUFDQyxLQUFLLEVBQUNBLENBQUEsS0FBSUEsS0FBSztFQUFDQyxJQUFJLEVBQUNBLENBQUEsS0FBSUEsSUFBSTtFQUFDQyxPQUFPLEVBQUNBLENBQUEsS0FBSUEsT0FBTztFQUFDQyxJQUFJLEVBQUNBLENBQUEsS0FBSUE7QUFBSSxDQUFDLENBQUM7QUFFM0YsTUFBTUosTUFBTSxHQUFHSyxNQUFNLENBQUNDLFNBQVMsQ0FBQ0MsY0FBYztBQUM5QyxNQUFNTixLQUFLLEdBQUdPLEtBQUssQ0FBQ0YsU0FBUyxDQUFDTCxLQUFLO0FBRW5DLFNBQVNDLElBQUlBLENBQUNPLEdBQUcsRUFBRTtFQUN4QixPQUFPSixNQUFNLENBQUNILElBQUksQ0FBQ0csTUFBTSxDQUFDSSxHQUFHLENBQUMsQ0FBQztBQUNqQztBQUVPLFNBQVNOLE9BQU9BLENBQUNNLEdBQUcsRUFBRTtFQUMzQixJQUFJQSxHQUFHLElBQUksSUFBSSxFQUFFO0lBQ2YsT0FBTyxJQUFJO0VBQ2I7RUFFQSxJQUFJRCxLQUFLLENBQUNFLE9BQU8sQ0FBQ0QsR0FBRyxDQUFDLElBQ2xCLE9BQU9BLEdBQUcsS0FBSyxRQUFRLEVBQUU7SUFDM0IsT0FBT0EsR0FBRyxDQUFDRSxNQUFNLEtBQUssQ0FBQztFQUN6QjtFQUVBLEtBQUssTUFBTUMsR0FBRyxJQUFJSCxHQUFHLEVBQUU7SUFDckIsSUFBSVQsTUFBTSxDQUFDYSxJQUFJLENBQUNKLEdBQUcsRUFBRUcsR0FBRyxDQUFDLEVBQUU7TUFDekIsT0FBTyxLQUFLO0lBQ2Q7RUFDRjtFQUVBLE9BQU8sSUFBSTtBQUNiO0FBRU8sU0FBU1IsSUFBSUEsQ0FBQ1UsS0FBSyxFQUFFQyxDQUFDLEVBQUVDLEtBQUssRUFBRTtFQUNwQyxJQUFJRixLQUFLLElBQUksSUFBSSxFQUFFO0lBQ2pCO0VBQ0Y7RUFFQSxJQUFLQyxDQUFDLElBQUksSUFBSSxJQUFLQyxLQUFLLEVBQUU7SUFDeEIsT0FBT0YsS0FBSyxDQUFDQSxLQUFLLENBQUNILE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDaEM7RUFFQSxPQUFPVixLQUFLLENBQUNZLElBQUksQ0FBQ0MsS0FBSyxFQUFFRyxJQUFJLENBQUNDLEdBQUcsQ0FBQ0osS0FBSyxDQUFDSCxNQUFNLEdBQUdJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN6RDtBQUVBNUMsU0FBUyxDQUFDZ0Qsc0JBQXNCLEdBQUcsQ0FBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBRTtBQUUxRGhELFNBQVMsQ0FBQ2lELFFBQVEsR0FBRyxVQUFVQyxhQUFhLEVBQUU7RUFDNUMsSUFBSTtJQUNGLElBQUlDLEdBQUcsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUNILGFBQWEsQ0FBQztFQUNyQyxDQUFDLENBQUMsT0FBT0ksQ0FBQyxFQUFFO0lBQ1ZwQyxNQUFNLENBQUNxQyxNQUFNLENBQUMsc0NBQXNDLEVBQUVMLGFBQWEsQ0FBQztJQUNwRSxPQUFPLElBQUk7RUFDYjtFQUNBO0VBQ0EsSUFBSUMsR0FBRyxLQUFLLElBQUksSUFBSSxPQUFPQSxHQUFHLEtBQUssUUFBUSxFQUFFO0lBQzNDakMsTUFBTSxDQUFDcUMsTUFBTSxDQUFDLG1DQUFtQyxFQUFFTCxhQUFhLENBQUM7SUFDakUsT0FBTyxJQUFJO0VBQ2I7O0VBRUE7O0VBRUE7RUFDQTtFQUNBLElBQUlyQixNQUFNLENBQUNhLElBQUksQ0FBQ1MsR0FBRyxFQUFFLFNBQVMsQ0FBQyxFQUFFO0lBQy9CLElBQUksQ0FBRXRCLE1BQU0sQ0FBQ2EsSUFBSSxDQUFDUyxHQUFHLEVBQUUsUUFBUSxDQUFDLEVBQUU7TUFDaENBLEdBQUcsQ0FBQ0ssTUFBTSxHQUFHLENBQUMsQ0FBQztJQUNqQjtJQUNBTCxHQUFHLENBQUNNLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDQyxRQUFRLElBQUk7TUFDOUJSLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDRyxRQUFRLENBQUMsR0FBR0MsU0FBUztJQUNsQyxDQUFDLENBQUM7SUFDRixPQUFPVCxHQUFHLENBQUNNLE9BQU87RUFDcEI7RUFFQSxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUNDLE9BQU8sQ0FBQ0csS0FBSyxJQUFJO0lBQzlDLElBQUloQyxNQUFNLENBQUNhLElBQUksQ0FBQ1MsR0FBRyxFQUFFVSxLQUFLLENBQUMsRUFBRTtNQUMzQlYsR0FBRyxDQUFDVSxLQUFLLENBQUMsR0FBR0MsS0FBSyxDQUFDQyx5QkFBeUIsQ0FBQ1osR0FBRyxDQUFDVSxLQUFLLENBQUMsQ0FBQztJQUMxRDtFQUNGLENBQUMsQ0FBQztFQUVGLE9BQU9WLEdBQUc7QUFDWixDQUFDO0FBRURuRCxTQUFTLENBQUNnRSxZQUFZLEdBQUcsVUFBVWIsR0FBRyxFQUFFO0VBQ3RDLE1BQU1jLElBQUksR0FBR0gsS0FBSyxDQUFDSSxLQUFLLENBQUNmLEdBQUcsQ0FBQzs7RUFFN0I7RUFDQTtFQUNBLElBQUl0QixNQUFNLENBQUNhLElBQUksQ0FBQ1MsR0FBRyxFQUFFLFFBQVEsQ0FBQyxFQUFFO0lBQzlCLE1BQU1NLE9BQU8sR0FBRyxFQUFFO0lBRWxCdkIsTUFBTSxDQUFDSCxJQUFJLENBQUNvQixHQUFHLENBQUNLLE1BQU0sQ0FBQyxDQUFDRSxPQUFPLENBQUNqQixHQUFHLElBQUk7TUFDckMsTUFBTTBCLEtBQUssR0FBR2hCLEdBQUcsQ0FBQ0ssTUFBTSxDQUFDZixHQUFHLENBQUM7TUFFN0IsSUFBSSxPQUFPMEIsS0FBSyxLQUFLLFdBQVcsRUFBRTtRQUNoQ1YsT0FBTyxDQUFDVyxJQUFJLENBQUMzQixHQUFHLENBQUM7UUFDakIsT0FBT3dCLElBQUksQ0FBQ1QsTUFBTSxDQUFDZixHQUFHLENBQUM7TUFDekI7SUFDRixDQUFDLENBQUM7SUFFRixJQUFJLENBQUVULE9BQU8sQ0FBQ3lCLE9BQU8sQ0FBQyxFQUFFO01BQ3RCUSxJQUFJLENBQUNSLE9BQU8sR0FBR0EsT0FBTztJQUN4QjtJQUVBLElBQUl6QixPQUFPLENBQUNpQyxJQUFJLENBQUNULE1BQU0sQ0FBQyxFQUFFO01BQ3hCLE9BQU9TLElBQUksQ0FBQ1QsTUFBTTtJQUNwQjtFQUNGOztFQUVBO0VBQ0EsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDRSxPQUFPLENBQUNHLEtBQUssSUFBSTtJQUM5QyxJQUFJaEMsTUFBTSxDQUFDYSxJQUFJLENBQUN1QixJQUFJLEVBQUVKLEtBQUssQ0FBQyxFQUFFO01BQzVCSSxJQUFJLENBQUNKLEtBQUssQ0FBQyxHQUFHQyxLQUFLLENBQUNPLHVCQUF1QixDQUFDSixJQUFJLENBQUNKLEtBQUssQ0FBQyxDQUFDO0lBQzFEO0VBQ0YsQ0FBQyxDQUFDO0VBRUYsSUFBSVYsR0FBRyxDQUFDbUIsRUFBRSxJQUFJLE9BQU9uQixHQUFHLENBQUNtQixFQUFFLEtBQUssUUFBUSxFQUFFO0lBQ3hDLE1BQU0sSUFBSUMsS0FBSyxDQUFDLDRCQUE0QixDQUFDO0VBQy9DO0VBRUEsT0FBT25CLElBQUksQ0FBQ29CLFNBQVMsQ0FBQ1AsSUFBSSxDQUFDO0FBQzdCLENBQUMsQzs7Ozs7Ozs7Ozs7QUNwSEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FqRSxTQUFTLENBQUN5RSxnQkFBZ0IsR0FBRyxNQUFNQSxnQkFBZ0IsQ0FBQztFQUNsRHZFLFdBQVdBLENBQUNDLE9BQU8sRUFBRTtJQUNuQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTs7SUFFQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0ksSUFBSSxDQUFDdUUsWUFBWSxHQUFHdkUsT0FBTyxDQUFDdUUsWUFBWTs7SUFFeEM7SUFDQTtJQUNBO0lBQ0EsSUFBSSxDQUFDQyxRQUFRLEdBQUd4RSxPQUFPLENBQUN5RSxPQUFPLElBQUksWUFBWSxDQUFDLENBQUM7SUFDakQsSUFBSSxDQUFDQyxjQUFjLEdBQUcsS0FBSzs7SUFFM0I7SUFDQSxJQUFJLENBQUNDLGdCQUFnQixHQUFHM0UsT0FBTyxDQUFDNEUsZUFBZTs7SUFFL0M7O0lBRUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDSSxJQUFJLENBQUNDLE1BQU0sR0FBRzdFLE9BQU8sQ0FBQzZFLE1BQU07O0lBRTVCO0lBQ0E7SUFDQSxJQUFJLENBQUNDLFVBQVUsR0FBRzlFLE9BQU8sQ0FBQytFLFNBQVMsSUFBSSxZQUFZLENBQUMsQ0FBQzs7SUFFckQ7O0lBRUE7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDSSxJQUFJLENBQUNDLFVBQVUsR0FBR2hGLE9BQU8sQ0FBQ2dGLFVBQVU7O0lBRXBDO0lBQ0EsSUFBSSxDQUFDQyxVQUFVLEdBQUdqRixPQUFPLENBQUNpRixVQUFVOztJQUVwQztJQUNBLElBQUksQ0FBQ0MsWUFBWSxHQUFHLElBQUk7RUFDMUI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VULE9BQU9BLENBQUEsRUFBRztJQUNSLElBQUksQ0FBQ0MsY0FBYyxHQUFHLElBQUk7SUFDMUIsSUFBSSxDQUFDRixRQUFRLENBQUMsQ0FBQztFQUNqQjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFTyxTQUFTQSxDQUFDRixNQUFNLEVBQUU7SUFDaEIsSUFBSSxJQUFJLENBQUNILGNBQWMsRUFBRTtNQUN2QixNQUFNLElBQUlOLEtBQUssQ0FBQyx3REFBd0QsQ0FBQztJQUMzRTtJQUNBLElBQUksQ0FBQ1MsTUFBTSxHQUFHQSxNQUFNO0lBQ3BCLElBQUksQ0FBQ0MsVUFBVSxDQUFDRCxNQUFNLENBQUM7RUFDekI7QUFDRixDQUFDLEM7Ozs7Ozs7Ozs7O0FDaEdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQWhGLFNBQVMsQ0FBQ3NGLFlBQVksR0FBRyxNQUFNQSxZQUFZLENBQUM7RUFDMUNwRixXQUFXQSxDQUFDQyxPQUFPLEVBQUU7SUFDbkIsSUFBSSxDQUFDb0YsSUFBSSxHQUFHLEVBQUUsQ0FBQ0MsTUFBTSxDQUFDckYsT0FBTyxDQUFDb0YsSUFBSSxJQUFJRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ3BELElBQUksQ0FBQ0MsU0FBUyxHQUFHeEQsTUFBTSxDQUFDeUQsTUFBTSxDQUFDLElBQUksQ0FBQztFQUN0Qzs7RUFFQTtFQUNBO0VBQ0E7RUFDQUMsU0FBU0EsQ0FBQ0MsSUFBSSxFQUFFO0lBQ2QsSUFBSUMsSUFBSSxHQUFHLElBQUk7SUFFZixJQUFJQyxRQUFRLEdBQUdELElBQUksQ0FBQ0osU0FBUyxDQUFDRyxJQUFJLENBQUMsSUFBSSxJQUFJO0lBQzNDLElBQUlFLFFBQVEsS0FBSyxJQUFJLEVBQUU7TUFDckIsSUFBSUMsWUFBWSxHQUFHRixJQUFJLENBQUNQLElBQUksQ0FBQ0MsTUFBTSxDQUFDSyxJQUFJLENBQUM7TUFDekMsS0FBSyxJQUFJSSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdELFlBQVksQ0FBQ3hELE1BQU0sRUFBRXlELENBQUMsRUFBRSxFQUFFO1FBQzVDLElBQUksT0FBT0QsWUFBWSxDQUFDQyxDQUFDLENBQUMsS0FBSyxVQUFVLEVBQUU7VUFDekNELFlBQVksQ0FBQ0MsQ0FBQyxDQUFDLEdBQUdELFlBQVksQ0FBQ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyQztNQUNGO01BQ0FILElBQUksQ0FBQ0osU0FBUyxDQUFDRyxJQUFJLENBQUMsR0FBR0UsUUFBUSxHQUFHRyxNQUFNLENBQUNDLGVBQWUsQ0FBQ0MsS0FBSyxDQUFDLElBQUksRUFBRUosWUFBWSxDQUFDO0lBQ3BGO0lBQ0EsT0FBT0QsUUFBUTtFQUNqQjtBQUNGLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTTixXQUFXQSxDQUFBLEVBQUc7RUFDckIsT0FBT1MsTUFBTSxDQUFDRyxTQUFTLENBQUMsRUFBRSxDQUFDO0FBQzdCO0FBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBckcsU0FBUyxDQUFDc0YsWUFBWSxDQUFDZ0IsR0FBRyxHQUFHLFVBQVVDLEtBQUssRUFBRVYsSUFBSSxFQUFFO0VBQ2xELElBQUksQ0FBQ0EsSUFBSSxFQUFFO0lBQ1RBLElBQUksR0FBRyxTQUFTO0VBQ2xCO0VBQ0EsSUFBSSxDQUFDVSxLQUFLLEVBQUU7SUFDVjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE9BQU9MLE1BQU0sQ0FBQ00sUUFBUTtFQUN4QjtFQUNBLElBQUluQixZQUFZLEdBQUdrQixLQUFLLENBQUNsQixZQUFZO0VBQ3JDLElBQUksQ0FBQ0EsWUFBWSxFQUFFO0lBQ2pCa0IsS0FBSyxDQUFDbEIsWUFBWSxHQUFHQSxZQUFZLEdBQUcsSUFBSXJGLFNBQVMsQ0FBQ3NGLFlBQVksQ0FBQztNQUM3REMsSUFBSSxFQUFFZ0IsS0FBSyxDQUFDbkI7SUFDZCxDQUFDLENBQUM7RUFDSjtFQUNBLE9BQU9DLFlBQVksQ0FBQ08sU0FBUyxDQUFDQyxJQUFJLENBQUM7QUFDckMsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTdGLFNBQVMsQ0FBQ3lHLFdBQVcsR0FBRyxVQUFVQyxTQUFTLEVBQUVDLFVBQVUsRUFBRTtFQUN2RCxJQUFJQyxNQUFNLEdBQUc1RyxTQUFTLENBQUNzRixZQUFZLENBQUNnQixHQUFHLENBQUNJLFNBQVMsRUFBRSxPQUFPLEdBQUdDLFVBQVUsQ0FBQztFQUN4RSxPQUFPQyxNQUFNLENBQUNQLFNBQVMsQ0FBQyxFQUFFLENBQUM7QUFDN0IsQ0FBQyxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9kZHAtY29tbW9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbmFtZXNwYWNlIEREUENvbW1vblxuICogQHN1bW1hcnkgTmFtZXNwYWNlIGZvciBERFBDb21tb24tcmVsYXRlZCBtZXRob2RzL2NsYXNzZXMuIFNoYXJlZCBiZXR3ZWVuIFxuICogYGRkcC1jbGllbnRgIGFuZCBgZGRwLXNlcnZlcmAsIHdoZXJlIHRoZSBkZHAtY2xpZW50IGlzIHRoZSBpbXBsZW1lbnRhdGlvblxuICogb2YgYSBkZHAgY2xpZW50IGZvciBib3RoIGNsaWVudCBBTkQgc2VydmVyOyBhbmQgdGhlIGRkcCBzZXJ2ZXIgaXMgdGhlXG4gKiBpbXBsZW1lbnRhdGlvbiBvZiB0aGUgbGl2ZWRhdGEgc2VydmVyIGFuZCBzdHJlYW0gc2VydmVyLiBDb21tb24gXG4gKiBmdW5jdGlvbmFsaXR5IHNoYXJlZCBiZXR3ZWVuIGJvdGggY2FuIGJlIHNoYXJlZCB1bmRlciB0aGlzIG5hbWVzcGFjZVxuICovXG5ERFBDb21tb24gPSB7fTtcbiIsIi8vIEhlYXJ0YmVhdCBvcHRpb25zOlxuLy8gICBoZWFydGJlYXRJbnRlcnZhbDogaW50ZXJ2YWwgdG8gc2VuZCBwaW5ncywgaW4gbWlsbGlzZWNvbmRzLlxuLy8gICBoZWFydGJlYXRUaW1lb3V0OiB0aW1lb3V0IHRvIGNsb3NlIHRoZSBjb25uZWN0aW9uIGlmIGEgcmVwbHkgaXNuJ3Rcbi8vICAgICByZWNlaXZlZCwgaW4gbWlsbGlzZWNvbmRzLlxuLy8gICBzZW5kUGluZzogZnVuY3Rpb24gdG8gY2FsbCB0byBzZW5kIGEgcGluZyBvbiB0aGUgY29ubmVjdGlvbi5cbi8vICAgb25UaW1lb3V0OiBmdW5jdGlvbiB0byBjYWxsIHRvIGNsb3NlIHRoZSBjb25uZWN0aW9uLlxuXG5ERFBDb21tb24uSGVhcnRiZWF0ID0gY2xhc3MgSGVhcnRiZWF0IHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHRoaXMuaGVhcnRiZWF0SW50ZXJ2YWwgPSBvcHRpb25zLmhlYXJ0YmVhdEludGVydmFsO1xuICAgIHRoaXMuaGVhcnRiZWF0VGltZW91dCA9IG9wdGlvbnMuaGVhcnRiZWF0VGltZW91dDtcbiAgICB0aGlzLl9zZW5kUGluZyA9IG9wdGlvbnMuc2VuZFBpbmc7XG4gICAgdGhpcy5fb25UaW1lb3V0ID0gb3B0aW9ucy5vblRpbWVvdXQ7XG4gICAgdGhpcy5fc2VlblBhY2tldCA9IGZhbHNlO1xuXG4gICAgdGhpcy5faGVhcnRiZWF0SW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICAgIHRoaXMuX2hlYXJ0YmVhdFRpbWVvdXRIYW5kbGUgPSBudWxsO1xuICB9XG5cbiAgc3RvcCgpIHtcbiAgICB0aGlzLl9jbGVhckhlYXJ0YmVhdEludGVydmFsVGltZXIoKTtcbiAgICB0aGlzLl9jbGVhckhlYXJ0YmVhdFRpbWVvdXRUaW1lcigpO1xuICB9XG5cbiAgc3RhcnQoKSB7XG4gICAgdGhpcy5zdG9wKCk7XG4gICAgdGhpcy5fc3RhcnRIZWFydGJlYXRJbnRlcnZhbFRpbWVyKCk7XG4gIH1cblxuICBfc3RhcnRIZWFydGJlYXRJbnRlcnZhbFRpbWVyKCkge1xuICAgIHRoaXMuX2hlYXJ0YmVhdEludGVydmFsSGFuZGxlID0gTWV0ZW9yLnNldEludGVydmFsKFxuICAgICAgKCkgPT4gdGhpcy5faGVhcnRiZWF0SW50ZXJ2YWxGaXJlZCgpLFxuICAgICAgdGhpcy5oZWFydGJlYXRJbnRlcnZhbFxuICAgICk7XG4gIH1cblxuICBfc3RhcnRIZWFydGJlYXRUaW1lb3V0VGltZXIoKSB7XG4gICAgdGhpcy5faGVhcnRiZWF0VGltZW91dEhhbmRsZSA9IE1ldGVvci5zZXRUaW1lb3V0KFxuICAgICAgKCkgPT4gdGhpcy5faGVhcnRiZWF0VGltZW91dEZpcmVkKCksXG4gICAgICB0aGlzLmhlYXJ0YmVhdFRpbWVvdXRcbiAgICApO1xuICB9XG5cbiAgX2NsZWFySGVhcnRiZWF0SW50ZXJ2YWxUaW1lcigpIHtcbiAgICBpZiAodGhpcy5faGVhcnRiZWF0SW50ZXJ2YWxIYW5kbGUpIHtcbiAgICAgIE1ldGVvci5jbGVhckludGVydmFsKHRoaXMuX2hlYXJ0YmVhdEludGVydmFsSGFuZGxlKTtcbiAgICAgIHRoaXMuX2hlYXJ0YmVhdEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgICB9XG4gIH1cblxuICBfY2xlYXJIZWFydGJlYXRUaW1lb3V0VGltZXIoKSB7XG4gICAgaWYgKHRoaXMuX2hlYXJ0YmVhdFRpbWVvdXRIYW5kbGUpIHtcbiAgICAgIE1ldGVvci5jbGVhclRpbWVvdXQodGhpcy5faGVhcnRiZWF0VGltZW91dEhhbmRsZSk7XG4gICAgICB0aGlzLl9oZWFydGJlYXRUaW1lb3V0SGFuZGxlID0gbnVsbDtcbiAgICB9XG4gIH1cblxuICAvLyBUaGUgaGVhcnRiZWF0IGludGVydmFsIHRpbWVyIGlzIGZpcmVkIHdoZW4gd2Ugc2hvdWxkIHNlbmQgYSBwaW5nLlxuICBfaGVhcnRiZWF0SW50ZXJ2YWxGaXJlZCgpIHtcbiAgICAvLyBkb24ndCBzZW5kIHBpbmcgaWYgd2UndmUgc2VlbiBhIHBhY2tldCBzaW5jZSB3ZSBsYXN0IGNoZWNrZWQsXG4gICAgLy8gKm9yKiBpZiB3ZSBoYXZlIGFscmVhZHkgc2VudCBhIHBpbmcgYW5kIGFyZSBhd2FpdGluZyBhIHRpbWVvdXQuXG4gICAgLy8gVGhhdCBzaG91bGRuJ3QgaGFwcGVuLCBidXQgaXQncyBwb3NzaWJsZSBpZlxuICAgIC8vIGB0aGlzLmhlYXJ0YmVhdEludGVydmFsYCBpcyBzbWFsbGVyIHRoYW5cbiAgICAvLyBgdGhpcy5oZWFydGJlYXRUaW1lb3V0YC5cbiAgICBpZiAoISB0aGlzLl9zZWVuUGFja2V0ICYmICEgdGhpcy5faGVhcnRiZWF0VGltZW91dEhhbmRsZSkge1xuICAgICAgdGhpcy5fc2VuZFBpbmcoKTtcbiAgICAgIC8vIFNldCB1cCB0aW1lb3V0LCBpbiBjYXNlIGEgcG9uZyBkb2Vzbid0IGFycml2ZSBpbiB0aW1lLlxuICAgICAgdGhpcy5fc3RhcnRIZWFydGJlYXRUaW1lb3V0VGltZXIoKTtcbiAgICB9XG4gICAgdGhpcy5fc2VlblBhY2tldCA9IGZhbHNlO1xuICB9XG5cbiAgLy8gVGhlIGhlYXJ0YmVhdCB0aW1lb3V0IHRpbWVyIGlzIGZpcmVkIHdoZW4gd2Ugc2VudCBhIHBpbmcsIGJ1dCB3ZVxuICAvLyB0aW1lZCBvdXQgd2FpdGluZyBmb3IgdGhlIHBvbmcuXG4gIF9oZWFydGJlYXRUaW1lb3V0RmlyZWQoKSB7XG4gICAgdGhpcy5faGVhcnRiZWF0VGltZW91dEhhbmRsZSA9IG51bGw7XG4gICAgdGhpcy5fb25UaW1lb3V0KCk7XG4gIH1cblxuICBtZXNzYWdlUmVjZWl2ZWQoKSB7XG4gICAgLy8gVGVsbCBwZXJpb2RpYyBjaGVja2luIHRoYXQgd2UgaGF2ZSBzZWVuIGEgcGFja2V0LCBhbmQgdGh1cyBpdFxuICAgIC8vIGRvZXMgbm90IG5lZWQgdG8gc2VuZCBhIHBpbmcgdGhpcyBjeWNsZS5cbiAgICB0aGlzLl9zZWVuUGFja2V0ID0gdHJ1ZTtcbiAgICAvLyBJZiB3ZSB3ZXJlIHdhaXRpbmcgZm9yIGEgcG9uZywgd2UgZ290IGl0LlxuICAgIGlmICh0aGlzLl9oZWFydGJlYXRUaW1lb3V0SGFuZGxlKSB7XG4gICAgICB0aGlzLl9jbGVhckhlYXJ0YmVhdFRpbWVvdXRUaW1lcigpO1xuICAgIH1cbiAgfVxufTtcbiIsIlwidXNlIHN0cmljdFwiO1xuXG5leHBvcnQgY29uc3QgaGFzT3duID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbmV4cG9ydCBjb25zdCBzbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcblxuZXhwb3J0IGZ1bmN0aW9uIGtleXMob2JqKSB7XG4gIHJldHVybiBPYmplY3Qua2V5cyhPYmplY3Qob2JqKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0VtcHR5KG9iaikge1xuICBpZiAob2JqID09IG51bGwpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGlmIChBcnJheS5pc0FycmF5KG9iaikgfHxcbiAgICAgIHR5cGVvZiBvYmogPT09IFwic3RyaW5nXCIpIHtcbiAgICByZXR1cm4gb2JqLmxlbmd0aCA9PT0gMDtcbiAgfVxuXG4gIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgIGlmIChoYXNPd24uY2FsbChvYmosIGtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdHJ1ZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGxhc3QoYXJyYXksIG4sIGd1YXJkKSB7XG4gIGlmIChhcnJheSA9PSBudWxsKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKChuID09IG51bGwpIHx8IGd1YXJkKSB7XG4gICAgcmV0dXJuIGFycmF5W2FycmF5Lmxlbmd0aCAtIDFdO1xuICB9XG5cbiAgcmV0dXJuIHNsaWNlLmNhbGwoYXJyYXksIE1hdGgubWF4KGFycmF5Lmxlbmd0aCAtIG4sIDApKTtcbn1cblxuRERQQ29tbW9uLlNVUFBPUlRFRF9ERFBfVkVSU0lPTlMgPSBbICcxJywgJ3ByZTInLCAncHJlMScgXTtcblxuRERQQ29tbW9uLnBhcnNlRERQID0gZnVuY3Rpb24gKHN0cmluZ01lc3NhZ2UpIHtcbiAgdHJ5IHtcbiAgICB2YXIgbXNnID0gSlNPTi5wYXJzZShzdHJpbmdNZXNzYWdlKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIE1ldGVvci5fZGVidWcoXCJEaXNjYXJkaW5nIG1lc3NhZ2Ugd2l0aCBpbnZhbGlkIEpTT05cIiwgc3RyaW5nTWVzc2FnZSk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgLy8gRERQIG1lc3NhZ2VzIG11c3QgYmUgb2JqZWN0cy5cbiAgaWYgKG1zZyA9PT0gbnVsbCB8fCB0eXBlb2YgbXNnICE9PSAnb2JqZWN0Jykge1xuICAgIE1ldGVvci5fZGVidWcoXCJEaXNjYXJkaW5nIG5vbi1vYmplY3QgRERQIG1lc3NhZ2VcIiwgc3RyaW5nTWVzc2FnZSk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICAvLyBtYXNzYWdlIG1zZyB0byBnZXQgaXQgaW50byBcImFic3RyYWN0IGRkcFwiIHJhdGhlciB0aGFuIFwid2lyZSBkZHBcIiBmb3JtYXQuXG5cbiAgLy8gc3dpdGNoIGJldHdlZW4gXCJjbGVhcmVkXCIgcmVwIG9mIHVuc2V0dGluZyBmaWVsZHMgYW5kIFwidW5kZWZpbmVkXCJcbiAgLy8gcmVwIG9mIHNhbWVcbiAgaWYgKGhhc093bi5jYWxsKG1zZywgJ2NsZWFyZWQnKSkge1xuICAgIGlmICghIGhhc093bi5jYWxsKG1zZywgJ2ZpZWxkcycpKSB7XG4gICAgICBtc2cuZmllbGRzID0ge307XG4gICAgfVxuICAgIG1zZy5jbGVhcmVkLmZvckVhY2goY2xlYXJLZXkgPT4ge1xuICAgICAgbXNnLmZpZWxkc1tjbGVhcktleV0gPSB1bmRlZmluZWQ7XG4gICAgfSk7XG4gICAgZGVsZXRlIG1zZy5jbGVhcmVkO1xuICB9XG5cbiAgWydmaWVsZHMnLCAncGFyYW1zJywgJ3Jlc3VsdCddLmZvckVhY2goZmllbGQgPT4ge1xuICAgIGlmIChoYXNPd24uY2FsbChtc2csIGZpZWxkKSkge1xuICAgICAgbXNnW2ZpZWxkXSA9IEVKU09OLl9hZGp1c3RUeXBlc0Zyb21KU09OVmFsdWUobXNnW2ZpZWxkXSk7XG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gbXNnO1xufTtcblxuRERQQ29tbW9uLnN0cmluZ2lmeUREUCA9IGZ1bmN0aW9uIChtc2cpIHtcbiAgY29uc3QgY29weSA9IEVKU09OLmNsb25lKG1zZyk7XG5cbiAgLy8gc3dpenpsZSAnY2hhbmdlZCcgbWVzc2FnZXMgZnJvbSAnZmllbGRzIHVuZGVmaW5lZCcgcmVwIHRvICdmaWVsZHNcbiAgLy8gYW5kIGNsZWFyZWQnIHJlcFxuICBpZiAoaGFzT3duLmNhbGwobXNnLCAnZmllbGRzJykpIHtcbiAgICBjb25zdCBjbGVhcmVkID0gW107XG5cbiAgICBPYmplY3Qua2V5cyhtc2cuZmllbGRzKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICBjb25zdCB2YWx1ZSA9IG1zZy5maWVsZHNba2V5XTtcblxuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBjbGVhcmVkLnB1c2goa2V5KTtcbiAgICAgICAgZGVsZXRlIGNvcHkuZmllbGRzW2tleV07XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBpZiAoISBpc0VtcHR5KGNsZWFyZWQpKSB7XG4gICAgICBjb3B5LmNsZWFyZWQgPSBjbGVhcmVkO1xuICAgIH1cblxuICAgIGlmIChpc0VtcHR5KGNvcHkuZmllbGRzKSkge1xuICAgICAgZGVsZXRlIGNvcHkuZmllbGRzO1xuICAgIH1cbiAgfVxuXG4gIC8vIGFkanVzdCB0eXBlcyB0byBiYXNpY1xuICBbJ2ZpZWxkcycsICdwYXJhbXMnLCAncmVzdWx0J10uZm9yRWFjaChmaWVsZCA9PiB7XG4gICAgaWYgKGhhc093bi5jYWxsKGNvcHksIGZpZWxkKSkge1xuICAgICAgY29weVtmaWVsZF0gPSBFSlNPTi5fYWRqdXN0VHlwZXNUb0pTT05WYWx1ZShjb3B5W2ZpZWxkXSk7XG4gICAgfVxuICB9KTtcblxuICBpZiAobXNnLmlkICYmIHR5cGVvZiBtc2cuaWQgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTWVzc2FnZSBpZCBpcyBub3QgYSBzdHJpbmdcIik7XG4gIH1cblxuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoY29weSk7XG59O1xuIiwiLy8gSW5zdGFuY2UgbmFtZSBpcyB0aGlzIGJlY2F1c2UgaXQgaXMgdXN1YWxseSByZWZlcnJlZCB0byBhcyB0aGlzIGluc2lkZSBhXG4vLyBtZXRob2QgZGVmaW5pdGlvblxuLyoqXG4gKiBAc3VtbWFyeSBUaGUgc3RhdGUgZm9yIGEgc2luZ2xlIGludm9jYXRpb24gb2YgYSBtZXRob2QsIHJlZmVyZW5jZWQgYnkgdGhpc1xuICogaW5zaWRlIGEgbWV0aG9kIGRlZmluaXRpb24uXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICogQGluc3RhbmNlTmFtZSB0aGlzXG4gKiBAc2hvd0luc3RhbmNlTmFtZSB0cnVlXG4gKi9cbkREUENvbW1vbi5NZXRob2RJbnZvY2F0aW9uID0gY2xhc3MgTWV0aG9kSW52b2NhdGlvbiB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAvLyB0cnVlIGlmIHdlJ3JlIHJ1bm5pbmcgbm90IHRoZSBhY3R1YWwgbWV0aG9kLCBidXQgYSBzdHViICh0aGF0IGlzLFxuICAgIC8vIGlmIHdlJ3JlIG9uIGEgY2xpZW50ICh3aGljaCBtYXkgYmUgYSBicm93c2VyLCBvciBpbiB0aGUgZnV0dXJlIGFcbiAgICAvLyBzZXJ2ZXIgY29ubmVjdGluZyB0byBhbm90aGVyIHNlcnZlcikgYW5kIHByZXNlbnRseSBydW5uaW5nIGFcbiAgICAvLyBzaW11bGF0aW9uIG9mIGEgc2VydmVyLXNpZGUgbWV0aG9kIGZvciBsYXRlbmN5IGNvbXBlbnNhdGlvblxuICAgIC8vIHB1cnBvc2VzKS4gbm90IGN1cnJlbnRseSB0cnVlIGV4Y2VwdCBpbiBhIGNsaWVudCBzdWNoIGFzIGEgYnJvd3NlcixcbiAgICAvLyBzaW5jZSB0aGVyZSdzIHVzdWFsbHkgbm8gcG9pbnQgaW4gcnVubmluZyBzdHVicyB1bmxlc3MgeW91IGhhdmUgYVxuICAgIC8vIHplcm8tbGF0ZW5jeSBjb25uZWN0aW9uIHRvIHRoZSB1c2VyLlxuXG4gICAgLyoqXG4gICAgICogQHN1bW1hcnkgQWNjZXNzIGluc2lkZSBhIG1ldGhvZCBpbnZvY2F0aW9uLiAgQm9vbGVhbiB2YWx1ZSwgdHJ1ZSBpZiB0aGlzIGludm9jYXRpb24gaXMgYSBzdHViLlxuICAgICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgICAqIEBuYW1lICBpc1NpbXVsYXRpb25cbiAgICAgKiBAbWVtYmVyT2YgRERQQ29tbW9uLk1ldGhvZEludm9jYXRpb25cbiAgICAgKiBAaW5zdGFuY2VcbiAgICAgKiBAdHlwZSB7Qm9vbGVhbn1cbiAgICAgKi9cbiAgICB0aGlzLmlzU2ltdWxhdGlvbiA9IG9wdGlvbnMuaXNTaW11bGF0aW9uO1xuXG4gICAgLy8gY2FsbCB0aGlzIGZ1bmN0aW9uIHRvIGFsbG93IG90aGVyIG1ldGhvZCBpbnZvY2F0aW9ucyAoZnJvbSB0aGVcbiAgICAvLyBzYW1lIGNsaWVudCkgdG8gY29udGludWUgcnVubmluZyB3aXRob3V0IHdhaXRpbmcgZm9yIHRoaXMgb25lIHRvXG4gICAgLy8gY29tcGxldGUuXG4gICAgdGhpcy5fdW5ibG9jayA9IG9wdGlvbnMudW5ibG9jayB8fCBmdW5jdGlvbiAoKSB7fTtcbiAgICB0aGlzLl9jYWxsZWRVbmJsb2NrID0gZmFsc2U7XG5cbiAgICAvLyB1c2VkIHRvIGtub3cgd2hlbiB0aGUgZnVuY3Rpb24gYXBwbHkgd2FzIGNhbGxlZCBieSBjYWxsQXN5bmNcbiAgICB0aGlzLl9pc0Zyb21DYWxsQXN5bmMgPSBvcHRpb25zLmlzRnJvbUNhbGxBc3luYztcblxuICAgIC8vIGN1cnJlbnQgdXNlciBpZFxuXG4gICAgLyoqXG4gICAgICogQHN1bW1hcnkgVGhlIGlkIG9mIHRoZSB1c2VyIHRoYXQgbWFkZSB0aGlzIG1ldGhvZCBjYWxsLCBvciBgbnVsbGAgaWYgbm8gdXNlciB3YXMgbG9nZ2VkIGluLlxuICAgICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgICAqIEBuYW1lICB1c2VySWRcbiAgICAgKiBAbWVtYmVyT2YgRERQQ29tbW9uLk1ldGhvZEludm9jYXRpb25cbiAgICAgKiBAaW5zdGFuY2VcbiAgICAgKi9cbiAgICB0aGlzLnVzZXJJZCA9IG9wdGlvbnMudXNlcklkO1xuXG4gICAgLy8gc2V0cyBjdXJyZW50IHVzZXIgaWQgaW4gYWxsIGFwcHJvcHJpYXRlIHNlcnZlciBjb250ZXh0cyBhbmRcbiAgICAvLyByZXJ1bnMgc3Vic2NyaXB0aW9uc1xuICAgIHRoaXMuX3NldFVzZXJJZCA9IG9wdGlvbnMuc2V0VXNlcklkIHx8IGZ1bmN0aW9uICgpIHt9O1xuXG4gICAgLy8gT24gdGhlIHNlcnZlciwgdGhlIGNvbm5lY3Rpb24gdGhpcyBtZXRob2QgY2FsbCBjYW1lIGluIG9uLlxuXG4gICAgLyoqXG4gICAgICogQHN1bW1hcnkgQWNjZXNzIGluc2lkZSBhIG1ldGhvZCBpbnZvY2F0aW9uLiBUaGUgW2Nvbm5lY3Rpb25dKCNtZXRlb3Jfb25jb25uZWN0aW9uKSB0aGF0IHRoaXMgbWV0aG9kIHdhcyByZWNlaXZlZCBvbi4gYG51bGxgIGlmIHRoZSBtZXRob2QgaXMgbm90IGFzc29jaWF0ZWQgd2l0aCBhIGNvbm5lY3Rpb24sIGVnLiBhIHNlcnZlciBpbml0aWF0ZWQgbWV0aG9kIGNhbGwuIENhbGxzIHRvIG1ldGhvZHMgbWFkZSBmcm9tIGEgc2VydmVyIG1ldGhvZCB3aGljaCB3YXMgaW4gdHVybiBpbml0aWF0ZWQgZnJvbSB0aGUgY2xpZW50IHNoYXJlIHRoZSBzYW1lIGBjb25uZWN0aW9uYC5cbiAgICAgKiBAbG9jdXMgU2VydmVyXG4gICAgICogQG5hbWUgIGNvbm5lY3Rpb25cbiAgICAgKiBAbWVtYmVyT2YgRERQQ29tbW9uLk1ldGhvZEludm9jYXRpb25cbiAgICAgKiBAaW5zdGFuY2VcbiAgICAgKi9cbiAgICB0aGlzLmNvbm5lY3Rpb24gPSBvcHRpb25zLmNvbm5lY3Rpb247XG5cbiAgICAvLyBUaGUgc2VlZCBmb3IgcmFuZG9tU3RyZWFtIHZhbHVlIGdlbmVyYXRpb25cbiAgICB0aGlzLnJhbmRvbVNlZWQgPSBvcHRpb25zLnJhbmRvbVNlZWQ7XG5cbiAgICAvLyBUaGlzIGlzIHNldCBieSBSYW5kb21TdHJlYW0uZ2V0OyBhbmQgaG9sZHMgdGhlIHJhbmRvbSBzdHJlYW0gc3RhdGVcbiAgICB0aGlzLnJhbmRvbVN0cmVhbSA9IG51bGw7XG4gIH1cblxuICAvKipcbiAgICogQHN1bW1hcnkgQ2FsbCBpbnNpZGUgYSBtZXRob2QgaW52b2NhdGlvbi4gIEFsbG93IHN1YnNlcXVlbnQgbWV0aG9kIGZyb20gdGhpcyBjbGllbnQgdG8gYmVnaW4gcnVubmluZyBpbiBhIG5ldyBmaWJlci5cbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRERQQ29tbW9uLk1ldGhvZEludm9jYXRpb25cbiAgICogQGluc3RhbmNlXG4gICAqL1xuICB1bmJsb2NrKCkge1xuICAgIHRoaXMuX2NhbGxlZFVuYmxvY2sgPSB0cnVlO1xuICAgIHRoaXMuX3VuYmxvY2soKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBTZXQgdGhlIGxvZ2dlZCBpbiB1c2VyLlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBERFBDb21tb24uTWV0aG9kSW52b2NhdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtTdHJpbmcgfCBudWxsfSB1c2VySWQgVGhlIHZhbHVlIHRoYXQgc2hvdWxkIGJlIHJldHVybmVkIGJ5IGB1c2VySWRgIG9uIHRoaXMgY29ubmVjdGlvbi5cbiAgICovXG4gIHNldFVzZXJJZCh1c2VySWQpIHtcbiAgICBpZiAodGhpcy5fY2FsbGVkVW5ibG9jaykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ2FuJ3QgY2FsbCBzZXRVc2VySWQgaW4gYSBtZXRob2QgYWZ0ZXIgY2FsbGluZyB1bmJsb2NrXCIpO1xuICAgIH1cbiAgICB0aGlzLnVzZXJJZCA9IHVzZXJJZDtcbiAgICB0aGlzLl9zZXRVc2VySWQodXNlcklkKTtcbiAgfVxufTtcbiIsIi8vIFJhbmRvbVN0cmVhbSBhbGxvd3MgZm9yIGdlbmVyYXRpb24gb2YgcHNldWRvLXJhbmRvbSB2YWx1ZXMsIGZyb20gYSBzZWVkLlxuLy9cbi8vIFdlIHVzZSB0aGlzIGZvciBjb25zaXN0ZW50ICdyYW5kb20nIG51bWJlcnMgYWNyb3NzIHRoZSBjbGllbnQgYW5kIHNlcnZlci5cbi8vIFdlIHdhbnQgdG8gZ2VuZXJhdGUgcHJvYmFibHktdW5pcXVlIElEcyBvbiB0aGUgY2xpZW50LCBhbmQgd2UgaWRlYWxseSB3YW50XG4vLyB0aGUgc2VydmVyIHRvIGdlbmVyYXRlIHRoZSBzYW1lIElEcyB3aGVuIGl0IGV4ZWN1dGVzIHRoZSBtZXRob2QuXG4vL1xuLy8gRm9yIGdlbmVyYXRlZCB2YWx1ZXMgdG8gYmUgdGhlIHNhbWUsIHdlIG11c3Qgc2VlZCBvdXJzZWx2ZXMgdGhlIHNhbWUgd2F5LFxuLy8gYW5kIHdlIG11c3Qga2VlcCB0cmFjayBvZiB0aGUgY3VycmVudCBzdGF0ZSBvZiBvdXIgcHNldWRvLXJhbmRvbSBnZW5lcmF0b3JzLlxuLy8gV2UgY2FsbCB0aGlzIHN0YXRlIHRoZSBzY29wZS4gQnkgZGVmYXVsdCwgd2UgdXNlIHRoZSBjdXJyZW50IEREUCBtZXRob2Rcbi8vIGludm9jYXRpb24gYXMgb3VyIHNjb3BlLiAgRERQIG5vdyBhbGxvd3MgdGhlIGNsaWVudCB0byBzcGVjaWZ5IGEgcmFuZG9tU2VlZC5cbi8vIElmIGEgcmFuZG9tU2VlZCBpcyBwcm92aWRlZCBpdCB3aWxsIGJlIHVzZWQgdG8gc2VlZCBvdXIgcmFuZG9tIHNlcXVlbmNlcy5cbi8vIEluIHRoaXMgd2F5LCBjbGllbnQgYW5kIHNlcnZlciBtZXRob2QgY2FsbHMgd2lsbCBnZW5lcmF0ZSB0aGUgc2FtZSB2YWx1ZXMuXG4vL1xuLy8gV2UgZXhwb3NlIG11bHRpcGxlIG5hbWVkIHN0cmVhbXM7IGVhY2ggc3RyZWFtIGlzIGluZGVwZW5kZW50XG4vLyBhbmQgaXMgc2VlZGVkIGRpZmZlcmVudGx5IChidXQgcHJlZGljdGFibHkgZnJvbSB0aGUgbmFtZSkuXG4vLyBCeSB1c2luZyBtdWx0aXBsZSBzdHJlYW1zLCB3ZSBzdXBwb3J0IHJlb3JkZXJpbmcgb2YgcmVxdWVzdHMsXG4vLyBhcyBsb25nIGFzIHRoZXkgb2NjdXIgb24gZGlmZmVyZW50IHN0cmVhbXMuXG4vL1xuLy8gQHBhcmFtIG9wdGlvbnMge09wdGlvbmFsIE9iamVjdH1cbi8vICAgc2VlZDogQXJyYXkgb3IgdmFsdWUgLSBTZWVkIHZhbHVlKHMpIGZvciB0aGUgZ2VuZXJhdG9yLlxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgIElmIGFuIGFycmF5LCB3aWxsIGJlIHVzZWQgYXMtaXNcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICBJZiBhIHZhbHVlLCB3aWxsIGJlIGNvbnZlcnRlZCB0byBhIHNpbmdsZS12YWx1ZSBhcnJheVxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgIElmIG9taXR0ZWQsIGEgcmFuZG9tIGFycmF5IHdpbGwgYmUgdXNlZCBhcyB0aGUgc2VlZC5cbkREUENvbW1vbi5SYW5kb21TdHJlYW0gPSBjbGFzcyBSYW5kb21TdHJlYW0ge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgdGhpcy5zZWVkID0gW10uY29uY2F0KG9wdGlvbnMuc2VlZCB8fCByYW5kb21Ub2tlbigpKTtcbiAgICB0aGlzLnNlcXVlbmNlcyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIH1cblxuICAvLyBHZXQgYSByYW5kb20gc2VxdWVuY2Ugd2l0aCB0aGUgc3BlY2lmaWVkIG5hbWUsIGNyZWF0aW5nIGl0IGlmIGRvZXMgbm90IGV4aXN0LlxuICAvLyBOZXcgc2VxdWVuY2VzIGFyZSBzZWVkZWQgd2l0aCB0aGUgc2VlZCBjb25jYXRlbmF0ZWQgd2l0aCB0aGUgbmFtZS5cbiAgLy8gQnkgcGFzc2luZyBhIHNlZWQgaW50byBSYW5kb20uY3JlYXRlLCB3ZSB1c2UgdGhlIEFsZWEgZ2VuZXJhdG9yLlxuICBfc2VxdWVuY2UobmFtZSkge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIHZhciBzZXF1ZW5jZSA9IHNlbGYuc2VxdWVuY2VzW25hbWVdIHx8IG51bGw7XG4gICAgaWYgKHNlcXVlbmNlID09PSBudWxsKSB7XG4gICAgICB2YXIgc2VxdWVuY2VTZWVkID0gc2VsZi5zZWVkLmNvbmNhdChuYW1lKTtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2VxdWVuY2VTZWVkLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmICh0eXBlb2Ygc2VxdWVuY2VTZWVkW2ldID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICBzZXF1ZW5jZVNlZWRbaV0gPSBzZXF1ZW5jZVNlZWRbaV0oKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgc2VsZi5zZXF1ZW5jZXNbbmFtZV0gPSBzZXF1ZW5jZSA9IFJhbmRvbS5jcmVhdGVXaXRoU2VlZHMuYXBwbHkobnVsbCwgc2VxdWVuY2VTZWVkKTtcbiAgICB9XG4gICAgcmV0dXJuIHNlcXVlbmNlO1xuICB9XG59O1xuXG4vLyBSZXR1cm5zIGEgcmFuZG9tIHN0cmluZyBvZiBzdWZmaWNpZW50IGxlbmd0aCBmb3IgYSByYW5kb20gc2VlZC5cbi8vIFRoaXMgaXMgYSBwbGFjZWhvbGRlciBmdW5jdGlvbjsgYSBzaW1pbGFyIGZ1bmN0aW9uIGlzIHBsYW5uZWRcbi8vIGZvciBSYW5kb20gaXRzZWxmOyB3aGVuIHRoYXQgaXMgYWRkZWQgd2Ugc2hvdWxkIHJlbW92ZSB0aGlzIGZ1bmN0aW9uLFxuLy8gYW5kIGNhbGwgUmFuZG9tJ3MgcmFuZG9tVG9rZW4gaW5zdGVhZC5cbmZ1bmN0aW9uIHJhbmRvbVRva2VuKCkge1xuICByZXR1cm4gUmFuZG9tLmhleFN0cmluZygyMCk7XG59O1xuXG4vLyBSZXR1cm5zIHRoZSByYW5kb20gc3RyZWFtIHdpdGggdGhlIHNwZWNpZmllZCBuYW1lLCBpbiB0aGUgc3BlY2lmaWVkXG4vLyBzY29wZS4gSWYgYSBzY29wZSBpcyBwYXNzZWQsIHRoZW4gd2UgdXNlIHRoYXQgdG8gc2VlZCBhIChub3Rcbi8vIGNyeXB0b2dyYXBoaWNhbGx5IHNlY3VyZSkgUFJORyB1c2luZyB0aGUgZmFzdCBBbGVhIGFsZ29yaXRobS4gIElmXG4vLyBzY29wZSBpcyBudWxsIChvciBvdGhlcndpc2UgZmFsc2V5KSB0aGVuIHdlIHVzZSBhIGdlbmVyYXRlZCBzZWVkLlxuLy9cbi8vIEhvd2V2ZXIsIHNjb3BlIHdpbGwgbm9ybWFsbHkgYmUgdGhlIGN1cnJlbnQgRERQIG1ldGhvZCBpbnZvY2F0aW9uLFxuLy8gc28gd2UnbGwgdXNlIHRoZSBzdHJlYW0gd2l0aCB0aGUgc3BlY2lmaWVkIG5hbWUsIGFuZCB3ZSBzaG91bGQgZ2V0XG4vLyBjb25zaXN0ZW50IHZhbHVlcyBvbiB0aGUgY2xpZW50IGFuZCBzZXJ2ZXIgc2lkZXMgb2YgYSBtZXRob2QgY2FsbC5cbkREUENvbW1vbi5SYW5kb21TdHJlYW0uZ2V0ID0gZnVuY3Rpb24gKHNjb3BlLCBuYW1lKSB7XG4gIGlmICghbmFtZSkge1xuICAgIG5hbWUgPSBcImRlZmF1bHRcIjtcbiAgfVxuICBpZiAoIXNjb3BlKSB7XG4gICAgLy8gVGhlcmUgd2FzIG5vIHNjb3BlIHBhc3NlZCBpbjsgdGhlIHNlcXVlbmNlIHdvbid0IGFjdHVhbGx5IGJlXG4gICAgLy8gcmVwcm9kdWNpYmxlLiBidXQgbWFrZSBpdCBmYXN0IChhbmQgbm90IGNyeXB0b2dyYXBoaWNhbGx5XG4gICAgLy8gc2VjdXJlKSBhbnl3YXlzLCBzbyB0aGF0IHRoZSBiZWhhdmlvciBpcyBzaW1pbGFyIHRvIHdoYXQgeW91J2RcbiAgICAvLyBnZXQgYnkgcGFzc2luZyBpbiBhIHNjb3BlLlxuICAgIHJldHVybiBSYW5kb20uaW5zZWN1cmU7XG4gIH1cbiAgdmFyIHJhbmRvbVN0cmVhbSA9IHNjb3BlLnJhbmRvbVN0cmVhbTtcbiAgaWYgKCFyYW5kb21TdHJlYW0pIHtcbiAgICBzY29wZS5yYW5kb21TdHJlYW0gPSByYW5kb21TdHJlYW0gPSBuZXcgRERQQ29tbW9uLlJhbmRvbVN0cmVhbSh7XG4gICAgICBzZWVkOiBzY29wZS5yYW5kb21TZWVkXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHJhbmRvbVN0cmVhbS5fc2VxdWVuY2UobmFtZSk7XG59O1xuXG4vLyBDcmVhdGVzIGEgcmFuZG9tU2VlZCBmb3IgcGFzc2luZyB0byBhIG1ldGhvZCBjYWxsLlxuLy8gTm90ZSB0aGF0IHdlIHRha2UgZW5jbG9zaW5nIGFzIGFuIGFyZ3VtZW50LFxuLy8gdGhvdWdoIHdlIGV4cGVjdCBpdCB0byBiZSBERFAuX0N1cnJlbnRNZXRob2RJbnZvY2F0aW9uLmdldCgpXG4vLyBIb3dldmVyLCB3ZSBvZnRlbiBldmFsdWF0ZSBtYWtlUnBjU2VlZCBsYXppbHksIGFuZCB0aHVzIHRoZSByZWxldmFudFxuLy8gaW52b2NhdGlvbiBtYXkgbm90IGJlIHRoZSBvbmUgY3VycmVudGx5IGluIHNjb3BlLlxuLy8gSWYgZW5jbG9zaW5nIGlzIG51bGwsIHdlJ2xsIHVzZSBSYW5kb20gYW5kIHZhbHVlcyB3b24ndCBiZSByZXBlYXRhYmxlLlxuRERQQ29tbW9uLm1ha2VScGNTZWVkID0gZnVuY3Rpb24gKGVuY2xvc2luZywgbWV0aG9kTmFtZSkge1xuICB2YXIgc3RyZWFtID0gRERQQ29tbW9uLlJhbmRvbVN0cmVhbS5nZXQoZW5jbG9zaW5nLCAnL3JwYy8nICsgbWV0aG9kTmFtZSk7XG4gIHJldHVybiBzdHJlYW0uaGV4U3RyaW5nKDIwKTtcbn07XG4iXX0=
