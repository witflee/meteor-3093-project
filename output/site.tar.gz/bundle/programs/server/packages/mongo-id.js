(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EJSON = Package.ejson.EJSON;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var hexString, MongoID;

var require = meteorInstall({"node_modules":{"meteor":{"mongo-id":{"id.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/mongo-id/id.js                                                                   //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  MongoID: () => MongoID
});
let EJSON;
module.link("meteor/ejson", {
  EJSON(v) {
    EJSON = v;
  }
}, 0);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }
}, 1);
const MongoID = {};
MongoID._looksLikeObjectID = str => str.length === 24 && /^[0-9a-f]*$/.test(str);
MongoID.ObjectID = class ObjectID {
  constructor(hexString) {
    //random-based impl of Mongo ObjectID
    if (hexString) {
      hexString = hexString.toLowerCase();
      if (!MongoID._looksLikeObjectID(hexString)) {
        throw new Error('Invalid hexadecimal string for creating an ObjectID');
      }
      // meant to work with _.isEqual(), which relies on structural equality
      this._str = hexString;
    } else {
      this._str = Random.hexString(24);
    }
  }
  equals(other) {
    return other instanceof MongoID.ObjectID && this.valueOf() === other.valueOf();
  }
  toString() {
    return "ObjectID(\"".concat(this._str, "\")");
  }
  clone() {
    return new MongoID.ObjectID(this._str);
  }
  typeName() {
    return 'oid';
  }
  getTimestamp() {
    return Number.parseInt(this._str.substr(0, 8), 16);
  }
  valueOf() {
    return this._str;
  }
  toJSONValue() {
    return this.valueOf();
  }
  toHexString() {
    return this.valueOf();
  }
};
EJSON.addType('oid', str => new MongoID.ObjectID(str));
MongoID.idStringify = id => {
  if (id instanceof MongoID.ObjectID) {
    return id.valueOf();
  } else if (typeof id === 'string') {
    var firstChar = id.charAt(0);
    if (id === '') {
      return id;
    } else if (firstChar === '-' ||
    // escape previously dashed strings
    firstChar === '~' ||
    // escape escaped numbers, true, false
    MongoID._looksLikeObjectID(id) ||
    // escape object-id-form strings
    firstChar === '{') {
      // escape object-form strings, for maybe implementing later
      return "-".concat(id);
    } else {
      return id; // other strings go through unchanged.
    }
  } else if (id === undefined) {
    return '-';
  } else if (typeof id === 'object' && id !== null) {
    throw new Error('Meteor does not currently support objects other than ObjectID as ids');
  } else {
    // Numbers, true, false, null
    return "~".concat(JSON.stringify(id));
  }
};
MongoID.idParse = id => {
  var firstChar = id.charAt(0);
  if (id === '') {
    return id;
  } else if (id === '-') {
    return undefined;
  } else if (firstChar === '-') {
    return id.substr(1);
  } else if (firstChar === '~') {
    return JSON.parse(id.substr(1));
  } else if (MongoID._looksLikeObjectID(id)) {
    return new MongoID.ObjectID(id);
  } else {
    return id;
  }
};
///////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/mongo-id/id.js");

/* Exports */
Package._define("mongo-id", exports, {
  MongoID: MongoID
});

})();

//# sourceURL=meteor://💻app/packages/mongo-id.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28taWQvaWQuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiTW9uZ29JRCIsIkVKU09OIiwibGluayIsInYiLCJSYW5kb20iLCJfbG9va3NMaWtlT2JqZWN0SUQiLCJzdHIiLCJsZW5ndGgiLCJ0ZXN0IiwiT2JqZWN0SUQiLCJjb25zdHJ1Y3RvciIsImhleFN0cmluZyIsInRvTG93ZXJDYXNlIiwiRXJyb3IiLCJfc3RyIiwiZXF1YWxzIiwib3RoZXIiLCJ2YWx1ZU9mIiwidG9TdHJpbmciLCJjb25jYXQiLCJjbG9uZSIsInR5cGVOYW1lIiwiZ2V0VGltZXN0YW1wIiwiTnVtYmVyIiwicGFyc2VJbnQiLCJzdWJzdHIiLCJ0b0pTT05WYWx1ZSIsInRvSGV4U3RyaW5nIiwiYWRkVHlwZSIsImlkU3RyaW5naWZ5IiwiaWQiLCJmaXJzdENoYXIiLCJjaGFyQXQiLCJ1bmRlZmluZWQiLCJKU09OIiwic3RyaW5naWZ5IiwiaWRQYXJzZSIsInBhcnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE1BQU0sQ0FBQztFQUFDQyxPQUFPLEVBQUNBLENBQUEsS0FBSUE7QUFBTyxDQUFDLENBQUM7QUFBQyxJQUFJQyxLQUFLO0FBQUNILE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDRCxLQUFLQSxDQUFDRSxDQUFDLEVBQUM7SUFBQ0YsS0FBSyxHQUFDRSxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUMsTUFBTTtBQUFDTixNQUFNLENBQUNJLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0UsTUFBTUEsQ0FBQ0QsQ0FBQyxFQUFDO0lBQUNDLE1BQU0sR0FBQ0QsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUdoSyxNQUFNSCxPQUFPLEdBQUcsQ0FBQyxDQUFDO0FBRWxCQSxPQUFPLENBQUNLLGtCQUFrQixHQUFHQyxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsTUFBTSxLQUFLLEVBQUUsSUFBSSxhQUFhLENBQUNDLElBQUksQ0FBQ0YsR0FBRyxDQUFDO0FBRWhGTixPQUFPLENBQUNTLFFBQVEsR0FBRyxNQUFNQSxRQUFRLENBQUM7RUFDaENDLFdBQVdBLENBQUVDLFNBQVMsRUFBRTtJQUN0QjtJQUNBLElBQUlBLFNBQVMsRUFBRTtNQUNiQSxTQUFTLEdBQUdBLFNBQVMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7TUFDbkMsSUFBSSxDQUFDWixPQUFPLENBQUNLLGtCQUFrQixDQUFDTSxTQUFTLENBQUMsRUFBRTtRQUMxQyxNQUFNLElBQUlFLEtBQUssQ0FBQyxxREFBcUQsQ0FBQztNQUN4RTtNQUNBO01BQ0EsSUFBSSxDQUFDQyxJQUFJLEdBQUdILFNBQVM7SUFDdkIsQ0FBQyxNQUFNO01BQ0wsSUFBSSxDQUFDRyxJQUFJLEdBQUdWLE1BQU0sQ0FBQ08sU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUNsQztFQUNGO0VBRUFJLE1BQU1BLENBQUNDLEtBQUssRUFBRTtJQUNaLE9BQU9BLEtBQUssWUFBWWhCLE9BQU8sQ0FBQ1MsUUFBUSxJQUN4QyxJQUFJLENBQUNRLE9BQU8sQ0FBQyxDQUFDLEtBQUtELEtBQUssQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDcEM7RUFFQUMsUUFBUUEsQ0FBQSxFQUFHO0lBQ1QscUJBQUFDLE1BQUEsQ0FBb0IsSUFBSSxDQUFDTCxJQUFJO0VBQy9CO0VBRUFNLEtBQUtBLENBQUEsRUFBRztJQUNOLE9BQU8sSUFBSXBCLE9BQU8sQ0FBQ1MsUUFBUSxDQUFDLElBQUksQ0FBQ0ssSUFBSSxDQUFDO0VBQ3hDO0VBRUFPLFFBQVFBLENBQUEsRUFBRztJQUNULE9BQU8sS0FBSztFQUNkO0VBRUFDLFlBQVlBLENBQUEsRUFBRztJQUNiLE9BQU9DLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDLElBQUksQ0FBQ1YsSUFBSSxDQUFDVyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNwRDtFQUVBUixPQUFPQSxDQUFBLEVBQUc7SUFDUixPQUFPLElBQUksQ0FBQ0gsSUFBSTtFQUNsQjtFQUVBWSxXQUFXQSxDQUFBLEVBQUc7SUFDWixPQUFPLElBQUksQ0FBQ1QsT0FBTyxDQUFDLENBQUM7RUFDdkI7RUFFQVUsV0FBV0EsQ0FBQSxFQUFHO0lBQ1osT0FBTyxJQUFJLENBQUNWLE9BQU8sQ0FBQyxDQUFDO0VBQ3ZCO0FBRUYsQ0FBQztBQUVEaEIsS0FBSyxDQUFDMkIsT0FBTyxDQUFDLEtBQUssRUFBRXRCLEdBQUcsSUFBSSxJQUFJTixPQUFPLENBQUNTLFFBQVEsQ0FBQ0gsR0FBRyxDQUFDLENBQUM7QUFFdEROLE9BQU8sQ0FBQzZCLFdBQVcsR0FBSUMsRUFBRSxJQUFLO0VBQzVCLElBQUlBLEVBQUUsWUFBWTlCLE9BQU8sQ0FBQ1MsUUFBUSxFQUFFO0lBQ2xDLE9BQU9xQixFQUFFLENBQUNiLE9BQU8sQ0FBQyxDQUFDO0VBQ3JCLENBQUMsTUFBTSxJQUFJLE9BQU9hLEVBQUUsS0FBSyxRQUFRLEVBQUU7SUFDakMsSUFBSUMsU0FBUyxHQUFHRCxFQUFFLENBQUNFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDNUIsSUFBSUYsRUFBRSxLQUFLLEVBQUUsRUFBRTtNQUNiLE9BQU9BLEVBQUU7SUFDWCxDQUFDLE1BQU0sSUFBSUMsU0FBUyxLQUFLLEdBQUc7SUFBSTtJQUNyQkEsU0FBUyxLQUFLLEdBQUc7SUFBSTtJQUNyQi9CLE9BQU8sQ0FBQ0ssa0JBQWtCLENBQUN5QixFQUFFLENBQUM7SUFBSTtJQUNsQ0MsU0FBUyxLQUFLLEdBQUcsRUFBRTtNQUFFO01BQzlCLFdBQUFaLE1BQUEsQ0FBV1csRUFBRTtJQUNmLENBQUMsTUFBTTtNQUNMLE9BQU9BLEVBQUUsQ0FBQyxDQUFDO0lBQ2I7RUFDRixDQUFDLE1BQU0sSUFBSUEsRUFBRSxLQUFLRyxTQUFTLEVBQUU7SUFDM0IsT0FBTyxHQUFHO0VBQ1osQ0FBQyxNQUFNLElBQUksT0FBT0gsRUFBRSxLQUFLLFFBQVEsSUFBSUEsRUFBRSxLQUFLLElBQUksRUFBRTtJQUNoRCxNQUFNLElBQUlqQixLQUFLLENBQUMsc0VBQXNFLENBQUM7RUFDekYsQ0FBQyxNQUFNO0lBQUU7SUFDUCxXQUFBTSxNQUFBLENBQVdlLElBQUksQ0FBQ0MsU0FBUyxDQUFDTCxFQUFFLENBQUM7RUFDL0I7QUFDRixDQUFDO0FBRUQ5QixPQUFPLENBQUNvQyxPQUFPLEdBQUlOLEVBQUUsSUFBSztFQUN4QixJQUFJQyxTQUFTLEdBQUdELEVBQUUsQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUM1QixJQUFJRixFQUFFLEtBQUssRUFBRSxFQUFFO0lBQ2IsT0FBT0EsRUFBRTtFQUNYLENBQUMsTUFBTSxJQUFJQSxFQUFFLEtBQUssR0FBRyxFQUFFO0lBQ3JCLE9BQU9HLFNBQVM7RUFDbEIsQ0FBQyxNQUFNLElBQUlGLFNBQVMsS0FBSyxHQUFHLEVBQUU7SUFDNUIsT0FBT0QsRUFBRSxDQUFDTCxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ3JCLENBQUMsTUFBTSxJQUFJTSxTQUFTLEtBQUssR0FBRyxFQUFFO0lBQzVCLE9BQU9HLElBQUksQ0FBQ0csS0FBSyxDQUFDUCxFQUFFLENBQUNMLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQyxDQUFDLE1BQU0sSUFBSXpCLE9BQU8sQ0FBQ0ssa0JBQWtCLENBQUN5QixFQUFFLENBQUMsRUFBRTtJQUN6QyxPQUFPLElBQUk5QixPQUFPLENBQUNTLFFBQVEsQ0FBQ3FCLEVBQUUsQ0FBQztFQUNqQyxDQUFDLE1BQU07SUFDTCxPQUFPQSxFQUFFO0VBQ1g7QUFDRixDQUFDLEMiLCJmaWxlIjoiL3BhY2thZ2VzL21vbmdvLWlkLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRUpTT04gfSBmcm9tICdtZXRlb3IvZWpzb24nO1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSc7XG5cbmNvbnN0IE1vbmdvSUQgPSB7fTtcblxuTW9uZ29JRC5fbG9va3NMaWtlT2JqZWN0SUQgPSBzdHIgPT4gc3RyLmxlbmd0aCA9PT0gMjQgJiYgL15bMC05YS1mXSokLy50ZXN0KHN0cik7XG5cbk1vbmdvSUQuT2JqZWN0SUQgPSBjbGFzcyBPYmplY3RJRCB7XG4gIGNvbnN0cnVjdG9yIChoZXhTdHJpbmcpIHtcbiAgICAvL3JhbmRvbS1iYXNlZCBpbXBsIG9mIE1vbmdvIE9iamVjdElEXG4gICAgaWYgKGhleFN0cmluZykge1xuICAgICAgaGV4U3RyaW5nID0gaGV4U3RyaW5nLnRvTG93ZXJDYXNlKCk7XG4gICAgICBpZiAoIU1vbmdvSUQuX2xvb2tzTGlrZU9iamVjdElEKGhleFN0cmluZykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIGhleGFkZWNpbWFsIHN0cmluZyBmb3IgY3JlYXRpbmcgYW4gT2JqZWN0SUQnKTtcbiAgICAgIH1cbiAgICAgIC8vIG1lYW50IHRvIHdvcmsgd2l0aCBfLmlzRXF1YWwoKSwgd2hpY2ggcmVsaWVzIG9uIHN0cnVjdHVyYWwgZXF1YWxpdHlcbiAgICAgIHRoaXMuX3N0ciA9IGhleFN0cmluZztcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fc3RyID0gUmFuZG9tLmhleFN0cmluZygyNCk7XG4gICAgfVxuICB9XG5cbiAgZXF1YWxzKG90aGVyKSB7XG4gICAgcmV0dXJuIG90aGVyIGluc3RhbmNlb2YgTW9uZ29JRC5PYmplY3RJRCAmJlxuICAgIHRoaXMudmFsdWVPZigpID09PSBvdGhlci52YWx1ZU9mKCk7XG4gIH1cblxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYE9iamVjdElEKFwiJHt0aGlzLl9zdHJ9XCIpYDtcbiAgfVxuXG4gIGNsb25lKCkge1xuICAgIHJldHVybiBuZXcgTW9uZ29JRC5PYmplY3RJRCh0aGlzLl9zdHIpO1xuICB9XG5cbiAgdHlwZU5hbWUoKSB7XG4gICAgcmV0dXJuICdvaWQnO1xuICB9XG5cbiAgZ2V0VGltZXN0YW1wKCkge1xuICAgIHJldHVybiBOdW1iZXIucGFyc2VJbnQodGhpcy5fc3RyLnN1YnN0cigwLCA4KSwgMTYpO1xuICB9XG5cbiAgdmFsdWVPZigpIHtcbiAgICByZXR1cm4gdGhpcy5fc3RyO1xuICB9XG5cbiAgdG9KU09OVmFsdWUoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWVPZigpO1xuICB9XG5cbiAgdG9IZXhTdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWVPZigpO1xuICB9XG5cbn1cblxuRUpTT04uYWRkVHlwZSgnb2lkJywgc3RyID0+IG5ldyBNb25nb0lELk9iamVjdElEKHN0cikpO1xuXG5Nb25nb0lELmlkU3RyaW5naWZ5ID0gKGlkKSA9PiB7XG4gIGlmIChpZCBpbnN0YW5jZW9mIE1vbmdvSUQuT2JqZWN0SUQpIHtcbiAgICByZXR1cm4gaWQudmFsdWVPZigpO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBpZCA9PT0gJ3N0cmluZycpIHtcbiAgICB2YXIgZmlyc3RDaGFyID0gaWQuY2hhckF0KDApO1xuICAgIGlmIChpZCA9PT0gJycpIHtcbiAgICAgIHJldHVybiBpZDtcbiAgICB9IGVsc2UgaWYgKGZpcnN0Q2hhciA9PT0gJy0nIHx8IC8vIGVzY2FwZSBwcmV2aW91c2x5IGRhc2hlZCBzdHJpbmdzXG4gICAgICAgICAgICAgICBmaXJzdENoYXIgPT09ICd+JyB8fCAvLyBlc2NhcGUgZXNjYXBlZCBudW1iZXJzLCB0cnVlLCBmYWxzZVxuICAgICAgICAgICAgICAgTW9uZ29JRC5fbG9va3NMaWtlT2JqZWN0SUQoaWQpIHx8IC8vIGVzY2FwZSBvYmplY3QtaWQtZm9ybSBzdHJpbmdzXG4gICAgICAgICAgICAgICBmaXJzdENoYXIgPT09ICd7JykgeyAvLyBlc2NhcGUgb2JqZWN0LWZvcm0gc3RyaW5ncywgZm9yIG1heWJlIGltcGxlbWVudGluZyBsYXRlclxuICAgICAgcmV0dXJuIGAtJHtpZH1gO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gaWQ7IC8vIG90aGVyIHN0cmluZ3MgZ28gdGhyb3VnaCB1bmNoYW5nZWQuXG4gICAgfVxuICB9IGVsc2UgaWYgKGlkID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gJy0nO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBpZCA9PT0gJ29iamVjdCcgJiYgaWQgIT09IG51bGwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ01ldGVvciBkb2VzIG5vdCBjdXJyZW50bHkgc3VwcG9ydCBvYmplY3RzIG90aGVyIHRoYW4gT2JqZWN0SUQgYXMgaWRzJyk7XG4gIH0gZWxzZSB7IC8vIE51bWJlcnMsIHRydWUsIGZhbHNlLCBudWxsXG4gICAgcmV0dXJuIGB+JHtKU09OLnN0cmluZ2lmeShpZCl9YDtcbiAgfVxufTtcblxuTW9uZ29JRC5pZFBhcnNlID0gKGlkKSA9PiB7XG4gIHZhciBmaXJzdENoYXIgPSBpZC5jaGFyQXQoMCk7XG4gIGlmIChpZCA9PT0gJycpIHtcbiAgICByZXR1cm4gaWQ7XG4gIH0gZWxzZSBpZiAoaWQgPT09ICctJykge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH0gZWxzZSBpZiAoZmlyc3RDaGFyID09PSAnLScpIHtcbiAgICByZXR1cm4gaWQuc3Vic3RyKDEpO1xuICB9IGVsc2UgaWYgKGZpcnN0Q2hhciA9PT0gJ34nKSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UoaWQuc3Vic3RyKDEpKTtcbiAgfSBlbHNlIGlmIChNb25nb0lELl9sb29rc0xpa2VPYmplY3RJRChpZCkpIHtcbiAgICByZXR1cm4gbmV3IE1vbmdvSUQuT2JqZWN0SUQoaWQpO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBpZDtcbiAgfVxufTtcblxuZXhwb3J0IHsgTW9uZ29JRCB9O1xuIl19
