(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var NpmModuleMongodb = Package['npm-mongo'].NpmModuleMongodb;
var NpmModuleMongodbVersion = Package['npm-mongo'].NpmModuleMongodbVersion;
var AllowDeny = Package['allow-deny'].AllowDeny;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var DiffSequence = Package['diff-sequence'].DiffSequence;
var MongoID = Package['mongo-id'].MongoID;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var Log = Package.logging.Log;
var Decimal = Package['mongo-decimal'].Decimal;
var _ = Package.underscore._;
var MaxHeap = Package['binary-heap'].MaxHeap;
var MinHeap = Package['binary-heap'].MinHeap;
var MinMaxHeap = Package['binary-heap'].MinMaxHeap;
var Hook = Package['callback-hook'].Hook;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var MongoInternals, MongoConnection, CursorDescription, Cursor, listenAll, forEachTrigger, OPLOG_COLLECTION, idForOp, OplogHandle, ObserveMultiplexer, ObserveHandle, PollingObserveDriver, OplogObserveDriver, Mongo, _ref, field, value, selector, callback, options;

var require = meteorInstall({"node_modules":{"meteor":{"mongo":{"mongo_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/mongo_driver.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!function (module1) {
  let _objectSpread;
  module1.link("@babel/runtime/helpers/objectSpread2", {
    default(v) {
      _objectSpread = v;
    }
  }, 0);
  let normalizeProjection;
  module1.link("./mongo_utils", {
    normalizeProjection(v) {
      normalizeProjection = v;
    }
  }, 0);
  let DocFetcher;
  module1.link("./doc_fetcher.js", {
    DocFetcher(v) {
      DocFetcher = v;
    }
  }, 1);
  let ASYNC_CURSOR_METHODS, getAsyncMethodName;
  module1.link("meteor/minimongo/constants", {
    ASYNC_CURSOR_METHODS(v) {
      ASYNC_CURSOR_METHODS = v;
    },
    getAsyncMethodName(v) {
      getAsyncMethodName = v;
    }
  }, 2);
  /**
   * Provide a synchronous Collection API using fibers, backed by
   * MongoDB.  This is only for use on the server, and mostly identical
   * to the client API.
   *
   * NOTE: the public API methods must be run within a fiber. If you call
   * these outside of a fiber they will explode!
   */

  const path = require("path");
  const util = require("util");

  /** @type {import('mongodb')} */
  var MongoDB = NpmModuleMongodb;
  var Future = Npm.require('fibers/future');
  MongoInternals = {};
  MongoInternals.NpmModules = {
    mongodb: {
      version: NpmModuleMongodbVersion,
      module: MongoDB
    }
  };

  // Older version of what is now available via
  // MongoInternals.NpmModules.mongodb.module.  It was never documented, but
  // people do use it.
  // XXX COMPAT WITH 1.0.3.2
  MongoInternals.NpmModule = MongoDB;
  const FILE_ASSET_SUFFIX = 'Asset';
  const ASSETS_FOLDER = 'assets';
  const APP_FOLDER = 'app';

  // This is used to add or remove EJSON from the beginning of everything nested
  // inside an EJSON custom type. It should only be called on pure JSON!
  var replaceNames = function (filter, thing) {
    if (typeof thing === "object" && thing !== null) {
      if (_.isArray(thing)) {
        return _.map(thing, _.bind(replaceNames, null, filter));
      }
      var ret = {};
      _.each(thing, function (value, key) {
        ret[filter(key)] = replaceNames(filter, value);
      });
      return ret;
    }
    return thing;
  };

  // Ensure that EJSON.clone keeps a Timestamp as a Timestamp (instead of just
  // doing a structural clone).
  // XXX how ok is this? what if there are multiple copies of MongoDB loaded?
  MongoDB.Timestamp.prototype.clone = function () {
    // Timestamps should be immutable.
    return this;
  };
  var makeMongoLegal = function (name) {
    return "EJSON" + name;
  };
  var unmakeMongoLegal = function (name) {
    return name.substr(5);
  };
  var replaceMongoAtomWithMeteor = function (document) {
    if (document instanceof MongoDB.Binary) {
      // for backwards compatibility
      if (document.sub_type !== 0) {
        return document;
      }
      var buffer = document.value(true);
      return new Uint8Array(buffer);
    }
    if (document instanceof MongoDB.ObjectID) {
      return new Mongo.ObjectID(document.toHexString());
    }
    if (document instanceof MongoDB.Decimal128) {
      return Decimal(document.toString());
    }
    if (document["EJSON$type"] && document["EJSON$value"] && _.size(document) === 2) {
      return EJSON.fromJSONValue(replaceNames(unmakeMongoLegal, document));
    }
    if (document instanceof MongoDB.Timestamp) {
      // For now, the Meteor representation of a Mongo timestamp type (not a date!
      // this is a weird internal thing used in the oplog!) is the same as the
      // Mongo representation. We need to do this explicitly or else we would do a
      // structural clone and lose the prototype.
      return document;
    }
    return undefined;
  };
  var replaceMeteorAtomWithMongo = function (document) {
    if (EJSON.isBinary(document)) {
      // This does more copies than we'd like, but is necessary because
      // MongoDB.BSON only looks like it takes a Uint8Array (and doesn't actually
      // serialize it correctly).
      return new MongoDB.Binary(Buffer.from(document));
    }
    if (document instanceof MongoDB.Binary) {
      return document;
    }
    if (document instanceof Mongo.ObjectID) {
      return new MongoDB.ObjectID(document.toHexString());
    }
    if (document instanceof MongoDB.Timestamp) {
      // For now, the Meteor representation of a Mongo timestamp type (not a date!
      // this is a weird internal thing used in the oplog!) is the same as the
      // Mongo representation. We need to do this explicitly or else we would do a
      // structural clone and lose the prototype.
      return document;
    }
    if (document instanceof Decimal) {
      return MongoDB.Decimal128.fromString(document.toString());
    }
    if (EJSON._isCustomType(document)) {
      return replaceNames(makeMongoLegal, EJSON.toJSONValue(document));
    }
    // It is not ordinarily possible to stick dollar-sign keys into mongo
    // so we don't bother checking for things that need escaping at this time.
    return undefined;
  };
  var replaceTypes = function (document, atomTransformer) {
    if (typeof document !== 'object' || document === null) return document;
    var replacedTopLevelAtom = atomTransformer(document);
    if (replacedTopLevelAtom !== undefined) return replacedTopLevelAtom;
    var ret = document;
    _.each(document, function (val, key) {
      var valReplaced = replaceTypes(val, atomTransformer);
      if (val !== valReplaced) {
        // Lazy clone. Shallow copy.
        if (ret === document) ret = _.clone(document);
        ret[key] = valReplaced;
      }
    });
    return ret;
  };
  MongoConnection = function (url, options) {
    var _Meteor$settings, _Meteor$settings$pack, _Meteor$settings$pack2;
    var self = this;
    options = options || {};
    self._observeMultiplexers = {};
    self._onFailoverHook = new Hook();
    const userOptions = _objectSpread(_objectSpread({}, Mongo._connectionOptions || {}), ((_Meteor$settings = Meteor.settings) === null || _Meteor$settings === void 0 ? void 0 : (_Meteor$settings$pack = _Meteor$settings.packages) === null || _Meteor$settings$pack === void 0 ? void 0 : (_Meteor$settings$pack2 = _Meteor$settings$pack.mongo) === null || _Meteor$settings$pack2 === void 0 ? void 0 : _Meteor$settings$pack2.options) || {});
    var mongoOptions = Object.assign({
      ignoreUndefined: true
    }, userOptions);

    // Internally the oplog connections specify their own maxPoolSize
    // which we don't want to overwrite with any user defined value
    if (_.has(options, 'maxPoolSize')) {
      // If we just set this for "server", replSet will override it. If we just
      // set it for replSet, it will be ignored if we're not using a replSet.
      mongoOptions.maxPoolSize = options.maxPoolSize;
    }
    if (_.has(options, 'minPoolSize')) {
      mongoOptions.minPoolSize = options.minPoolSize;
    }

    // Transform options like "tlsCAFileAsset": "filename.pem" into
    // "tlsCAFile": "/<fullpath>/filename.pem"
    Object.entries(mongoOptions || {}).filter(_ref => {
      let [key] = _ref;
      return key && key.endsWith(FILE_ASSET_SUFFIX);
    }).forEach(_ref2 => {
      let [key, value] = _ref2;
      const optionName = key.replace(FILE_ASSET_SUFFIX, '');
      mongoOptions[optionName] = path.join(Assets.getServerDir(), ASSETS_FOLDER, APP_FOLDER, value);
      delete mongoOptions[key];
    });
    self.db = null;
    self._oplogHandle = null;
    self._docFetcher = null;
    self.client = new MongoDB.MongoClient(url, mongoOptions);
    self.db = self.client.db();
    self.client.on('serverDescriptionChanged', Meteor.bindEnvironment(event => {
      // When the connection is no longer against the primary node, execute all
      // failover hooks. This is important for the driver as it has to re-pool the
      // query when it happens.
      if (event.previousDescription.type !== 'RSPrimary' && event.newDescription.type === 'RSPrimary') {
        self._onFailoverHook.each(callback => {
          callback();
          return true;
        });
      }
    }));
    if (options.oplogUrl && !Package['disable-oplog']) {
      self._oplogHandle = new OplogHandle(options.oplogUrl, self.db.databaseName);
      self._docFetcher = new DocFetcher(self);
    }
    Promise.await(self.client.connect());
  };
  MongoConnection.prototype.close = function () {
    var self = this;
    if (!self.db) throw Error("close called before Connection created?");

    // XXX probably untested
    var oplogHandle = self._oplogHandle;
    self._oplogHandle = null;
    if (oplogHandle) oplogHandle.stop();

    // Use Future.wrap so that errors get thrown. This happens to
    // work even outside a fiber since the 'close' method is not
    // actually asynchronous.
    Future.wrap(_.bind(self.client.close, self.client))(true).wait();
  };

  // Returns the Mongo Collection object; may yield.
  MongoConnection.prototype.rawCollection = function (collectionName) {
    var self = this;
    if (!self.db) throw Error("rawCollection called before Connection created?");
    return self.db.collection(collectionName);
  };
  MongoConnection.prototype._createCappedCollection = function (collectionName, byteSize, maxDocuments) {
    var self = this;
    if (!self.db) throw Error("_createCappedCollection called before Connection created?");
    var future = new Future();
    self.db.createCollection(collectionName, {
      capped: true,
      size: byteSize,
      max: maxDocuments
    }, future.resolver());
    future.wait();
  };

  // This should be called synchronously with a write, to create a
  // transaction on the current write fence, if any. After we can read
  // the write, and after observers have been notified (or at least,
  // after the observer notifiers have added themselves to the write
  // fence), you should call 'committed()' on the object returned.
  MongoConnection.prototype._maybeBeginWrite = function () {
    var fence = DDPServer._CurrentWriteFence.get();
    if (fence) {
      return fence.beginWrite();
    } else {
      return {
        committed: function () {}
      };
    }
  };

  // Internal interface: adds a callback which is called when the Mongo primary
  // changes. Returns a stop handle.
  MongoConnection.prototype._onFailover = function (callback) {
    return this._onFailoverHook.register(callback);
  };

  //////////// Public API //////////

  // The write methods block until the database has confirmed the write (it may
  // not be replicated or stable on disk, but one server has confirmed it) if no
  // callback is provided. If a callback is provided, then they call the callback
  // when the write is confirmed. They return nothing on success, and raise an
  // exception on failure.
  //
  // After making a write (with insert, update, remove), observers are
  // notified asynchronously. If you want to receive a callback once all
  // of the observer notifications have landed for your write, do the
  // writes inside a write fence (set DDPServer._CurrentWriteFence to a new
  // _WriteFence, and then set a callback on the write fence.)
  //
  // Since our execution environment is single-threaded, this is
  // well-defined -- a write "has been made" if it's returned, and an
  // observer "has been notified" if its callback has returned.

  var writeCallback = function (write, refresh, callback) {
    return function (err, result) {
      if (!err) {
        // XXX We don't have to run this on error, right?
        try {
          refresh();
        } catch (refreshErr) {
          if (callback) {
            callback(refreshErr);
            return;
          } else {
            throw refreshErr;
          }
        }
      }
      write.committed();
      if (callback) {
        callback(err, result);
      } else if (err) {
        throw err;
      }
    };
  };
  var bindEnvironmentForWrite = function (callback) {
    return Meteor.bindEnvironment(callback, "Mongo write");
  };
  MongoConnection.prototype._insert = function (collection_name, document, callback) {
    var self = this;
    var sendError = function (e) {
      if (callback) return callback(e);
      throw e;
    };
    if (collection_name === "___meteor_failure_test_collection") {
      var e = new Error("Failure test");
      e._expectedByTest = true;
      sendError(e);
      return;
    }
    if (!(LocalCollection._isPlainObject(document) && !EJSON._isCustomType(document))) {
      sendError(new Error("Only plain objects may be inserted into MongoDB"));
      return;
    }
    var write = self._maybeBeginWrite();
    var refresh = function () {
      Meteor.refresh({
        collection: collection_name,
        id: document._id
      });
    };
    callback = bindEnvironmentForWrite(writeCallback(write, refresh, callback));
    try {
      var collection = self.rawCollection(collection_name);
      collection.insertOne(replaceTypes(document, replaceMeteorAtomWithMongo), {
        safe: true
      }).then(_ref3 => {
        let {
          insertedId
        } = _ref3;
        callback(null, insertedId);
      }).catch(e => {
        callback(e, null);
      });
    } catch (err) {
      write.committed();
      throw err;
    }
  };

  // Cause queries that may be affected by the selector to poll in this write
  // fence.
  MongoConnection.prototype._refresh = function (collectionName, selector) {
    var refreshKey = {
      collection: collectionName
    };
    // If we know which documents we're removing, don't poll queries that are
    // specific to other documents. (Note that multiple notifications here should
    // not cause multiple polls, since all our listener is doing is enqueueing a
    // poll.)
    var specificIds = LocalCollection._idsMatchedBySelector(selector);
    if (specificIds) {
      _.each(specificIds, function (id) {
        Meteor.refresh(_.extend({
          id: id
        }, refreshKey));
      });
    } else {
      Meteor.refresh(refreshKey);
    }
  };
  MongoConnection.prototype._remove = function (collection_name, selector, callback) {
    var self = this;
    if (collection_name === "___meteor_failure_test_collection") {
      var e = new Error("Failure test");
      e._expectedByTest = true;
      if (callback) {
        return callback(e);
      } else {
        throw e;
      }
    }
    var write = self._maybeBeginWrite();
    var refresh = function () {
      self._refresh(collection_name, selector);
    };
    callback = bindEnvironmentForWrite(writeCallback(write, refresh, callback));
    try {
      var collection = self.rawCollection(collection_name);
      collection.deleteMany(replaceTypes(selector, replaceMeteorAtomWithMongo), {
        safe: true
      }).then(_ref4 => {
        let {
          deletedCount
        } = _ref4;
        callback(null, transformResult({
          result: {
            modifiedCount: deletedCount
          }
        }).numberAffected);
      }).catch(err => {
        callback(err);
      });
    } catch (err) {
      write.committed();
      throw err;
    }
  };
  MongoConnection.prototype._dropCollection = function (collectionName, cb) {
    var self = this;
    var write = self._maybeBeginWrite();
    var refresh = function () {
      Meteor.refresh({
        collection: collectionName,
        id: null,
        dropCollection: true
      });
    };
    cb = bindEnvironmentForWrite(writeCallback(write, refresh, cb));
    try {
      var collection = self.rawCollection(collectionName);
      collection.drop(cb);
    } catch (e) {
      write.committed();
      throw e;
    }
  };

  // For testing only.  Slightly better than `c.rawDatabase().dropDatabase()`
  // because it lets the test's fence wait for it to be complete.
  MongoConnection.prototype._dropDatabase = function (cb) {
    var self = this;
    var write = self._maybeBeginWrite();
    var refresh = function () {
      Meteor.refresh({
        dropDatabase: true
      });
    };
    cb = bindEnvironmentForWrite(writeCallback(write, refresh, cb));
    try {
      self.db.dropDatabase(cb);
    } catch (e) {
      write.committed();
      throw e;
    }
  };
  MongoConnection.prototype._update = function (collection_name, selector, mod, options, callback) {
    var self = this;
    if (!callback && options instanceof Function) {
      callback = options;
      options = null;
    }
    if (collection_name === "___meteor_failure_test_collection") {
      var e = new Error("Failure test");
      e._expectedByTest = true;
      if (callback) {
        return callback(e);
      } else {
        throw e;
      }
    }

    // explicit safety check. null and undefined can crash the mongo
    // driver. Although the node driver and minimongo do 'support'
    // non-object modifier in that they don't crash, they are not
    // meaningful operations and do not do anything. Defensively throw an
    // error here.
    if (!mod || typeof mod !== 'object') throw new Error("Invalid modifier. Modifier must be an object.");
    if (!(LocalCollection._isPlainObject(mod) && !EJSON._isCustomType(mod))) {
      throw new Error("Only plain objects may be used as replacement" + " documents in MongoDB");
    }
    if (!options) options = {};
    var write = self._maybeBeginWrite();
    var refresh = function () {
      self._refresh(collection_name, selector);
    };
    callback = writeCallback(write, refresh, callback);
    try {
      var collection = self.rawCollection(collection_name);
      var mongoOpts = {
        safe: true
      };
      // Add support for filtered positional operator
      if (options.arrayFilters !== undefined) mongoOpts.arrayFilters = options.arrayFilters;
      // explictly enumerate options that minimongo supports
      if (options.upsert) mongoOpts.upsert = true;
      if (options.multi) mongoOpts.multi = true;
      // Lets you get a more more full result from MongoDB. Use with caution:
      // might not work with C.upsert (as opposed to C.update({upsert:true}) or
      // with simulated upsert.
      if (options.fullResult) mongoOpts.fullResult = true;
      var mongoSelector = replaceTypes(selector, replaceMeteorAtomWithMongo);
      var mongoMod = replaceTypes(mod, replaceMeteorAtomWithMongo);
      var isModify = LocalCollection._isModificationMod(mongoMod);
      if (options._forbidReplace && !isModify) {
        var err = new Error("Invalid modifier. Replacements are forbidden.");
        if (callback) {
          return callback(err);
        } else {
          throw err;
        }
      }

      // We've already run replaceTypes/replaceMeteorAtomWithMongo on
      // selector and mod.  We assume it doesn't matter, as far as
      // the behavior of modifiers is concerned, whether `_modify`
      // is run on EJSON or on mongo-converted EJSON.

      // Run this code up front so that it fails fast if someone uses
      // a Mongo update operator we don't support.
      let knownId;
      if (options.upsert) {
        try {
          let newDoc = LocalCollection._createUpsertDocument(selector, mod);
          knownId = newDoc._id;
        } catch (err) {
          if (callback) {
            return callback(err);
          } else {
            throw err;
          }
        }
      }
      if (options.upsert && !isModify && !knownId && options.insertedId && !(options.insertedId instanceof Mongo.ObjectID && options.generatedId)) {
        // In case of an upsert with a replacement, where there is no _id defined
        // in either the query or the replacement doc, mongo will generate an id itself.
        // Therefore we need this special strategy if we want to control the id ourselves.

        // We don't need to do this when:
        // - This is not a replacement, so we can add an _id to $setOnInsert
        // - The id is defined by query or mod we can just add it to the replacement doc
        // - The user did not specify any id preference and the id is a Mongo ObjectId,
        //     then we can just let Mongo generate the id

        simulateUpsertWithInsertedId(collection, mongoSelector, mongoMod, options,
        // This callback does not need to be bindEnvironment'ed because
        // simulateUpsertWithInsertedId() wraps it and then passes it through
        // bindEnvironmentForWrite.
        function (error, result) {
          // If we got here via a upsert() call, then options._returnObject will
          // be set and we should return the whole object. Otherwise, we should
          // just return the number of affected docs to match the mongo API.
          if (result && !options._returnObject) {
            callback(error, result.numberAffected);
          } else {
            callback(error, result);
          }
        });
      } else {
        if (options.upsert && !knownId && options.insertedId && isModify) {
          if (!mongoMod.hasOwnProperty('$setOnInsert')) {
            mongoMod.$setOnInsert = {};
          }
          knownId = options.insertedId;
          Object.assign(mongoMod.$setOnInsert, replaceTypes({
            _id: options.insertedId
          }, replaceMeteorAtomWithMongo));
        }
        const strings = Object.keys(mongoMod).filter(key => !key.startsWith("$"));
        let updateMethod = strings.length > 0 ? 'replaceOne' : 'updateMany';
        updateMethod = updateMethod === 'updateMany' && !mongoOpts.multi ? 'updateOne' : updateMethod;
        collection[updateMethod].bind(collection)(mongoSelector, mongoMod, mongoOpts,
        // mongo driver now returns undefined for err in the callback
        bindEnvironmentForWrite(function () {
          let err = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
          let result = arguments.length > 1 ? arguments[1] : undefined;
          if (!err) {
            var meteorResult = transformResult({
              result
            });
            if (meteorResult && options._returnObject) {
              // If this was an upsert() call, and we ended up
              // inserting a new doc and we know its id, then
              // return that id as well.
              if (options.upsert && meteorResult.insertedId) {
                if (knownId) {
                  meteorResult.insertedId = knownId;
                } else if (meteorResult.insertedId instanceof MongoDB.ObjectID) {
                  meteorResult.insertedId = new Mongo.ObjectID(meteorResult.insertedId.toHexString());
                }
              }
              callback(err, meteorResult);
            } else {
              callback(err, meteorResult.numberAffected);
            }
          } else {
            callback(err);
          }
        }));
      }
    } catch (e) {
      write.committed();
      throw e;
    }
  };
  var transformResult = function (driverResult) {
    var meteorResult = {
      numberAffected: 0
    };
    if (driverResult) {
      var mongoResult = driverResult.result;
      // On updates with upsert:true, the inserted values come as a list of
      // upserted values -- even with options.multi, when the upsert does insert,
      // it only inserts one element.
      if (mongoResult.upsertedCount) {
        meteorResult.numberAffected = mongoResult.upsertedCount;
        if (mongoResult.upsertedId) {
          meteorResult.insertedId = mongoResult.upsertedId;
        }
      } else {
        // n was used before Mongo 5.0, in Mongo 5.0 we are not receiving this n
        // field and so we are using modifiedCount instead
        meteorResult.numberAffected = mongoResult.n || mongoResult.matchedCount || mongoResult.modifiedCount;
      }
    }
    return meteorResult;
  };
  var NUM_OPTIMISTIC_TRIES = 3;

  // exposed for testing
  MongoConnection._isCannotChangeIdError = function (err) {
    // Mongo 3.2.* returns error as next Object:
    // {name: String, code: Number, errmsg: String}
    // Older Mongo returns:
    // {name: String, code: Number, err: String}
    var error = err.errmsg || err.err;

    // We don't use the error code here
    // because the error code we observed it producing (16837) appears to be
    // a far more generic error code based on examining the source.
    if (error.indexOf('The _id field cannot be changed') === 0 || error.indexOf("the (immutable) field '_id' was found to have been altered to _id") !== -1) {
      return true;
    }
    return false;
  };
  var simulateUpsertWithInsertedId = function (collection, selector, mod, options, callback) {
    // STRATEGY: First try doing an upsert with a generated ID.
    // If this throws an error about changing the ID on an existing document
    // then without affecting the database, we know we should probably try
    // an update without the generated ID. If it affected 0 documents,
    // then without affecting the database, we the document that first
    // gave the error is probably removed and we need to try an insert again
    // We go back to step one and repeat.
    // Like all "optimistic write" schemes, we rely on the fact that it's
    // unlikely our writes will continue to be interfered with under normal
    // circumstances (though sufficiently heavy contention with writers
    // disagreeing on the existence of an object will cause writes to fail
    // in theory).

    var insertedId = options.insertedId; // must exist
    var mongoOptsForUpdate = {
      safe: true,
      multi: options.multi
    };
    var mongoOptsForInsert = {
      safe: true,
      upsert: true
    };
    var replacementWithId = Object.assign(replaceTypes({
      _id: insertedId
    }, replaceMeteorAtomWithMongo), mod);
    var tries = NUM_OPTIMISTIC_TRIES;
    var doUpdate = function () {
      tries--;
      if (!tries) {
        callback(new Error("Upsert failed after " + NUM_OPTIMISTIC_TRIES + " tries."));
      } else {
        let method = collection.updateMany;
        if (!Object.keys(mod).some(key => key.startsWith("$"))) {
          method = collection.replaceOne.bind(collection);
        }
        method(selector, mod, mongoOptsForUpdate, bindEnvironmentForWrite(function (err, result) {
          if (err) {
            callback(err);
          } else if (result && (result.modifiedCount || result.upsertedCount)) {
            callback(null, {
              numberAffected: result.modifiedCount || result.upsertedCount,
              insertedId: result.upsertedId || undefined
            });
          } else {
            doConditionalInsert();
          }
        }));
      }
    };
    var doConditionalInsert = function () {
      collection.replaceOne(selector, replacementWithId, mongoOptsForInsert, bindEnvironmentForWrite(function (err, result) {
        if (err) {
          // figure out if this is a
          // "cannot change _id of document" error, and
          // if so, try doUpdate() again, up to 3 times.
          if (MongoConnection._isCannotChangeIdError(err)) {
            doUpdate();
          } else {
            callback(err);
          }
        } else {
          callback(null, {
            numberAffected: result.upsertedCount,
            insertedId: result.upsertedId
          });
        }
      }));
    };
    doUpdate();
  };
  _.each(["insert", "update", "remove", "dropCollection", "dropDatabase"], function (method) {
    MongoConnection.prototype[method] = function /* arguments */
    () {
      var self = this;
      return Meteor.wrapAsync(self["_" + method]).apply(self, arguments);
    };
  });

  // XXX MongoConnection.upsert() does not return the id of the inserted document
  // unless you set it explicitly in the selector or modifier (as a replacement
  // doc).
  MongoConnection.prototype.upsert = function (collectionName, selector, mod, options, callback) {
    var self = this;
    if (typeof options === "function" && !callback) {
      callback = options;
      options = {};
    }
    return self.update(collectionName, selector, mod, _.extend({}, options, {
      upsert: true,
      _returnObject: true
    }), callback);
  };
  MongoConnection.prototype.find = function (collectionName, selector, options) {
    var self = this;
    if (arguments.length === 1) selector = {};
    return new Cursor(self, new CursorDescription(collectionName, selector, options));
  };
  MongoConnection.prototype.findOneAsync = function (collection_name, selector, options) {
    return Promise.asyncApply(() => {
      var self = this;
      if (arguments.length === 1) selector = {};
      options = options || {};
      options.limit = 1;
      return Promise.await(self.find(collection_name, selector, options).fetchAsync())[0];
    });
  };
  MongoConnection.prototype.findOne = function (collection_name, selector, options) {
    var self = this;
    return Future.fromPromise(self.findOneAsync(collection_name, selector, options)).wait();
  };
  MongoConnection.prototype.createIndexAsync = function (collectionName, index, options) {
    var self = this;

    // We expect this function to be called at startup, not from within a method,
    // so we don't interact with the write fence.
    var collection = self.rawCollection(collectionName);
    return collection.createIndex(index, options);
  };

  // We'll actually design an index API later. For now, we just pass through to
  // Mongo's, but make it synchronous.
  MongoConnection.prototype.createIndex = function (collectionName, index, options) {
    var self = this;
    return Future.fromPromise(self.createIndexAsync(collectionName, index, options));
  };
  MongoConnection.prototype.countDocuments = function (collectionName) {
    for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }
    args = args.map(arg => replaceTypes(arg, replaceMeteorAtomWithMongo));
    const collection = this.rawCollection(collectionName);
    return collection.countDocuments(...args);
  };
  MongoConnection.prototype.estimatedDocumentCount = function (collectionName) {
    for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
      args[_key2 - 1] = arguments[_key2];
    }
    args = args.map(arg => replaceTypes(arg, replaceMeteorAtomWithMongo));
    const collection = this.rawCollection(collectionName);
    return collection.estimatedDocumentCount(...args);
  };
  MongoConnection.prototype._ensureIndex = MongoConnection.prototype.createIndex;
  MongoConnection.prototype._dropIndex = function (collectionName, index) {
    var self = this;

    // This function is only used by test code, not within a method, so we don't
    // interact with the write fence.
    var collection = self.rawCollection(collectionName);
    var future = new Future();
    var indexName = collection.dropIndex(index, future.resolver());
    future.wait();
  };

  // CURSORS

  // There are several classes which relate to cursors:
  //
  // CursorDescription represents the arguments used to construct a cursor:
  // collectionName, selector, and (find) options.  Because it is used as a key
  // for cursor de-dup, everything in it should either be JSON-stringifiable or
  // not affect observeChanges output (eg, options.transform functions are not
  // stringifiable but do not affect observeChanges).
  //
  // SynchronousCursor is a wrapper around a MongoDB cursor
  // which includes fully-synchronous versions of forEach, etc.
  //
  // Cursor is the cursor object returned from find(), which implements the
  // documented Mongo.Collection cursor API.  It wraps a CursorDescription and a
  // SynchronousCursor (lazily: it doesn't contact Mongo until you call a method
  // like fetch or forEach on it).
  //
  // ObserveHandle is the "observe handle" returned from observeChanges. It has a
  // reference to an ObserveMultiplexer.
  //
  // ObserveMultiplexer allows multiple identical ObserveHandles to be driven by a
  // single observe driver.
  //
  // There are two "observe drivers" which drive ObserveMultiplexers:
  //   - PollingObserveDriver caches the results of a query and reruns it when
  //     necessary.
  //   - OplogObserveDriver follows the Mongo operation log to directly observe
  //     database changes.
  // Both implementations follow the same simple interface: when you create them,
  // they start sending observeChanges callbacks (and a ready() invocation) to
  // their ObserveMultiplexer, and you stop them by calling their stop() method.

  CursorDescription = function (collectionName, selector, options) {
    var self = this;
    self.collectionName = collectionName;
    self.selector = Mongo.Collection._rewriteSelector(selector);
    self.options = options || {};
  };
  Cursor = function (mongo, cursorDescription) {
    var self = this;
    self._mongo = mongo;
    self._cursorDescription = cursorDescription;
    self._synchronousCursor = null;
  };
  function setupSynchronousCursor(cursor, method) {
    // You can only observe a tailable cursor.
    if (cursor._cursorDescription.options.tailable) throw new Error('Cannot call ' + method + ' on a tailable cursor');
    if (!cursor._synchronousCursor) {
      cursor._synchronousCursor = cursor._mongo._createSynchronousCursor(cursor._cursorDescription, {
        // Make sure that the "cursor" argument to forEach/map callbacks is the
        // Cursor, not the SynchronousCursor.
        selfForIteration: cursor,
        useTransform: true
      });
    }
    return cursor._synchronousCursor;
  }
  Cursor.prototype.count = function () {
    const collection = this._mongo.rawCollection(this._cursorDescription.collectionName);
    return Promise.await(collection.countDocuments(replaceTypes(this._cursorDescription.selector, replaceMeteorAtomWithMongo), replaceTypes(this._cursorDescription.options, replaceMeteorAtomWithMongo)));
  };
  [...ASYNC_CURSOR_METHODS, Symbol.iterator, Symbol.asyncIterator].forEach(methodName => {
    // count is handled specially since we don't want to create a cursor.
    // it is still included in ASYNC_CURSOR_METHODS because we still want an async version of it to exist.
    if (methodName !== 'count') {
      Cursor.prototype[methodName] = function () {
        const cursor = setupSynchronousCursor(this, methodName);
        return cursor[methodName](...arguments);
      };
    }

    // These methods are handled separately.
    if (methodName === Symbol.iterator || methodName === Symbol.asyncIterator) {
      return;
    }
    const methodNameAsync = getAsyncMethodName(methodName);
    Cursor.prototype[methodNameAsync] = function () {
      try {
        this[methodName].isCalledFromAsync = true;
        return Promise.resolve(this[methodName](...arguments));
      } catch (error) {
        return Promise.reject(error);
      }
    };
  });
  Cursor.prototype.getTransform = function () {
    return this._cursorDescription.options.transform;
  };

  // When you call Meteor.publish() with a function that returns a Cursor, we need
  // to transmute it into the equivalent subscription.  This is the function that
  // does that.

  Cursor.prototype._publishCursor = function (sub) {
    var self = this;
    var collection = self._cursorDescription.collectionName;
    return Mongo.Collection._publishCursor(self, sub, collection);
  };

  // Used to guarantee that publish functions return at most one cursor per
  // collection. Private, because we might later have cursors that include
  // documents from multiple collections somehow.
  Cursor.prototype._getCollectionName = function () {
    var self = this;
    return self._cursorDescription.collectionName;
  };
  Cursor.prototype.observe = function (callbacks) {
    var self = this;
    return LocalCollection._observeFromObserveChanges(self, callbacks);
  };
  Cursor.prototype.observeChanges = function (callbacks) {
    let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var self = this;
    var methods = ['addedAt', 'added', 'changedAt', 'changed', 'removedAt', 'removed', 'movedTo'];
    var ordered = LocalCollection._observeChangesCallbacksAreOrdered(callbacks);
    let exceptionName = callbacks._fromObserve ? 'observe' : 'observeChanges';
    exceptionName += ' callback';
    methods.forEach(function (method) {
      if (callbacks[method] && typeof callbacks[method] == "function") {
        callbacks[method] = Meteor.bindEnvironment(callbacks[method], method + exceptionName);
      }
    });
    return self._mongo._observeChanges(self._cursorDescription, ordered, callbacks, options.nonMutatingCallbacks);
  };
  MongoConnection.prototype._createSynchronousCursor = function (cursorDescription, options) {
    var self = this;
    options = _.pick(options || {}, 'selfForIteration', 'useTransform');
    var collection = self.rawCollection(cursorDescription.collectionName);
    var cursorOptions = cursorDescription.options;
    var mongoOptions = {
      sort: cursorOptions.sort,
      limit: cursorOptions.limit,
      skip: cursorOptions.skip,
      projection: cursorOptions.fields || cursorOptions.projection,
      readPreference: cursorOptions.readPreference
    };

    // Do we want a tailable cursor (which only works on capped collections)?
    if (cursorOptions.tailable) {
      mongoOptions.numberOfRetries = -1;
    }
    var dbCursor = collection.find(replaceTypes(cursorDescription.selector, replaceMeteorAtomWithMongo), mongoOptions);

    // Do we want a tailable cursor (which only works on capped collections)?
    if (cursorOptions.tailable) {
      // We want a tailable cursor...
      dbCursor.addCursorFlag("tailable", true);
      // ... and for the server to wait a bit if any getMore has no data (rather
      // than making us put the relevant sleeps in the client)...
      dbCursor.addCursorFlag("awaitData", true);

      // And if this is on the oplog collection and the cursor specifies a 'ts',
      // then set the undocumented oplog replay flag, which does a special scan to
      // find the first document (instead of creating an index on ts). This is a
      // very hard-coded Mongo flag which only works on the oplog collection and
      // only works with the ts field.
      if (cursorDescription.collectionName === OPLOG_COLLECTION && cursorDescription.selector.ts) {
        dbCursor.addCursorFlag("oplogReplay", true);
      }
    }
    if (typeof cursorOptions.maxTimeMs !== 'undefined') {
      dbCursor = dbCursor.maxTimeMS(cursorOptions.maxTimeMs);
    }
    if (typeof cursorOptions.hint !== 'undefined') {
      dbCursor = dbCursor.hint(cursorOptions.hint);
    }
    return new SynchronousCursor(dbCursor, cursorDescription, options, collection);
  };
  var SynchronousCursor = function (dbCursor, cursorDescription, options, collection) {
    var self = this;
    options = _.pick(options || {}, 'selfForIteration', 'useTransform');
    self._dbCursor = dbCursor;
    self._cursorDescription = cursorDescription;
    // The "self" argument passed to forEach/map callbacks. If we're wrapped
    // inside a user-visible Cursor, we want to provide the outer cursor!
    self._selfForIteration = options.selfForIteration || self;
    if (options.useTransform && cursorDescription.options.transform) {
      self._transform = LocalCollection.wrapTransform(cursorDescription.options.transform);
    } else {
      self._transform = null;
    }
    self._synchronousCount = Future.wrap(collection.countDocuments.bind(collection, replaceTypes(cursorDescription.selector, replaceMeteorAtomWithMongo), replaceTypes(cursorDescription.options, replaceMeteorAtomWithMongo)));
    self._visitedIds = new LocalCollection._IdMap();
  };
  _.extend(SynchronousCursor.prototype, {
    // Returns a Promise for the next object from the underlying cursor (before
    // the Mongo->Meteor type replacement).
    _rawNextObjectPromise: function () {
      const self = this;
      return new Promise((resolve, reject) => {
        self._dbCursor.next((err, doc) => {
          if (err) {
            reject(err);
          } else {
            resolve(doc);
          }
        });
      });
    },
    // Returns a Promise for the next object from the cursor, skipping those whose
    // IDs we've already seen and replacing Mongo atoms with Meteor atoms.
    _nextObjectPromise: function () {
      return Promise.asyncApply(() => {
        var self = this;
        while (true) {
          var doc = Promise.await(self._rawNextObjectPromise());
          if (!doc) return null;
          doc = replaceTypes(doc, replaceMongoAtomWithMeteor);
          if (!self._cursorDescription.options.tailable && _.has(doc, '_id')) {
            // Did Mongo give us duplicate documents in the same cursor? If so,
            // ignore this one. (Do this before the transform, since transform might
            // return some unrelated value.) We don't do this for tailable cursors,
            // because we want to maintain O(1) memory usage. And if there isn't _id
            // for some reason (maybe it's the oplog), then we don't do this either.
            // (Be careful to do this for falsey but existing _id, though.)
            if (self._visitedIds.has(doc._id)) continue;
            self._visitedIds.set(doc._id, true);
          }
          if (self._transform) doc = self._transform(doc);
          return doc;
        }
      });
    },
    // Returns a promise which is resolved with the next object (like with
    // _nextObjectPromise) or rejected if the cursor doesn't return within
    // timeoutMS ms.
    _nextObjectPromiseWithTimeout: function (timeoutMS) {
      const self = this;
      if (!timeoutMS) {
        return self._nextObjectPromise();
      }
      const nextObjectPromise = self._nextObjectPromise();
      const timeoutErr = new Error('Client-side timeout waiting for next object');
      const timeoutPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(timeoutErr);
        }, timeoutMS);
      });
      return Promise.race([nextObjectPromise, timeoutPromise]).catch(err => {
        if (err === timeoutErr) {
          self.close();
        }
        throw err;
      });
    },
    _nextObject: function () {
      var self = this;
      return self._nextObjectPromise().await();
    },
    forEach: function (callback, thisArg) {
      var self = this;
      const wrappedFn = Meteor.wrapFn(callback);

      // Get back to the beginning.
      self._rewind();

      // We implement the loop ourself instead of using self._dbCursor.each,
      // because "each" will call its callback outside of a fiber which makes it
      // much more complex to make this function synchronous.
      var index = 0;
      while (true) {
        var doc = self._nextObject();
        if (!doc) return;
        wrappedFn.call(thisArg, doc, index++, self._selfForIteration);
      }
    },
    // XXX Allow overlapping callback executions if callback yields.
    map: function (callback, thisArg) {
      var self = this;
      const wrappedFn = Meteor.wrapFn(callback);
      var res = [];
      self.forEach(function (doc, index) {
        res.push(wrappedFn.call(thisArg, doc, index, self._selfForIteration));
      });
      return res;
    },
    _rewind: function () {
      var self = this;

      // known to be synchronous
      self._dbCursor.rewind();
      self._visitedIds = new LocalCollection._IdMap();
    },
    // Mostly usable for tailable cursors.
    close: function () {
      var self = this;
      self._dbCursor.close();
    },
    fetch: function () {
      var self = this;
      return self.map(_.identity);
    },
    count: function () {
      var self = this;
      return self._synchronousCount().wait();
    },
    // This method is NOT wrapped in Cursor.
    getRawObjects: function (ordered) {
      var self = this;
      if (ordered) {
        return self.fetch();
      } else {
        var results = new LocalCollection._IdMap();
        self.forEach(function (doc) {
          results.set(doc._id, doc);
        });
        return results;
      }
    }
  });
  SynchronousCursor.prototype[Symbol.iterator] = function () {
    var self = this;

    // Get back to the beginning.
    self._rewind();
    return {
      next() {
        const doc = self._nextObject();
        return doc ? {
          value: doc
        } : {
          done: true
        };
      }
    };
  };
  SynchronousCursor.prototype[Symbol.asyncIterator] = function () {
    const syncResult = this[Symbol.iterator]();
    return {
      next() {
        return Promise.asyncApply(() => {
          return Promise.resolve(syncResult.next());
        });
      }
    };
  };

  // Tails the cursor described by cursorDescription, most likely on the
  // oplog. Calls docCallback with each document found. Ignores errors and just
  // restarts the tail on error.
  //
  // If timeoutMS is set, then if we don't get a new document every timeoutMS,
  // kill and restart the cursor. This is primarily a workaround for #8598.
  MongoConnection.prototype.tail = function (cursorDescription, docCallback, timeoutMS) {
    var self = this;
    if (!cursorDescription.options.tailable) throw new Error("Can only tail a tailable cursor");
    var cursor = self._createSynchronousCursor(cursorDescription);
    var stopped = false;
    var lastTS;
    var loop = function () {
      var doc = null;
      while (true) {
        if (stopped) return;
        try {
          doc = cursor._nextObjectPromiseWithTimeout(timeoutMS).await();
        } catch (err) {
          // There's no good way to figure out if this was actually an error from
          // Mongo, or just client-side (including our own timeout error). Ah
          // well. But either way, we need to retry the cursor (unless the failure
          // was because the observe got stopped).
          doc = null;
        }
        // Since we awaited a promise above, we need to check again to see if
        // we've been stopped before calling the callback.
        if (stopped) return;
        if (doc) {
          // If a tailable cursor contains a "ts" field, use it to recreate the
          // cursor on error. ("ts" is a standard that Mongo uses internally for
          // the oplog, and there's a special flag that lets you do binary search
          // on it instead of needing to use an index.)
          lastTS = doc.ts;
          docCallback(doc);
        } else {
          var newSelector = _.clone(cursorDescription.selector);
          if (lastTS) {
            newSelector.ts = {
              $gt: lastTS
            };
          }
          cursor = self._createSynchronousCursor(new CursorDescription(cursorDescription.collectionName, newSelector, cursorDescription.options));
          // Mongo failover takes many seconds.  Retry in a bit.  (Without this
          // setTimeout, we peg the CPU at 100% and never notice the actual
          // failover.
          Meteor.setTimeout(loop, 100);
          break;
        }
      }
    };
    Meteor.defer(loop);
    return {
      stop: function () {
        stopped = true;
        cursor.close();
      }
    };
  };
  MongoConnection.prototype._observeChanges = function (cursorDescription, ordered, callbacks, nonMutatingCallbacks) {
    var self = this;
    if (cursorDescription.options.tailable) {
      return self._observeChangesTailable(cursorDescription, ordered, callbacks);
    }

    // You may not filter out _id when observing changes, because the id is a core
    // part of the observeChanges API.
    const fieldsOptions = cursorDescription.options.projection || cursorDescription.options.fields;
    if (fieldsOptions && (fieldsOptions._id === 0 || fieldsOptions._id === false)) {
      throw Error("You may not observe a cursor with {fields: {_id: 0}}");
    }
    var observeKey = EJSON.stringify(_.extend({
      ordered: ordered
    }, cursorDescription));
    var multiplexer, observeDriver;
    var firstHandle = false;

    // Find a matching ObserveMultiplexer, or create a new one. This next block is
    // guaranteed to not yield (and it doesn't call anything that can observe a
    // new query), so no other calls to this function can interleave with it.
    Meteor._noYieldsAllowed(function () {
      if (_.has(self._observeMultiplexers, observeKey)) {
        multiplexer = self._observeMultiplexers[observeKey];
      } else {
        firstHandle = true;
        // Create a new ObserveMultiplexer.
        multiplexer = new ObserveMultiplexer({
          ordered: ordered,
          onStop: function () {
            delete self._observeMultiplexers[observeKey];
            observeDriver.stop();
          }
        });
        self._observeMultiplexers[observeKey] = multiplexer;
      }
    });
    var observeHandle = new ObserveHandle(multiplexer, callbacks, nonMutatingCallbacks);
    if (firstHandle) {
      var matcher, sorter;
      var canUseOplog = _.all([function () {
        // At a bare minimum, using the oplog requires us to have an oplog, to
        // want unordered callbacks, and to not want a callback on the polls
        // that won't happen.
        return self._oplogHandle && !ordered && !callbacks._testOnlyPollCallback;
      }, function () {
        // We need to be able to compile the selector. Fall back to polling for
        // some newfangled $selector that minimongo doesn't support yet.
        try {
          matcher = new Minimongo.Matcher(cursorDescription.selector);
          return true;
        } catch (e) {
          // XXX make all compilation errors MinimongoError or something
          //     so that this doesn't ignore unrelated exceptions
          return false;
        }
      }, function () {
        // ... and the selector itself needs to support oplog.
        return OplogObserveDriver.cursorSupported(cursorDescription, matcher);
      }, function () {
        // And we need to be able to compile the sort, if any.  eg, can't be
        // {$natural: 1}.
        if (!cursorDescription.options.sort) return true;
        try {
          sorter = new Minimongo.Sorter(cursorDescription.options.sort);
          return true;
        } catch (e) {
          // XXX make all compilation errors MinimongoError or something
          //     so that this doesn't ignore unrelated exceptions
          return false;
        }
      }], function (f) {
        return f();
      }); // invoke each function

      var driverClass = canUseOplog ? OplogObserveDriver : PollingObserveDriver;
      observeDriver = new driverClass({
        cursorDescription: cursorDescription,
        mongoHandle: self,
        multiplexer: multiplexer,
        ordered: ordered,
        matcher: matcher,
        // ignored by polling
        sorter: sorter,
        // ignored by polling
        _testOnlyPollCallback: callbacks._testOnlyPollCallback
      });

      // This field is only set for use in tests.
      multiplexer._observeDriver = observeDriver;
    }

    // Blocks until the initial adds have been sent.
    multiplexer.addHandleAndSendInitialAdds(observeHandle);
    return observeHandle;
  };

  // Listen for the invalidation messages that will trigger us to poll the
  // database for changes. If this selector specifies specific IDs, specify them
  // here, so that updates to different specific IDs don't cause us to poll.
  // listenCallback is the same kind of (notification, complete) callback passed
  // to InvalidationCrossbar.listen.

  listenAll = function (cursorDescription, listenCallback) {
    var listeners = [];
    forEachTrigger(cursorDescription, function (trigger) {
      listeners.push(DDPServer._InvalidationCrossbar.listen(trigger, listenCallback));
    });
    return {
      stop: function () {
        _.each(listeners, function (listener) {
          listener.stop();
        });
      }
    };
  };
  forEachTrigger = function (cursorDescription, triggerCallback) {
    var key = {
      collection: cursorDescription.collectionName
    };
    var specificIds = LocalCollection._idsMatchedBySelector(cursorDescription.selector);
    if (specificIds) {
      _.each(specificIds, function (id) {
        triggerCallback(_.extend({
          id: id
        }, key));
      });
      triggerCallback(_.extend({
        dropCollection: true,
        id: null
      }, key));
    } else {
      triggerCallback(key);
    }
    // Everyone cares about the database being dropped.
    triggerCallback({
      dropDatabase: true
    });
  };

  // observeChanges for tailable cursors on capped collections.
  //
  // Some differences from normal cursors:
  //   - Will never produce anything other than 'added' or 'addedBefore'. If you
  //     do update a document that has already been produced, this will not notice
  //     it.
  //   - If you disconnect and reconnect from Mongo, it will essentially restart
  //     the query, which will lead to duplicate results. This is pretty bad,
  //     but if you include a field called 'ts' which is inserted as
  //     new MongoInternals.MongoTimestamp(0, 0) (which is initialized to the
  //     current Mongo-style timestamp), we'll be able to find the place to
  //     restart properly. (This field is specifically understood by Mongo with an
  //     optimization which allows it to find the right place to start without
  //     an index on ts. It's how the oplog works.)
  //   - No callbacks are triggered synchronously with the call (there's no
  //     differentiation between "initial data" and "later changes"; everything
  //     that matches the query gets sent asynchronously).
  //   - De-duplication is not implemented.
  //   - Does not yet interact with the write fence. Probably, this should work by
  //     ignoring removes (which don't work on capped collections) and updates
  //     (which don't affect tailable cursors), and just keeping track of the ID
  //     of the inserted object, and closing the write fence once you get to that
  //     ID (or timestamp?).  This doesn't work well if the document doesn't match
  //     the query, though.  On the other hand, the write fence can close
  //     immediately if it does not match the query. So if we trust minimongo
  //     enough to accurately evaluate the query against the write fence, we
  //     should be able to do this...  Of course, minimongo doesn't even support
  //     Mongo Timestamps yet.
  MongoConnection.prototype._observeChangesTailable = function (cursorDescription, ordered, callbacks) {
    var self = this;

    // Tailable cursors only ever call added/addedBefore callbacks, so it's an
    // error if you didn't provide them.
    if (ordered && !callbacks.addedBefore || !ordered && !callbacks.added) {
      throw new Error("Can't observe an " + (ordered ? "ordered" : "unordered") + " tailable cursor without a " + (ordered ? "addedBefore" : "added") + " callback");
    }
    return self.tail(cursorDescription, function (doc) {
      var id = doc._id;
      delete doc._id;
      // The ts is an implementation detail. Hide it.
      delete doc.ts;
      if (ordered) {
        callbacks.addedBefore(id, doc, null);
      } else {
        callbacks.added(id, doc);
      }
    });
  };

  // XXX We probably need to find a better way to expose this. Right now
  // it's only used by tests, but in fact you need it in normal
  // operation to interact with capped collections.
  MongoInternals.MongoTimestamp = MongoDB.Timestamp;
  MongoInternals.Connection = MongoConnection;
}.call(this, module);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oplog_tailing.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/oplog_tailing.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let NpmModuleMongodb;
module.link("meteor/npm-mongo", {
  NpmModuleMongodb(v) {
    NpmModuleMongodb = v;
  }
}, 0);
var Future = Npm.require('fibers/future');
const {
  Long
} = NpmModuleMongodb;
OPLOG_COLLECTION = 'oplog.rs';
var TOO_FAR_BEHIND = process.env.METEOR_OPLOG_TOO_FAR_BEHIND || 2000;
var TAIL_TIMEOUT = +process.env.METEOR_OPLOG_TAIL_TIMEOUT || 30000;
var showTS = function (ts) {
  return "Timestamp(" + ts.getHighBits() + ", " + ts.getLowBits() + ")";
};
idForOp = function (op) {
  if (op.op === 'd') return op.o._id;else if (op.op === 'i') return op.o._id;else if (op.op === 'u') return op.o2._id;else if (op.op === 'c') throw Error("Operator 'c' doesn't supply an object with id: " + EJSON.stringify(op));else throw Error("Unknown op: " + EJSON.stringify(op));
};
OplogHandle = function (oplogUrl, dbName) {
  var self = this;
  self._oplogUrl = oplogUrl;
  self._dbName = dbName;
  self._oplogLastEntryConnection = null;
  self._oplogTailConnection = null;
  self._stopped = false;
  self._tailHandle = null;
  self._readyFuture = new Future();
  self._crossbar = new DDPServer._Crossbar({
    factPackage: "mongo-livedata",
    factName: "oplog-watchers"
  });
  self._baseOplogSelector = {
    ns: new RegExp("^(?:" + [Meteor._escapeRegExp(self._dbName + "."), Meteor._escapeRegExp("admin.$cmd")].join("|") + ")"),
    $or: [{
      op: {
        $in: ['i', 'u', 'd']
      }
    },
    // drop collection
    {
      op: 'c',
      'o.drop': {
        $exists: true
      }
    }, {
      op: 'c',
      'o.dropDatabase': 1
    }, {
      op: 'c',
      'o.applyOps': {
        $exists: true
      }
    }]
  };

  // Data structures to support waitUntilCaughtUp(). Each oplog entry has a
  // MongoTimestamp object on it (which is not the same as a Date --- it's a
  // combination of time and an incrementing counter; see
  // http://docs.mongodb.org/manual/reference/bson-types/#timestamps).
  //
  // _catchingUpFutures is an array of {ts: MongoTimestamp, future: Future}
  // objects, sorted by ascending timestamp. _lastProcessedTS is the
  // MongoTimestamp of the last oplog entry we've processed.
  //
  // Each time we call waitUntilCaughtUp, we take a peek at the final oplog
  // entry in the db.  If we've already processed it (ie, it is not greater than
  // _lastProcessedTS), waitUntilCaughtUp immediately returns. Otherwise,
  // waitUntilCaughtUp makes a new Future and inserts it along with the final
  // timestamp entry that it read, into _catchingUpFutures. waitUntilCaughtUp
  // then waits on that future, which is resolved once _lastProcessedTS is
  // incremented to be past its timestamp by the worker fiber.
  //
  // XXX use a priority queue or something else that's faster than an array
  self._catchingUpFutures = [];
  self._lastProcessedTS = null;
  self._onSkippedEntriesHook = new Hook({
    debugPrintExceptions: "onSkippedEntries callback"
  });
  self._entryQueue = new Meteor._DoubleEndedQueue();
  self._workerActive = false;
  self._startTailing();
};
Object.assign(OplogHandle.prototype, {
  stop: function () {
    var self = this;
    if (self._stopped) return;
    self._stopped = true;
    if (self._tailHandle) self._tailHandle.stop();
    // XXX should close connections too
  },
  onOplogEntry: function (trigger, callback) {
    var self = this;
    if (self._stopped) throw new Error("Called onOplogEntry on stopped handle!");

    // Calling onOplogEntry requires us to wait for the tailing to be ready.
    self._readyFuture.wait();
    var originalCallback = callback;
    callback = Meteor.bindEnvironment(function (notification) {
      originalCallback(notification);
    }, function (err) {
      Meteor._debug("Error in oplog callback", err);
    });
    var listenHandle = self._crossbar.listen(trigger, callback);
    return {
      stop: function () {
        listenHandle.stop();
      }
    };
  },
  // Register a callback to be invoked any time we skip oplog entries (eg,
  // because we are too far behind).
  onSkippedEntries: function (callback) {
    var self = this;
    if (self._stopped) throw new Error("Called onSkippedEntries on stopped handle!");
    return self._onSkippedEntriesHook.register(callback);
  },
  // Calls `callback` once the oplog has been processed up to a point that is
  // roughly "now": specifically, once we've processed all ops that are
  // currently visible.
  // XXX become convinced that this is actually safe even if oplogConnection
  // is some kind of pool
  waitUntilCaughtUp: function () {
    var self = this;
    if (self._stopped) throw new Error("Called waitUntilCaughtUp on stopped handle!");

    // Calling waitUntilCaughtUp requries us to wait for the oplog connection to
    // be ready.
    self._readyFuture.wait();
    var lastEntry;
    while (!self._stopped) {
      // We need to make the selector at least as restrictive as the actual
      // tailing selector (ie, we need to specify the DB name) or else we might
      // find a TS that won't show up in the actual tail stream.
      try {
        lastEntry = self._oplogLastEntryConnection.findOne(OPLOG_COLLECTION, self._baseOplogSelector, {
          projection: {
            ts: 1
          },
          sort: {
            $natural: -1
          }
        });
        break;
      } catch (e) {
        // During failover (eg) if we get an exception we should log and retry
        // instead of crashing.
        Meteor._debug("Got exception while reading last entry", e);
        Meteor._sleepForMs(100);
      }
    }
    if (self._stopped) return;
    if (!lastEntry) {
      // Really, nothing in the oplog? Well, we've processed everything.
      return;
    }
    var ts = lastEntry.ts;
    if (!ts) throw Error("oplog entry without ts: " + EJSON.stringify(lastEntry));
    if (self._lastProcessedTS && ts.lessThanOrEqual(self._lastProcessedTS)) {
      // We've already caught up to here.
      return;
    }

    // Insert the future into our list. Almost always, this will be at the end,
    // but it's conceivable that if we fail over from one primary to another,
    // the oplog entries we see will go backwards.
    var insertAfter = self._catchingUpFutures.length;
    while (insertAfter - 1 > 0 && self._catchingUpFutures[insertAfter - 1].ts.greaterThan(ts)) {
      insertAfter--;
    }
    var f = new Future();
    self._catchingUpFutures.splice(insertAfter, 0, {
      ts: ts,
      future: f
    });
    f.wait();
  },
  _startTailing: function () {
    var self = this;
    // First, make sure that we're talking to the local database.
    var mongodbUri = Npm.require('mongodb-uri');
    if (mongodbUri.parse(self._oplogUrl).database !== 'local') {
      throw Error("$MONGO_OPLOG_URL must be set to the 'local' database of " + "a Mongo replica set");
    }

    // We make two separate connections to Mongo. The Node Mongo driver
    // implements a naive round-robin connection pool: each "connection" is a
    // pool of several (5 by default) TCP connections, and each request is
    // rotated through the pools. Tailable cursor queries block on the server
    // until there is some data to return (or until a few seconds have
    // passed). So if the connection pool used for tailing cursors is the same
    // pool used for other queries, the other queries will be delayed by seconds
    // 1/5 of the time.
    //
    // The tail connection will only ever be running a single tail command, so
    // it only needs to make one underlying TCP connection.
    self._oplogTailConnection = new MongoConnection(self._oplogUrl, {
      maxPoolSize: 1,
      minPoolSize: 1
    });
    // XXX better docs, but: it's to get monotonic results
    // XXX is it safe to say "if there's an in flight query, just use its
    //     results"? I don't think so but should consider that
    self._oplogLastEntryConnection = new MongoConnection(self._oplogUrl, {
      maxPoolSize: 1,
      minPoolSize: 1
    });

    // Now, make sure that there actually is a repl set here. If not, oplog
    // tailing won't ever find anything!
    // More on the isMasterDoc
    // https://docs.mongodb.com/manual/reference/command/isMaster/
    var f = new Future();
    self._oplogLastEntryConnection.db.admin().command({
      ismaster: 1
    }, f.resolver());
    var isMasterDoc = f.wait();
    if (!(isMasterDoc && isMasterDoc.setName)) {
      throw Error("$MONGO_OPLOG_URL must be set to the 'local' database of " + "a Mongo replica set");
    }

    // Find the last oplog entry.
    var lastOplogEntry = self._oplogLastEntryConnection.findOne(OPLOG_COLLECTION, {}, {
      sort: {
        $natural: -1
      },
      projection: {
        ts: 1
      }
    });
    var oplogSelector = _.clone(self._baseOplogSelector);
    if (lastOplogEntry) {
      // Start after the last entry that currently exists.
      oplogSelector.ts = {
        $gt: lastOplogEntry.ts
      };
      // If there are any calls to callWhenProcessedLatest before any other
      // oplog entries show up, allow callWhenProcessedLatest to call its
      // callback immediately.
      self._lastProcessedTS = lastOplogEntry.ts;
    }
    var cursorDescription = new CursorDescription(OPLOG_COLLECTION, oplogSelector, {
      tailable: true
    });

    // Start tailing the oplog.
    //
    // We restart the low-level oplog query every 30 seconds if we didn't get a
    // doc. This is a workaround for #8598: the Node Mongo driver has at least
    // one bug that can lead to query callbacks never getting called (even with
    // an error) when leadership failover occur.
    self._tailHandle = self._oplogTailConnection.tail(cursorDescription, function (doc) {
      self._entryQueue.push(doc);
      self._maybeStartWorker();
    }, TAIL_TIMEOUT);
    self._readyFuture.return();
  },
  _maybeStartWorker: function () {
    var self = this;
    if (self._workerActive) return;
    self._workerActive = true;
    Meteor.defer(function () {
      // May be called recursively in case of transactions.
      function handleDoc(doc) {
        if (doc.ns === "admin.$cmd") {
          if (doc.o.applyOps) {
            // This was a successful transaction, so we need to apply the
            // operations that were involved.
            let nextTimestamp = doc.ts;
            doc.o.applyOps.forEach(op => {
              // See https://github.com/meteor/meteor/issues/10420.
              if (!op.ts) {
                op.ts = nextTimestamp;
                nextTimestamp = nextTimestamp.add(Long.ONE);
              }
              handleDoc(op);
            });
            return;
          }
          throw new Error("Unknown command " + EJSON.stringify(doc));
        }
        const trigger = {
          dropCollection: false,
          dropDatabase: false,
          op: doc
        };
        if (typeof doc.ns === "string" && doc.ns.startsWith(self._dbName + ".")) {
          trigger.collection = doc.ns.slice(self._dbName.length + 1);
        }

        // Is it a special command and the collection name is hidden
        // somewhere in operator?
        if (trigger.collection === "$cmd") {
          if (doc.o.dropDatabase) {
            delete trigger.collection;
            trigger.dropDatabase = true;
          } else if (_.has(doc.o, "drop")) {
            trigger.collection = doc.o.drop;
            trigger.dropCollection = true;
            trigger.id = null;
          } else if ("create" in doc.o && "idIndex" in doc.o) {
            // A collection got implicitly created within a transaction. There's
            // no need to do anything about it.
          } else {
            throw Error("Unknown command " + EJSON.stringify(doc));
          }
        } else {
          // All other ops have an id.
          trigger.id = idForOp(doc);
        }
        self._crossbar.fire(trigger);
      }
      try {
        while (!self._stopped && !self._entryQueue.isEmpty()) {
          // Are we too far behind? Just tell our observers that they need to
          // repoll, and drop our queue.
          if (self._entryQueue.length > TOO_FAR_BEHIND) {
            var lastEntry = self._entryQueue.pop();
            self._entryQueue.clear();
            self._onSkippedEntriesHook.each(function (callback) {
              callback();
              return true;
            });

            // Free any waitUntilCaughtUp() calls that were waiting for us to
            // pass something that we just skipped.
            self._setLastProcessedTS(lastEntry.ts);
            continue;
          }
          const doc = self._entryQueue.shift();

          // Fire trigger(s) for this doc.
          handleDoc(doc);

          // Now that we've processed this operation, process pending
          // sequencers.
          if (doc.ts) {
            self._setLastProcessedTS(doc.ts);
          } else {
            throw Error("oplog entry without ts: " + EJSON.stringify(doc));
          }
        }
      } finally {
        self._workerActive = false;
      }
    });
  },
  _setLastProcessedTS: function (ts) {
    var self = this;
    self._lastProcessedTS = ts;
    while (!_.isEmpty(self._catchingUpFutures) && self._catchingUpFutures[0].ts.lessThanOrEqual(self._lastProcessedTS)) {
      var sequencer = self._catchingUpFutures.shift();
      sequencer.future.return();
    }
  },
  //Methods used on tests to dinamically change TOO_FAR_BEHIND
  _defineTooFarBehind: function (value) {
    TOO_FAR_BEHIND = value;
  },
  _resetTooFarBehind: function () {
    TOO_FAR_BEHIND = process.env.METEOR_OPLOG_TOO_FAR_BEHIND || 2000;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observe_multiplex.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/observe_multiplex.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const _excluded = ["_id"];
let _objectWithoutProperties;
module.link("@babel/runtime/helpers/objectWithoutProperties", {
  default(v) {
    _objectWithoutProperties = v;
  }
}, 0);
var Future = Npm.require('fibers/future');
ObserveMultiplexer = function (options) {
  var self = this;
  if (!options || !_.has(options, 'ordered')) throw Error("must specified ordered");
  Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-multiplexers", 1);
  self._ordered = options.ordered;
  self._onStop = options.onStop || function () {};
  self._queue = new Meteor._SynchronousQueue();
  self._handles = {};
  self._readyFuture = new Future();
  self._cache = new LocalCollection._CachingChangeObserver({
    ordered: options.ordered
  });
  // Number of addHandleAndSendInitialAdds tasks scheduled but not yet
  // running. removeHandle uses this to know if it's time to call the onStop
  // callback.
  self._addHandleTasksScheduledButNotPerformed = 0;
  _.each(self.callbackNames(), function (callbackName) {
    self[callbackName] = function /* ... */
    () {
      self._applyCallback(callbackName, _.toArray(arguments));
    };
  });
};
_.extend(ObserveMultiplexer.prototype, {
  addHandleAndSendInitialAdds: function (handle) {
    var self = this;

    // Check this before calling runTask (even though runTask does the same
    // check) so that we don't leak an ObserveMultiplexer on error by
    // incrementing _addHandleTasksScheduledButNotPerformed and never
    // decrementing it.
    if (!self._queue.safeToRunTask()) throw new Error("Can't call observeChanges from an observe callback on the same query");
    ++self._addHandleTasksScheduledButNotPerformed;
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-handles", 1);
    self._queue.runTask(function () {
      self._handles[handle._id] = handle;
      // Send out whatever adds we have so far (whether or not we the
      // multiplexer is ready).
      self._sendAdds(handle);
      --self._addHandleTasksScheduledButNotPerformed;
    });
    // *outside* the task, since otherwise we'd deadlock
    self._readyFuture.wait();
  },
  // Remove an observe handle. If it was the last observe handle, call the
  // onStop callback; you cannot add any more observe handles after this.
  //
  // This is not synchronized with polls and handle additions: this means that
  // you can safely call it from within an observe callback, but it also means
  // that we have to be careful when we iterate over _handles.
  removeHandle: function (id) {
    var self = this;

    // This should not be possible: you can only call removeHandle by having
    // access to the ObserveHandle, which isn't returned to user code until the
    // multiplex is ready.
    if (!self._ready()) throw new Error("Can't remove handles until the multiplex is ready");
    delete self._handles[id];
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-handles", -1);
    if (_.isEmpty(self._handles) && self._addHandleTasksScheduledButNotPerformed === 0) {
      self._stop();
    }
  },
  _stop: function (options) {
    var self = this;
    options = options || {};

    // It shouldn't be possible for us to stop when all our handles still
    // haven't been returned from observeChanges!
    if (!self._ready() && !options.fromQueryError) throw Error("surprising _stop: not ready");

    // Call stop callback (which kills the underlying process which sends us
    // callbacks and removes us from the connection's dictionary).
    self._onStop();
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-multiplexers", -1);

    // Cause future addHandleAndSendInitialAdds calls to throw (but the onStop
    // callback should make our connection forget about us).
    self._handles = null;
  },
  // Allows all addHandleAndSendInitialAdds calls to return, once all preceding
  // adds have been processed. Does not block.
  ready: function () {
    var self = this;
    self._queue.queueTask(function () {
      if (self._ready()) throw Error("can't make ObserveMultiplex ready twice!");
      self._readyFuture.return();
    });
  },
  // If trying to execute the query results in an error, call this. This is
  // intended for permanent errors, not transient network errors that could be
  // fixed. It should only be called before ready(), because if you called ready
  // that meant that you managed to run the query once. It will stop this
  // ObserveMultiplex and cause addHandleAndSendInitialAdds calls (and thus
  // observeChanges calls) to throw the error.
  queryError: function (err) {
    var self = this;
    self._queue.runTask(function () {
      if (self._ready()) throw Error("can't claim query has an error after it worked!");
      self._stop({
        fromQueryError: true
      });
      self._readyFuture.throw(err);
    });
  },
  // Calls "cb" once the effects of all "ready", "addHandleAndSendInitialAdds"
  // and observe callbacks which came before this call have been propagated to
  // all handles. "ready" must have already been called on this multiplexer.
  onFlush: function (cb) {
    var self = this;
    self._queue.queueTask(function () {
      if (!self._ready()) throw Error("only call onFlush on a multiplexer that will be ready");
      cb();
    });
  },
  callbackNames: function () {
    var self = this;
    if (self._ordered) return ["addedBefore", "changed", "movedBefore", "removed"];else return ["added", "changed", "removed"];
  },
  _ready: function () {
    return this._readyFuture.isResolved();
  },
  _applyCallback: function (callbackName, args) {
    var self = this;
    self._queue.queueTask(function () {
      // If we stopped in the meantime, do nothing.
      if (!self._handles) return;

      // First, apply the change to the cache.
      self._cache.applyChange[callbackName].apply(null, args);

      // If we haven't finished the initial adds, then we should only be getting
      // adds.
      if (!self._ready() && callbackName !== 'added' && callbackName !== 'addedBefore') {
        throw new Error("Got " + callbackName + " during initial adds");
      }

      // Now multiplex the callbacks out to all observe handles. It's OK if
      // these calls yield; since we're inside a task, no other use of our queue
      // can continue until these are done. (But we do have to be careful to not
      // use a handle that got removed, because removeHandle does not use the
      // queue; thus, we iterate over an array of keys that we control.)
      _.each(_.keys(self._handles), function (handleId) {
        var handle = self._handles && self._handles[handleId];
        if (!handle) return;
        var callback = handle['_' + callbackName];
        // clone arguments so that callbacks can mutate their arguments
        callback && callback.apply(null, handle.nonMutatingCallbacks ? args : EJSON.clone(args));
      });
    });
  },
  // Sends initial adds to a handle. It should only be called from within a task
  // (the task that is processing the addHandleAndSendInitialAdds call). It
  // synchronously invokes the handle's added or addedBefore; there's no need to
  // flush the queue afterwards to ensure that the callbacks get out.
  _sendAdds: function (handle) {
    var self = this;
    if (self._queue.safeToRunTask()) throw Error("_sendAdds may only be called from within a task!");
    var add = self._ordered ? handle._addedBefore : handle._added;
    if (!add) return;
    // note: docs may be an _IdMap or an OrderedDict
    self._cache.docs.forEach(function (doc, id) {
      if (!_.has(self._handles, handle._id)) throw Error("handle got removed before sending initial adds!");
      const _ref = handle.nonMutatingCallbacks ? doc : EJSON.clone(doc),
        {
          _id
        } = _ref,
        fields = _objectWithoutProperties(_ref, _excluded);
      if (self._ordered) add(id, fields, null); // we're going in order, so add at end
      else add(id, fields);
    });
  }
});
var nextObserveHandleId = 1;

// When the callbacks do not mutate the arguments, we can skip a lot of data clones
ObserveHandle = function (multiplexer, callbacks) {
  let nonMutatingCallbacks = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
  var self = this;
  // The end user is only supposed to call stop().  The other fields are
  // accessible to the multiplexer, though.
  self._multiplexer = multiplexer;
  _.each(multiplexer.callbackNames(), function (name) {
    if (callbacks[name]) {
      self['_' + name] = callbacks[name];
    } else if (name === "addedBefore" && callbacks.added) {
      // Special case: if you specify "added" and "movedBefore", you get an
      // ordered observe where for some reason you don't get ordering data on
      // the adds.  I dunno, we wrote tests for it, there must have been a
      // reason.
      self._addedBefore = function (id, fields, before) {
        callbacks.added(id, fields);
      };
    }
  });
  self._stopped = false;
  self._id = nextObserveHandleId++;
  self.nonMutatingCallbacks = nonMutatingCallbacks;
};
ObserveHandle.prototype.stop = function () {
  var self = this;
  if (self._stopped) return;
  self._stopped = true;
  self._multiplexer.removeHandle(self._id);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"doc_fetcher.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/doc_fetcher.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DocFetcher: () => DocFetcher
});
var Fiber = Npm.require('fibers');
class DocFetcher {
  constructor(mongoConnection) {
    this._mongoConnection = mongoConnection;
    // Map from op -> [callback]
    this._callbacksForOp = new Map();
  }

  // Fetches document "id" from collectionName, returning it or null if not
  // found.
  //
  // If you make multiple calls to fetch() with the same op reference,
  // DocFetcher may assume that they all return the same document. (It does
  // not check to see if collectionName/id match.)
  //
  // You may assume that callback is never called synchronously (and in fact
  // OplogObserveDriver does so).
  fetch(collectionName, id, op, callback) {
    const self = this;
    check(collectionName, String);
    check(op, Object);

    // If there's already an in-progress fetch for this cache key, yield until
    // it's done and return whatever it returns.
    if (self._callbacksForOp.has(op)) {
      self._callbacksForOp.get(op).push(callback);
      return;
    }
    const callbacks = [callback];
    self._callbacksForOp.set(op, callbacks);
    Fiber(function () {
      try {
        var doc = self._mongoConnection.findOne(collectionName, {
          _id: id
        }) || null;
        // Return doc to all relevant callbacks. Note that this array can
        // continue to grow during callback excecution.
        while (callbacks.length > 0) {
          // Clone the document so that the various calls to fetch don't return
          // objects that are intertwingled with each other. Clone before
          // popping the future, so that if clone throws, the error gets passed
          // to the next callback.
          callbacks.pop()(null, EJSON.clone(doc));
        }
      } catch (e) {
        while (callbacks.length > 0) {
          callbacks.pop()(e);
        }
      } finally {
        // XXX consider keeping the doc around for a period of time before
        // removing from the cache
        self._callbacksForOp.delete(op);
      }
    }).run();
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"polling_observe_driver.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/polling_observe_driver.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var POLLING_THROTTLE_MS = +process.env.METEOR_POLLING_THROTTLE_MS || 50;
var POLLING_INTERVAL_MS = +process.env.METEOR_POLLING_INTERVAL_MS || 10 * 1000;
PollingObserveDriver = function (options) {
  var self = this;
  self._cursorDescription = options.cursorDescription;
  self._mongoHandle = options.mongoHandle;
  self._ordered = options.ordered;
  self._multiplexer = options.multiplexer;
  self._stopCallbacks = [];
  self._stopped = false;
  self._synchronousCursor = self._mongoHandle._createSynchronousCursor(self._cursorDescription);

  // previous results snapshot.  on each poll cycle, diffs against
  // results drives the callbacks.
  self._results = null;

  // The number of _pollMongo calls that have been added to self._taskQueue but
  // have not started running. Used to make sure we never schedule more than one
  // _pollMongo (other than possibly the one that is currently running). It's
  // also used by _suspendPolling to pretend there's a poll scheduled. Usually,
  // it's either 0 (for "no polls scheduled other than maybe one currently
  // running") or 1 (for "a poll scheduled that isn't running yet"), but it can
  // also be 2 if incremented by _suspendPolling.
  self._pollsScheduledButNotStarted = 0;
  self._pendingWrites = []; // people to notify when polling completes

  // Make sure to create a separately throttled function for each
  // PollingObserveDriver object.
  self._ensurePollIsScheduled = _.throttle(self._unthrottledEnsurePollIsScheduled, self._cursorDescription.options.pollingThrottleMs || POLLING_THROTTLE_MS /* ms */);

  // XXX figure out if we still need a queue
  self._taskQueue = new Meteor._SynchronousQueue();
  var listenersHandle = listenAll(self._cursorDescription, function (notification) {
    // When someone does a transaction that might affect us, schedule a poll
    // of the database. If that transaction happens inside of a write fence,
    // block the fence until we've polled and notified observers.
    var fence = DDPServer._CurrentWriteFence.get();
    if (fence) self._pendingWrites.push(fence.beginWrite());
    // Ensure a poll is scheduled... but if we already know that one is,
    // don't hit the throttled _ensurePollIsScheduled function (which might
    // lead to us calling it unnecessarily in <pollingThrottleMs> ms).
    if (self._pollsScheduledButNotStarted === 0) self._ensurePollIsScheduled();
  });
  self._stopCallbacks.push(function () {
    listenersHandle.stop();
  });

  // every once and a while, poll even if we don't think we're dirty, for
  // eventual consistency with database writes from outside the Meteor
  // universe.
  //
  // For testing, there's an undocumented callback argument to observeChanges
  // which disables time-based polling and gets called at the beginning of each
  // poll.
  if (options._testOnlyPollCallback) {
    self._testOnlyPollCallback = options._testOnlyPollCallback;
  } else {
    var pollingInterval = self._cursorDescription.options.pollingIntervalMs || self._cursorDescription.options._pollingInterval ||
    // COMPAT with 1.2
    POLLING_INTERVAL_MS;
    var intervalHandle = Meteor.setInterval(_.bind(self._ensurePollIsScheduled, self), pollingInterval);
    self._stopCallbacks.push(function () {
      Meteor.clearInterval(intervalHandle);
    });
  }

  // Make sure we actually poll soon!
  self._unthrottledEnsurePollIsScheduled();
  Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-polling", 1);
};
_.extend(PollingObserveDriver.prototype, {
  // This is always called through _.throttle (except once at startup).
  _unthrottledEnsurePollIsScheduled: function () {
    var self = this;
    if (self._pollsScheduledButNotStarted > 0) return;
    ++self._pollsScheduledButNotStarted;
    self._taskQueue.queueTask(function () {
      self._pollMongo();
    });
  },
  // test-only interface for controlling polling.
  //
  // _suspendPolling blocks until any currently running and scheduled polls are
  // done, and prevents any further polls from being scheduled. (new
  // ObserveHandles can be added and receive their initial added callbacks,
  // though.)
  //
  // _resumePolling immediately polls, and allows further polls to occur.
  _suspendPolling: function () {
    var self = this;
    // Pretend that there's another poll scheduled (which will prevent
    // _ensurePollIsScheduled from queueing any more polls).
    ++self._pollsScheduledButNotStarted;
    // Now block until all currently running or scheduled polls are done.
    self._taskQueue.runTask(function () {});

    // Confirm that there is only one "poll" (the fake one we're pretending to
    // have) scheduled.
    if (self._pollsScheduledButNotStarted !== 1) throw new Error("_pollsScheduledButNotStarted is " + self._pollsScheduledButNotStarted);
  },
  _resumePolling: function () {
    var self = this;
    // We should be in the same state as in the end of _suspendPolling.
    if (self._pollsScheduledButNotStarted !== 1) throw new Error("_pollsScheduledButNotStarted is " + self._pollsScheduledButNotStarted);
    // Run a poll synchronously (which will counteract the
    // ++_pollsScheduledButNotStarted from _suspendPolling).
    self._taskQueue.runTask(function () {
      self._pollMongo();
    });
  },
  _pollMongo: function () {
    var self = this;
    --self._pollsScheduledButNotStarted;
    if (self._stopped) return;
    var first = false;
    var newResults;
    var oldResults = self._results;
    if (!oldResults) {
      first = true;
      // XXX maybe use OrderedDict instead?
      oldResults = self._ordered ? [] : new LocalCollection._IdMap();
    }
    self._testOnlyPollCallback && self._testOnlyPollCallback();

    // Save the list of pending writes which this round will commit.
    var writesForCycle = self._pendingWrites;
    self._pendingWrites = [];

    // Get the new query results. (This yields.)
    try {
      newResults = self._synchronousCursor.getRawObjects(self._ordered);
    } catch (e) {
      if (first && typeof e.code === 'number') {
        // This is an error document sent to us by mongod, not a connection
        // error generated by the client. And we've never seen this query work
        // successfully. Probably it's a bad selector or something, so we should
        // NOT retry. Instead, we should halt the observe (which ends up calling
        // `stop` on us).
        self._multiplexer.queryError(new Error("Exception while polling query " + JSON.stringify(self._cursorDescription) + ": " + e.message));
        return;
      }

      // getRawObjects can throw if we're having trouble talking to the
      // database.  That's fine --- we will repoll later anyway. But we should
      // make sure not to lose track of this cycle's writes.
      // (It also can throw if there's just something invalid about this query;
      // unfortunately the ObserveDriver API doesn't provide a good way to
      // "cancel" the observe from the inside in this case.
      Array.prototype.push.apply(self._pendingWrites, writesForCycle);
      Meteor._debug("Exception while polling query " + JSON.stringify(self._cursorDescription), e);
      return;
    }

    // Run diffs.
    if (!self._stopped) {
      LocalCollection._diffQueryChanges(self._ordered, oldResults, newResults, self._multiplexer);
    }

    // Signals the multiplexer to allow all observeChanges calls that share this
    // multiplexer to return. (This happens asynchronously, via the
    // multiplexer's queue.)
    if (first) self._multiplexer.ready();

    // Replace self._results atomically.  (This assignment is what makes `first`
    // stay through on the next cycle, so we've waited until after we've
    // committed to ready-ing the multiplexer.)
    self._results = newResults;

    // Once the ObserveMultiplexer has processed everything we've done in this
    // round, mark all the writes which existed before this call as
    // commmitted. (If new writes have shown up in the meantime, there'll
    // already be another _pollMongo task scheduled.)
    self._multiplexer.onFlush(function () {
      _.each(writesForCycle, function (w) {
        w.committed();
      });
    });
  },
  stop: function () {
    var self = this;
    self._stopped = true;
    _.each(self._stopCallbacks, function (c) {
      c();
    });
    // Release any write fences that are waiting on us.
    _.each(self._pendingWrites, function (w) {
      w.committed();
    });
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-polling", -1);
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oplog_observe_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/oplog_observe_driver.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let oplogV2V1Converter;
module.link("./oplog_v2_converter", {
  oplogV2V1Converter(v) {
    oplogV2V1Converter = v;
  }
}, 0);
var Future = Npm.require('fibers/future');
var PHASE = {
  QUERYING: "QUERYING",
  FETCHING: "FETCHING",
  STEADY: "STEADY"
};

// Exception thrown by _needToPollQuery which unrolls the stack up to the
// enclosing call to finishIfNeedToPollQuery.
var SwitchedToQuery = function () {};
var finishIfNeedToPollQuery = function (f) {
  return function () {
    try {
      f.apply(this, arguments);
    } catch (e) {
      if (!(e instanceof SwitchedToQuery)) throw e;
    }
  };
};
var currentId = 0;

// OplogObserveDriver is an alternative to PollingObserveDriver which follows
// the Mongo operation log instead of just re-polling the query. It obeys the
// same simple interface: constructing it starts sending observeChanges
// callbacks (and a ready() invocation) to the ObserveMultiplexer, and you stop
// it by calling the stop() method.
OplogObserveDriver = function (options) {
  var self = this;
  self._usesOplog = true; // tests look at this

  self._id = currentId;
  currentId++;
  self._cursorDescription = options.cursorDescription;
  self._mongoHandle = options.mongoHandle;
  self._multiplexer = options.multiplexer;
  if (options.ordered) {
    throw Error("OplogObserveDriver only supports unordered observeChanges");
  }
  var sorter = options.sorter;
  // We don't support $near and other geo-queries so it's OK to initialize the
  // comparator only once in the constructor.
  var comparator = sorter && sorter.getComparator();
  if (options.cursorDescription.options.limit) {
    // There are several properties ordered driver implements:
    // - _limit is a positive number
    // - _comparator is a function-comparator by which the query is ordered
    // - _unpublishedBuffer is non-null Min/Max Heap,
    //                      the empty buffer in STEADY phase implies that the
    //                      everything that matches the queries selector fits
    //                      into published set.
    // - _published - Max Heap (also implements IdMap methods)

    var heapOptions = {
      IdMap: LocalCollection._IdMap
    };
    self._limit = self._cursorDescription.options.limit;
    self._comparator = comparator;
    self._sorter = sorter;
    self._unpublishedBuffer = new MinMaxHeap(comparator, heapOptions);
    // We need something that can find Max value in addition to IdMap interface
    self._published = new MaxHeap(comparator, heapOptions);
  } else {
    self._limit = 0;
    self._comparator = null;
    self._sorter = null;
    self._unpublishedBuffer = null;
    self._published = new LocalCollection._IdMap();
  }

  // Indicates if it is safe to insert a new document at the end of the buffer
  // for this query. i.e. it is known that there are no documents matching the
  // selector those are not in published or buffer.
  self._safeAppendToBuffer = false;
  self._stopped = false;
  self._stopHandles = [];
  Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-oplog", 1);
  self._registerPhaseChange(PHASE.QUERYING);
  self._matcher = options.matcher;
  // we are now using projection, not fields in the cursor description even if you pass {fields}
  // in the cursor construction
  var projection = self._cursorDescription.options.fields || self._cursorDescription.options.projection || {};
  self._projectionFn = LocalCollection._compileProjection(projection);
  // Projection function, result of combining important fields for selector and
  // existing fields projection
  self._sharedProjection = self._matcher.combineIntoProjection(projection);
  if (sorter) self._sharedProjection = sorter.combineIntoProjection(self._sharedProjection);
  self._sharedProjectionFn = LocalCollection._compileProjection(self._sharedProjection);
  self._needToFetch = new LocalCollection._IdMap();
  self._currentlyFetching = null;
  self._fetchGeneration = 0;
  self._requeryWhenDoneThisQuery = false;
  self._writesToCommitWhenWeReachSteady = [];

  // If the oplog handle tells us that it skipped some entries (because it got
  // behind, say), re-poll.
  self._stopHandles.push(self._mongoHandle._oplogHandle.onSkippedEntries(finishIfNeedToPollQuery(function () {
    self._needToPollQuery();
  })));
  forEachTrigger(self._cursorDescription, function (trigger) {
    self._stopHandles.push(self._mongoHandle._oplogHandle.onOplogEntry(trigger, function (notification) {
      Meteor._noYieldsAllowed(finishIfNeedToPollQuery(function () {
        var op = notification.op;
        if (notification.dropCollection || notification.dropDatabase) {
          // Note: this call is not allowed to block on anything (especially
          // on waiting for oplog entries to catch up) because that will block
          // onOplogEntry!
          self._needToPollQuery();
        } else {
          // All other operators should be handled depending on phase
          if (self._phase === PHASE.QUERYING) {
            self._handleOplogEntryQuerying(op);
          } else {
            self._handleOplogEntrySteadyOrFetching(op);
          }
        }
      }));
    }));
  });

  // XXX ordering w.r.t. everything else?
  self._stopHandles.push(listenAll(self._cursorDescription, function (notification) {
    // If we're not in a pre-fire write fence, we don't have to do anything.
    var fence = DDPServer._CurrentWriteFence.get();
    if (!fence || fence.fired) return;
    if (fence._oplogObserveDrivers) {
      fence._oplogObserveDrivers[self._id] = self;
      return;
    }
    fence._oplogObserveDrivers = {};
    fence._oplogObserveDrivers[self._id] = self;
    fence.onBeforeFire(function () {
      var drivers = fence._oplogObserveDrivers;
      delete fence._oplogObserveDrivers;

      // This fence cannot fire until we've caught up to "this point" in the
      // oplog, and all observers made it back to the steady state.
      self._mongoHandle._oplogHandle.waitUntilCaughtUp();
      _.each(drivers, function (driver) {
        if (driver._stopped) return;
        var write = fence.beginWrite();
        if (driver._phase === PHASE.STEADY) {
          // Make sure that all of the callbacks have made it through the
          // multiplexer and been delivered to ObserveHandles before committing
          // writes.
          driver._multiplexer.onFlush(function () {
            write.committed();
          });
        } else {
          driver._writesToCommitWhenWeReachSteady.push(write);
        }
      });
    });
  }));

  // When Mongo fails over, we need to repoll the query, in case we processed an
  // oplog entry that got rolled back.
  self._stopHandles.push(self._mongoHandle._onFailover(finishIfNeedToPollQuery(function () {
    self._needToPollQuery();
  })));

  // Give _observeChanges a chance to add the new ObserveHandle to our
  // multiplexer, so that the added calls get streamed.
  Meteor.defer(finishIfNeedToPollQuery(function () {
    self._runInitialQuery();
  }));
};
_.extend(OplogObserveDriver.prototype, {
  _addPublished: function (id, doc) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      var fields = _.clone(doc);
      delete fields._id;
      self._published.set(id, self._sharedProjectionFn(doc));
      self._multiplexer.added(id, self._projectionFn(fields));

      // After adding this document, the published set might be overflowed
      // (exceeding capacity specified by limit). If so, push the maximum
      // element to the buffer, we might want to save it in memory to reduce the
      // amount of Mongo lookups in the future.
      if (self._limit && self._published.size() > self._limit) {
        // XXX in theory the size of published is no more than limit+1
        if (self._published.size() !== self._limit + 1) {
          throw new Error("After adding to published, " + (self._published.size() - self._limit) + " documents are overflowing the set");
        }
        var overflowingDocId = self._published.maxElementId();
        var overflowingDoc = self._published.get(overflowingDocId);
        if (EJSON.equals(overflowingDocId, id)) {
          throw new Error("The document just added is overflowing the published set");
        }
        self._published.remove(overflowingDocId);
        self._multiplexer.removed(overflowingDocId);
        self._addBuffered(overflowingDocId, overflowingDoc);
      }
    });
  },
  _removePublished: function (id) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._published.remove(id);
      self._multiplexer.removed(id);
      if (!self._limit || self._published.size() === self._limit) return;
      if (self._published.size() > self._limit) throw Error("self._published got too big");

      // OK, we are publishing less than the limit. Maybe we should look in the
      // buffer to find the next element past what we were publishing before.

      if (!self._unpublishedBuffer.empty()) {
        // There's something in the buffer; move the first thing in it to
        // _published.
        var newDocId = self._unpublishedBuffer.minElementId();
        var newDoc = self._unpublishedBuffer.get(newDocId);
        self._removeBuffered(newDocId);
        self._addPublished(newDocId, newDoc);
        return;
      }

      // There's nothing in the buffer.  This could mean one of a few things.

      // (a) We could be in the middle of re-running the query (specifically, we
      // could be in _publishNewResults). In that case, _unpublishedBuffer is
      // empty because we clear it at the beginning of _publishNewResults. In
      // this case, our caller already knows the entire answer to the query and
      // we don't need to do anything fancy here.  Just return.
      if (self._phase === PHASE.QUERYING) return;

      // (b) We're pretty confident that the union of _published and
      // _unpublishedBuffer contain all documents that match selector. Because
      // _unpublishedBuffer is empty, that means we're confident that _published
      // contains all documents that match selector. So we have nothing to do.
      if (self._safeAppendToBuffer) return;

      // (c) Maybe there are other documents out there that should be in our
      // buffer. But in that case, when we emptied _unpublishedBuffer in
      // _removeBuffered, we should have called _needToPollQuery, which will
      // either put something in _unpublishedBuffer or set _safeAppendToBuffer
      // (or both), and it will put us in QUERYING for that whole time. So in
      // fact, we shouldn't be able to get here.

      throw new Error("Buffer inexplicably empty");
    });
  },
  _changePublished: function (id, oldDoc, newDoc) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._published.set(id, self._sharedProjectionFn(newDoc));
      var projectedNew = self._projectionFn(newDoc);
      var projectedOld = self._projectionFn(oldDoc);
      var changed = DiffSequence.makeChangedFields(projectedNew, projectedOld);
      if (!_.isEmpty(changed)) self._multiplexer.changed(id, changed);
    });
  },
  _addBuffered: function (id, doc) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._unpublishedBuffer.set(id, self._sharedProjectionFn(doc));

      // If something is overflowing the buffer, we just remove it from cache
      if (self._unpublishedBuffer.size() > self._limit) {
        var maxBufferedId = self._unpublishedBuffer.maxElementId();
        self._unpublishedBuffer.remove(maxBufferedId);

        // Since something matching is removed from cache (both published set and
        // buffer), set flag to false
        self._safeAppendToBuffer = false;
      }
    });
  },
  // Is called either to remove the doc completely from matching set or to move
  // it to the published set later.
  _removeBuffered: function (id) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._unpublishedBuffer.remove(id);
      // To keep the contract "buffer is never empty in STEADY phase unless the
      // everything matching fits into published" true, we poll everything as
      // soon as we see the buffer becoming empty.
      if (!self._unpublishedBuffer.size() && !self._safeAppendToBuffer) self._needToPollQuery();
    });
  },
  // Called when a document has joined the "Matching" results set.
  // Takes responsibility of keeping _unpublishedBuffer in sync with _published
  // and the effect of limit enforced.
  _addMatching: function (doc) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      var id = doc._id;
      if (self._published.has(id)) throw Error("tried to add something already published " + id);
      if (self._limit && self._unpublishedBuffer.has(id)) throw Error("tried to add something already existed in buffer " + id);
      var limit = self._limit;
      var comparator = self._comparator;
      var maxPublished = limit && self._published.size() > 0 ? self._published.get(self._published.maxElementId()) : null;
      var maxBuffered = limit && self._unpublishedBuffer.size() > 0 ? self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId()) : null;
      // The query is unlimited or didn't publish enough documents yet or the
      // new document would fit into published set pushing the maximum element
      // out, then we need to publish the doc.
      var toPublish = !limit || self._published.size() < limit || comparator(doc, maxPublished) < 0;

      // Otherwise we might need to buffer it (only in case of limited query).
      // Buffering is allowed if the buffer is not filled up yet and all
      // matching docs are either in the published set or in the buffer.
      var canAppendToBuffer = !toPublish && self._safeAppendToBuffer && self._unpublishedBuffer.size() < limit;

      // Or if it is small enough to be safely inserted to the middle or the
      // beginning of the buffer.
      var canInsertIntoBuffer = !toPublish && maxBuffered && comparator(doc, maxBuffered) <= 0;
      var toBuffer = canAppendToBuffer || canInsertIntoBuffer;
      if (toPublish) {
        self._addPublished(id, doc);
      } else if (toBuffer) {
        self._addBuffered(id, doc);
      } else {
        // dropping it and not saving to the cache
        self._safeAppendToBuffer = false;
      }
    });
  },
  // Called when a document leaves the "Matching" results set.
  // Takes responsibility of keeping _unpublishedBuffer in sync with _published
  // and the effect of limit enforced.
  _removeMatching: function (id) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      if (!self._published.has(id) && !self._limit) throw Error("tried to remove something matching but not cached " + id);
      if (self._published.has(id)) {
        self._removePublished(id);
      } else if (self._unpublishedBuffer.has(id)) {
        self._removeBuffered(id);
      }
    });
  },
  _handleDoc: function (id, newDoc) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      var matchesNow = newDoc && self._matcher.documentMatches(newDoc).result;
      var publishedBefore = self._published.has(id);
      var bufferedBefore = self._limit && self._unpublishedBuffer.has(id);
      var cachedBefore = publishedBefore || bufferedBefore;
      if (matchesNow && !cachedBefore) {
        self._addMatching(newDoc);
      } else if (cachedBefore && !matchesNow) {
        self._removeMatching(id);
      } else if (cachedBefore && matchesNow) {
        var oldDoc = self._published.get(id);
        var comparator = self._comparator;
        var minBuffered = self._limit && self._unpublishedBuffer.size() && self._unpublishedBuffer.get(self._unpublishedBuffer.minElementId());
        var maxBuffered;
        if (publishedBefore) {
          // Unlimited case where the document stays in published once it
          // matches or the case when we don't have enough matching docs to
          // publish or the changed but matching doc will stay in published
          // anyways.
          //
          // XXX: We rely on the emptiness of buffer. Be sure to maintain the
          // fact that buffer can't be empty if there are matching documents not
          // published. Notably, we don't want to schedule repoll and continue
          // relying on this property.
          var staysInPublished = !self._limit || self._unpublishedBuffer.size() === 0 || comparator(newDoc, minBuffered) <= 0;
          if (staysInPublished) {
            self._changePublished(id, oldDoc, newDoc);
          } else {
            // after the change doc doesn't stay in the published, remove it
            self._removePublished(id);
            // but it can move into buffered now, check it
            maxBuffered = self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId());
            var toBuffer = self._safeAppendToBuffer || maxBuffered && comparator(newDoc, maxBuffered) <= 0;
            if (toBuffer) {
              self._addBuffered(id, newDoc);
            } else {
              // Throw away from both published set and buffer
              self._safeAppendToBuffer = false;
            }
          }
        } else if (bufferedBefore) {
          oldDoc = self._unpublishedBuffer.get(id);
          // remove the old version manually instead of using _removeBuffered so
          // we don't trigger the querying immediately.  if we end this block
          // with the buffer empty, we will need to trigger the query poll
          // manually too.
          self._unpublishedBuffer.remove(id);
          var maxPublished = self._published.get(self._published.maxElementId());
          maxBuffered = self._unpublishedBuffer.size() && self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId());

          // the buffered doc was updated, it could move to published
          var toPublish = comparator(newDoc, maxPublished) < 0;

          // or stays in buffer even after the change
          var staysInBuffer = !toPublish && self._safeAppendToBuffer || !toPublish && maxBuffered && comparator(newDoc, maxBuffered) <= 0;
          if (toPublish) {
            self._addPublished(id, newDoc);
          } else if (staysInBuffer) {
            // stays in buffer but changes
            self._unpublishedBuffer.set(id, newDoc);
          } else {
            // Throw away from both published set and buffer
            self._safeAppendToBuffer = false;
            // Normally this check would have been done in _removeBuffered but
            // we didn't use it, so we need to do it ourself now.
            if (!self._unpublishedBuffer.size()) {
              self._needToPollQuery();
            }
          }
        } else {
          throw new Error("cachedBefore implies either of publishedBefore or bufferedBefore is true.");
        }
      }
    });
  },
  _fetchModifiedDocuments: function () {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._registerPhaseChange(PHASE.FETCHING);
      // Defer, because nothing called from the oplog entry handler may yield,
      // but fetch() yields.
      Meteor.defer(finishIfNeedToPollQuery(function () {
        while (!self._stopped && !self._needToFetch.empty()) {
          if (self._phase === PHASE.QUERYING) {
            // While fetching, we decided to go into QUERYING mode, and then we
            // saw another oplog entry, so _needToFetch is not empty. But we
            // shouldn't fetch these documents until AFTER the query is done.
            break;
          }

          // Being in steady phase here would be surprising.
          if (self._phase !== PHASE.FETCHING) throw new Error("phase in fetchModifiedDocuments: " + self._phase);
          self._currentlyFetching = self._needToFetch;
          var thisGeneration = ++self._fetchGeneration;
          self._needToFetch = new LocalCollection._IdMap();
          var waiting = 0;
          var fut = new Future();
          // This loop is safe, because _currentlyFetching will not be updated
          // during this loop (in fact, it is never mutated).
          self._currentlyFetching.forEach(function (op, id) {
            waiting++;
            self._mongoHandle._docFetcher.fetch(self._cursorDescription.collectionName, id, op, finishIfNeedToPollQuery(function (err, doc) {
              try {
                if (err) {
                  Meteor._debug("Got exception while fetching documents", err);
                  // If we get an error from the fetcher (eg, trouble
                  // connecting to Mongo), let's just abandon the fetch phase
                  // altogether and fall back to polling. It's not like we're
                  // getting live updates anyway.
                  if (self._phase !== PHASE.QUERYING) {
                    self._needToPollQuery();
                  }
                } else if (!self._stopped && self._phase === PHASE.FETCHING && self._fetchGeneration === thisGeneration) {
                  // We re-check the generation in case we've had an explicit
                  // _pollQuery call (eg, in another fiber) which should
                  // effectively cancel this round of fetches.  (_pollQuery
                  // increments the generation.)
                  self._handleDoc(id, doc);
                }
              } finally {
                waiting--;
                // Because fetch() never calls its callback synchronously,
                // this is safe (ie, we won't call fut.return() before the
                // forEach is done).
                if (waiting === 0) fut.return();
              }
            }));
          });
          fut.wait();
          // Exit now if we've had a _pollQuery call (here or in another fiber).
          if (self._phase === PHASE.QUERYING) return;
          self._currentlyFetching = null;
        }
        // We're done fetching, so we can be steady, unless we've had a
        // _pollQuery call (here or in another fiber).
        if (self._phase !== PHASE.QUERYING) self._beSteady();
      }));
    });
  },
  _beSteady: function () {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._registerPhaseChange(PHASE.STEADY);
      var writes = self._writesToCommitWhenWeReachSteady;
      self._writesToCommitWhenWeReachSteady = [];
      self._multiplexer.onFlush(function () {
        _.each(writes, function (w) {
          w.committed();
        });
      });
    });
  },
  _handleOplogEntryQuerying: function (op) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      self._needToFetch.set(idForOp(op), op);
    });
  },
  _handleOplogEntrySteadyOrFetching: function (op) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      var id = idForOp(op);
      // If we're already fetching this one, or about to, we can't optimize;
      // make sure that we fetch it again if necessary.
      if (self._phase === PHASE.FETCHING && (self._currentlyFetching && self._currentlyFetching.has(id) || self._needToFetch.has(id))) {
        self._needToFetch.set(id, op);
        return;
      }
      if (op.op === 'd') {
        if (self._published.has(id) || self._limit && self._unpublishedBuffer.has(id)) self._removeMatching(id);
      } else if (op.op === 'i') {
        if (self._published.has(id)) throw new Error("insert found for already-existing ID in published");
        if (self._unpublishedBuffer && self._unpublishedBuffer.has(id)) throw new Error("insert found for already-existing ID in buffer");

        // XXX what if selector yields?  for now it can't but later it could
        // have $where
        if (self._matcher.documentMatches(op.o).result) self._addMatching(op.o);
      } else if (op.op === 'u') {
        // we are mapping the new oplog format on mongo 5
        // to what we know better, $set
        op.o = oplogV2V1Converter(op.o);
        // Is this a modifier ($set/$unset, which may require us to poll the
        // database to figure out if the whole document matches the selector) or
        // a replacement (in which case we can just directly re-evaluate the
        // selector)?
        // oplog format has changed on mongodb 5, we have to support both now
        // diff is the format in Mongo 5+ (oplog v2)
        var isReplace = !_.has(op.o, '$set') && !_.has(op.o, 'diff') && !_.has(op.o, '$unset');
        // If this modifier modifies something inside an EJSON custom type (ie,
        // anything with EJSON$), then we can't try to use
        // LocalCollection._modify, since that just mutates the EJSON encoding,
        // not the actual object.
        var canDirectlyModifyDoc = !isReplace && modifierCanBeDirectlyApplied(op.o);
        var publishedBefore = self._published.has(id);
        var bufferedBefore = self._limit && self._unpublishedBuffer.has(id);
        if (isReplace) {
          self._handleDoc(id, _.extend({
            _id: id
          }, op.o));
        } else if ((publishedBefore || bufferedBefore) && canDirectlyModifyDoc) {
          // Oh great, we actually know what the document is, so we can apply
          // this directly.
          var newDoc = self._published.has(id) ? self._published.get(id) : self._unpublishedBuffer.get(id);
          newDoc = EJSON.clone(newDoc);
          newDoc._id = id;
          try {
            LocalCollection._modify(newDoc, op.o);
          } catch (e) {
            if (e.name !== "MinimongoError") throw e;
            // We didn't understand the modifier.  Re-fetch.
            self._needToFetch.set(id, op);
            if (self._phase === PHASE.STEADY) {
              self._fetchModifiedDocuments();
            }
            return;
          }
          self._handleDoc(id, self._sharedProjectionFn(newDoc));
        } else if (!canDirectlyModifyDoc || self._matcher.canBecomeTrueByModifier(op.o) || self._sorter && self._sorter.affectedByModifier(op.o)) {
          self._needToFetch.set(id, op);
          if (self._phase === PHASE.STEADY) self._fetchModifiedDocuments();
        }
      } else {
        throw Error("XXX SURPRISING OPERATION: " + op);
      }
    });
  },
  // Yields!
  _runInitialQuery: function () {
    var self = this;
    if (self._stopped) throw new Error("oplog stopped surprisingly early");
    self._runQuery({
      initial: true
    }); // yields

    if (self._stopped) return; // can happen on queryError

    // Allow observeChanges calls to return. (After this, it's possible for
    // stop() to be called.)
    self._multiplexer.ready();
    self._doneQuerying(); // yields
  },
  // In various circumstances, we may just want to stop processing the oplog and
  // re-run the initial query, just as if we were a PollingObserveDriver.
  //
  // This function may not block, because it is called from an oplog entry
  // handler.
  //
  // XXX We should call this when we detect that we've been in FETCHING for "too
  // long".
  //
  // XXX We should call this when we detect Mongo failover (since that might
  // mean that some of the oplog entries we have processed have been rolled
  // back). The Node Mongo driver is in the middle of a bunch of huge
  // refactorings, including the way that it notifies you when primary
  // changes. Will put off implementing this until driver 1.4 is out.
  _pollQuery: function () {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      if (self._stopped) return;

      // Yay, we get to forget about all the things we thought we had to fetch.
      self._needToFetch = new LocalCollection._IdMap();
      self._currentlyFetching = null;
      ++self._fetchGeneration; // ignore any in-flight fetches
      self._registerPhaseChange(PHASE.QUERYING);

      // Defer so that we don't yield.  We don't need finishIfNeedToPollQuery
      // here because SwitchedToQuery is not thrown in QUERYING mode.
      Meteor.defer(function () {
        self._runQuery();
        self._doneQuerying();
      });
    });
  },
  // Yields!
  _runQuery: function (options) {
    var self = this;
    options = options || {};
    var newResults, newBuffer;

    // This while loop is just to retry failures.
    while (true) {
      // If we've been stopped, we don't have to run anything any more.
      if (self._stopped) return;
      newResults = new LocalCollection._IdMap();
      newBuffer = new LocalCollection._IdMap();

      // Query 2x documents as the half excluded from the original query will go
      // into unpublished buffer to reduce additional Mongo lookups in cases
      // when documents are removed from the published set and need a
      // replacement.
      // XXX needs more thought on non-zero skip
      // XXX 2 is a "magic number" meaning there is an extra chunk of docs for
      // buffer if such is needed.
      var cursor = self._cursorForQuery({
        limit: self._limit * 2
      });
      try {
        cursor.forEach(function (doc, i) {
          // yields
          if (!self._limit || i < self._limit) {
            newResults.set(doc._id, doc);
          } else {
            newBuffer.set(doc._id, doc);
          }
        });
        break;
      } catch (e) {
        if (options.initial && typeof e.code === 'number') {
          // This is an error document sent to us by mongod, not a connection
          // error generated by the client. And we've never seen this query work
          // successfully. Probably it's a bad selector or something, so we
          // should NOT retry. Instead, we should halt the observe (which ends
          // up calling `stop` on us).
          self._multiplexer.queryError(e);
          return;
        }

        // During failover (eg) if we get an exception we should log and retry
        // instead of crashing.
        Meteor._debug("Got exception while polling query", e);
        Meteor._sleepForMs(100);
      }
    }
    if (self._stopped) return;
    self._publishNewResults(newResults, newBuffer);
  },
  // Transitions to QUERYING and runs another query, or (if already in QUERYING)
  // ensures that we will query again later.
  //
  // This function may not block, because it is called from an oplog entry
  // handler. However, if we were not already in the QUERYING phase, it throws
  // an exception that is caught by the closest surrounding
  // finishIfNeedToPollQuery call; this ensures that we don't continue running
  // close that was designed for another phase inside PHASE.QUERYING.
  //
  // (It's also necessary whenever logic in this file yields to check that other
  // phases haven't put us into QUERYING mode, though; eg,
  // _fetchModifiedDocuments does this.)
  _needToPollQuery: function () {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      if (self._stopped) return;

      // If we're not already in the middle of a query, we can query now
      // (possibly pausing FETCHING).
      if (self._phase !== PHASE.QUERYING) {
        self._pollQuery();
        throw new SwitchedToQuery();
      }

      // We're currently in QUERYING. Set a flag to ensure that we run another
      // query when we're done.
      self._requeryWhenDoneThisQuery = true;
    });
  },
  // Yields!
  _doneQuerying: function () {
    var self = this;
    if (self._stopped) return;
    self._mongoHandle._oplogHandle.waitUntilCaughtUp(); // yields
    if (self._stopped) return;
    if (self._phase !== PHASE.QUERYING) throw Error("Phase unexpectedly " + self._phase);
    Meteor._noYieldsAllowed(function () {
      if (self._requeryWhenDoneThisQuery) {
        self._requeryWhenDoneThisQuery = false;
        self._pollQuery();
      } else if (self._needToFetch.empty()) {
        self._beSteady();
      } else {
        self._fetchModifiedDocuments();
      }
    });
  },
  _cursorForQuery: function (optionsOverwrite) {
    var self = this;
    return Meteor._noYieldsAllowed(function () {
      // The query we run is almost the same as the cursor we are observing,
      // with a few changes. We need to read all the fields that are relevant to
      // the selector, not just the fields we are going to publish (that's the
      // "shared" projection). And we don't want to apply any transform in the
      // cursor, because observeChanges shouldn't use the transform.
      var options = _.clone(self._cursorDescription.options);

      // Allow the caller to modify the options. Useful to specify different
      // skip and limit values.
      _.extend(options, optionsOverwrite);
      options.fields = self._sharedProjection;
      delete options.transform;
      // We are NOT deep cloning fields or selector here, which should be OK.
      var description = new CursorDescription(self._cursorDescription.collectionName, self._cursorDescription.selector, options);
      return new Cursor(self._mongoHandle, description);
    });
  },
  // Replace self._published with newResults (both are IdMaps), invoking observe
  // callbacks on the multiplexer.
  // Replace self._unpublishedBuffer with newBuffer.
  //
  // XXX This is very similar to LocalCollection._diffQueryUnorderedChanges. We
  // should really: (a) Unify IdMap and OrderedDict into Unordered/OrderedDict
  // (b) Rewrite diff.js to use these classes instead of arrays and objects.
  _publishNewResults: function (newResults, newBuffer) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      // If the query is limited and there is a buffer, shut down so it doesn't
      // stay in a way.
      if (self._limit) {
        self._unpublishedBuffer.clear();
      }

      // First remove anything that's gone. Be careful not to modify
      // self._published while iterating over it.
      var idsToRemove = [];
      self._published.forEach(function (doc, id) {
        if (!newResults.has(id)) idsToRemove.push(id);
      });
      _.each(idsToRemove, function (id) {
        self._removePublished(id);
      });

      // Now do adds and changes.
      // If self has a buffer and limit, the new fetched result will be
      // limited correctly as the query has sort specifier.
      newResults.forEach(function (doc, id) {
        self._handleDoc(id, doc);
      });

      // Sanity-check that everything we tried to put into _published ended up
      // there.
      // XXX if this is slow, remove it later
      if (self._published.size() !== newResults.size()) {
        Meteor._debug('The Mongo server and the Meteor query disagree on how ' + 'many documents match your query. Cursor description: ', self._cursorDescription);
      }
      self._published.forEach(function (doc, id) {
        if (!newResults.has(id)) throw Error("_published has a doc that newResults doesn't; " + id);
      });

      // Finally, replace the buffer
      newBuffer.forEach(function (doc, id) {
        self._addBuffered(id, doc);
      });
      self._safeAppendToBuffer = newBuffer.size() < self._limit;
    });
  },
  // This stop function is invoked from the onStop of the ObserveMultiplexer, so
  // it shouldn't actually be possible to call it until the multiplexer is
  // ready.
  //
  // It's important to check self._stopped after every call in this file that
  // can yield!
  stop: function () {
    var self = this;
    if (self._stopped) return;
    self._stopped = true;
    _.each(self._stopHandles, function (handle) {
      handle.stop();
    });

    // Note: we *don't* use multiplexer.onFlush here because this stop
    // callback is actually invoked by the multiplexer itself when it has
    // determined that there are no handles left. So nothing is actually going
    // to get flushed (and it's probably not valid to call methods on the
    // dying multiplexer).
    _.each(self._writesToCommitWhenWeReachSteady, function (w) {
      w.committed(); // maybe yields?
    });
    self._writesToCommitWhenWeReachSteady = null;

    // Proactively drop references to potentially big things.
    self._published = null;
    self._unpublishedBuffer = null;
    self._needToFetch = null;
    self._currentlyFetching = null;
    self._oplogEntryHandle = null;
    self._listenersHandle = null;
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-oplog", -1);
  },
  _registerPhaseChange: function (phase) {
    var self = this;
    Meteor._noYieldsAllowed(function () {
      var now = new Date();
      if (self._phase) {
        var timeDiff = now - self._phaseStartTime;
        Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "time-spent-in-" + self._phase + "-phase", timeDiff);
      }
      self._phase = phase;
      self._phaseStartTime = now;
    });
  }
});

// Does our oplog tailing code support this cursor? For now, we are being very
// conservative and allowing only simple queries with simple options.
// (This is a "static method".)
OplogObserveDriver.cursorSupported = function (cursorDescription, matcher) {
  // First, check the options.
  var options = cursorDescription.options;

  // Did the user say no explicitly?
  // underscored version of the option is COMPAT with 1.2
  if (options.disableOplog || options._disableOplog) return false;

  // skip is not supported: to support it we would need to keep track of all
  // "skipped" documents or at least their ids.
  // limit w/o a sort specifier is not supported: current implementation needs a
  // deterministic way to order documents.
  if (options.skip || options.limit && !options.sort) return false;

  // If a fields projection option is given check if it is supported by
  // minimongo (some operators are not supported).
  const fields = options.fields || options.projection;
  if (fields) {
    try {
      LocalCollection._checkSupportedProjection(fields);
    } catch (e) {
      if (e.name === "MinimongoError") {
        return false;
      } else {
        throw e;
      }
    }
  }

  // We don't allow the following selectors:
  //   - $where (not confident that we provide the same JS environment
  //             as Mongo, and can yield!)
  //   - $near (has "interesting" properties in MongoDB, like the possibility
  //            of returning an ID multiple times, though even polling maybe
  //            have a bug there)
  //           XXX: once we support it, we would need to think more on how we
  //           initialize the comparators when we create the driver.
  return !matcher.hasWhere() && !matcher.hasGeoQuery();
};
var modifierCanBeDirectlyApplied = function (modifier) {
  return _.all(modifier, function (fields, operation) {
    return _.all(fields, function (value, field) {
      return !/EJSON\$/.test(field);
    });
  });
};
MongoInternals.OplogObserveDriver = OplogObserveDriver;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oplog_v2_converter.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/oplog_v2_converter.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  oplogV2V1Converter: () => oplogV2V1Converter
});
// Converter of the new MongoDB Oplog format (>=5.0) to the one that Meteor
// handles well, i.e., `$set` and `$unset`. The new format is completely new,
// and looks as follows:
//
//   { $v: 2, diff: Diff }
//
// where `Diff` is a recursive structure:
//
//   {
//     // Nested updates (sometimes also represented with an s-field).
//     // Example: `{ $set: { 'foo.bar': 1 } }`.
//     i: { <key>: <value>, ... },
//
//     // Top-level updates.
//     // Example: `{ $set: { foo: { bar: 1 } } }`.
//     u: { <key>: <value>, ... },
//
//     // Unsets.
//     // Example: `{ $unset: { foo: '' } }`.
//     d: { <key>: false, ... },
//
//     // Array operations.
//     // Example: `{ $push: { foo: 'bar' } }`.
//     s<key>: { a: true, u<index>: <value>, ... },
//     ...
//
//     // Nested operations (sometimes also represented in the `i` field).
//     // Example: `{ $set: { 'foo.bar': 1 } }`.
//     s<key>: Diff,
//     ...
//   }
//
// (all fields are optional).

function join(prefix, key) {
  return prefix ? "".concat(prefix, ".").concat(key) : key;
}
const arrayOperatorKeyRegex = /^(a|[su]\d+)$/;
function isArrayOperatorKey(field) {
  return arrayOperatorKeyRegex.test(field);
}
function isArrayOperator(operator) {
  return operator.a === true && Object.keys(operator).every(isArrayOperatorKey);
}
function flattenObjectInto(target, source, prefix) {
  if (Array.isArray(source) || typeof source !== 'object' || source === null || source instanceof Mongo.ObjectID) {
    target[prefix] = source;
  } else {
    const entries = Object.entries(source);
    if (entries.length) {
      entries.forEach(_ref => {
        let [key, value] = _ref;
        flattenObjectInto(target, value, join(prefix, key));
      });
    } else {
      target[prefix] = source;
    }
  }
}
const logDebugMessages = !!process.env.OPLOG_CONVERTER_DEBUG;
function convertOplogDiff(oplogEntry, diff, prefix) {
  if (logDebugMessages) {
    console.log("convertOplogDiff(".concat(JSON.stringify(oplogEntry), ", ").concat(JSON.stringify(diff), ", ").concat(JSON.stringify(prefix), ")"));
  }
  Object.entries(diff).forEach(_ref2 => {
    let [diffKey, value] = _ref2;
    if (diffKey === 'd') {
      var _oplogEntry$$unset;
      // Handle `$unset`s.
      (_oplogEntry$$unset = oplogEntry.$unset) !== null && _oplogEntry$$unset !== void 0 ? _oplogEntry$$unset : oplogEntry.$unset = {};
      Object.keys(value).forEach(key => {
        oplogEntry.$unset[join(prefix, key)] = true;
      });
    } else if (diffKey === 'i') {
      var _oplogEntry$$set;
      // Handle (potentially) nested `$set`s.
      (_oplogEntry$$set = oplogEntry.$set) !== null && _oplogEntry$$set !== void 0 ? _oplogEntry$$set : oplogEntry.$set = {};
      flattenObjectInto(oplogEntry.$set, value, prefix);
    } else if (diffKey === 'u') {
      var _oplogEntry$$set2;
      // Handle flat `$set`s.
      (_oplogEntry$$set2 = oplogEntry.$set) !== null && _oplogEntry$$set2 !== void 0 ? _oplogEntry$$set2 : oplogEntry.$set = {};
      Object.entries(value).forEach(_ref3 => {
        let [key, value] = _ref3;
        oplogEntry.$set[join(prefix, key)] = value;
      });
    } else {
      // Handle s-fields.
      const key = diffKey.slice(1);
      if (isArrayOperator(value)) {
        // Array operator.
        Object.entries(value).forEach(_ref4 => {
          let [position, value] = _ref4;
          if (position === 'a') {
            return;
          }
          const positionKey = join(join(prefix, key), position.slice(1));
          if (position[0] === 's') {
            convertOplogDiff(oplogEntry, value, positionKey);
          } else if (value === null) {
            var _oplogEntry$$unset2;
            (_oplogEntry$$unset2 = oplogEntry.$unset) !== null && _oplogEntry$$unset2 !== void 0 ? _oplogEntry$$unset2 : oplogEntry.$unset = {};
            oplogEntry.$unset[positionKey] = true;
          } else {
            var _oplogEntry$$set3;
            (_oplogEntry$$set3 = oplogEntry.$set) !== null && _oplogEntry$$set3 !== void 0 ? _oplogEntry$$set3 : oplogEntry.$set = {};
            oplogEntry.$set[positionKey] = value;
          }
        });
      } else if (key) {
        // Nested object.
        convertOplogDiff(oplogEntry, value, join(prefix, key));
      }
    }
  });
}
function oplogV2V1Converter(oplogEntry) {
  // Pass-through v1 and (probably) invalid entries.
  if (oplogEntry.$v !== 2 || !oplogEntry.diff) {
    return oplogEntry;
  }
  const convertedOplogEntry = {
    $v: 2
  };
  convertOplogDiff(convertedOplogEntry, oplogEntry.diff, '');
  return convertedOplogEntry;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"local_collection_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/local_collection_driver.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  LocalCollectionDriver: () => LocalCollectionDriver
});
const LocalCollectionDriver = new class LocalCollectionDriver {
  constructor() {
    this.noConnCollections = Object.create(null);
  }
  open(name, conn) {
    if (!name) {
      return new LocalCollection();
    }
    if (!conn) {
      return ensureCollection(name, this.noConnCollections);
    }
    if (!conn._mongo_livedata_collections) {
      conn._mongo_livedata_collections = Object.create(null);
    }

    // XXX is there a way to keep track of a connection's collections without
    // dangling it off the connection object?
    return ensureCollection(name, conn._mongo_livedata_collections);
  }
}();
function ensureCollection(name, collections) {
  return name in collections ? collections[name] : collections[name] = new LocalCollection(name);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote_collection_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/remote_collection_driver.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let ASYNC_COLLECTION_METHODS, getAsyncMethodName;
module.link("meteor/minimongo/constants", {
  ASYNC_COLLECTION_METHODS(v) {
    ASYNC_COLLECTION_METHODS = v;
  },
  getAsyncMethodName(v) {
    getAsyncMethodName = v;
  }
}, 0);
MongoInternals.RemoteCollectionDriver = function (mongo_url, options) {
  var self = this;
  self.mongo = new MongoConnection(mongo_url, options);
};
const REMOTE_COLLECTION_METHODS = ['_createCappedCollection', '_dropIndex', '_ensureIndex', 'createIndex', 'countDocuments', 'dropCollection', 'estimatedDocumentCount', 'find', 'findOne', 'insert', 'rawCollection', 'remove', 'update', 'upsert'];
Object.assign(MongoInternals.RemoteCollectionDriver.prototype, {
  open: function (name) {
    var self = this;
    var ret = {};
    REMOTE_COLLECTION_METHODS.forEach(function (m) {
      ret[m] = _.bind(self.mongo[m], self.mongo, name);
      if (!ASYNC_COLLECTION_METHODS.includes(m)) return;
      const asyncMethodName = getAsyncMethodName(m);
      ret[asyncMethodName] = function () {
        try {
          return Promise.resolve(ret[m](...arguments));
        } catch (error) {
          return Promise.reject(error);
        }
      };
    });
    return ret;
  }
});

// Create the singleton RemoteCollectionDriver only on demand, so we
// only require Mongo configuration if it's actually used (eg, not if
// you're only trying to receive data from a remote DDP server.)
MongoInternals.defaultRemoteCollectionDriver = _.once(function () {
  var connectionOptions = {};
  var mongoUrl = process.env.MONGO_URL;
  if (process.env.MONGO_OPLOG_URL) {
    connectionOptions.oplogUrl = process.env.MONGO_OPLOG_URL;
  }
  if (!mongoUrl) throw new Error("MONGO_URL must be set in environment");
  const driver = new MongoInternals.RemoteCollectionDriver(mongoUrl, connectionOptions);

  // As many deployment tools, including Meteor Up, send requests to the app in
  // order to confirm that the deployment finished successfully, it's required
  // to know about a database connection problem before the app starts. Doing so
  // in a `Meteor.startup` is fine, as the `WebApp` handles requests only after
  // all are finished.
  Meteor.startup(() => {
    Promise.await(driver.mongo.client.connect());
  });
  return driver;
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collection.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/collection.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!function (module1) {
  let _objectSpread;
  module1.link("@babel/runtime/helpers/objectSpread2", {
    default(v) {
      _objectSpread = v;
    }
  }, 0);
  module1.export({
    warnUsingOldApi: () => warnUsingOldApi
  });
  let ASYNC_COLLECTION_METHODS, getAsyncMethodName;
  module1.link("meteor/minimongo/constants", {
    ASYNC_COLLECTION_METHODS(v) {
      ASYNC_COLLECTION_METHODS = v;
    },
    getAsyncMethodName(v) {
      getAsyncMethodName = v;
    }
  }, 0);
  let normalizeProjection;
  module1.link("./mongo_utils", {
    normalizeProjection(v) {
      normalizeProjection = v;
    }
  }, 1);
  function warnUsingOldApi(methodName, collectionName, isCalledFromAsync) {
    if (process.env.WARN_WHEN_USING_OLD_API &&
    // also ensures it is on the server
    !isCalledFromAsync // must be true otherwise we should log
    ) {
      if (collectionName === undefined || collectionName.includes('oplog')) return;
      console.warn("\n   \n   Calling method ".concat(collectionName, ".").concat(methodName, " from old API on server.\n   This method will be removed, from the server, in version 3.\n   Trace is below:"));
      console.trace();
    }
  }
  /**
   * @summary Namespace for MongoDB-related items
   * @namespace
   */
  Mongo = {};

  /**
   * @summary Constructor for a Collection
   * @locus Anywhere
   * @instancename collection
   * @class
   * @param {String} name The name of the collection.  If null, creates an unmanaged (unsynchronized) local collection.
   * @param {Object} [options]
   * @param {Object} options.connection The server connection that will manage this collection. Uses the default connection if not specified.  Pass the return value of calling [`DDP.connect`](#ddp_connect) to specify a different server. Pass `null` to specify no connection. Unmanaged (`name` is null) collections cannot specify a connection.
   * @param {String} options.idGeneration The method of generating the `_id` fields of new documents in this collection.  Possible values:
  
   - **`'STRING'`**: random strings
   - **`'MONGO'`**:  random [`Mongo.ObjectID`](#mongo_object_id) values
  
  The default id generation technique is `'STRING'`.
   * @param {Function} options.transform An optional transformation function. Documents will be passed through this function before being returned from `fetch` or `findOne`, and before being passed to callbacks of `observe`, `map`, `forEach`, `allow`, and `deny`. Transforms are *not* applied for the callbacks of `observeChanges` or to cursors returned from publish functions.
   * @param {Boolean} options.defineMutationMethods Set to `false` to skip setting up the mutation methods that enable insert/update/remove from client code. Default `true`.
   */
  Mongo.Collection = function Collection(name, options) {
    if (!name && name !== null) {
      Meteor._debug('Warning: creating anonymous collection. It will not be ' + 'saved or synchronized over the network. (Pass null for ' + 'the collection name to turn off this warning.)');
      name = null;
    }
    if (name !== null && typeof name !== 'string') {
      throw new Error('First argument to new Mongo.Collection must be a string or null');
    }
    if (options && options.methods) {
      // Backwards compatibility hack with original signature (which passed
      // "connection" directly instead of in options. (Connections must have a "methods"
      // method.)
      // XXX remove before 1.0
      options = {
        connection: options
      };
    }
    // Backwards compatibility: "connection" used to be called "manager".
    if (options && options.manager && !options.connection) {
      options.connection = options.manager;
    }
    options = _objectSpread({
      connection: undefined,
      idGeneration: 'STRING',
      transform: null,
      _driver: undefined,
      _preventAutopublish: false
    }, options);
    switch (options.idGeneration) {
      case 'MONGO':
        this._makeNewID = function () {
          var src = name ? DDP.randomStream('/collection/' + name) : Random.insecure;
          return new Mongo.ObjectID(src.hexString(24));
        };
        break;
      case 'STRING':
      default:
        this._makeNewID = function () {
          var src = name ? DDP.randomStream('/collection/' + name) : Random.insecure;
          return src.id();
        };
        break;
    }
    this._transform = LocalCollection.wrapTransform(options.transform);
    if (!name || options.connection === null)
      // note: nameless collections never have a connection
      this._connection = null;else if (options.connection) this._connection = options.connection;else if (Meteor.isClient) this._connection = Meteor.connection;else this._connection = Meteor.server;
    if (!options._driver) {
      // XXX This check assumes that webapp is loaded so that Meteor.server !==
      // null. We should fully support the case of "want to use a Mongo-backed
      // collection from Node code without webapp", but we don't yet.
      // #MeteorServerNull
      if (name && this._connection === Meteor.server && typeof MongoInternals !== 'undefined' && MongoInternals.defaultRemoteCollectionDriver) {
        options._driver = MongoInternals.defaultRemoteCollectionDriver();
      } else {
        const {
          LocalCollectionDriver
        } = require('./local_collection_driver.js');
        options._driver = LocalCollectionDriver;
      }
    }
    this._collection = options._driver.open(name, this._connection);
    this._name = name;
    this._driver = options._driver;
    this._maybeSetUpReplication(name, options);

    // XXX don't define these until allow or deny is actually used for this
    // collection. Could be hard if the security rules are only defined on the
    // server.
    if (options.defineMutationMethods !== false) {
      try {
        this._defineMutationMethods({
          useExisting: options._suppressSameNameError === true
        });
      } catch (error) {
        // Throw a more understandable error on the server for same collection name
        if (error.message === "A method named '/".concat(name, "/insert' is already defined")) throw new Error("There is already a collection named \"".concat(name, "\""));
        throw error;
      }
    }

    // autopublish
    if (Package.autopublish && !options._preventAutopublish && this._connection && this._connection.publish) {
      this._connection.publish(null, () => this.find(), {
        is_auto: true
      });
    }
  };
  Object.assign(Mongo.Collection.prototype, {
    _maybeSetUpReplication(name, _ref2) {
      let {
        _suppressSameNameError = false
      } = _ref2;
      const self = this;
      if (!(self._connection && self._connection.registerStore)) {
        return;
      }

      // OK, we're going to be a slave, replicating some remote
      // database, except possibly with some temporary divergence while
      // we have unacknowledged RPC's.
      const ok = self._connection.registerStore(name, {
        // Called at the beginning of a batch of updates. batchSize is the number
        // of update calls to expect.
        //
        // XXX This interface is pretty janky. reset probably ought to go back to
        // being its own function, and callers shouldn't have to calculate
        // batchSize. The optimization of not calling pause/remove should be
        // delayed until later: the first call to update() should buffer its
        // message, and then we can either directly apply it at endUpdate time if
        // it was the only update, or do pauseObservers/apply/apply at the next
        // update() if there's another one.
        beginUpdate(batchSize, reset) {
          // pause observers so users don't see flicker when updating several
          // objects at once (including the post-reconnect reset-and-reapply
          // stage), and so that a re-sorting of a query can take advantage of the
          // full _diffQuery moved calculation instead of applying change one at a
          // time.
          if (batchSize > 1 || reset) self._collection.pauseObservers();
          if (reset) self._collection.remove({});
        },
        // Apply an update.
        // XXX better specify this interface (not in terms of a wire message)?
        update(msg) {
          var mongoId = MongoID.idParse(msg.id);
          var doc = self._collection._docs.get(mongoId);

          //When the server's mergebox is disabled for a collection, the client must gracefully handle it when:
          // *We receive an added message for a document that is already there. Instead, it will be changed
          // *We reeive a change message for a document that is not there. Instead, it will be added
          // *We receive a removed messsage for a document that is not there. Instead, noting wil happen.

          //Code is derived from client-side code originally in peerlibrary:control-mergebox
          //https://github.com/peerlibrary/meteor-control-mergebox/blob/master/client.coffee

          //For more information, refer to discussion "Initial support for publication strategies in livedata server":
          //https://github.com/meteor/meteor/pull/11151
          if (Meteor.isClient) {
            if (msg.msg === 'added' && doc) {
              msg.msg = 'changed';
            } else if (msg.msg === 'removed' && !doc) {
              return;
            } else if (msg.msg === 'changed' && !doc) {
              msg.msg = 'added';
              _ref = msg.fields;
              for (field in _ref) {
                value = _ref[field];
                if (value === void 0) {
                  delete msg.fields[field];
                }
              }
            }
          }

          // Is this a "replace the whole doc" message coming from the quiescence
          // of method writes to an object? (Note that 'undefined' is a valid
          // value meaning "remove it".)
          if (msg.msg === 'replace') {
            var replace = msg.replace;
            if (!replace) {
              if (doc) self._collection.remove(mongoId);
            } else if (!doc) {
              self._collection.insert(replace);
            } else {
              // XXX check that replace has no $ ops
              self._collection.update(mongoId, replace);
            }
            return;
          } else if (msg.msg === 'added') {
            if (doc) {
              throw new Error('Expected not to find a document already present for an add');
            }
            self._collection.insert(_objectSpread({
              _id: mongoId
            }, msg.fields));
          } else if (msg.msg === 'removed') {
            if (!doc) throw new Error('Expected to find a document already present for removed');
            self._collection.remove(mongoId);
          } else if (msg.msg === 'changed') {
            if (!doc) throw new Error('Expected to find a document to change');
            const keys = Object.keys(msg.fields);
            if (keys.length > 0) {
              var modifier = {};
              keys.forEach(key => {
                const value = msg.fields[key];
                if (EJSON.equals(doc[key], value)) {
                  return;
                }
                if (typeof value === 'undefined') {
                  if (!modifier.$unset) {
                    modifier.$unset = {};
                  }
                  modifier.$unset[key] = 1;
                } else {
                  if (!modifier.$set) {
                    modifier.$set = {};
                  }
                  modifier.$set[key] = value;
                }
              });
              if (Object.keys(modifier).length > 0) {
                self._collection.update(mongoId, modifier);
              }
            }
          } else {
            throw new Error("I don't know how to deal with this message");
          }
        },
        // Called at the end of a batch of updates.
        endUpdate() {
          self._collection.resumeObservers();
        },
        // Called around method stub invocations to capture the original versions
        // of modified documents.
        saveOriginals() {
          self._collection.saveOriginals();
        },
        retrieveOriginals() {
          return self._collection.retrieveOriginals();
        },
        // Used to preserve current versions of documents across a store reset.
        getDoc(id) {
          return self.findOne(id);
        },
        // To be able to get back to the collection from the store.
        _getCollection() {
          return self;
        }
      });
      if (!ok) {
        const message = "There is already a collection named \"".concat(name, "\"");
        if (_suppressSameNameError === true) {
          // XXX In theory we do not have to throw when `ok` is falsy. The
          // store is already defined for this collection name, but this
          // will simply be another reference to it and everything should
          // work. However, we have historically thrown an error here, so
          // for now we will skip the error only when _suppressSameNameError
          // is `true`, allowing people to opt in and give this some real
          // world testing.
          console.warn ? console.warn(message) : console.log(message);
        } else {
          throw new Error(message);
        }
      }
    },
    ///
    /// Main collection API
    ///
    /**
     * @summary Gets the number of documents matching the filter. For a fast count of the total documents in a collection see `estimatedDocumentCount`.
     * @locus Anywhere
     * @method countDocuments
     * @memberof Mongo.Collection
     * @instance
     * @param {MongoSelector} [selector] A query describing the documents to count
     * @param {Object} [options] All options are listed in [MongoDB documentation](https://mongodb.github.io/node-mongodb-native/4.11/interfaces/CountDocumentsOptions.html). Please note that not all of them are available on the client.
     * @returns {Promise<number>}
     */
    countDocuments() {
      return this._collection.countDocuments(...arguments);
    },
    /**
     * @summary Gets an estimate of the count of documents in a collection using collection metadata. For an exact count of the documents in a collection see `countDocuments`.
     * @locus Anywhere
     * @method estimatedDocumentCount
     * @memberof Mongo.Collection
     * @instance
     * @param {Object} [options] All options are listed in [MongoDB documentation](https://mongodb.github.io/node-mongodb-native/4.11/interfaces/EstimatedDocumentCountOptions.html). Please note that not all of them are available on the client.
     * @returns {Promise<number>}
     */
    estimatedDocumentCount() {
      return this._collection.estimatedDocumentCount(...arguments);
    },
    _getFindSelector(args) {
      if (args.length == 0) return {};else return args[0];
    },
    _getFindOptions(args) {
      const [, options] = args || [];
      const newOptions = normalizeProjection(options);
      var self = this;
      if (args.length < 2) {
        return {
          transform: self._transform
        };
      } else {
        check(newOptions, Match.Optional(Match.ObjectIncluding({
          projection: Match.Optional(Match.OneOf(Object, undefined)),
          sort: Match.Optional(Match.OneOf(Object, Array, Function, undefined)),
          limit: Match.Optional(Match.OneOf(Number, undefined)),
          skip: Match.Optional(Match.OneOf(Number, undefined))
        })));
        return _objectSpread({
          transform: self._transform
        }, newOptions);
      }
    },
    /**
     * @summary Find the documents in a collection that match the selector.
     * @locus Anywhere
     * @method find
     * @memberof Mongo.Collection
     * @instance
     * @param {MongoSelector} [selector] A query describing the documents to find
     * @param {Object} [options]
     * @param {MongoSortSpecifier} options.sort Sort order (default: natural order)
     * @param {Number} options.skip Number of results to skip at the beginning
     * @param {Number} options.limit Maximum number of results to return
     * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
     * @param {Boolean} options.reactive (Client only) Default `true`; pass `false` to disable reactivity
     * @param {Function} options.transform Overrides `transform` on the  [`Collection`](#collections) for this cursor.  Pass `null` to disable transformation.
     * @param {Boolean} options.disableOplog (Server only) Pass true to disable oplog-tailing on this query. This affects the way server processes calls to `observe` on this query. Disabling the oplog can be useful when working with data that updates in large batches.
     * @param {Number} options.pollingIntervalMs (Server only) When oplog is disabled (through the use of `disableOplog` or when otherwise not available), the frequency (in milliseconds) of how often to poll this query when observing on the server. Defaults to 10000ms (10 seconds).
     * @param {Number} options.pollingThrottleMs (Server only) When oplog is disabled (through the use of `disableOplog` or when otherwise not available), the minimum time (in milliseconds) to allow between re-polling when observing on the server. Increasing this will save CPU and mongo load at the expense of slower updates to users. Decreasing this is not recommended. Defaults to 50ms.
     * @param {Number} options.maxTimeMs (Server only) If set, instructs MongoDB to set a time limit for this cursor's operations. If the operation reaches the specified time limit (in milliseconds) without the having been completed, an exception will be thrown. Useful to prevent an (accidental or malicious) unoptimized query from causing a full collection scan that would disrupt other database users, at the expense of needing to handle the resulting error.
     * @param {String|Object} options.hint (Server only) Overrides MongoDB's default index selection and query optimization process. Specify an index to force its use, either by its name or index specification. You can also specify `{ $natural : 1 }` to force a forwards collection scan, or `{ $natural : -1 }` for a reverse collection scan. Setting this is only recommended for advanced users.
     * @param {String} options.readPreference (Server only) Specifies a custom MongoDB [`readPreference`](https://docs.mongodb.com/manual/core/read-preference) for this particular cursor. Possible values are `primary`, `primaryPreferred`, `secondary`, `secondaryPreferred` and `nearest`.
     * @returns {Mongo.Cursor}
     */
    find() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      // Collection.find() (return all docs) behaves differently
      // from Collection.find(undefined) (return 0 docs).  so be
      // careful about the length of arguments.
      return this._collection.find(this._getFindSelector(args), this._getFindOptions(args));
    },
    /**
     * @summary Finds the first document that matches the selector, as ordered by sort and skip options. Returns `undefined` if no matching document is found.
     * @locus Anywhere
     * @method findOne
     * @memberof Mongo.Collection
     * @instance
     * @param {MongoSelector} [selector] A query describing the documents to find
     * @param {Object} [options]
     * @param {MongoSortSpecifier} options.sort Sort order (default: natural order)
     * @param {Number} options.skip Number of results to skip at the beginning
     * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
     * @param {Boolean} options.reactive (Client only) Default true; pass false to disable reactivity
     * @param {Function} options.transform Overrides `transform` on the [`Collection`](#collections) for this cursor.  Pass `null` to disable transformation.
     * @param {String} options.readPreference (Server only) Specifies a custom MongoDB [`readPreference`](https://docs.mongodb.com/manual/core/read-preference) for fetching the document. Possible values are `primary`, `primaryPreferred`, `secondary`, `secondaryPreferred` and `nearest`.
     * @returns {Object}
     */
    findOne() {
      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('findOne', this._name, this.findOne.isCalledFromAsync);
      this.findOne.isCalledFromAsync = false;
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      return this._collection.findOne(this._getFindSelector(args), this._getFindOptions(args));
    }
  });
  Object.assign(Mongo.Collection, {
    _publishCursor(cursor, sub, collection) {
      var observeHandle = cursor.observeChanges({
        added: function (id, fields) {
          sub.added(collection, id, fields);
        },
        changed: function (id, fields) {
          sub.changed(collection, id, fields);
        },
        removed: function (id) {
          sub.removed(collection, id);
        }
      },
      // Publications don't mutate the documents
      // This is tested by the `livedata - publish callbacks clone` test
      {
        nonMutatingCallbacks: true
      });

      // We don't call sub.ready() here: it gets called in livedata_server, after
      // possibly calling _publishCursor on multiple returned cursors.

      // register stop callback (expects lambda w/ no args).
      sub.onStop(function () {
        observeHandle.stop();
      });

      // return the observeHandle in case it needs to be stopped early
      return observeHandle;
    },
    // protect against dangerous selectors.  falsey and {_id: falsey} are both
    // likely programmer error, and not what you want, particularly for destructive
    // operations. If a falsey _id is sent in, a new string _id will be
    // generated and returned; if a fallbackId is provided, it will be returned
    // instead.
    _rewriteSelector(selector) {
      let {
        fallbackId
      } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      // shorthand -- scalars match _id
      if (LocalCollection._selectorIsId(selector)) selector = {
        _id: selector
      };
      if (Array.isArray(selector)) {
        // This is consistent with the Mongo console itself; if we don't do this
        // check passing an empty array ends up selecting all items
        throw new Error("Mongo selector can't be an array.");
      }
      if (!selector || '_id' in selector && !selector._id) {
        // can't match anything
        return {
          _id: fallbackId || Random.id()
        };
      }
      return selector;
    }
  });
  Object.assign(Mongo.Collection.prototype, {
    // 'insert' immediately returns the inserted document's new _id.
    // The others return values immediately if you are in a stub, an in-memory
    // unmanaged collection, or a mongo-backed collection and you don't pass a
    // callback. 'update' and 'remove' return the number of affected
    // documents. 'upsert' returns an object with keys 'numberAffected' and, if an
    // insert happened, 'insertedId'.
    //
    // Otherwise, the semantics are exactly like other methods: they take
    // a callback as an optional last argument; if no callback is
    // provided, they block until the operation is complete, and throw an
    // exception if it fails; if a callback is provided, then they don't
    // necessarily block, and they call the callback when they finish with error and
    // result arguments.  (The insert method provides the document ID as its result;
    // update and remove provide the number of affected docs as the result; upsert
    // provides an object with numberAffected and maybe insertedId.)
    //
    // On the client, blocking is impossible, so if a callback
    // isn't provided, they just return immediately and any error
    // information is lost.
    //
    // There's one more tweak. On the client, if you don't provide a
    // callback, then if there is an error, a message will be logged with
    // Meteor._debug.
    //
    // The intent (though this is actually determined by the underlying
    // drivers) is that the operations should be done synchronously, not
    // generating their result until the database has acknowledged
    // them. In the future maybe we should provide a flag to turn this
    // off.

    /**
     * @summary Insert a document in the collection.  Returns its unique _id.
     * @locus Anywhere
     * @method  insert
     * @memberof Mongo.Collection
     * @instance
     * @param {Object} doc The document to insert. May not yet have an _id attribute, in which case Meteor will generate one for you.
     * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the _id as the second.
     */
    insert(doc, callback) {
      // Make sure we were passed a document to insert
      if (!doc) {
        throw new Error('insert requires an argument');
      }

      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('insert', this._name, this.insert.isCalledFromAsync);
      this.insert.isCalledFromAsync = false;

      // Make a shallow clone of the document, preserving its prototype.
      doc = Object.create(Object.getPrototypeOf(doc), Object.getOwnPropertyDescriptors(doc));
      if ('_id' in doc) {
        if (!doc._id || !(typeof doc._id === 'string' || doc._id instanceof Mongo.ObjectID)) {
          throw new Error('Meteor requires document _id fields to be non-empty strings or ObjectIDs');
        }
      } else {
        let generateId = true;

        // Don't generate the id if we're the client and the 'outermost' call
        // This optimization saves us passing both the randomSeed and the id
        // Passing both is redundant.
        if (this._isRemoteCollection()) {
          const enclosing = DDP._CurrentMethodInvocation.get();
          if (!enclosing) {
            generateId = false;
          }
        }
        if (generateId) {
          doc._id = this._makeNewID();
        }
      }

      // On inserts, always return the id that we generated; on all other
      // operations, just return the result from the collection.
      var chooseReturnValueFromCollectionResult = function (result) {
        if (doc._id) {
          return doc._id;
        }

        // XXX what is this for??
        // It's some iteraction between the callback to _callMutatorMethod and
        // the return value conversion
        doc._id = result;
        return result;
      };
      const wrappedCallback = wrapCallback(callback, chooseReturnValueFromCollectionResult);
      if (this._isRemoteCollection()) {
        const result = this._callMutatorMethod('insert', [doc], wrappedCallback);
        return chooseReturnValueFromCollectionResult(result);
      }

      // it's my collection.  descend into the collection object
      // and propagate any exception.
      try {
        // If the user provided a callback and the collection implements this
        // operation asynchronously, then queryRet will be undefined, and the
        // result will be returned through the callback instead.
        const result = this._collection.insert(doc, wrappedCallback);
        return chooseReturnValueFromCollectionResult(result);
      } catch (e) {
        if (callback) {
          callback(e);
          return null;
        }
        throw e;
      }
    },
    /**
     * @summary Modify one or more documents in the collection. Returns the number of matched documents.
     * @locus Anywhere
     * @method update
     * @memberof Mongo.Collection
     * @instance
     * @param {MongoSelector} selector Specifies which documents to modify
     * @param {MongoModifier} modifier Specifies how to modify the documents
     * @param {Object} [options]
     * @param {Boolean} options.multi True to modify all matching documents; false to only modify one of the matching documents (the default).
     * @param {Boolean} options.upsert True to insert a document if no matching documents are found.
     * @param {Array} options.arrayFilters Optional. Used in combination with MongoDB [filtered positional operator](https://docs.mongodb.com/manual/reference/operator/update/positional-filtered/) to specify which elements to modify in an array field.
     * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the number of affected documents as the second.
     */
    update(selector, modifier) {
      for (var _len3 = arguments.length, optionsAndCallback = new Array(_len3 > 2 ? _len3 - 2 : 0), _key3 = 2; _key3 < _len3; _key3++) {
        optionsAndCallback[_key3 - 2] = arguments[_key3];
      }
      const callback = popCallbackFromArgs(optionsAndCallback);

      // We've already popped off the callback, so we are left with an array
      // of one or zero items
      const options = _objectSpread({}, optionsAndCallback[0] || null);
      let insertedId;
      if (options && options.upsert) {
        // set `insertedId` if absent.  `insertedId` is a Meteor extension.
        if (options.insertedId) {
          if (!(typeof options.insertedId === 'string' || options.insertedId instanceof Mongo.ObjectID)) throw new Error('insertedId must be string or ObjectID');
          insertedId = options.insertedId;
        } else if (!selector || !selector._id) {
          insertedId = this._makeNewID();
          options.generatedId = true;
          options.insertedId = insertedId;
        }
      }

      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('update', this._name, this.update.isCalledFromAsync);
      this.update.isCalledFromAsync = false;
      selector = Mongo.Collection._rewriteSelector(selector, {
        fallbackId: insertedId
      });
      const wrappedCallback = wrapCallback(callback);
      if (this._isRemoteCollection()) {
        const args = [selector, modifier, options];
        return this._callMutatorMethod('update', args, wrappedCallback);
      }

      // it's my collection.  descend into the collection object
      // and propagate any exception.
      try {
        // If the user provided a callback and the collection implements this
        // operation asynchronously, then queryRet will be undefined, and the
        // result will be returned through the callback instead.
        return this._collection.update(selector, modifier, options, wrappedCallback);
      } catch (e) {
        if (callback) {
          callback(e);
          return null;
        }
        throw e;
      }
    },
    /**
     * @summary Remove documents from the collection
     * @locus Anywhere
     * @method remove
     * @memberof Mongo.Collection
     * @instance
     * @param {MongoSelector} selector Specifies which documents to remove
     * @param {Function} [callback] Optional.  If present, called with an error object as its argument.
     */
    remove(selector, callback) {
      selector = Mongo.Collection._rewriteSelector(selector);
      const wrappedCallback = wrapCallback(callback);
      if (this._isRemoteCollection()) {
        return this._callMutatorMethod('remove', [selector], wrappedCallback);
      }

      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('remove', this._name, this.remove.isCalledFromAsync);
      this.remove.isCalledFromAsync = false;
      // it's my collection.  descend into the collection object
      // and propagate any exception.
      try {
        // If the user provided a callback and the collection implements this
        // operation asynchronously, then queryRet will be undefined, and the
        // result will be returned through the callback instead.
        return this._collection.remove(selector, wrappedCallback);
      } catch (e) {
        if (callback) {
          callback(e);
          return null;
        }
        throw e;
      }
    },
    // Determine if this collection is simply a minimongo representation of a real
    // database on another server
    _isRemoteCollection() {
      // XXX see #MeteorServerNull
      return this._connection && this._connection !== Meteor.server;
    },
    /**
     * @summary Modify one or more documents in the collection, or insert one if no matching documents were found. Returns an object with keys `numberAffected` (the number of documents modified)  and `insertedId` (the unique _id of the document that was inserted, if any).
     * @locus Anywhere
     * @method upsert
     * @memberof Mongo.Collection
     * @instance
     * @param {MongoSelector} selector Specifies which documents to modify
     * @param {MongoModifier} modifier Specifies how to modify the documents
     * @param {Object} [options]
     * @param {Boolean} options.multi True to modify all matching documents; false to only modify one of the matching documents (the default).
     * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the number of affected documents as the second.
     */
    upsert(selector, modifier, options, callback) {
      if (!callback && typeof options === 'function') {
        callback = options;
        options = {};
      }

      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('upsert', this._name, this.upsert.isCalledFromAsync);
      this.upsert.isCalledFromAsync = false;
      // caught here https://github.com/meteor/meteor/issues/12626
      this.update.isCalledFromAsync = true; // to not trigger on the next call
      return this.update(selector, modifier, _objectSpread(_objectSpread({}, options), {}, {
        _returnObject: true,
        upsert: true
      }), callback);
    },
    // We'll actually design an index API later. For now, we just pass through to
    // Mongo's, but make it synchronous.
    _ensureIndex(index, options) {
      var self = this;
      if (!self._collection._ensureIndex || !self._collection.createIndex) throw new Error('Can only call createIndex on server collections');
      if (self._collection.createIndex) {
        self._collection.createIndex(index, options);
      } else {
        let Log;
        module1.link("meteor/logging", {
          Log(v) {
            Log = v;
          }
        }, 2);
        Log.debug("_ensureIndex has been deprecated, please use the new 'createIndex' instead".concat(options !== null && options !== void 0 && options.name ? ", index name: ".concat(options.name) : ", index: ".concat(JSON.stringify(index))));
        self._collection._ensureIndex(index, options);
      }
    },
    /**
     * @summary Creates the specified index on the collection.
     * @locus server
     * @method createIndex
     * @memberof Mongo.Collection
     * @instance
     * @param {Object} index A document that contains the field and value pairs where the field is the index key and the value describes the type of index for that field. For an ascending index on a field, specify a value of `1`; for descending index, specify a value of `-1`. Use `text` for text indexes.
     * @param {Object} [options] All options are listed in [MongoDB documentation](https://docs.mongodb.com/manual/reference/method/db.collection.createIndex/#options)
     * @param {String} options.name Name of the index
     * @param {Boolean} options.unique Define that the index values must be unique, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-unique/)
     * @param {Boolean} options.sparse Define that the index is sparse, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-sparse/)
     */
    createIndex(index, options) {
      var self = this;
      if (!self._collection.createIndex) throw new Error('Can only call createIndex on server collections');
      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('createIndex', self._name, self.createIndex.isCalledFromAsync);
      self.createIndex.isCalledFromAsync = false;
      try {
        self._collection.createIndex(index, options);
      } catch (e) {
        var _Meteor$settings, _Meteor$settings$pack, _Meteor$settings$pack2;
        if (e.message.includes('An equivalent index already exists with the same name but different options.') && (_Meteor$settings = Meteor.settings) !== null && _Meteor$settings !== void 0 && (_Meteor$settings$pack = _Meteor$settings.packages) !== null && _Meteor$settings$pack !== void 0 && (_Meteor$settings$pack2 = _Meteor$settings$pack.mongo) !== null && _Meteor$settings$pack2 !== void 0 && _Meteor$settings$pack2.reCreateIndexOnOptionMismatch) {
          let Log;
          module1.link("meteor/logging", {
            Log(v) {
              Log = v;
            }
          }, 3);
          Log.info("Re-creating index ".concat(index, " for ").concat(self._name, " due to options mismatch."));
          self._collection._dropIndex(index);
          self._collection.createIndex(index, options);
        } else {
          throw new Meteor.Error("An error occurred when creating an index for collection \"".concat(self._name, ": ").concat(e.message));
        }
      }
    },
    _dropIndex(index) {
      var self = this;
      if (!self._collection._dropIndex) throw new Error('Can only call _dropIndex on server collections');
      self._collection._dropIndex(index);
    },
    _dropCollection() {
      var self = this;
      if (!self._collection.dropCollection) throw new Error('Can only call _dropCollection on server collections');
      self._collection.dropCollection();
    },
    _createCappedCollection(byteSize, maxDocuments) {
      var self = this;
      if (!self._collection._createCappedCollection) throw new Error('Can only call _createCappedCollection on server collections');

      // [FIBERS]
      // TODO: Remove this when 3.0 is released.
      warnUsingOldApi('_createCappedCollection', self._name, self._createCappedCollection.isCalledFromAsync);
      self._createCappedCollection.isCalledFromAsync = false;
      self._collection._createCappedCollection(byteSize, maxDocuments);
    },
    /**
     * @summary Returns the [`Collection`](http://mongodb.github.io/node-mongodb-native/3.0/api/Collection.html) object corresponding to this collection from the [npm `mongodb` driver module](https://www.npmjs.com/package/mongodb) which is wrapped by `Mongo.Collection`.
     * @locus Server
     * @memberof Mongo.Collection
     * @instance
     */
    rawCollection() {
      var self = this;
      if (!self._collection.rawCollection) {
        throw new Error('Can only call rawCollection on server collections');
      }
      return self._collection.rawCollection();
    },
    /**
     * @summary Returns the [`Db`](http://mongodb.github.io/node-mongodb-native/3.0/api/Db.html) object corresponding to this collection's database connection from the [npm `mongodb` driver module](https://www.npmjs.com/package/mongodb) which is wrapped by `Mongo.Collection`.
     * @locus Server
     * @memberof Mongo.Collection
     * @instance
     */
    rawDatabase() {
      var self = this;
      if (!(self._driver.mongo && self._driver.mongo.db)) {
        throw new Error('Can only call rawDatabase on server collections');
      }
      return self._driver.mongo.db;
    }
  });

  // Convert the callback to not return a result if there is an error
  function wrapCallback(callback, convertResult) {
    return callback && function (error, result) {
      if (error) {
        callback(error);
      } else if (typeof convertResult === 'function') {
        callback(error, convertResult(result));
      } else {
        callback(error, result);
      }
    };
  }

  /**
   * @summary Create a Mongo-style `ObjectID`.  If you don't specify a `hexString`, the `ObjectID` will generated randomly (not using MongoDB's ID construction rules).
   * @locus Anywhere
   * @class
   * @param {String} [hexString] Optional.  The 24-character hexadecimal contents of the ObjectID to create
   */
  Mongo.ObjectID = MongoID.ObjectID;

  /**
   * @summary To create a cursor, use find. To access the documents in a cursor, use forEach, map, or fetch.
   * @class
   * @instanceName cursor
   */
  Mongo.Cursor = LocalCollection.Cursor;

  /**
   * @deprecated in 0.9.1
   */
  Mongo.Collection.Cursor = Mongo.Cursor;

  /**
   * @deprecated in 0.9.1
   */
  Mongo.Collection.ObjectID = Mongo.ObjectID;

  /**
   * @deprecated in 0.9.1
   */
  Meteor.Collection = Mongo.Collection;

  // Allow deny stuff is now in the allow-deny package
  Object.assign(Mongo.Collection.prototype, AllowDeny.CollectionPrototype);
  function popCallbackFromArgs(args) {
    // Pull off any callback (or perhaps a 'callback' variable that was passed
    // in undefined, like how 'upsert' does it).
    if (args.length && (args[args.length - 1] === undefined || args[args.length - 1] instanceof Function)) {
      return args.pop();
    }
  }
  ASYNC_COLLECTION_METHODS.forEach(methodName => {
    const methodNameAsync = getAsyncMethodName(methodName);
    Mongo.Collection.prototype[methodNameAsync] = function () {
      try {
        // TODO: Fibers remove this when we remove fibers.
        this[methodName].isCalledFromAsync = true;
        return Promise.resolve(this[methodName](...arguments));
      } catch (error) {
        return Promise.reject(error);
      }
    };
  });
}.call(this, module);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"connection_options.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/connection_options.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @summary Allows for user specified connection options
 * @example http://mongodb.github.io/node-mongodb-native/3.0/reference/connecting/connection-settings/
 * @locus Server
 * @param {Object} options User specified Mongo connection options
 */
Mongo.setConnectionOptions = function setConnectionOptions(options) {
  check(options, Object);
  Mongo._connectionOptions = options;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo_utils.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/mongo_utils.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
const _excluded = ["fields", "projection"];
let _objectSpread;
module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }
}, 0);
let _objectWithoutProperties;
module.link("@babel/runtime/helpers/objectWithoutProperties", {
  default(v) {
    _objectWithoutProperties = v;
  }
}, 1);
module.export({
  normalizeProjection: () => normalizeProjection
});
const normalizeProjection = options => {
  // transform fields key in projection
  const _ref = options || {},
    {
      fields,
      projection
    } = _ref,
    otherOptions = _objectWithoutProperties(_ref, _excluded);
  // TODO: enable this comment when deprecating the fields option
  // Log.debug(`fields option has been deprecated, please use the new 'projection' instead`)

  return _objectSpread(_objectSpread({}, otherOptions), projection || fields ? {
    projection: fields || projection
  } : {});
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/mongo/mongo_driver.js");
require("/node_modules/meteor/mongo/oplog_tailing.js");
require("/node_modules/meteor/mongo/observe_multiplex.js");
require("/node_modules/meteor/mongo/doc_fetcher.js");
require("/node_modules/meteor/mongo/polling_observe_driver.js");
require("/node_modules/meteor/mongo/oplog_observe_driver.js");
require("/node_modules/meteor/mongo/oplog_v2_converter.js");
require("/node_modules/meteor/mongo/local_collection_driver.js");
require("/node_modules/meteor/mongo/remote_collection_driver.js");
require("/node_modules/meteor/mongo/collection.js");
require("/node_modules/meteor/mongo/connection_options.js");

/* Exports */
Package._define("mongo", {
  MongoInternals: MongoInternals,
  Mongo: Mongo,
  ObserveMultiplexer: ObserveMultiplexer
});

})();

//# sourceURL=meteor://💻app/packages/mongo.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28vbW9uZ29fZHJpdmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9vcGxvZ190YWlsaW5nLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9vYnNlcnZlX211bHRpcGxleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28vZG9jX2ZldGNoZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL3BvbGxpbmdfb2JzZXJ2ZV9kcml2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL29wbG9nX29ic2VydmVfZHJpdmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9vcGxvZ192Ml9jb252ZXJ0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL2xvY2FsX2NvbGxlY3Rpb25fZHJpdmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9yZW1vdGVfY29sbGVjdGlvbl9kcml2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL2Nvbm5lY3Rpb25fb3B0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28vbW9uZ29fdXRpbHMuanMiXSwibmFtZXMiOlsiX29iamVjdFNwcmVhZCIsIm1vZHVsZTEiLCJsaW5rIiwiZGVmYXVsdCIsInYiLCJub3JtYWxpemVQcm9qZWN0aW9uIiwiRG9jRmV0Y2hlciIsIkFTWU5DX0NVUlNPUl9NRVRIT0RTIiwiZ2V0QXN5bmNNZXRob2ROYW1lIiwicGF0aCIsInJlcXVpcmUiLCJ1dGlsIiwiTW9uZ29EQiIsIk5wbU1vZHVsZU1vbmdvZGIiLCJGdXR1cmUiLCJOcG0iLCJNb25nb0ludGVybmFscyIsIk5wbU1vZHVsZXMiLCJtb25nb2RiIiwidmVyc2lvbiIsIk5wbU1vZHVsZU1vbmdvZGJWZXJzaW9uIiwibW9kdWxlIiwiTnBtTW9kdWxlIiwiRklMRV9BU1NFVF9TVUZGSVgiLCJBU1NFVFNfRk9MREVSIiwiQVBQX0ZPTERFUiIsInJlcGxhY2VOYW1lcyIsImZpbHRlciIsInRoaW5nIiwiXyIsImlzQXJyYXkiLCJtYXAiLCJiaW5kIiwicmV0IiwiZWFjaCIsInZhbHVlIiwia2V5IiwiVGltZXN0YW1wIiwicHJvdG90eXBlIiwiY2xvbmUiLCJtYWtlTW9uZ29MZWdhbCIsIm5hbWUiLCJ1bm1ha2VNb25nb0xlZ2FsIiwic3Vic3RyIiwicmVwbGFjZU1vbmdvQXRvbVdpdGhNZXRlb3IiLCJkb2N1bWVudCIsIkJpbmFyeSIsInN1Yl90eXBlIiwiYnVmZmVyIiwiVWludDhBcnJheSIsIk9iamVjdElEIiwiTW9uZ28iLCJ0b0hleFN0cmluZyIsIkRlY2ltYWwxMjgiLCJEZWNpbWFsIiwidG9TdHJpbmciLCJzaXplIiwiRUpTT04iLCJmcm9tSlNPTlZhbHVlIiwidW5kZWZpbmVkIiwicmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28iLCJpc0JpbmFyeSIsIkJ1ZmZlciIsImZyb20iLCJmcm9tU3RyaW5nIiwiX2lzQ3VzdG9tVHlwZSIsInRvSlNPTlZhbHVlIiwicmVwbGFjZVR5cGVzIiwiYXRvbVRyYW5zZm9ybWVyIiwicmVwbGFjZWRUb3BMZXZlbEF0b20iLCJ2YWwiLCJ2YWxSZXBsYWNlZCIsIk1vbmdvQ29ubmVjdGlvbiIsInVybCIsIm9wdGlvbnMiLCJfTWV0ZW9yJHNldHRpbmdzIiwiX01ldGVvciRzZXR0aW5ncyRwYWNrIiwiX01ldGVvciRzZXR0aW5ncyRwYWNrMiIsInNlbGYiLCJfb2JzZXJ2ZU11bHRpcGxleGVycyIsIl9vbkZhaWxvdmVySG9vayIsIkhvb2siLCJ1c2VyT3B0aW9ucyIsIl9jb25uZWN0aW9uT3B0aW9ucyIsIk1ldGVvciIsInNldHRpbmdzIiwicGFja2FnZXMiLCJtb25nbyIsIm1vbmdvT3B0aW9ucyIsIk9iamVjdCIsImFzc2lnbiIsImlnbm9yZVVuZGVmaW5lZCIsImhhcyIsIm1heFBvb2xTaXplIiwibWluUG9vbFNpemUiLCJlbnRyaWVzIiwiX3JlZiIsImVuZHNXaXRoIiwiZm9yRWFjaCIsIl9yZWYyIiwib3B0aW9uTmFtZSIsInJlcGxhY2UiLCJqb2luIiwiQXNzZXRzIiwiZ2V0U2VydmVyRGlyIiwiZGIiLCJfb3Bsb2dIYW5kbGUiLCJfZG9jRmV0Y2hlciIsImNsaWVudCIsIk1vbmdvQ2xpZW50Iiwib24iLCJiaW5kRW52aXJvbm1lbnQiLCJldmVudCIsInByZXZpb3VzRGVzY3JpcHRpb24iLCJ0eXBlIiwibmV3RGVzY3JpcHRpb24iLCJjYWxsYmFjayIsIm9wbG9nVXJsIiwiUGFja2FnZSIsIk9wbG9nSGFuZGxlIiwiZGF0YWJhc2VOYW1lIiwiUHJvbWlzZSIsImF3YWl0IiwiY29ubmVjdCIsImNsb3NlIiwiRXJyb3IiLCJvcGxvZ0hhbmRsZSIsInN0b3AiLCJ3cmFwIiwid2FpdCIsInJhd0NvbGxlY3Rpb24iLCJjb2xsZWN0aW9uTmFtZSIsImNvbGxlY3Rpb24iLCJfY3JlYXRlQ2FwcGVkQ29sbGVjdGlvbiIsImJ5dGVTaXplIiwibWF4RG9jdW1lbnRzIiwiZnV0dXJlIiwiY3JlYXRlQ29sbGVjdGlvbiIsImNhcHBlZCIsIm1heCIsInJlc29sdmVyIiwiX21heWJlQmVnaW5Xcml0ZSIsImZlbmNlIiwiRERQU2VydmVyIiwiX0N1cnJlbnRXcml0ZUZlbmNlIiwiZ2V0IiwiYmVnaW5Xcml0ZSIsImNvbW1pdHRlZCIsIl9vbkZhaWxvdmVyIiwicmVnaXN0ZXIiLCJ3cml0ZUNhbGxiYWNrIiwid3JpdGUiLCJyZWZyZXNoIiwiZXJyIiwicmVzdWx0IiwicmVmcmVzaEVyciIsImJpbmRFbnZpcm9ubWVudEZvcldyaXRlIiwiX2luc2VydCIsImNvbGxlY3Rpb25fbmFtZSIsInNlbmRFcnJvciIsImUiLCJfZXhwZWN0ZWRCeVRlc3QiLCJMb2NhbENvbGxlY3Rpb24iLCJfaXNQbGFpbk9iamVjdCIsImlkIiwiX2lkIiwiaW5zZXJ0T25lIiwic2FmZSIsInRoZW4iLCJfcmVmMyIsImluc2VydGVkSWQiLCJjYXRjaCIsIl9yZWZyZXNoIiwic2VsZWN0b3IiLCJyZWZyZXNoS2V5Iiwic3BlY2lmaWNJZHMiLCJfaWRzTWF0Y2hlZEJ5U2VsZWN0b3IiLCJleHRlbmQiLCJfcmVtb3ZlIiwiZGVsZXRlTWFueSIsIl9yZWY0IiwiZGVsZXRlZENvdW50IiwidHJhbnNmb3JtUmVzdWx0IiwibW9kaWZpZWRDb3VudCIsIm51bWJlckFmZmVjdGVkIiwiX2Ryb3BDb2xsZWN0aW9uIiwiY2IiLCJkcm9wQ29sbGVjdGlvbiIsImRyb3AiLCJfZHJvcERhdGFiYXNlIiwiZHJvcERhdGFiYXNlIiwiX3VwZGF0ZSIsIm1vZCIsIkZ1bmN0aW9uIiwibW9uZ29PcHRzIiwiYXJyYXlGaWx0ZXJzIiwidXBzZXJ0IiwibXVsdGkiLCJmdWxsUmVzdWx0IiwibW9uZ29TZWxlY3RvciIsIm1vbmdvTW9kIiwiaXNNb2RpZnkiLCJfaXNNb2RpZmljYXRpb25Nb2QiLCJfZm9yYmlkUmVwbGFjZSIsImtub3duSWQiLCJuZXdEb2MiLCJfY3JlYXRlVXBzZXJ0RG9jdW1lbnQiLCJnZW5lcmF0ZWRJZCIsInNpbXVsYXRlVXBzZXJ0V2l0aEluc2VydGVkSWQiLCJlcnJvciIsIl9yZXR1cm5PYmplY3QiLCJoYXNPd25Qcm9wZXJ0eSIsIiRzZXRPbkluc2VydCIsInN0cmluZ3MiLCJrZXlzIiwic3RhcnRzV2l0aCIsInVwZGF0ZU1ldGhvZCIsImxlbmd0aCIsImFyZ3VtZW50cyIsIm1ldGVvclJlc3VsdCIsImRyaXZlclJlc3VsdCIsIm1vbmdvUmVzdWx0IiwidXBzZXJ0ZWRDb3VudCIsInVwc2VydGVkSWQiLCJuIiwibWF0Y2hlZENvdW50IiwiTlVNX09QVElNSVNUSUNfVFJJRVMiLCJfaXNDYW5ub3RDaGFuZ2VJZEVycm9yIiwiZXJybXNnIiwiaW5kZXhPZiIsIm1vbmdvT3B0c0ZvclVwZGF0ZSIsIm1vbmdvT3B0c0Zvckluc2VydCIsInJlcGxhY2VtZW50V2l0aElkIiwidHJpZXMiLCJkb1VwZGF0ZSIsIm1ldGhvZCIsInVwZGF0ZU1hbnkiLCJzb21lIiwicmVwbGFjZU9uZSIsImRvQ29uZGl0aW9uYWxJbnNlcnQiLCJ3cmFwQXN5bmMiLCJhcHBseSIsInVwZGF0ZSIsImZpbmQiLCJDdXJzb3IiLCJDdXJzb3JEZXNjcmlwdGlvbiIsImZpbmRPbmVBc3luYyIsImFzeW5jQXBwbHkiLCJsaW1pdCIsImZldGNoQXN5bmMiLCJmaW5kT25lIiwiZnJvbVByb21pc2UiLCJjcmVhdGVJbmRleEFzeW5jIiwiaW5kZXgiLCJjcmVhdGVJbmRleCIsImNvdW50RG9jdW1lbnRzIiwiX2xlbiIsImFyZ3MiLCJBcnJheSIsIl9rZXkiLCJhcmciLCJlc3RpbWF0ZWREb2N1bWVudENvdW50IiwiX2xlbjIiLCJfa2V5MiIsIl9lbnN1cmVJbmRleCIsIl9kcm9wSW5kZXgiLCJpbmRleE5hbWUiLCJkcm9wSW5kZXgiLCJDb2xsZWN0aW9uIiwiX3Jld3JpdGVTZWxlY3RvciIsImN1cnNvckRlc2NyaXB0aW9uIiwiX21vbmdvIiwiX2N1cnNvckRlc2NyaXB0aW9uIiwiX3N5bmNocm9ub3VzQ3Vyc29yIiwic2V0dXBTeW5jaHJvbm91c0N1cnNvciIsImN1cnNvciIsInRhaWxhYmxlIiwiX2NyZWF0ZVN5bmNocm9ub3VzQ3Vyc29yIiwic2VsZkZvckl0ZXJhdGlvbiIsInVzZVRyYW5zZm9ybSIsImNvdW50IiwiU3ltYm9sIiwiaXRlcmF0b3IiLCJhc3luY0l0ZXJhdG9yIiwibWV0aG9kTmFtZSIsIm1ldGhvZE5hbWVBc3luYyIsImlzQ2FsbGVkRnJvbUFzeW5jIiwicmVzb2x2ZSIsInJlamVjdCIsImdldFRyYW5zZm9ybSIsInRyYW5zZm9ybSIsIl9wdWJsaXNoQ3Vyc29yIiwic3ViIiwiX2dldENvbGxlY3Rpb25OYW1lIiwib2JzZXJ2ZSIsImNhbGxiYWNrcyIsIl9vYnNlcnZlRnJvbU9ic2VydmVDaGFuZ2VzIiwib2JzZXJ2ZUNoYW5nZXMiLCJtZXRob2RzIiwib3JkZXJlZCIsIl9vYnNlcnZlQ2hhbmdlc0NhbGxiYWNrc0FyZU9yZGVyZWQiLCJleGNlcHRpb25OYW1lIiwiX2Zyb21PYnNlcnZlIiwiX29ic2VydmVDaGFuZ2VzIiwibm9uTXV0YXRpbmdDYWxsYmFja3MiLCJwaWNrIiwiY3Vyc29yT3B0aW9ucyIsInNvcnQiLCJza2lwIiwicHJvamVjdGlvbiIsImZpZWxkcyIsInJlYWRQcmVmZXJlbmNlIiwibnVtYmVyT2ZSZXRyaWVzIiwiZGJDdXJzb3IiLCJhZGRDdXJzb3JGbGFnIiwiT1BMT0dfQ09MTEVDVElPTiIsInRzIiwibWF4VGltZU1zIiwibWF4VGltZU1TIiwiaGludCIsIlN5bmNocm9ub3VzQ3Vyc29yIiwiX2RiQ3Vyc29yIiwiX3NlbGZGb3JJdGVyYXRpb24iLCJfdHJhbnNmb3JtIiwid3JhcFRyYW5zZm9ybSIsIl9zeW5jaHJvbm91c0NvdW50IiwiX3Zpc2l0ZWRJZHMiLCJfSWRNYXAiLCJfcmF3TmV4dE9iamVjdFByb21pc2UiLCJuZXh0IiwiZG9jIiwiX25leHRPYmplY3RQcm9taXNlIiwic2V0IiwiX25leHRPYmplY3RQcm9taXNlV2l0aFRpbWVvdXQiLCJ0aW1lb3V0TVMiLCJuZXh0T2JqZWN0UHJvbWlzZSIsInRpbWVvdXRFcnIiLCJ0aW1lb3V0UHJvbWlzZSIsInRpbWVyIiwic2V0VGltZW91dCIsInJhY2UiLCJfbmV4dE9iamVjdCIsInRoaXNBcmciLCJ3cmFwcGVkRm4iLCJ3cmFwRm4iLCJfcmV3aW5kIiwiY2FsbCIsInJlcyIsInB1c2giLCJyZXdpbmQiLCJmZXRjaCIsImlkZW50aXR5IiwiZ2V0UmF3T2JqZWN0cyIsInJlc3VsdHMiLCJkb25lIiwic3luY1Jlc3VsdCIsInRhaWwiLCJkb2NDYWxsYmFjayIsInN0b3BwZWQiLCJsYXN0VFMiLCJsb29wIiwibmV3U2VsZWN0b3IiLCIkZ3QiLCJkZWZlciIsIl9vYnNlcnZlQ2hhbmdlc1RhaWxhYmxlIiwiZmllbGRzT3B0aW9ucyIsIm9ic2VydmVLZXkiLCJzdHJpbmdpZnkiLCJtdWx0aXBsZXhlciIsIm9ic2VydmVEcml2ZXIiLCJmaXJzdEhhbmRsZSIsIl9ub1lpZWxkc0FsbG93ZWQiLCJPYnNlcnZlTXVsdGlwbGV4ZXIiLCJvblN0b3AiLCJvYnNlcnZlSGFuZGxlIiwiT2JzZXJ2ZUhhbmRsZSIsIm1hdGNoZXIiLCJzb3J0ZXIiLCJjYW5Vc2VPcGxvZyIsImFsbCIsIl90ZXN0T25seVBvbGxDYWxsYmFjayIsIk1pbmltb25nbyIsIk1hdGNoZXIiLCJPcGxvZ09ic2VydmVEcml2ZXIiLCJjdXJzb3JTdXBwb3J0ZWQiLCJTb3J0ZXIiLCJmIiwiZHJpdmVyQ2xhc3MiLCJQb2xsaW5nT2JzZXJ2ZURyaXZlciIsIm1vbmdvSGFuZGxlIiwiX29ic2VydmVEcml2ZXIiLCJhZGRIYW5kbGVBbmRTZW5kSW5pdGlhbEFkZHMiLCJsaXN0ZW5BbGwiLCJsaXN0ZW5DYWxsYmFjayIsImxpc3RlbmVycyIsImZvckVhY2hUcmlnZ2VyIiwidHJpZ2dlciIsIl9JbnZhbGlkYXRpb25Dcm9zc2JhciIsImxpc3RlbiIsImxpc3RlbmVyIiwidHJpZ2dlckNhbGxiYWNrIiwiYWRkZWRCZWZvcmUiLCJhZGRlZCIsIk1vbmdvVGltZXN0YW1wIiwiQ29ubmVjdGlvbiIsIkxvbmciLCJUT09fRkFSX0JFSElORCIsInByb2Nlc3MiLCJlbnYiLCJNRVRFT1JfT1BMT0dfVE9PX0ZBUl9CRUhJTkQiLCJUQUlMX1RJTUVPVVQiLCJNRVRFT1JfT1BMT0dfVEFJTF9USU1FT1VUIiwic2hvd1RTIiwiZ2V0SGlnaEJpdHMiLCJnZXRMb3dCaXRzIiwiaWRGb3JPcCIsIm9wIiwibyIsIm8yIiwiZGJOYW1lIiwiX29wbG9nVXJsIiwiX2RiTmFtZSIsIl9vcGxvZ0xhc3RFbnRyeUNvbm5lY3Rpb24iLCJfb3Bsb2dUYWlsQ29ubmVjdGlvbiIsIl9zdG9wcGVkIiwiX3RhaWxIYW5kbGUiLCJfcmVhZHlGdXR1cmUiLCJfY3Jvc3NiYXIiLCJfQ3Jvc3NiYXIiLCJmYWN0UGFja2FnZSIsImZhY3ROYW1lIiwiX2Jhc2VPcGxvZ1NlbGVjdG9yIiwibnMiLCJSZWdFeHAiLCJfZXNjYXBlUmVnRXhwIiwiJG9yIiwiJGluIiwiJGV4aXN0cyIsIl9jYXRjaGluZ1VwRnV0dXJlcyIsIl9sYXN0UHJvY2Vzc2VkVFMiLCJfb25Ta2lwcGVkRW50cmllc0hvb2siLCJkZWJ1Z1ByaW50RXhjZXB0aW9ucyIsIl9lbnRyeVF1ZXVlIiwiX0RvdWJsZUVuZGVkUXVldWUiLCJfd29ya2VyQWN0aXZlIiwiX3N0YXJ0VGFpbGluZyIsIm9uT3Bsb2dFbnRyeSIsIm9yaWdpbmFsQ2FsbGJhY2siLCJub3RpZmljYXRpb24iLCJfZGVidWciLCJsaXN0ZW5IYW5kbGUiLCJvblNraXBwZWRFbnRyaWVzIiwid2FpdFVudGlsQ2F1Z2h0VXAiLCJsYXN0RW50cnkiLCIkbmF0dXJhbCIsIl9zbGVlcEZvck1zIiwibGVzc1RoYW5PckVxdWFsIiwiaW5zZXJ0QWZ0ZXIiLCJncmVhdGVyVGhhbiIsInNwbGljZSIsIm1vbmdvZGJVcmkiLCJwYXJzZSIsImRhdGFiYXNlIiwiYWRtaW4iLCJjb21tYW5kIiwiaXNtYXN0ZXIiLCJpc01hc3RlckRvYyIsInNldE5hbWUiLCJsYXN0T3Bsb2dFbnRyeSIsIm9wbG9nU2VsZWN0b3IiLCJfbWF5YmVTdGFydFdvcmtlciIsInJldHVybiIsImhhbmRsZURvYyIsImFwcGx5T3BzIiwibmV4dFRpbWVzdGFtcCIsImFkZCIsIk9ORSIsInNsaWNlIiwiZmlyZSIsImlzRW1wdHkiLCJwb3AiLCJjbGVhciIsIl9zZXRMYXN0UHJvY2Vzc2VkVFMiLCJzaGlmdCIsInNlcXVlbmNlciIsIl9kZWZpbmVUb29GYXJCZWhpbmQiLCJfcmVzZXRUb29GYXJCZWhpbmQiLCJfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMiLCJGYWN0cyIsImluY3JlbWVudFNlcnZlckZhY3QiLCJfb3JkZXJlZCIsIl9vblN0b3AiLCJfcXVldWUiLCJfU3luY2hyb25vdXNRdWV1ZSIsIl9oYW5kbGVzIiwiX2NhY2hlIiwiX0NhY2hpbmdDaGFuZ2VPYnNlcnZlciIsIl9hZGRIYW5kbGVUYXNrc1NjaGVkdWxlZEJ1dE5vdFBlcmZvcm1lZCIsImNhbGxiYWNrTmFtZXMiLCJjYWxsYmFja05hbWUiLCJfYXBwbHlDYWxsYmFjayIsInRvQXJyYXkiLCJoYW5kbGUiLCJzYWZlVG9SdW5UYXNrIiwicnVuVGFzayIsIl9zZW5kQWRkcyIsInJlbW92ZUhhbmRsZSIsIl9yZWFkeSIsIl9zdG9wIiwiZnJvbVF1ZXJ5RXJyb3IiLCJyZWFkeSIsInF1ZXVlVGFzayIsInF1ZXJ5RXJyb3IiLCJ0aHJvdyIsIm9uRmx1c2giLCJpc1Jlc29sdmVkIiwiYXBwbHlDaGFuZ2UiLCJoYW5kbGVJZCIsIl9hZGRlZEJlZm9yZSIsIl9hZGRlZCIsImRvY3MiLCJfZXhjbHVkZWQiLCJuZXh0T2JzZXJ2ZUhhbmRsZUlkIiwiX211bHRpcGxleGVyIiwiYmVmb3JlIiwiZXhwb3J0IiwiRmliZXIiLCJjb25zdHJ1Y3RvciIsIm1vbmdvQ29ubmVjdGlvbiIsIl9tb25nb0Nvbm5lY3Rpb24iLCJfY2FsbGJhY2tzRm9yT3AiLCJNYXAiLCJjaGVjayIsIlN0cmluZyIsImRlbGV0ZSIsInJ1biIsIlBPTExJTkdfVEhST1RUTEVfTVMiLCJNRVRFT1JfUE9MTElOR19USFJPVFRMRV9NUyIsIlBPTExJTkdfSU5URVJWQUxfTVMiLCJNRVRFT1JfUE9MTElOR19JTlRFUlZBTF9NUyIsIl9tb25nb0hhbmRsZSIsIl9zdG9wQ2FsbGJhY2tzIiwiX3Jlc3VsdHMiLCJfcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkIiwiX3BlbmRpbmdXcml0ZXMiLCJfZW5zdXJlUG9sbElzU2NoZWR1bGVkIiwidGhyb3R0bGUiLCJfdW50aHJvdHRsZWRFbnN1cmVQb2xsSXNTY2hlZHVsZWQiLCJwb2xsaW5nVGhyb3R0bGVNcyIsIl90YXNrUXVldWUiLCJsaXN0ZW5lcnNIYW5kbGUiLCJwb2xsaW5nSW50ZXJ2YWwiLCJwb2xsaW5nSW50ZXJ2YWxNcyIsIl9wb2xsaW5nSW50ZXJ2YWwiLCJpbnRlcnZhbEhhbmRsZSIsInNldEludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsIl9wb2xsTW9uZ28iLCJfc3VzcGVuZFBvbGxpbmciLCJfcmVzdW1lUG9sbGluZyIsImZpcnN0IiwibmV3UmVzdWx0cyIsIm9sZFJlc3VsdHMiLCJ3cml0ZXNGb3JDeWNsZSIsImNvZGUiLCJKU09OIiwibWVzc2FnZSIsIl9kaWZmUXVlcnlDaGFuZ2VzIiwidyIsImMiLCJvcGxvZ1YyVjFDb252ZXJ0ZXIiLCJQSEFTRSIsIlFVRVJZSU5HIiwiRkVUQ0hJTkciLCJTVEVBRFkiLCJTd2l0Y2hlZFRvUXVlcnkiLCJmaW5pc2hJZk5lZWRUb1BvbGxRdWVyeSIsImN1cnJlbnRJZCIsIl91c2VzT3Bsb2ciLCJjb21wYXJhdG9yIiwiZ2V0Q29tcGFyYXRvciIsImhlYXBPcHRpb25zIiwiSWRNYXAiLCJfbGltaXQiLCJfY29tcGFyYXRvciIsIl9zb3J0ZXIiLCJfdW5wdWJsaXNoZWRCdWZmZXIiLCJNaW5NYXhIZWFwIiwiX3B1Ymxpc2hlZCIsIk1heEhlYXAiLCJfc2FmZUFwcGVuZFRvQnVmZmVyIiwiX3N0b3BIYW5kbGVzIiwiX3JlZ2lzdGVyUGhhc2VDaGFuZ2UiLCJfbWF0Y2hlciIsIl9wcm9qZWN0aW9uRm4iLCJfY29tcGlsZVByb2plY3Rpb24iLCJfc2hhcmVkUHJvamVjdGlvbiIsImNvbWJpbmVJbnRvUHJvamVjdGlvbiIsIl9zaGFyZWRQcm9qZWN0aW9uRm4iLCJfbmVlZFRvRmV0Y2giLCJfY3VycmVudGx5RmV0Y2hpbmciLCJfZmV0Y2hHZW5lcmF0aW9uIiwiX3JlcXVlcnlXaGVuRG9uZVRoaXNRdWVyeSIsIl93cml0ZXNUb0NvbW1pdFdoZW5XZVJlYWNoU3RlYWR5IiwiX25lZWRUb1BvbGxRdWVyeSIsIl9waGFzZSIsIl9oYW5kbGVPcGxvZ0VudHJ5UXVlcnlpbmciLCJfaGFuZGxlT3Bsb2dFbnRyeVN0ZWFkeU9yRmV0Y2hpbmciLCJmaXJlZCIsIl9vcGxvZ09ic2VydmVEcml2ZXJzIiwib25CZWZvcmVGaXJlIiwiZHJpdmVycyIsImRyaXZlciIsIl9ydW5Jbml0aWFsUXVlcnkiLCJfYWRkUHVibGlzaGVkIiwib3ZlcmZsb3dpbmdEb2NJZCIsIm1heEVsZW1lbnRJZCIsIm92ZXJmbG93aW5nRG9jIiwiZXF1YWxzIiwicmVtb3ZlIiwicmVtb3ZlZCIsIl9hZGRCdWZmZXJlZCIsIl9yZW1vdmVQdWJsaXNoZWQiLCJlbXB0eSIsIm5ld0RvY0lkIiwibWluRWxlbWVudElkIiwiX3JlbW92ZUJ1ZmZlcmVkIiwiX2NoYW5nZVB1Ymxpc2hlZCIsIm9sZERvYyIsInByb2plY3RlZE5ldyIsInByb2plY3RlZE9sZCIsImNoYW5nZWQiLCJEaWZmU2VxdWVuY2UiLCJtYWtlQ2hhbmdlZEZpZWxkcyIsIm1heEJ1ZmZlcmVkSWQiLCJfYWRkTWF0Y2hpbmciLCJtYXhQdWJsaXNoZWQiLCJtYXhCdWZmZXJlZCIsInRvUHVibGlzaCIsImNhbkFwcGVuZFRvQnVmZmVyIiwiY2FuSW5zZXJ0SW50b0J1ZmZlciIsInRvQnVmZmVyIiwiX3JlbW92ZU1hdGNoaW5nIiwiX2hhbmRsZURvYyIsIm1hdGNoZXNOb3ciLCJkb2N1bWVudE1hdGNoZXMiLCJwdWJsaXNoZWRCZWZvcmUiLCJidWZmZXJlZEJlZm9yZSIsImNhY2hlZEJlZm9yZSIsIm1pbkJ1ZmZlcmVkIiwic3RheXNJblB1Ymxpc2hlZCIsInN0YXlzSW5CdWZmZXIiLCJfZmV0Y2hNb2RpZmllZERvY3VtZW50cyIsInRoaXNHZW5lcmF0aW9uIiwid2FpdGluZyIsImZ1dCIsIl9iZVN0ZWFkeSIsIndyaXRlcyIsImlzUmVwbGFjZSIsImNhbkRpcmVjdGx5TW9kaWZ5RG9jIiwibW9kaWZpZXJDYW5CZURpcmVjdGx5QXBwbGllZCIsIl9tb2RpZnkiLCJjYW5CZWNvbWVUcnVlQnlNb2RpZmllciIsImFmZmVjdGVkQnlNb2RpZmllciIsIl9ydW5RdWVyeSIsImluaXRpYWwiLCJfZG9uZVF1ZXJ5aW5nIiwiX3BvbGxRdWVyeSIsIm5ld0J1ZmZlciIsIl9jdXJzb3JGb3JRdWVyeSIsImkiLCJfcHVibGlzaE5ld1Jlc3VsdHMiLCJvcHRpb25zT3ZlcndyaXRlIiwiZGVzY3JpcHRpb24iLCJpZHNUb1JlbW92ZSIsIl9vcGxvZ0VudHJ5SGFuZGxlIiwiX2xpc3RlbmVyc0hhbmRsZSIsInBoYXNlIiwibm93IiwiRGF0ZSIsInRpbWVEaWZmIiwiX3BoYXNlU3RhcnRUaW1lIiwiZGlzYWJsZU9wbG9nIiwiX2Rpc2FibGVPcGxvZyIsIl9jaGVja1N1cHBvcnRlZFByb2plY3Rpb24iLCJoYXNXaGVyZSIsImhhc0dlb1F1ZXJ5IiwibW9kaWZpZXIiLCJvcGVyYXRpb24iLCJmaWVsZCIsInRlc3QiLCJwcmVmaXgiLCJjb25jYXQiLCJhcnJheU9wZXJhdG9yS2V5UmVnZXgiLCJpc0FycmF5T3BlcmF0b3JLZXkiLCJpc0FycmF5T3BlcmF0b3IiLCJvcGVyYXRvciIsImEiLCJldmVyeSIsImZsYXR0ZW5PYmplY3RJbnRvIiwidGFyZ2V0Iiwic291cmNlIiwibG9nRGVidWdNZXNzYWdlcyIsIk9QTE9HX0NPTlZFUlRFUl9ERUJVRyIsImNvbnZlcnRPcGxvZ0RpZmYiLCJvcGxvZ0VudHJ5IiwiZGlmZiIsImNvbnNvbGUiLCJsb2ciLCJkaWZmS2V5IiwiX29wbG9nRW50cnkkJHVuc2V0IiwiJHVuc2V0IiwiX29wbG9nRW50cnkkJHNldCIsIiRzZXQiLCJfb3Bsb2dFbnRyeSQkc2V0MiIsInBvc2l0aW9uIiwicG9zaXRpb25LZXkiLCJfb3Bsb2dFbnRyeSQkdW5zZXQyIiwiX29wbG9nRW50cnkkJHNldDMiLCIkdiIsImNvbnZlcnRlZE9wbG9nRW50cnkiLCJMb2NhbENvbGxlY3Rpb25Ecml2ZXIiLCJub0Nvbm5Db2xsZWN0aW9ucyIsImNyZWF0ZSIsIm9wZW4iLCJjb25uIiwiZW5zdXJlQ29sbGVjdGlvbiIsIl9tb25nb19saXZlZGF0YV9jb2xsZWN0aW9ucyIsImNvbGxlY3Rpb25zIiwiQVNZTkNfQ09MTEVDVElPTl9NRVRIT0RTIiwiUmVtb3RlQ29sbGVjdGlvbkRyaXZlciIsIm1vbmdvX3VybCIsIlJFTU9URV9DT0xMRUNUSU9OX01FVEhPRFMiLCJtIiwiaW5jbHVkZXMiLCJhc3luY01ldGhvZE5hbWUiLCJkZWZhdWx0UmVtb3RlQ29sbGVjdGlvbkRyaXZlciIsIm9uY2UiLCJjb25uZWN0aW9uT3B0aW9ucyIsIm1vbmdvVXJsIiwiTU9OR09fVVJMIiwiTU9OR09fT1BMT0dfVVJMIiwic3RhcnR1cCIsIndhcm5Vc2luZ09sZEFwaSIsIldBUk5fV0hFTl9VU0lOR19PTERfQVBJIiwid2FybiIsInRyYWNlIiwiY29ubmVjdGlvbiIsIm1hbmFnZXIiLCJpZEdlbmVyYXRpb24iLCJfZHJpdmVyIiwiX3ByZXZlbnRBdXRvcHVibGlzaCIsIl9tYWtlTmV3SUQiLCJzcmMiLCJERFAiLCJyYW5kb21TdHJlYW0iLCJSYW5kb20iLCJpbnNlY3VyZSIsImhleFN0cmluZyIsIl9jb25uZWN0aW9uIiwiaXNDbGllbnQiLCJzZXJ2ZXIiLCJfY29sbGVjdGlvbiIsIl9uYW1lIiwiX21heWJlU2V0VXBSZXBsaWNhdGlvbiIsImRlZmluZU11dGF0aW9uTWV0aG9kcyIsIl9kZWZpbmVNdXRhdGlvbk1ldGhvZHMiLCJ1c2VFeGlzdGluZyIsIl9zdXBwcmVzc1NhbWVOYW1lRXJyb3IiLCJhdXRvcHVibGlzaCIsInB1Ymxpc2giLCJpc19hdXRvIiwicmVnaXN0ZXJTdG9yZSIsIm9rIiwiYmVnaW5VcGRhdGUiLCJiYXRjaFNpemUiLCJyZXNldCIsInBhdXNlT2JzZXJ2ZXJzIiwibXNnIiwibW9uZ29JZCIsIk1vbmdvSUQiLCJpZFBhcnNlIiwiX2RvY3MiLCJpbnNlcnQiLCJlbmRVcGRhdGUiLCJyZXN1bWVPYnNlcnZlcnMiLCJzYXZlT3JpZ2luYWxzIiwicmV0cmlldmVPcmlnaW5hbHMiLCJnZXREb2MiLCJfZ2V0Q29sbGVjdGlvbiIsIl9nZXRGaW5kU2VsZWN0b3IiLCJfZ2V0RmluZE9wdGlvbnMiLCJuZXdPcHRpb25zIiwiTWF0Y2giLCJPcHRpb25hbCIsIk9iamVjdEluY2x1ZGluZyIsIk9uZU9mIiwiTnVtYmVyIiwiZmFsbGJhY2tJZCIsIl9zZWxlY3RvcklzSWQiLCJnZXRQcm90b3R5cGVPZiIsImdldE93blByb3BlcnR5RGVzY3JpcHRvcnMiLCJnZW5lcmF0ZUlkIiwiX2lzUmVtb3RlQ29sbGVjdGlvbiIsImVuY2xvc2luZyIsIl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbiIsImNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHQiLCJ3cmFwcGVkQ2FsbGJhY2siLCJ3cmFwQ2FsbGJhY2siLCJfY2FsbE11dGF0b3JNZXRob2QiLCJfbGVuMyIsIm9wdGlvbnNBbmRDYWxsYmFjayIsIl9rZXkzIiwicG9wQ2FsbGJhY2tGcm9tQXJncyIsIkxvZyIsImRlYnVnIiwicmVDcmVhdGVJbmRleE9uT3B0aW9uTWlzbWF0Y2giLCJpbmZvIiwicmF3RGF0YWJhc2UiLCJjb252ZXJ0UmVzdWx0IiwiQWxsb3dEZW55IiwiQ29sbGVjdGlvblByb3RvdHlwZSIsInNldENvbm5lY3Rpb25PcHRpb25zIiwib3RoZXJPcHRpb25zIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQUFBLElBQUlBLGFBQWE7RUFBQ0MsT0FBTyxDQUFDQyxJQUFJLENBQUMsc0NBQXNDLEVBQUM7SUFBQ0MsT0FBT0EsQ0FBQ0MsQ0FBQyxFQUFDO01BQUNKLGFBQWEsR0FBQ0ksQ0FBQztJQUFBO0VBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztFQUF0RyxJQUFJQyxtQkFBbUI7RUFBQ0osT0FBTyxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0lBQUNHLG1CQUFtQkEsQ0FBQ0QsQ0FBQyxFQUFDO01BQUNDLG1CQUFtQixHQUFDRCxDQUFDO0lBQUE7RUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUMsSUFBSUUsVUFBVTtFQUFDTCxPQUFPLENBQUNDLElBQUksQ0FBQyxrQkFBa0IsRUFBQztJQUFDSSxVQUFVQSxDQUFDRixDQUFDLEVBQUM7TUFBQ0UsVUFBVSxHQUFDRixDQUFDO0lBQUE7RUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQUMsSUFBSUcsb0JBQW9CLEVBQUNDLGtCQUFrQjtFQUFDUCxPQUFPLENBQUNDLElBQUksQ0FBQyw0QkFBNEIsRUFBQztJQUFDSyxvQkFBb0JBLENBQUNILENBQUMsRUFBQztNQUFDRyxvQkFBb0IsR0FBQ0gsQ0FBQztJQUFBLENBQUM7SUFBQ0ksa0JBQWtCQSxDQUFDSixDQUFDLEVBQUM7TUFBQ0ksa0JBQWtCLEdBQUNKLENBQUM7SUFBQTtFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFFOVc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7RUFFQSxNQUFNSyxJQUFJLEdBQUdDLE9BQU8sQ0FBQyxNQUFNLENBQUM7RUFDNUIsTUFBTUMsSUFBSSxHQUFHRCxPQUFPLENBQUMsTUFBTSxDQUFDOztFQUU1QjtFQUNBLElBQUlFLE9BQU8sR0FBR0MsZ0JBQWdCO0VBQzlCLElBQUlDLE1BQU0sR0FBR0MsR0FBRyxDQUFDTCxPQUFPLENBQUMsZUFBZSxDQUFDO0VBT3pDTSxjQUFjLEdBQUcsQ0FBQyxDQUFDO0VBRW5CQSxjQUFjLENBQUNDLFVBQVUsR0FBRztJQUMxQkMsT0FBTyxFQUFFO01BQ1BDLE9BQU8sRUFBRUMsdUJBQXVCO01BQ2hDQyxNQUFNLEVBQUVUO0lBQ1Y7RUFDRixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0FJLGNBQWMsQ0FBQ00sU0FBUyxHQUFHVixPQUFPO0VBRWxDLE1BQU1XLGlCQUFpQixHQUFHLE9BQU87RUFDakMsTUFBTUMsYUFBYSxHQUFHLFFBQVE7RUFDOUIsTUFBTUMsVUFBVSxHQUFHLEtBQUs7O0VBRXhCO0VBQ0E7RUFDQSxJQUFJQyxZQUFZLEdBQUcsU0FBQUEsQ0FBVUMsTUFBTSxFQUFFQyxLQUFLLEVBQUU7SUFDMUMsSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJQSxLQUFLLEtBQUssSUFBSSxFQUFFO01BQy9DLElBQUlDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDRixLQUFLLENBQUMsRUFBRTtRQUNwQixPQUFPQyxDQUFDLENBQUNFLEdBQUcsQ0FBQ0gsS0FBSyxFQUFFQyxDQUFDLENBQUNHLElBQUksQ0FBQ04sWUFBWSxFQUFFLElBQUksRUFBRUMsTUFBTSxDQUFDLENBQUM7TUFDekQ7TUFDQSxJQUFJTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO01BQ1pKLENBQUMsQ0FBQ0ssSUFBSSxDQUFDTixLQUFLLEVBQUUsVUFBVU8sS0FBSyxFQUFFQyxHQUFHLEVBQUU7UUFDbENILEdBQUcsQ0FBQ04sTUFBTSxDQUFDUyxHQUFHLENBQUMsQ0FBQyxHQUFHVixZQUFZLENBQUNDLE1BQU0sRUFBRVEsS0FBSyxDQUFDO01BQ2hELENBQUMsQ0FBQztNQUNGLE9BQU9GLEdBQUc7SUFDWjtJQUNBLE9BQU9MLEtBQUs7RUFDZCxDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBaEIsT0FBTyxDQUFDeUIsU0FBUyxDQUFDQyxTQUFTLENBQUNDLEtBQUssR0FBRyxZQUFZO0lBQzlDO0lBQ0EsT0FBTyxJQUFJO0VBQ2IsQ0FBQztFQUVELElBQUlDLGNBQWMsR0FBRyxTQUFBQSxDQUFVQyxJQUFJLEVBQUU7SUFBRSxPQUFPLE9BQU8sR0FBR0EsSUFBSTtFQUFFLENBQUM7RUFDL0QsSUFBSUMsZ0JBQWdCLEdBQUcsU0FBQUEsQ0FBVUQsSUFBSSxFQUFFO0lBQUUsT0FBT0EsSUFBSSxDQUFDRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQUUsQ0FBQztFQUVqRSxJQUFJQywwQkFBMEIsR0FBRyxTQUFBQSxDQUFVQyxRQUFRLEVBQUU7SUFDbkQsSUFBSUEsUUFBUSxZQUFZakMsT0FBTyxDQUFDa0MsTUFBTSxFQUFFO01BQ3RDO01BQ0EsSUFBSUQsUUFBUSxDQUFDRSxRQUFRLEtBQUssQ0FBQyxFQUFFO1FBQzNCLE9BQU9GLFFBQVE7TUFDakI7TUFDQSxJQUFJRyxNQUFNLEdBQUdILFFBQVEsQ0FBQ1YsS0FBSyxDQUFDLElBQUksQ0FBQztNQUNqQyxPQUFPLElBQUljLFVBQVUsQ0FBQ0QsTUFBTSxDQUFDO0lBQy9CO0lBQ0EsSUFBSUgsUUFBUSxZQUFZakMsT0FBTyxDQUFDc0MsUUFBUSxFQUFFO01BQ3hDLE9BQU8sSUFBSUMsS0FBSyxDQUFDRCxRQUFRLENBQUNMLFFBQVEsQ0FBQ08sV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUlQLFFBQVEsWUFBWWpDLE9BQU8sQ0FBQ3lDLFVBQVUsRUFBRTtNQUMxQyxPQUFPQyxPQUFPLENBQUNULFFBQVEsQ0FBQ1UsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNyQztJQUNBLElBQUlWLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSUEsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJaEIsQ0FBQyxDQUFDMkIsSUFBSSxDQUFDWCxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUU7TUFDL0UsT0FBT1ksS0FBSyxDQUFDQyxhQUFhLENBQUNoQyxZQUFZLENBQUNnQixnQkFBZ0IsRUFBRUcsUUFBUSxDQUFDLENBQUM7SUFDdEU7SUFDQSxJQUFJQSxRQUFRLFlBQVlqQyxPQUFPLENBQUN5QixTQUFTLEVBQUU7TUFDekM7TUFDQTtNQUNBO01BQ0E7TUFDQSxPQUFPUSxRQUFRO0lBQ2pCO0lBQ0EsT0FBT2MsU0FBUztFQUNsQixDQUFDO0VBRUQsSUFBSUMsMEJBQTBCLEdBQUcsU0FBQUEsQ0FBVWYsUUFBUSxFQUFFO0lBQ25ELElBQUlZLEtBQUssQ0FBQ0ksUUFBUSxDQUFDaEIsUUFBUSxDQUFDLEVBQUU7TUFDNUI7TUFDQTtNQUNBO01BQ0EsT0FBTyxJQUFJakMsT0FBTyxDQUFDa0MsTUFBTSxDQUFDZ0IsTUFBTSxDQUFDQyxJQUFJLENBQUNsQixRQUFRLENBQUMsQ0FBQztJQUNsRDtJQUNBLElBQUlBLFFBQVEsWUFBWWpDLE9BQU8sQ0FBQ2tDLE1BQU0sRUFBRTtNQUNyQyxPQUFPRCxRQUFRO0lBQ2xCO0lBQ0EsSUFBSUEsUUFBUSxZQUFZTSxLQUFLLENBQUNELFFBQVEsRUFBRTtNQUN0QyxPQUFPLElBQUl0QyxPQUFPLENBQUNzQyxRQUFRLENBQUNMLFFBQVEsQ0FBQ08sV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNyRDtJQUNBLElBQUlQLFFBQVEsWUFBWWpDLE9BQU8sQ0FBQ3lCLFNBQVMsRUFBRTtNQUN6QztNQUNBO01BQ0E7TUFDQTtNQUNBLE9BQU9RLFFBQVE7SUFDakI7SUFDQSxJQUFJQSxRQUFRLFlBQVlTLE9BQU8sRUFBRTtNQUMvQixPQUFPMUMsT0FBTyxDQUFDeUMsVUFBVSxDQUFDVyxVQUFVLENBQUNuQixRQUFRLENBQUNVLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDM0Q7SUFDQSxJQUFJRSxLQUFLLENBQUNRLGFBQWEsQ0FBQ3BCLFFBQVEsQ0FBQyxFQUFFO01BQ2pDLE9BQU9uQixZQUFZLENBQUNjLGNBQWMsRUFBRWlCLEtBQUssQ0FBQ1MsV0FBVyxDQUFDckIsUUFBUSxDQUFDLENBQUM7SUFDbEU7SUFDQTtJQUNBO0lBQ0EsT0FBT2MsU0FBUztFQUNsQixDQUFDO0VBRUQsSUFBSVEsWUFBWSxHQUFHLFNBQUFBLENBQVV0QixRQUFRLEVBQUV1QixlQUFlLEVBQUU7SUFDdEQsSUFBSSxPQUFPdkIsUUFBUSxLQUFLLFFBQVEsSUFBSUEsUUFBUSxLQUFLLElBQUksRUFDbkQsT0FBT0EsUUFBUTtJQUVqQixJQUFJd0Isb0JBQW9CLEdBQUdELGVBQWUsQ0FBQ3ZCLFFBQVEsQ0FBQztJQUNwRCxJQUFJd0Isb0JBQW9CLEtBQUtWLFNBQVMsRUFDcEMsT0FBT1Usb0JBQW9CO0lBRTdCLElBQUlwQyxHQUFHLEdBQUdZLFFBQVE7SUFDbEJoQixDQUFDLENBQUNLLElBQUksQ0FBQ1csUUFBUSxFQUFFLFVBQVV5QixHQUFHLEVBQUVsQyxHQUFHLEVBQUU7TUFDbkMsSUFBSW1DLFdBQVcsR0FBR0osWUFBWSxDQUFDRyxHQUFHLEVBQUVGLGVBQWUsQ0FBQztNQUNwRCxJQUFJRSxHQUFHLEtBQUtDLFdBQVcsRUFBRTtRQUN2QjtRQUNBLElBQUl0QyxHQUFHLEtBQUtZLFFBQVEsRUFDbEJaLEdBQUcsR0FBR0osQ0FBQyxDQUFDVSxLQUFLLENBQUNNLFFBQVEsQ0FBQztRQUN6QlosR0FBRyxDQUFDRyxHQUFHLENBQUMsR0FBR21DLFdBQVc7TUFDeEI7SUFDRixDQUFDLENBQUM7SUFDRixPQUFPdEMsR0FBRztFQUNaLENBQUM7RUFHRHVDLGVBQWUsR0FBRyxTQUFBQSxDQUFVQyxHQUFHLEVBQUVDLE9BQU8sRUFBRTtJQUFBLElBQUFDLGdCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLHNCQUFBO0lBQ3hDLElBQUlDLElBQUksR0FBRyxJQUFJO0lBQ2ZKLE9BQU8sR0FBR0EsT0FBTyxJQUFJLENBQUMsQ0FBQztJQUN2QkksSUFBSSxDQUFDQyxvQkFBb0IsR0FBRyxDQUFDLENBQUM7SUFDOUJELElBQUksQ0FBQ0UsZUFBZSxHQUFHLElBQUlDLElBQUksQ0FBRCxDQUFDO0lBRS9CLE1BQU1DLFdBQVcsR0FBQWxGLGFBQUEsQ0FBQUEsYUFBQSxLQUNYbUQsS0FBSyxDQUFDZ0Msa0JBQWtCLElBQUksQ0FBQyxDQUFDLEdBQzlCLEVBQUFSLGdCQUFBLEdBQUFTLE1BQU0sQ0FBQ0MsUUFBUSxjQUFBVixnQkFBQSx3QkFBQUMscUJBQUEsR0FBZkQsZ0JBQUEsQ0FBaUJXLFFBQVEsY0FBQVYscUJBQUEsd0JBQUFDLHNCQUFBLEdBQXpCRCxxQkFBQSxDQUEyQlcsS0FBSyxjQUFBVixzQkFBQSx1QkFBaENBLHNCQUFBLENBQWtDSCxPQUFPLEtBQUksQ0FBQyxDQUFDLENBQ3BEO0lBRUQsSUFBSWMsWUFBWSxHQUFHQyxNQUFNLENBQUNDLE1BQU0sQ0FBQztNQUMvQkMsZUFBZSxFQUFFO0lBQ25CLENBQUMsRUFBRVQsV0FBVyxDQUFDOztJQUlmO0lBQ0E7SUFDQSxJQUFJckQsQ0FBQyxDQUFDK0QsR0FBRyxDQUFDbEIsT0FBTyxFQUFFLGFBQWEsQ0FBQyxFQUFFO01BQ2pDO01BQ0E7TUFDQWMsWUFBWSxDQUFDSyxXQUFXLEdBQUduQixPQUFPLENBQUNtQixXQUFXO0lBQ2hEO0lBQ0EsSUFBSWhFLENBQUMsQ0FBQytELEdBQUcsQ0FBQ2xCLE9BQU8sRUFBRSxhQUFhLENBQUMsRUFBRTtNQUNqQ2MsWUFBWSxDQUFDTSxXQUFXLEdBQUdwQixPQUFPLENBQUNvQixXQUFXO0lBQ2hEOztJQUVBO0lBQ0E7SUFDQUwsTUFBTSxDQUFDTSxPQUFPLENBQUNQLFlBQVksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUMvQjdELE1BQU0sQ0FBQ3FFLElBQUE7TUFBQSxJQUFDLENBQUM1RCxHQUFHLENBQUMsR0FBQTRELElBQUE7TUFBQSxPQUFLNUQsR0FBRyxJQUFJQSxHQUFHLENBQUM2RCxRQUFRLENBQUMxRSxpQkFBaUIsQ0FBQztJQUFBLEVBQUMsQ0FDekQyRSxPQUFPLENBQUNDLEtBQUEsSUFBa0I7TUFBQSxJQUFqQixDQUFDL0QsR0FBRyxFQUFFRCxLQUFLLENBQUMsR0FBQWdFLEtBQUE7TUFDcEIsTUFBTUMsVUFBVSxHQUFHaEUsR0FBRyxDQUFDaUUsT0FBTyxDQUFDOUUsaUJBQWlCLEVBQUUsRUFBRSxDQUFDO01BQ3JEaUUsWUFBWSxDQUFDWSxVQUFVLENBQUMsR0FBRzNGLElBQUksQ0FBQzZGLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxZQUFZLENBQUMsQ0FBQyxFQUN4RGhGLGFBQWEsRUFBRUMsVUFBVSxFQUFFVSxLQUFLLENBQUM7TUFDbkMsT0FBT3FELFlBQVksQ0FBQ3BELEdBQUcsQ0FBQztJQUMxQixDQUFDLENBQUM7SUFFSjBDLElBQUksQ0FBQzJCLEVBQUUsR0FBRyxJQUFJO0lBQ2QzQixJQUFJLENBQUM0QixZQUFZLEdBQUcsSUFBSTtJQUN4QjVCLElBQUksQ0FBQzZCLFdBQVcsR0FBRyxJQUFJO0lBRXZCN0IsSUFBSSxDQUFDOEIsTUFBTSxHQUFHLElBQUloRyxPQUFPLENBQUNpRyxXQUFXLENBQUNwQyxHQUFHLEVBQUVlLFlBQVksQ0FBQztJQUN4RFYsSUFBSSxDQUFDMkIsRUFBRSxHQUFHM0IsSUFBSSxDQUFDOEIsTUFBTSxDQUFDSCxFQUFFLENBQUMsQ0FBQztJQUUxQjNCLElBQUksQ0FBQzhCLE1BQU0sQ0FBQ0UsRUFBRSxDQUFDLDBCQUEwQixFQUFFMUIsTUFBTSxDQUFDMkIsZUFBZSxDQUFDQyxLQUFLLElBQUk7TUFDekU7TUFDQTtNQUNBO01BQ0EsSUFDRUEsS0FBSyxDQUFDQyxtQkFBbUIsQ0FBQ0MsSUFBSSxLQUFLLFdBQVcsSUFDOUNGLEtBQUssQ0FBQ0csY0FBYyxDQUFDRCxJQUFJLEtBQUssV0FBVyxFQUN6QztRQUNBcEMsSUFBSSxDQUFDRSxlQUFlLENBQUM5QyxJQUFJLENBQUNrRixRQUFRLElBQUk7VUFDcENBLFFBQVEsQ0FBQyxDQUFDO1VBQ1YsT0FBTyxJQUFJO1FBQ2IsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDLENBQUMsQ0FBQztJQUVILElBQUkxQyxPQUFPLENBQUMyQyxRQUFRLElBQUksQ0FBRUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQ2xEeEMsSUFBSSxDQUFDNEIsWUFBWSxHQUFHLElBQUlhLFdBQVcsQ0FBQzdDLE9BQU8sQ0FBQzJDLFFBQVEsRUFBRXZDLElBQUksQ0FBQzJCLEVBQUUsQ0FBQ2UsWUFBWSxDQUFDO01BQzNFMUMsSUFBSSxDQUFDNkIsV0FBVyxHQUFHLElBQUlyRyxVQUFVLENBQUN3RSxJQUFJLENBQUM7SUFDekM7SUFDQTJDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDNUMsSUFBSSxDQUFDOEIsTUFBTSxDQUFDZSxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQ3RDLENBQUM7RUFFRG5ELGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ3NGLEtBQUssR0FBRyxZQUFXO0lBQzNDLElBQUk5QyxJQUFJLEdBQUcsSUFBSTtJQUVmLElBQUksQ0FBRUEsSUFBSSxDQUFDMkIsRUFBRSxFQUNYLE1BQU1vQixLQUFLLENBQUMseUNBQXlDLENBQUM7O0lBRXhEO0lBQ0EsSUFBSUMsV0FBVyxHQUFHaEQsSUFBSSxDQUFDNEIsWUFBWTtJQUNuQzVCLElBQUksQ0FBQzRCLFlBQVksR0FBRyxJQUFJO0lBQ3hCLElBQUlvQixXQUFXLEVBQ2JBLFdBQVcsQ0FBQ0MsSUFBSSxDQUFDLENBQUM7O0lBRXBCO0lBQ0E7SUFDQTtJQUNBakgsTUFBTSxDQUFDa0gsSUFBSSxDQUFDbkcsQ0FBQyxDQUFDRyxJQUFJLENBQUM4QyxJQUFJLENBQUM4QixNQUFNLENBQUNnQixLQUFLLEVBQUU5QyxJQUFJLENBQUM4QixNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDcUIsSUFBSSxDQUFDLENBQUM7RUFDbEUsQ0FBQzs7RUFFRDtFQUNBekQsZUFBZSxDQUFDbEMsU0FBUyxDQUFDNEYsYUFBYSxHQUFHLFVBQVVDLGNBQWMsRUFBRTtJQUNsRSxJQUFJckQsSUFBSSxHQUFHLElBQUk7SUFFZixJQUFJLENBQUVBLElBQUksQ0FBQzJCLEVBQUUsRUFDWCxNQUFNb0IsS0FBSyxDQUFDLGlEQUFpRCxDQUFDO0lBRWhFLE9BQU8vQyxJQUFJLENBQUMyQixFQUFFLENBQUMyQixVQUFVLENBQUNELGNBQWMsQ0FBQztFQUMzQyxDQUFDO0VBRUQzRCxlQUFlLENBQUNsQyxTQUFTLENBQUMrRix1QkFBdUIsR0FBRyxVQUNoREYsY0FBYyxFQUFFRyxRQUFRLEVBQUVDLFlBQVksRUFBRTtJQUMxQyxJQUFJekQsSUFBSSxHQUFHLElBQUk7SUFFZixJQUFJLENBQUVBLElBQUksQ0FBQzJCLEVBQUUsRUFDWCxNQUFNb0IsS0FBSyxDQUFDLDJEQUEyRCxDQUFDO0lBRzFFLElBQUlXLE1BQU0sR0FBRyxJQUFJMUgsTUFBTSxDQUFDLENBQUM7SUFDekJnRSxJQUFJLENBQUMyQixFQUFFLENBQUNnQyxnQkFBZ0IsQ0FDdEJOLGNBQWMsRUFDZDtNQUFFTyxNQUFNLEVBQUUsSUFBSTtNQUFFbEYsSUFBSSxFQUFFOEUsUUFBUTtNQUFFSyxHQUFHLEVBQUVKO0lBQWEsQ0FBQyxFQUNuREMsTUFBTSxDQUFDSSxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3BCSixNQUFNLENBQUNQLElBQUksQ0FBQyxDQUFDO0VBQ2YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0F6RCxlQUFlLENBQUNsQyxTQUFTLENBQUN1RyxnQkFBZ0IsR0FBRyxZQUFZO0lBQ3ZELElBQUlDLEtBQUssR0FBR0MsU0FBUyxDQUFDQyxrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDLENBQUM7SUFDOUMsSUFBSUgsS0FBSyxFQUFFO01BQ1QsT0FBT0EsS0FBSyxDQUFDSSxVQUFVLENBQUMsQ0FBQztJQUMzQixDQUFDLE1BQU07TUFDTCxPQUFPO1FBQUNDLFNBQVMsRUFBRSxTQUFBQSxDQUFBLEVBQVksQ0FBQztNQUFDLENBQUM7SUFDcEM7RUFDRixDQUFDOztFQUVEO0VBQ0E7RUFDQTNFLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQzhHLFdBQVcsR0FBRyxVQUFVaEMsUUFBUSxFQUFFO0lBQzFELE9BQU8sSUFBSSxDQUFDcEMsZUFBZSxDQUFDcUUsUUFBUSxDQUFDakMsUUFBUSxDQUFDO0VBQ2hELENBQUM7O0VBR0Q7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztFQUVBLElBQUlrQyxhQUFhLEdBQUcsU0FBQUEsQ0FBVUMsS0FBSyxFQUFFQyxPQUFPLEVBQUVwQyxRQUFRLEVBQUU7SUFDdEQsT0FBTyxVQUFVcUMsR0FBRyxFQUFFQyxNQUFNLEVBQUU7TUFDNUIsSUFBSSxDQUFFRCxHQUFHLEVBQUU7UUFDVDtRQUNBLElBQUk7VUFDRkQsT0FBTyxDQUFDLENBQUM7UUFDWCxDQUFDLENBQUMsT0FBT0csVUFBVSxFQUFFO1VBQ25CLElBQUl2QyxRQUFRLEVBQUU7WUFDWkEsUUFBUSxDQUFDdUMsVUFBVSxDQUFDO1lBQ3BCO1VBQ0YsQ0FBQyxNQUFNO1lBQ0wsTUFBTUEsVUFBVTtVQUNsQjtRQUNGO01BQ0Y7TUFDQUosS0FBSyxDQUFDSixTQUFTLENBQUMsQ0FBQztNQUNqQixJQUFJL0IsUUFBUSxFQUFFO1FBQ1pBLFFBQVEsQ0FBQ3FDLEdBQUcsRUFBRUMsTUFBTSxDQUFDO01BQ3ZCLENBQUMsTUFBTSxJQUFJRCxHQUFHLEVBQUU7UUFDZCxNQUFNQSxHQUFHO01BQ1g7SUFDRixDQUFDO0VBQ0gsQ0FBQztFQUVELElBQUlHLHVCQUF1QixHQUFHLFNBQUFBLENBQVV4QyxRQUFRLEVBQUU7SUFDaEQsT0FBT2hDLE1BQU0sQ0FBQzJCLGVBQWUsQ0FBQ0ssUUFBUSxFQUFFLGFBQWEsQ0FBQztFQUN4RCxDQUFDO0VBRUQ1QyxlQUFlLENBQUNsQyxTQUFTLENBQUN1SCxPQUFPLEdBQUcsVUFBVUMsZUFBZSxFQUFFakgsUUFBUSxFQUN6QnVFLFFBQVEsRUFBRTtJQUN0RCxJQUFJdEMsSUFBSSxHQUFHLElBQUk7SUFFZixJQUFJaUYsU0FBUyxHQUFHLFNBQUFBLENBQVVDLENBQUMsRUFBRTtNQUMzQixJQUFJNUMsUUFBUSxFQUNWLE9BQU9BLFFBQVEsQ0FBQzRDLENBQUMsQ0FBQztNQUNwQixNQUFNQSxDQUFDO0lBQ1QsQ0FBQztJQUVELElBQUlGLGVBQWUsS0FBSyxtQ0FBbUMsRUFBRTtNQUMzRCxJQUFJRSxDQUFDLEdBQUcsSUFBSW5DLEtBQUssQ0FBQyxjQUFjLENBQUM7TUFDakNtQyxDQUFDLENBQUNDLGVBQWUsR0FBRyxJQUFJO01BQ3hCRixTQUFTLENBQUNDLENBQUMsQ0FBQztNQUNaO0lBQ0Y7SUFFQSxJQUFJLEVBQUVFLGVBQWUsQ0FBQ0MsY0FBYyxDQUFDdEgsUUFBUSxDQUFDLElBQ3hDLENBQUNZLEtBQUssQ0FBQ1EsYUFBYSxDQUFDcEIsUUFBUSxDQUFDLENBQUMsRUFBRTtNQUNyQ2tILFNBQVMsQ0FBQyxJQUFJbEMsS0FBSyxDQUNqQixpREFBaUQsQ0FBQyxDQUFDO01BQ3JEO0lBQ0Y7SUFFQSxJQUFJMEIsS0FBSyxHQUFHekUsSUFBSSxDQUFDK0QsZ0JBQWdCLENBQUMsQ0FBQztJQUNuQyxJQUFJVyxPQUFPLEdBQUcsU0FBQUEsQ0FBQSxFQUFZO01BQ3hCcEUsTUFBTSxDQUFDb0UsT0FBTyxDQUFDO1FBQUNwQixVQUFVLEVBQUUwQixlQUFlO1FBQUVNLEVBQUUsRUFBRXZILFFBQVEsQ0FBQ3dIO01BQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFDRGpELFFBQVEsR0FBR3dDLHVCQUF1QixDQUFDTixhQUFhLENBQUNDLEtBQUssRUFBRUMsT0FBTyxFQUFFcEMsUUFBUSxDQUFDLENBQUM7SUFDM0UsSUFBSTtNQUNGLElBQUlnQixVQUFVLEdBQUd0RCxJQUFJLENBQUNvRCxhQUFhLENBQUM0QixlQUFlLENBQUM7TUFDcEQxQixVQUFVLENBQUNrQyxTQUFTLENBQ2xCbkcsWUFBWSxDQUFDdEIsUUFBUSxFQUFFZSwwQkFBMEIsQ0FBQyxFQUNsRDtRQUNFMkcsSUFBSSxFQUFFO01BQ1IsQ0FDRixDQUFDLENBQUNDLElBQUksQ0FBQ0MsS0FBQSxJQUFrQjtRQUFBLElBQWpCO1VBQUNDO1FBQVUsQ0FBQyxHQUFBRCxLQUFBO1FBQ2xCckQsUUFBUSxDQUFDLElBQUksRUFBRXNELFVBQVUsQ0FBQztNQUM1QixDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFFWCxDQUFDLElBQUs7UUFDZDVDLFFBQVEsQ0FBQzRDLENBQUMsRUFBRSxJQUFJLENBQUM7TUFDbkIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9QLEdBQUcsRUFBRTtNQUNaRixLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO01BQ2pCLE1BQU1NLEdBQUc7SUFDWDtFQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBakYsZUFBZSxDQUFDbEMsU0FBUyxDQUFDc0ksUUFBUSxHQUFHLFVBQVV6QyxjQUFjLEVBQUUwQyxRQUFRLEVBQUU7SUFDdkUsSUFBSUMsVUFBVSxHQUFHO01BQUMxQyxVQUFVLEVBQUVEO0lBQWMsQ0FBQztJQUM3QztJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUk0QyxXQUFXLEdBQUdiLGVBQWUsQ0FBQ2MscUJBQXFCLENBQUNILFFBQVEsQ0FBQztJQUNqRSxJQUFJRSxXQUFXLEVBQUU7TUFDZmxKLENBQUMsQ0FBQ0ssSUFBSSxDQUFDNkksV0FBVyxFQUFFLFVBQVVYLEVBQUUsRUFBRTtRQUNoQ2hGLE1BQU0sQ0FBQ29FLE9BQU8sQ0FBQzNILENBQUMsQ0FBQ29KLE1BQU0sQ0FBQztVQUFDYixFQUFFLEVBQUVBO1FBQUUsQ0FBQyxFQUFFVSxVQUFVLENBQUMsQ0FBQztNQUNoRCxDQUFDLENBQUM7SUFDSixDQUFDLE1BQU07TUFDTDFGLE1BQU0sQ0FBQ29FLE9BQU8sQ0FBQ3NCLFVBQVUsQ0FBQztJQUM1QjtFQUNGLENBQUM7RUFFRHRHLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQzRJLE9BQU8sR0FBRyxVQUFVcEIsZUFBZSxFQUFFZSxRQUFRLEVBQ3pCekQsUUFBUSxFQUFFO0lBQ3RELElBQUl0QyxJQUFJLEdBQUcsSUFBSTtJQUVmLElBQUlnRixlQUFlLEtBQUssbUNBQW1DLEVBQUU7TUFDM0QsSUFBSUUsQ0FBQyxHQUFHLElBQUluQyxLQUFLLENBQUMsY0FBYyxDQUFDO01BQ2pDbUMsQ0FBQyxDQUFDQyxlQUFlLEdBQUcsSUFBSTtNQUN4QixJQUFJN0MsUUFBUSxFQUFFO1FBQ1osT0FBT0EsUUFBUSxDQUFDNEMsQ0FBQyxDQUFDO01BQ3BCLENBQUMsTUFBTTtRQUNMLE1BQU1BLENBQUM7TUFDVDtJQUNGO0lBRUEsSUFBSVQsS0FBSyxHQUFHekUsSUFBSSxDQUFDK0QsZ0JBQWdCLENBQUMsQ0FBQztJQUNuQyxJQUFJVyxPQUFPLEdBQUcsU0FBQUEsQ0FBQSxFQUFZO01BQ3hCMUUsSUFBSSxDQUFDOEYsUUFBUSxDQUFDZCxlQUFlLEVBQUVlLFFBQVEsQ0FBQztJQUMxQyxDQUFDO0lBQ0R6RCxRQUFRLEdBQUd3Qyx1QkFBdUIsQ0FBQ04sYUFBYSxDQUFDQyxLQUFLLEVBQUVDLE9BQU8sRUFBRXBDLFFBQVEsQ0FBQyxDQUFDO0lBRTNFLElBQUk7TUFDRixJQUFJZ0IsVUFBVSxHQUFHdEQsSUFBSSxDQUFDb0QsYUFBYSxDQUFDNEIsZUFBZSxDQUFDO01BQ3BEMUIsVUFBVSxDQUNQK0MsVUFBVSxDQUFDaEgsWUFBWSxDQUFDMEcsUUFBUSxFQUFFakgsMEJBQTBCLENBQUMsRUFBRTtRQUM5RDJHLElBQUksRUFBRTtNQUNSLENBQUMsQ0FBQyxDQUNEQyxJQUFJLENBQUNZLEtBQUEsSUFBc0I7UUFBQSxJQUFyQjtVQUFFQztRQUFhLENBQUMsR0FBQUQsS0FBQTtRQUNyQmhFLFFBQVEsQ0FBQyxJQUFJLEVBQUVrRSxlQUFlLENBQUM7VUFBRTVCLE1BQU0sRUFBRztZQUFDNkIsYUFBYSxFQUFHRjtVQUFZO1FBQUUsQ0FBQyxDQUFDLENBQUNHLGNBQWMsQ0FBQztNQUM3RixDQUFDLENBQUMsQ0FBQ2IsS0FBSyxDQUFFbEIsR0FBRyxJQUFLO1FBQ2xCckMsUUFBUSxDQUFDcUMsR0FBRyxDQUFDO01BQ2YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9BLEdBQUcsRUFBRTtNQUNaRixLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO01BQ2pCLE1BQU1NLEdBQUc7SUFDWDtFQUNGLENBQUM7RUFFRGpGLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ21KLGVBQWUsR0FBRyxVQUFVdEQsY0FBYyxFQUFFdUQsRUFBRSxFQUFFO0lBQ3hFLElBQUk1RyxJQUFJLEdBQUcsSUFBSTtJQUdmLElBQUl5RSxLQUFLLEdBQUd6RSxJQUFJLENBQUMrRCxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ25DLElBQUlXLE9BQU8sR0FBRyxTQUFBQSxDQUFBLEVBQVk7TUFDeEJwRSxNQUFNLENBQUNvRSxPQUFPLENBQUM7UUFBQ3BCLFVBQVUsRUFBRUQsY0FBYztRQUFFaUMsRUFBRSxFQUFFLElBQUk7UUFDcEN1QixjQUFjLEVBQUU7TUFBSSxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUdERCxFQUFFLEdBQUc5Qix1QkFBdUIsQ0FBQ04sYUFBYSxDQUFDQyxLQUFLLEVBQUVDLE9BQU8sRUFBRWtDLEVBQUUsQ0FBQyxDQUFDO0lBRS9ELElBQUk7TUFDRixJQUFJdEQsVUFBVSxHQUFHdEQsSUFBSSxDQUFDb0QsYUFBYSxDQUFDQyxjQUFjLENBQUM7TUFDbkRDLFVBQVUsQ0FBQ3dELElBQUksQ0FBQ0YsRUFBRSxDQUFDO0lBQ3JCLENBQUMsQ0FBQyxPQUFPMUIsQ0FBQyxFQUFFO01BQ1ZULEtBQUssQ0FBQ0osU0FBUyxDQUFDLENBQUM7TUFDakIsTUFBTWEsQ0FBQztJQUNUO0VBQ0YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0F4RixlQUFlLENBQUNsQyxTQUFTLENBQUN1SixhQUFhLEdBQUcsVUFBVUgsRUFBRSxFQUFFO0lBQ3RELElBQUk1RyxJQUFJLEdBQUcsSUFBSTtJQUVmLElBQUl5RSxLQUFLLEdBQUd6RSxJQUFJLENBQUMrRCxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ25DLElBQUlXLE9BQU8sR0FBRyxTQUFBQSxDQUFBLEVBQVk7TUFDeEJwRSxNQUFNLENBQUNvRSxPQUFPLENBQUM7UUFBRXNDLFlBQVksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBQ0RKLEVBQUUsR0FBRzlCLHVCQUF1QixDQUFDTixhQUFhLENBQUNDLEtBQUssRUFBRUMsT0FBTyxFQUFFa0MsRUFBRSxDQUFDLENBQUM7SUFFL0QsSUFBSTtNQUNGNUcsSUFBSSxDQUFDMkIsRUFBRSxDQUFDcUYsWUFBWSxDQUFDSixFQUFFLENBQUM7SUFDMUIsQ0FBQyxDQUFDLE9BQU8xQixDQUFDLEVBQUU7TUFDVlQsS0FBSyxDQUFDSixTQUFTLENBQUMsQ0FBQztNQUNqQixNQUFNYSxDQUFDO0lBQ1Q7RUFDRixDQUFDO0VBRUR4RixlQUFlLENBQUNsQyxTQUFTLENBQUN5SixPQUFPLEdBQUcsVUFBVWpDLGVBQWUsRUFBRWUsUUFBUSxFQUFFbUIsR0FBRyxFQUM5QnRILE9BQU8sRUFBRTBDLFFBQVEsRUFBRTtJQUMvRCxJQUFJdEMsSUFBSSxHQUFHLElBQUk7SUFJZixJQUFJLENBQUVzQyxRQUFRLElBQUkxQyxPQUFPLFlBQVl1SCxRQUFRLEVBQUU7TUFDN0M3RSxRQUFRLEdBQUcxQyxPQUFPO01BQ2xCQSxPQUFPLEdBQUcsSUFBSTtJQUNoQjtJQUVBLElBQUlvRixlQUFlLEtBQUssbUNBQW1DLEVBQUU7TUFDM0QsSUFBSUUsQ0FBQyxHQUFHLElBQUluQyxLQUFLLENBQUMsY0FBYyxDQUFDO01BQ2pDbUMsQ0FBQyxDQUFDQyxlQUFlLEdBQUcsSUFBSTtNQUN4QixJQUFJN0MsUUFBUSxFQUFFO1FBQ1osT0FBT0EsUUFBUSxDQUFDNEMsQ0FBQyxDQUFDO01BQ3BCLENBQUMsTUFBTTtRQUNMLE1BQU1BLENBQUM7TUFDVDtJQUNGOztJQUVBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFJLENBQUNnQyxHQUFHLElBQUksT0FBT0EsR0FBRyxLQUFLLFFBQVEsRUFDakMsTUFBTSxJQUFJbkUsS0FBSyxDQUFDLCtDQUErQyxDQUFDO0lBRWxFLElBQUksRUFBRXFDLGVBQWUsQ0FBQ0MsY0FBYyxDQUFDNkIsR0FBRyxDQUFDLElBQ25DLENBQUN2SSxLQUFLLENBQUNRLGFBQWEsQ0FBQytILEdBQUcsQ0FBQyxDQUFDLEVBQUU7TUFDaEMsTUFBTSxJQUFJbkUsS0FBSyxDQUNiLCtDQUErQyxHQUM3Qyx1QkFBdUIsQ0FBQztJQUM5QjtJQUVBLElBQUksQ0FBQ25ELE9BQU8sRUFBRUEsT0FBTyxHQUFHLENBQUMsQ0FBQztJQUUxQixJQUFJNkUsS0FBSyxHQUFHekUsSUFBSSxDQUFDK0QsZ0JBQWdCLENBQUMsQ0FBQztJQUNuQyxJQUFJVyxPQUFPLEdBQUcsU0FBQUEsQ0FBQSxFQUFZO01BQ3hCMUUsSUFBSSxDQUFDOEYsUUFBUSxDQUFDZCxlQUFlLEVBQUVlLFFBQVEsQ0FBQztJQUMxQyxDQUFDO0lBQ0R6RCxRQUFRLEdBQUdrQyxhQUFhLENBQUNDLEtBQUssRUFBRUMsT0FBTyxFQUFFcEMsUUFBUSxDQUFDO0lBQ2xELElBQUk7TUFDRixJQUFJZ0IsVUFBVSxHQUFHdEQsSUFBSSxDQUFDb0QsYUFBYSxDQUFDNEIsZUFBZSxDQUFDO01BQ3BELElBQUlvQyxTQUFTLEdBQUc7UUFBQzNCLElBQUksRUFBRTtNQUFJLENBQUM7TUFDNUI7TUFDQSxJQUFJN0YsT0FBTyxDQUFDeUgsWUFBWSxLQUFLeEksU0FBUyxFQUFFdUksU0FBUyxDQUFDQyxZQUFZLEdBQUd6SCxPQUFPLENBQUN5SCxZQUFZO01BQ3JGO01BQ0EsSUFBSXpILE9BQU8sQ0FBQzBILE1BQU0sRUFBRUYsU0FBUyxDQUFDRSxNQUFNLEdBQUcsSUFBSTtNQUMzQyxJQUFJMUgsT0FBTyxDQUFDMkgsS0FBSyxFQUFFSCxTQUFTLENBQUNHLEtBQUssR0FBRyxJQUFJO01BQ3pDO01BQ0E7TUFDQTtNQUNBLElBQUkzSCxPQUFPLENBQUM0SCxVQUFVLEVBQUVKLFNBQVMsQ0FBQ0ksVUFBVSxHQUFHLElBQUk7TUFFbkQsSUFBSUMsYUFBYSxHQUFHcEksWUFBWSxDQUFDMEcsUUFBUSxFQUFFakgsMEJBQTBCLENBQUM7TUFDdEUsSUFBSTRJLFFBQVEsR0FBR3JJLFlBQVksQ0FBQzZILEdBQUcsRUFBRXBJLDBCQUEwQixDQUFDO01BRTVELElBQUk2SSxRQUFRLEdBQUd2QyxlQUFlLENBQUN3QyxrQkFBa0IsQ0FBQ0YsUUFBUSxDQUFDO01BRTNELElBQUk5SCxPQUFPLENBQUNpSSxjQUFjLElBQUksQ0FBQ0YsUUFBUSxFQUFFO1FBQ3ZDLElBQUloRCxHQUFHLEdBQUcsSUFBSTVCLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQztRQUNwRSxJQUFJVCxRQUFRLEVBQUU7VUFDWixPQUFPQSxRQUFRLENBQUNxQyxHQUFHLENBQUM7UUFDdEIsQ0FBQyxNQUFNO1VBQ0wsTUFBTUEsR0FBRztRQUNYO01BQ0Y7O01BRUE7TUFDQTtNQUNBO01BQ0E7O01BRUE7TUFDQTtNQUNBLElBQUltRCxPQUFPO01BQ1gsSUFBSWxJLE9BQU8sQ0FBQzBILE1BQU0sRUFBRTtRQUNsQixJQUFJO1VBQ0YsSUFBSVMsTUFBTSxHQUFHM0MsZUFBZSxDQUFDNEMscUJBQXFCLENBQUNqQyxRQUFRLEVBQUVtQixHQUFHLENBQUM7VUFDakVZLE9BQU8sR0FBR0MsTUFBTSxDQUFDeEMsR0FBRztRQUN0QixDQUFDLENBQUMsT0FBT1osR0FBRyxFQUFFO1VBQ1osSUFBSXJDLFFBQVEsRUFBRTtZQUNaLE9BQU9BLFFBQVEsQ0FBQ3FDLEdBQUcsQ0FBQztVQUN0QixDQUFDLE1BQU07WUFDTCxNQUFNQSxHQUFHO1VBQ1g7UUFDRjtNQUNGO01BRUEsSUFBSS9FLE9BQU8sQ0FBQzBILE1BQU0sSUFDZCxDQUFFSyxRQUFRLElBQ1YsQ0FBRUcsT0FBTyxJQUNUbEksT0FBTyxDQUFDZ0csVUFBVSxJQUNsQixFQUFHaEcsT0FBTyxDQUFDZ0csVUFBVSxZQUFZdkgsS0FBSyxDQUFDRCxRQUFRLElBQzVDd0IsT0FBTyxDQUFDcUksV0FBVyxDQUFDLEVBQUU7UUFDM0I7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUFDLDRCQUE0QixDQUMxQjVFLFVBQVUsRUFBRW1FLGFBQWEsRUFBRUMsUUFBUSxFQUFFOUgsT0FBTztRQUM1QztRQUNBO1FBQ0E7UUFDQSxVQUFVdUksS0FBSyxFQUFFdkQsTUFBTSxFQUFFO1VBQ3ZCO1VBQ0E7VUFDQTtVQUNBLElBQUlBLE1BQU0sSUFBSSxDQUFFaEYsT0FBTyxDQUFDd0ksYUFBYSxFQUFFO1lBQ3JDOUYsUUFBUSxDQUFDNkYsS0FBSyxFQUFFdkQsTUFBTSxDQUFDOEIsY0FBYyxDQUFDO1VBQ3hDLENBQUMsTUFBTTtZQUNMcEUsUUFBUSxDQUFDNkYsS0FBSyxFQUFFdkQsTUFBTSxDQUFDO1VBQ3pCO1FBQ0YsQ0FDRixDQUFDO01BQ0gsQ0FBQyxNQUFNO1FBRUwsSUFBSWhGLE9BQU8sQ0FBQzBILE1BQU0sSUFBSSxDQUFDUSxPQUFPLElBQUlsSSxPQUFPLENBQUNnRyxVQUFVLElBQUkrQixRQUFRLEVBQUU7VUFDaEUsSUFBSSxDQUFDRCxRQUFRLENBQUNXLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUM1Q1gsUUFBUSxDQUFDWSxZQUFZLEdBQUcsQ0FBQyxDQUFDO1VBQzVCO1VBQ0FSLE9BQU8sR0FBR2xJLE9BQU8sQ0FBQ2dHLFVBQVU7VUFDNUJqRixNQUFNLENBQUNDLE1BQU0sQ0FBQzhHLFFBQVEsQ0FBQ1ksWUFBWSxFQUFFakosWUFBWSxDQUFDO1lBQUNrRyxHQUFHLEVBQUUzRixPQUFPLENBQUNnRztVQUFVLENBQUMsRUFBRTlHLDBCQUEwQixDQUFDLENBQUM7UUFDM0c7UUFFQSxNQUFNeUosT0FBTyxHQUFHNUgsTUFBTSxDQUFDNkgsSUFBSSxDQUFDZCxRQUFRLENBQUMsQ0FBQzdLLE1BQU0sQ0FBRVMsR0FBRyxJQUFLLENBQUNBLEdBQUcsQ0FBQ21MLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzRSxJQUFJQyxZQUFZLEdBQUdILE9BQU8sQ0FBQ0ksTUFBTSxHQUFHLENBQUMsR0FBRyxZQUFZLEdBQUcsWUFBWTtRQUNuRUQsWUFBWSxHQUNWQSxZQUFZLEtBQUssWUFBWSxJQUFJLENBQUN0QixTQUFTLENBQUNHLEtBQUssR0FDN0MsV0FBVyxHQUNYbUIsWUFBWTtRQUNsQnBGLFVBQVUsQ0FBQ29GLFlBQVksQ0FBQyxDQUFDeEwsSUFBSSxDQUFDb0csVUFBVSxDQUFDLENBQ3ZDbUUsYUFBYSxFQUFFQyxRQUFRLEVBQUVOLFNBQVM7UUFDaEM7UUFDQXRDLHVCQUF1QixDQUFDLFlBQThCO1VBQUEsSUFBcEJILEdBQUcsR0FBQWlFLFNBQUEsQ0FBQUQsTUFBQSxRQUFBQyxTQUFBLFFBQUEvSixTQUFBLEdBQUErSixTQUFBLE1BQUcsSUFBSTtVQUFBLElBQUVoRSxNQUFNLEdBQUFnRSxTQUFBLENBQUFELE1BQUEsT0FBQUMsU0FBQSxNQUFBL0osU0FBQTtVQUNwRCxJQUFJLENBQUU4RixHQUFHLEVBQUU7WUFDVCxJQUFJa0UsWUFBWSxHQUFHckMsZUFBZSxDQUFDO2NBQUM1QjtZQUFNLENBQUMsQ0FBQztZQUM1QyxJQUFJaUUsWUFBWSxJQUFJakosT0FBTyxDQUFDd0ksYUFBYSxFQUFFO2NBQ3pDO2NBQ0E7Y0FDQTtjQUNBLElBQUl4SSxPQUFPLENBQUMwSCxNQUFNLElBQUl1QixZQUFZLENBQUNqRCxVQUFVLEVBQUU7Z0JBQzdDLElBQUlrQyxPQUFPLEVBQUU7a0JBQ1hlLFlBQVksQ0FBQ2pELFVBQVUsR0FBR2tDLE9BQU87Z0JBQ25DLENBQUMsTUFBTSxJQUFJZSxZQUFZLENBQUNqRCxVQUFVLFlBQVk5SixPQUFPLENBQUNzQyxRQUFRLEVBQUU7a0JBQzlEeUssWUFBWSxDQUFDakQsVUFBVSxHQUFHLElBQUl2SCxLQUFLLENBQUNELFFBQVEsQ0FBQ3lLLFlBQVksQ0FBQ2pELFVBQVUsQ0FBQ3RILFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JGO2NBQ0Y7Y0FFQWdFLFFBQVEsQ0FBQ3FDLEdBQUcsRUFBRWtFLFlBQVksQ0FBQztZQUM3QixDQUFDLE1BQU07Y0FDTHZHLFFBQVEsQ0FBQ3FDLEdBQUcsRUFBRWtFLFlBQVksQ0FBQ25DLGNBQWMsQ0FBQztZQUM1QztVQUNGLENBQUMsTUFBTTtZQUNMcEUsUUFBUSxDQUFDcUMsR0FBRyxDQUFDO1VBQ2Y7UUFDRixDQUFDLENBQUMsQ0FBQztNQUNQO0lBQ0YsQ0FBQyxDQUFDLE9BQU9PLENBQUMsRUFBRTtNQUNWVCxLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO01BQ2pCLE1BQU1hLENBQUM7SUFDVDtFQUNGLENBQUM7RUFFRCxJQUFJc0IsZUFBZSxHQUFHLFNBQUFBLENBQVVzQyxZQUFZLEVBQUU7SUFDNUMsSUFBSUQsWUFBWSxHQUFHO01BQUVuQyxjQUFjLEVBQUU7SUFBRSxDQUFDO0lBQ3hDLElBQUlvQyxZQUFZLEVBQUU7TUFDaEIsSUFBSUMsV0FBVyxHQUFHRCxZQUFZLENBQUNsRSxNQUFNO01BQ3JDO01BQ0E7TUFDQTtNQUNBLElBQUltRSxXQUFXLENBQUNDLGFBQWEsRUFBRTtRQUM3QkgsWUFBWSxDQUFDbkMsY0FBYyxHQUFHcUMsV0FBVyxDQUFDQyxhQUFhO1FBRXZELElBQUlELFdBQVcsQ0FBQ0UsVUFBVSxFQUFFO1VBQzFCSixZQUFZLENBQUNqRCxVQUFVLEdBQUdtRCxXQUFXLENBQUNFLFVBQVU7UUFDbEQ7TUFDRixDQUFDLE1BQU07UUFDTDtRQUNBO1FBQ0FKLFlBQVksQ0FBQ25DLGNBQWMsR0FBR3FDLFdBQVcsQ0FBQ0csQ0FBQyxJQUFJSCxXQUFXLENBQUNJLFlBQVksSUFBSUosV0FBVyxDQUFDdEMsYUFBYTtNQUN0RztJQUNGO0lBRUEsT0FBT29DLFlBQVk7RUFDckIsQ0FBQztFQUdELElBQUlPLG9CQUFvQixHQUFHLENBQUM7O0VBRTVCO0VBQ0ExSixlQUFlLENBQUMySixzQkFBc0IsR0FBRyxVQUFVMUUsR0FBRyxFQUFFO0lBRXREO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSXdELEtBQUssR0FBR3hELEdBQUcsQ0FBQzJFLE1BQU0sSUFBSTNFLEdBQUcsQ0FBQ0EsR0FBRzs7SUFFakM7SUFDQTtJQUNBO0lBQ0EsSUFBSXdELEtBQUssQ0FBQ29CLE9BQU8sQ0FBQyxpQ0FBaUMsQ0FBQyxLQUFLLENBQUMsSUFDckRwQixLQUFLLENBQUNvQixPQUFPLENBQUMsbUVBQW1FLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtNQUM5RixPQUFPLElBQUk7SUFDYjtJQUVBLE9BQU8sS0FBSztFQUNkLENBQUM7RUFFRCxJQUFJckIsNEJBQTRCLEdBQUcsU0FBQUEsQ0FBVTVFLFVBQVUsRUFBRXlDLFFBQVEsRUFBRW1CLEdBQUcsRUFDekJ0SCxPQUFPLEVBQUUwQyxRQUFRLEVBQUU7SUFDOUQ7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBOztJQUVBLElBQUlzRCxVQUFVLEdBQUdoRyxPQUFPLENBQUNnRyxVQUFVLENBQUMsQ0FBQztJQUNyQyxJQUFJNEQsa0JBQWtCLEdBQUc7TUFDdkIvRCxJQUFJLEVBQUUsSUFBSTtNQUNWOEIsS0FBSyxFQUFFM0gsT0FBTyxDQUFDMkg7SUFDakIsQ0FBQztJQUNELElBQUlrQyxrQkFBa0IsR0FBRztNQUN2QmhFLElBQUksRUFBRSxJQUFJO01BQ1Y2QixNQUFNLEVBQUU7SUFDVixDQUFDO0lBRUQsSUFBSW9DLGlCQUFpQixHQUFHL0ksTUFBTSxDQUFDQyxNQUFNLENBQ25DdkIsWUFBWSxDQUFDO01BQUNrRyxHQUFHLEVBQUVLO0lBQVUsQ0FBQyxFQUFFOUcsMEJBQTBCLENBQUMsRUFDM0RvSSxHQUFHLENBQUM7SUFFTixJQUFJeUMsS0FBSyxHQUFHUCxvQkFBb0I7SUFFaEMsSUFBSVEsUUFBUSxHQUFHLFNBQUFBLENBQUEsRUFBWTtNQUN6QkQsS0FBSyxFQUFFO01BQ1AsSUFBSSxDQUFFQSxLQUFLLEVBQUU7UUFDWHJILFFBQVEsQ0FBQyxJQUFJUyxLQUFLLENBQUMsc0JBQXNCLEdBQUdxRyxvQkFBb0IsR0FBRyxTQUFTLENBQUMsQ0FBQztNQUNoRixDQUFDLE1BQU07UUFDTCxJQUFJUyxNQUFNLEdBQUd2RyxVQUFVLENBQUN3RyxVQUFVO1FBQ2xDLElBQUcsQ0FBQ25KLE1BQU0sQ0FBQzZILElBQUksQ0FBQ3RCLEdBQUcsQ0FBQyxDQUFDNkMsSUFBSSxDQUFDek0sR0FBRyxJQUFJQSxHQUFHLENBQUNtTCxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQztVQUNwRG9CLE1BQU0sR0FBR3ZHLFVBQVUsQ0FBQzBHLFVBQVUsQ0FBQzlNLElBQUksQ0FBQ29HLFVBQVUsQ0FBQztRQUNqRDtRQUNBdUcsTUFBTSxDQUNKOUQsUUFBUSxFQUNSbUIsR0FBRyxFQUNIc0Msa0JBQWtCLEVBQ2xCMUUsdUJBQXVCLENBQUMsVUFBU0gsR0FBRyxFQUFFQyxNQUFNLEVBQUU7VUFDNUMsSUFBSUQsR0FBRyxFQUFFO1lBQ1ByQyxRQUFRLENBQUNxQyxHQUFHLENBQUM7VUFDZixDQUFDLE1BQU0sSUFBSUMsTUFBTSxLQUFLQSxNQUFNLENBQUM2QixhQUFhLElBQUk3QixNQUFNLENBQUNvRSxhQUFhLENBQUMsRUFBRTtZQUNuRTFHLFFBQVEsQ0FBQyxJQUFJLEVBQUU7Y0FDYm9FLGNBQWMsRUFBRTlCLE1BQU0sQ0FBQzZCLGFBQWEsSUFBSTdCLE1BQU0sQ0FBQ29FLGFBQWE7Y0FDNURwRCxVQUFVLEVBQUVoQixNQUFNLENBQUNxRSxVQUFVLElBQUlwSztZQUNuQyxDQUFDLENBQUM7VUFDSixDQUFDLE1BQU07WUFDTG9MLG1CQUFtQixDQUFDLENBQUM7VUFDdkI7UUFDRixDQUFDLENBQ0gsQ0FBQztNQUNIO0lBQ0YsQ0FBQztJQUVELElBQUlBLG1CQUFtQixHQUFHLFNBQUFBLENBQUEsRUFBVztNQUNuQzNHLFVBQVUsQ0FBQzBHLFVBQVUsQ0FDbkJqRSxRQUFRLEVBQ1IyRCxpQkFBaUIsRUFDakJELGtCQUFrQixFQUNsQjNFLHVCQUF1QixDQUFDLFVBQVNILEdBQUcsRUFBRUMsTUFBTSxFQUFFO1FBQzVDLElBQUlELEdBQUcsRUFBRTtVQUNQO1VBQ0E7VUFDQTtVQUNBLElBQUlqRixlQUFlLENBQUMySixzQkFBc0IsQ0FBQzFFLEdBQUcsQ0FBQyxFQUFFO1lBQy9DaUYsUUFBUSxDQUFDLENBQUM7VUFDWixDQUFDLE1BQU07WUFDTHRILFFBQVEsQ0FBQ3FDLEdBQUcsQ0FBQztVQUNmO1FBQ0YsQ0FBQyxNQUFNO1VBQ0xyQyxRQUFRLENBQUMsSUFBSSxFQUFFO1lBQ2JvRSxjQUFjLEVBQUU5QixNQUFNLENBQUNvRSxhQUFhO1lBQ3BDcEQsVUFBVSxFQUFFaEIsTUFBTSxDQUFDcUU7VUFDckIsQ0FBQyxDQUFDO1FBQ0o7TUFDRixDQUFDLENBQ0gsQ0FBQztJQUNILENBQUM7SUFFRFcsUUFBUSxDQUFDLENBQUM7RUFDWixDQUFDO0VBRUQ3TSxDQUFDLENBQUNLLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLGdCQUFnQixFQUFFLGNBQWMsQ0FBQyxFQUFFLFVBQVV5TSxNQUFNLEVBQUU7SUFDekZuSyxlQUFlLENBQUNsQyxTQUFTLENBQUNxTSxNQUFNLENBQUMsR0FBRyxTQUFVO0lBQUEsR0FBaUI7TUFDN0QsSUFBSTdKLElBQUksR0FBRyxJQUFJO01BQ2YsT0FBT00sTUFBTSxDQUFDNEosU0FBUyxDQUFDbEssSUFBSSxDQUFDLEdBQUcsR0FBRzZKLE1BQU0sQ0FBQyxDQUFDLENBQUNNLEtBQUssQ0FBQ25LLElBQUksRUFBRTRJLFNBQVMsQ0FBQztJQUNwRSxDQUFDO0VBQ0gsQ0FBQyxDQUFDOztFQUVGO0VBQ0E7RUFDQTtFQUNBbEosZUFBZSxDQUFDbEMsU0FBUyxDQUFDOEosTUFBTSxHQUFHLFVBQVVqRSxjQUFjLEVBQUUwQyxRQUFRLEVBQUVtQixHQUFHLEVBQzdCdEgsT0FBTyxFQUFFMEMsUUFBUSxFQUFFO0lBQzlELElBQUl0QyxJQUFJLEdBQUcsSUFBSTtJQUlmLElBQUksT0FBT0osT0FBTyxLQUFLLFVBQVUsSUFBSSxDQUFFMEMsUUFBUSxFQUFFO01BQy9DQSxRQUFRLEdBQUcxQyxPQUFPO01BQ2xCQSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQ2Q7SUFFQSxPQUFPSSxJQUFJLENBQUNvSyxNQUFNLENBQUMvRyxjQUFjLEVBQUUwQyxRQUFRLEVBQUVtQixHQUFHLEVBQzdCbkssQ0FBQyxDQUFDb0osTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFdkcsT0FBTyxFQUFFO01BQ3BCMEgsTUFBTSxFQUFFLElBQUk7TUFDWmMsYUFBYSxFQUFFO0lBQ2pCLENBQUMsQ0FBQyxFQUFFOUYsUUFBUSxDQUFDO0VBQ2xDLENBQUM7RUFFRDVDLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQzZNLElBQUksR0FBRyxVQUFVaEgsY0FBYyxFQUFFMEMsUUFBUSxFQUFFbkcsT0FBTyxFQUFFO0lBQzVFLElBQUlJLElBQUksR0FBRyxJQUFJO0lBRWYsSUFBSTRJLFNBQVMsQ0FBQ0QsTUFBTSxLQUFLLENBQUMsRUFDeEI1QyxRQUFRLEdBQUcsQ0FBQyxDQUFDO0lBRWYsT0FBTyxJQUFJdUUsTUFBTSxDQUNmdEssSUFBSSxFQUFFLElBQUl1SyxpQkFBaUIsQ0FBQ2xILGNBQWMsRUFBRTBDLFFBQVEsRUFBRW5HLE9BQU8sQ0FBQyxDQUFDO0VBQ25FLENBQUM7RUFFREYsZUFBZSxDQUFDbEMsU0FBUyxDQUFDZ04sWUFBWSxHQUFHLFVBQWdCeEYsZUFBZSxFQUFFZSxRQUFRLEVBQ25DbkcsT0FBTztJQUFBLE9BQUErQyxPQUFBLENBQUE4SCxVQUFBLE9BQUU7TUFDdEQsSUFBSXpLLElBQUksR0FBRyxJQUFJO01BQ2YsSUFBSTRJLFNBQVMsQ0FBQ0QsTUFBTSxLQUFLLENBQUMsRUFDeEI1QyxRQUFRLEdBQUcsQ0FBQyxDQUFDO01BRWZuRyxPQUFPLEdBQUdBLE9BQU8sSUFBSSxDQUFDLENBQUM7TUFDdkJBLE9BQU8sQ0FBQzhLLEtBQUssR0FBRyxDQUFDO01BQ2pCLE9BQU8vSCxPQUFBLENBQUFDLEtBQUEsQ0FBTzVDLElBQUksQ0FBQ3FLLElBQUksQ0FBQ3JGLGVBQWUsRUFBRWUsUUFBUSxFQUFFbkcsT0FBTyxDQUFDLENBQUMrSyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM5RSxDQUFDO0VBQUE7RUFFRGpMLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ29OLE9BQU8sR0FBRyxVQUFVNUYsZUFBZSxFQUFFZSxRQUFRLEVBQ3pCbkcsT0FBTyxFQUFFO0lBQ3JELElBQUlJLElBQUksR0FBRyxJQUFJO0lBRWYsT0FBT2hFLE1BQU0sQ0FBQzZPLFdBQVcsQ0FBQzdLLElBQUksQ0FBQ3dLLFlBQVksQ0FBQ3hGLGVBQWUsRUFBRWUsUUFBUSxFQUFFbkcsT0FBTyxDQUFDLENBQUMsQ0FBQ3VELElBQUksQ0FBQyxDQUFDO0VBQ3pGLENBQUM7RUFFRHpELGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ3NOLGdCQUFnQixHQUFHLFVBQVV6SCxjQUFjLEVBQUUwSCxLQUFLLEVBQzFCbkwsT0FBTyxFQUFFO0lBQ3pELElBQUlJLElBQUksR0FBRyxJQUFJOztJQUVmO0lBQ0E7SUFDQSxJQUFJc0QsVUFBVSxHQUFHdEQsSUFBSSxDQUFDb0QsYUFBYSxDQUFDQyxjQUFjLENBQUM7SUFDbkQsT0FBT0MsVUFBVSxDQUFDMEgsV0FBVyxDQUFDRCxLQUFLLEVBQUVuTCxPQUFPLENBQUM7RUFDL0MsQ0FBQzs7RUFFRDtFQUNBO0VBQ0FGLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ3dOLFdBQVcsR0FBRyxVQUFVM0gsY0FBYyxFQUFFMEgsS0FBSyxFQUNwQm5MLE9BQU8sRUFBRTtJQUMxRCxJQUFJSSxJQUFJLEdBQUcsSUFBSTtJQUdmLE9BQU9oRSxNQUFNLENBQUM2TyxXQUFXLENBQUM3SyxJQUFJLENBQUM4SyxnQkFBZ0IsQ0FBQ3pILGNBQWMsRUFBRTBILEtBQUssRUFBRW5MLE9BQU8sQ0FBQyxDQUFDO0VBQ2xGLENBQUM7RUFFREYsZUFBZSxDQUFDbEMsU0FBUyxDQUFDeU4sY0FBYyxHQUFHLFVBQVU1SCxjQUFjLEVBQVc7SUFBQSxTQUFBNkgsSUFBQSxHQUFBdEMsU0FBQSxDQUFBRCxNQUFBLEVBQU53QyxJQUFJLE9BQUFDLEtBQUEsQ0FBQUYsSUFBQSxPQUFBQSxJQUFBLFdBQUFHLElBQUEsTUFBQUEsSUFBQSxHQUFBSCxJQUFBLEVBQUFHLElBQUE7TUFBSkYsSUFBSSxDQUFBRSxJQUFBLFFBQUF6QyxTQUFBLENBQUF5QyxJQUFBO0lBQUE7SUFDMUVGLElBQUksR0FBR0EsSUFBSSxDQUFDbE8sR0FBRyxDQUFDcU8sR0FBRyxJQUFJak0sWUFBWSxDQUFDaU0sR0FBRyxFQUFFeE0sMEJBQTBCLENBQUMsQ0FBQztJQUNyRSxNQUFNd0UsVUFBVSxHQUFHLElBQUksQ0FBQ0YsYUFBYSxDQUFDQyxjQUFjLENBQUM7SUFDckQsT0FBT0MsVUFBVSxDQUFDMkgsY0FBYyxDQUFDLEdBQUdFLElBQUksQ0FBQztFQUMzQyxDQUFDO0VBRUR6TCxlQUFlLENBQUNsQyxTQUFTLENBQUMrTixzQkFBc0IsR0FBRyxVQUFVbEksY0FBYyxFQUFXO0lBQUEsU0FBQW1JLEtBQUEsR0FBQTVDLFNBQUEsQ0FBQUQsTUFBQSxFQUFOd0MsSUFBSSxPQUFBQyxLQUFBLENBQUFJLEtBQUEsT0FBQUEsS0FBQSxXQUFBQyxLQUFBLE1BQUFBLEtBQUEsR0FBQUQsS0FBQSxFQUFBQyxLQUFBO01BQUpOLElBQUksQ0FBQU0sS0FBQSxRQUFBN0MsU0FBQSxDQUFBNkMsS0FBQTtJQUFBO0lBQ2xGTixJQUFJLEdBQUdBLElBQUksQ0FBQ2xPLEdBQUcsQ0FBQ3FPLEdBQUcsSUFBSWpNLFlBQVksQ0FBQ2lNLEdBQUcsRUFBRXhNLDBCQUEwQixDQUFDLENBQUM7SUFDckUsTUFBTXdFLFVBQVUsR0FBRyxJQUFJLENBQUNGLGFBQWEsQ0FBQ0MsY0FBYyxDQUFDO0lBQ3JELE9BQU9DLFVBQVUsQ0FBQ2lJLHNCQUFzQixDQUFDLEdBQUdKLElBQUksQ0FBQztFQUNuRCxDQUFDO0VBRUR6TCxlQUFlLENBQUNsQyxTQUFTLENBQUNrTyxZQUFZLEdBQUdoTSxlQUFlLENBQUNsQyxTQUFTLENBQUN3TixXQUFXO0VBRTlFdEwsZUFBZSxDQUFDbEMsU0FBUyxDQUFDbU8sVUFBVSxHQUFHLFVBQVV0SSxjQUFjLEVBQUUwSCxLQUFLLEVBQUU7SUFDdEUsSUFBSS9LLElBQUksR0FBRyxJQUFJOztJQUdmO0lBQ0E7SUFDQSxJQUFJc0QsVUFBVSxHQUFHdEQsSUFBSSxDQUFDb0QsYUFBYSxDQUFDQyxjQUFjLENBQUM7SUFDbkQsSUFBSUssTUFBTSxHQUFHLElBQUkxSCxNQUFNLENBQUQsQ0FBQztJQUN2QixJQUFJNFAsU0FBUyxHQUFHdEksVUFBVSxDQUFDdUksU0FBUyxDQUFDZCxLQUFLLEVBQUVySCxNQUFNLENBQUNJLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDOURKLE1BQU0sQ0FBQ1AsSUFBSSxDQUFDLENBQUM7RUFDZixDQUFDOztFQUVEOztFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7RUFFQW9ILGlCQUFpQixHQUFHLFNBQUFBLENBQVVsSCxjQUFjLEVBQUUwQyxRQUFRLEVBQUVuRyxPQUFPLEVBQUU7SUFDL0QsSUFBSUksSUFBSSxHQUFHLElBQUk7SUFDZkEsSUFBSSxDQUFDcUQsY0FBYyxHQUFHQSxjQUFjO0lBQ3BDckQsSUFBSSxDQUFDK0YsUUFBUSxHQUFHMUgsS0FBSyxDQUFDeU4sVUFBVSxDQUFDQyxnQkFBZ0IsQ0FBQ2hHLFFBQVEsQ0FBQztJQUMzRC9GLElBQUksQ0FBQ0osT0FBTyxHQUFHQSxPQUFPLElBQUksQ0FBQyxDQUFDO0VBQzlCLENBQUM7RUFFRDBLLE1BQU0sR0FBRyxTQUFBQSxDQUFVN0osS0FBSyxFQUFFdUwsaUJBQWlCLEVBQUU7SUFDM0MsSUFBSWhNLElBQUksR0FBRyxJQUFJO0lBRWZBLElBQUksQ0FBQ2lNLE1BQU0sR0FBR3hMLEtBQUs7SUFDbkJULElBQUksQ0FBQ2tNLGtCQUFrQixHQUFHRixpQkFBaUI7SUFDM0NoTSxJQUFJLENBQUNtTSxrQkFBa0IsR0FBRyxJQUFJO0VBQ2hDLENBQUM7RUFFRCxTQUFTQyxzQkFBc0JBLENBQUNDLE1BQU0sRUFBRXhDLE1BQU0sRUFBRTtJQUM5QztJQUNBLElBQUl3QyxNQUFNLENBQUNILGtCQUFrQixDQUFDdE0sT0FBTyxDQUFDME0sUUFBUSxFQUM1QyxNQUFNLElBQUl2SixLQUFLLENBQUMsY0FBYyxHQUFHOEcsTUFBTSxHQUFHLHVCQUF1QixDQUFDO0lBRXBFLElBQUksQ0FBQ3dDLE1BQU0sQ0FBQ0Ysa0JBQWtCLEVBQUU7TUFDOUJFLE1BQU0sQ0FBQ0Ysa0JBQWtCLEdBQUdFLE1BQU0sQ0FBQ0osTUFBTSxDQUFDTSx3QkFBd0IsQ0FDaEVGLE1BQU0sQ0FBQ0gsa0JBQWtCLEVBQ3pCO1FBQ0U7UUFDQTtRQUNBTSxnQkFBZ0IsRUFBRUgsTUFBTTtRQUN4QkksWUFBWSxFQUFFO01BQ2hCLENBQ0YsQ0FBQztJQUNIO0lBRUEsT0FBT0osTUFBTSxDQUFDRixrQkFBa0I7RUFDbEM7RUFHQTdCLE1BQU0sQ0FBQzlNLFNBQVMsQ0FBQ2tQLEtBQUssR0FBRyxZQUFZO0lBRW5DLE1BQU1wSixVQUFVLEdBQUcsSUFBSSxDQUFDMkksTUFBTSxDQUFDN0ksYUFBYSxDQUFDLElBQUksQ0FBQzhJLGtCQUFrQixDQUFDN0ksY0FBYyxDQUFDO0lBQ3BGLE9BQU9WLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDVSxVQUFVLENBQUMySCxjQUFjLENBQzVDNUwsWUFBWSxDQUFDLElBQUksQ0FBQzZNLGtCQUFrQixDQUFDbkcsUUFBUSxFQUFFakgsMEJBQTBCLENBQUMsRUFDMUVPLFlBQVksQ0FBQyxJQUFJLENBQUM2TSxrQkFBa0IsQ0FBQ3RNLE9BQU8sRUFBRWQsMEJBQTBCLENBQzFFLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFRCxDQUFDLEdBQUdyRCxvQkFBb0IsRUFBRWtSLE1BQU0sQ0FBQ0MsUUFBUSxFQUFFRCxNQUFNLENBQUNFLGFBQWEsQ0FBQyxDQUFDekwsT0FBTyxDQUFDMEwsVUFBVSxJQUFJO0lBQ3JGO0lBQ0E7SUFDQSxJQUFJQSxVQUFVLEtBQUssT0FBTyxFQUFFO01BQzFCeEMsTUFBTSxDQUFDOU0sU0FBUyxDQUFDc1AsVUFBVSxDQUFDLEdBQUcsWUFBbUI7UUFDaEQsTUFBTVQsTUFBTSxHQUFHRCxzQkFBc0IsQ0FBQyxJQUFJLEVBQUVVLFVBQVUsQ0FBQztRQUN2RCxPQUFPVCxNQUFNLENBQUNTLFVBQVUsQ0FBQyxDQUFDLEdBQUFsRSxTQUFPLENBQUM7TUFDcEMsQ0FBQztJQUNIOztJQUVBO0lBQ0EsSUFBSWtFLFVBQVUsS0FBS0gsTUFBTSxDQUFDQyxRQUFRLElBQUlFLFVBQVUsS0FBS0gsTUFBTSxDQUFDRSxhQUFhLEVBQUU7TUFDekU7SUFDRjtJQUVBLE1BQU1FLGVBQWUsR0FBR3JSLGtCQUFrQixDQUFDb1IsVUFBVSxDQUFDO0lBQ3REeEMsTUFBTSxDQUFDOU0sU0FBUyxDQUFDdVAsZUFBZSxDQUFDLEdBQUcsWUFBbUI7TUFDckQsSUFBSTtRQUNGLElBQUksQ0FBQ0QsVUFBVSxDQUFDLENBQUNFLGlCQUFpQixHQUFHLElBQUk7UUFDekMsT0FBT3JLLE9BQU8sQ0FBQ3NLLE9BQU8sQ0FBQyxJQUFJLENBQUNILFVBQVUsQ0FBQyxDQUFDLEdBQUFsRSxTQUFPLENBQUMsQ0FBQztNQUNuRCxDQUFDLENBQUMsT0FBT1QsS0FBSyxFQUFFO1FBQ2QsT0FBT3hGLE9BQU8sQ0FBQ3VLLE1BQU0sQ0FBQy9FLEtBQUssQ0FBQztNQUM5QjtJQUNGLENBQUM7RUFDSCxDQUFDLENBQUM7RUFFRm1DLE1BQU0sQ0FBQzlNLFNBQVMsQ0FBQzJQLFlBQVksR0FBRyxZQUFZO0lBQzFDLE9BQU8sSUFBSSxDQUFDakIsa0JBQWtCLENBQUN0TSxPQUFPLENBQUN3TixTQUFTO0VBQ2xELENBQUM7O0VBRUQ7RUFDQTtFQUNBOztFQUVBOUMsTUFBTSxDQUFDOU0sU0FBUyxDQUFDNlAsY0FBYyxHQUFHLFVBQVVDLEdBQUcsRUFBRTtJQUMvQyxJQUFJdE4sSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJc0QsVUFBVSxHQUFHdEQsSUFBSSxDQUFDa00sa0JBQWtCLENBQUM3SSxjQUFjO0lBQ3ZELE9BQU9oRixLQUFLLENBQUN5TixVQUFVLENBQUN1QixjQUFjLENBQUNyTixJQUFJLEVBQUVzTixHQUFHLEVBQUVoSyxVQUFVLENBQUM7RUFDL0QsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQWdILE1BQU0sQ0FBQzlNLFNBQVMsQ0FBQytQLGtCQUFrQixHQUFHLFlBQVk7SUFDaEQsSUFBSXZOLElBQUksR0FBRyxJQUFJO0lBQ2YsT0FBT0EsSUFBSSxDQUFDa00sa0JBQWtCLENBQUM3SSxjQUFjO0VBQy9DLENBQUM7RUFFRGlILE1BQU0sQ0FBQzlNLFNBQVMsQ0FBQ2dRLE9BQU8sR0FBRyxVQUFVQyxTQUFTLEVBQUU7SUFDOUMsSUFBSXpOLElBQUksR0FBRyxJQUFJO0lBQ2YsT0FBT29GLGVBQWUsQ0FBQ3NJLDBCQUEwQixDQUFDMU4sSUFBSSxFQUFFeU4sU0FBUyxDQUFDO0VBQ3BFLENBQUM7RUFFRG5ELE1BQU0sQ0FBQzlNLFNBQVMsQ0FBQ21RLGNBQWMsR0FBRyxVQUFVRixTQUFTLEVBQWdCO0lBQUEsSUFBZDdOLE9BQU8sR0FBQWdKLFNBQUEsQ0FBQUQsTUFBQSxRQUFBQyxTQUFBLFFBQUEvSixTQUFBLEdBQUErSixTQUFBLE1BQUcsQ0FBQyxDQUFDO0lBQ2pFLElBQUk1SSxJQUFJLEdBQUcsSUFBSTtJQUNmLElBQUk0TixPQUFPLEdBQUcsQ0FDWixTQUFTLEVBQ1QsT0FBTyxFQUNQLFdBQVcsRUFDWCxTQUFTLEVBQ1QsV0FBVyxFQUNYLFNBQVMsRUFDVCxTQUFTLENBQ1Y7SUFDRCxJQUFJQyxPQUFPLEdBQUd6SSxlQUFlLENBQUMwSSxrQ0FBa0MsQ0FBQ0wsU0FBUyxDQUFDO0lBRTNFLElBQUlNLGFBQWEsR0FBR04sU0FBUyxDQUFDTyxZQUFZLEdBQUcsU0FBUyxHQUFHLGdCQUFnQjtJQUN6RUQsYUFBYSxJQUFJLFdBQVc7SUFDNUJILE9BQU8sQ0FBQ3hNLE9BQU8sQ0FBQyxVQUFVeUksTUFBTSxFQUFFO01BQ2hDLElBQUk0RCxTQUFTLENBQUM1RCxNQUFNLENBQUMsSUFBSSxPQUFPNEQsU0FBUyxDQUFDNUQsTUFBTSxDQUFDLElBQUksVUFBVSxFQUFFO1FBQy9ENEQsU0FBUyxDQUFDNUQsTUFBTSxDQUFDLEdBQUd2SixNQUFNLENBQUMyQixlQUFlLENBQUN3TCxTQUFTLENBQUM1RCxNQUFNLENBQUMsRUFBRUEsTUFBTSxHQUFHa0UsYUFBYSxDQUFDO01BQ3ZGO0lBQ0YsQ0FBQyxDQUFDO0lBRUYsT0FBTy9OLElBQUksQ0FBQ2lNLE1BQU0sQ0FBQ2dDLGVBQWUsQ0FDaENqTyxJQUFJLENBQUNrTSxrQkFBa0IsRUFBRTJCLE9BQU8sRUFBRUosU0FBUyxFQUFFN04sT0FBTyxDQUFDc08sb0JBQW9CLENBQUM7RUFDOUUsQ0FBQztFQUVEeE8sZUFBZSxDQUFDbEMsU0FBUyxDQUFDK08sd0JBQXdCLEdBQUcsVUFDakRQLGlCQUFpQixFQUFFcE0sT0FBTyxFQUFFO0lBQzlCLElBQUlJLElBQUksR0FBRyxJQUFJO0lBQ2ZKLE9BQU8sR0FBRzdDLENBQUMsQ0FBQ29SLElBQUksQ0FBQ3ZPLE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRSxrQkFBa0IsRUFBRSxjQUFjLENBQUM7SUFFbkUsSUFBSTBELFVBQVUsR0FBR3RELElBQUksQ0FBQ29ELGFBQWEsQ0FBQzRJLGlCQUFpQixDQUFDM0ksY0FBYyxDQUFDO0lBQ3JFLElBQUkrSyxhQUFhLEdBQUdwQyxpQkFBaUIsQ0FBQ3BNLE9BQU87SUFDN0MsSUFBSWMsWUFBWSxHQUFHO01BQ2pCMk4sSUFBSSxFQUFFRCxhQUFhLENBQUNDLElBQUk7TUFDeEIzRCxLQUFLLEVBQUUwRCxhQUFhLENBQUMxRCxLQUFLO01BQzFCNEQsSUFBSSxFQUFFRixhQUFhLENBQUNFLElBQUk7TUFDeEJDLFVBQVUsRUFBRUgsYUFBYSxDQUFDSSxNQUFNLElBQUlKLGFBQWEsQ0FBQ0csVUFBVTtNQUM1REUsY0FBYyxFQUFFTCxhQUFhLENBQUNLO0lBQ2hDLENBQUM7O0lBRUQ7SUFDQSxJQUFJTCxhQUFhLENBQUM5QixRQUFRLEVBQUU7TUFDMUI1TCxZQUFZLENBQUNnTyxlQUFlLEdBQUcsQ0FBQyxDQUFDO0lBQ25DO0lBRUEsSUFBSUMsUUFBUSxHQUFHckwsVUFBVSxDQUFDK0csSUFBSSxDQUM1QmhMLFlBQVksQ0FBQzJNLGlCQUFpQixDQUFDakcsUUFBUSxFQUFFakgsMEJBQTBCLENBQUMsRUFDcEU0QixZQUFZLENBQUM7O0lBRWY7SUFDQSxJQUFJME4sYUFBYSxDQUFDOUIsUUFBUSxFQUFFO01BQzFCO01BQ0FxQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDO01BQ3hDO01BQ0E7TUFDQUQsUUFBUSxDQUFDQyxhQUFhLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQzs7TUFFekM7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUk1QyxpQkFBaUIsQ0FBQzNJLGNBQWMsS0FBS3dMLGdCQUFnQixJQUNyRDdDLGlCQUFpQixDQUFDakcsUUFBUSxDQUFDK0ksRUFBRSxFQUFFO1FBQ2pDSCxRQUFRLENBQUNDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDO01BQzdDO0lBQ0Y7SUFFQSxJQUFJLE9BQU9SLGFBQWEsQ0FBQ1csU0FBUyxLQUFLLFdBQVcsRUFBRTtNQUNsREosUUFBUSxHQUFHQSxRQUFRLENBQUNLLFNBQVMsQ0FBQ1osYUFBYSxDQUFDVyxTQUFTLENBQUM7SUFDeEQ7SUFDQSxJQUFJLE9BQU9YLGFBQWEsQ0FBQ2EsSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUM3Q04sUUFBUSxHQUFHQSxRQUFRLENBQUNNLElBQUksQ0FBQ2IsYUFBYSxDQUFDYSxJQUFJLENBQUM7SUFDOUM7SUFFQSxPQUFPLElBQUlDLGlCQUFpQixDQUFDUCxRQUFRLEVBQUUzQyxpQkFBaUIsRUFBRXBNLE9BQU8sRUFBRTBELFVBQVUsQ0FBQztFQUNoRixDQUFDO0VBRUQsSUFBSTRMLGlCQUFpQixHQUFHLFNBQUFBLENBQVVQLFFBQVEsRUFBRTNDLGlCQUFpQixFQUFFcE0sT0FBTyxFQUFFMEQsVUFBVSxFQUFFO0lBQ2xGLElBQUl0RCxJQUFJLEdBQUcsSUFBSTtJQUNmSixPQUFPLEdBQUc3QyxDQUFDLENBQUNvUixJQUFJLENBQUN2TyxPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUsY0FBYyxDQUFDO0lBRW5FSSxJQUFJLENBQUNtUCxTQUFTLEdBQUdSLFFBQVE7SUFDekIzTyxJQUFJLENBQUNrTSxrQkFBa0IsR0FBR0YsaUJBQWlCO0lBQzNDO0lBQ0E7SUFDQWhNLElBQUksQ0FBQ29QLGlCQUFpQixHQUFHeFAsT0FBTyxDQUFDNE0sZ0JBQWdCLElBQUl4TSxJQUFJO0lBQ3pELElBQUlKLE9BQU8sQ0FBQzZNLFlBQVksSUFBSVQsaUJBQWlCLENBQUNwTSxPQUFPLENBQUN3TixTQUFTLEVBQUU7TUFDL0RwTixJQUFJLENBQUNxUCxVQUFVLEdBQUdqSyxlQUFlLENBQUNrSyxhQUFhLENBQzdDdEQsaUJBQWlCLENBQUNwTSxPQUFPLENBQUN3TixTQUFTLENBQUM7SUFDeEMsQ0FBQyxNQUFNO01BQ0xwTixJQUFJLENBQUNxUCxVQUFVLEdBQUcsSUFBSTtJQUN4QjtJQUVBclAsSUFBSSxDQUFDdVAsaUJBQWlCLEdBQUd2VCxNQUFNLENBQUNrSCxJQUFJLENBQ2xDSSxVQUFVLENBQUMySCxjQUFjLENBQUMvTixJQUFJLENBQzVCb0csVUFBVSxFQUNWakUsWUFBWSxDQUFDMk0saUJBQWlCLENBQUNqRyxRQUFRLEVBQUVqSCwwQkFBMEIsQ0FBQyxFQUNwRU8sWUFBWSxDQUFDMk0saUJBQWlCLENBQUNwTSxPQUFPLEVBQUVkLDBCQUEwQixDQUNwRSxDQUNGLENBQUM7SUFDRGtCLElBQUksQ0FBQ3dQLFdBQVcsR0FBRyxJQUFJcEssZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7RUFDL0MsQ0FBQztFQUVEMVMsQ0FBQyxDQUFDb0osTUFBTSxDQUFDK0ksaUJBQWlCLENBQUMxUixTQUFTLEVBQUU7SUFDcEM7SUFDQTtJQUNBa1MscUJBQXFCLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO01BQ2pDLE1BQU0xUCxJQUFJLEdBQUcsSUFBSTtNQUNqQixPQUFPLElBQUkyQyxPQUFPLENBQUMsQ0FBQ3NLLE9BQU8sRUFBRUMsTUFBTSxLQUFLO1FBQ3RDbE4sSUFBSSxDQUFDbVAsU0FBUyxDQUFDUSxJQUFJLENBQUMsQ0FBQ2hMLEdBQUcsRUFBRWlMLEdBQUcsS0FBSztVQUNoQyxJQUFJakwsR0FBRyxFQUFFO1lBQ1B1SSxNQUFNLENBQUN2SSxHQUFHLENBQUM7VUFDYixDQUFDLE1BQU07WUFDTHNJLE9BQU8sQ0FBQzJDLEdBQUcsQ0FBQztVQUNkO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVEO0lBQ0E7SUFDQUMsa0JBQWtCLEVBQUUsU0FBQUEsQ0FBQTtNQUFBLE9BQUFsTixPQUFBLENBQUE4SCxVQUFBLE9BQWtCO1FBQ3BDLElBQUl6SyxJQUFJLEdBQUcsSUFBSTtRQUVmLE9BQU8sSUFBSSxFQUFFO1VBQ1gsSUFBSTRQLEdBQUcsR0FBQWpOLE9BQUEsQ0FBQUMsS0FBQSxDQUFTNUMsSUFBSSxDQUFDMFAscUJBQXFCLENBQUMsQ0FBQztVQUU1QyxJQUFJLENBQUNFLEdBQUcsRUFBRSxPQUFPLElBQUk7VUFDckJBLEdBQUcsR0FBR3ZRLFlBQVksQ0FBQ3VRLEdBQUcsRUFBRTlSLDBCQUEwQixDQUFDO1VBRW5ELElBQUksQ0FBQ2tDLElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDdE0sT0FBTyxDQUFDME0sUUFBUSxJQUFJdlAsQ0FBQyxDQUFDK0QsR0FBRyxDQUFDOE8sR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ2xFO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBLElBQUk1UCxJQUFJLENBQUN3UCxXQUFXLENBQUMxTyxHQUFHLENBQUM4TyxHQUFHLENBQUNySyxHQUFHLENBQUMsRUFBRTtZQUNuQ3ZGLElBQUksQ0FBQ3dQLFdBQVcsQ0FBQ00sR0FBRyxDQUFDRixHQUFHLENBQUNySyxHQUFHLEVBQUUsSUFBSSxDQUFDO1VBQ3JDO1VBRUEsSUFBSXZGLElBQUksQ0FBQ3FQLFVBQVUsRUFDakJPLEdBQUcsR0FBRzVQLElBQUksQ0FBQ3FQLFVBQVUsQ0FBQ08sR0FBRyxDQUFDO1VBRTVCLE9BQU9BLEdBQUc7UUFDWjtNQUNGLENBQUM7SUFBQTtJQUVEO0lBQ0E7SUFDQTtJQUNBRyw2QkFBNkIsRUFBRSxTQUFBQSxDQUFVQyxTQUFTLEVBQUU7TUFDbEQsTUFBTWhRLElBQUksR0FBRyxJQUFJO01BQ2pCLElBQUksQ0FBQ2dRLFNBQVMsRUFBRTtRQUNkLE9BQU9oUSxJQUFJLENBQUM2UCxrQkFBa0IsQ0FBQyxDQUFDO01BQ2xDO01BQ0EsTUFBTUksaUJBQWlCLEdBQUdqUSxJQUFJLENBQUM2UCxrQkFBa0IsQ0FBQyxDQUFDO01BQ25ELE1BQU1LLFVBQVUsR0FBRyxJQUFJbk4sS0FBSyxDQUFDLDZDQUE2QyxDQUFDO01BQzNFLE1BQU1vTixjQUFjLEdBQUcsSUFBSXhOLE9BQU8sQ0FBQyxDQUFDc0ssT0FBTyxFQUFFQyxNQUFNLEtBQUs7UUFDdEQsTUFBTWtELEtBQUssR0FBR0MsVUFBVSxDQUFDLE1BQU07VUFDN0JuRCxNQUFNLENBQUNnRCxVQUFVLENBQUM7UUFDcEIsQ0FBQyxFQUFFRixTQUFTLENBQUM7TUFDZixDQUFDLENBQUM7TUFDRixPQUFPck4sT0FBTyxDQUFDMk4sSUFBSSxDQUFDLENBQUNMLGlCQUFpQixFQUFFRSxjQUFjLENBQUMsQ0FBQyxDQUNyRHRLLEtBQUssQ0FBRWxCLEdBQUcsSUFBSztRQUNkLElBQUlBLEdBQUcsS0FBS3VMLFVBQVUsRUFBRTtVQUN0QmxRLElBQUksQ0FBQzhDLEtBQUssQ0FBQyxDQUFDO1FBQ2Q7UUFDQSxNQUFNNkIsR0FBRztNQUNYLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRDRMLFdBQVcsRUFBRSxTQUFBQSxDQUFBLEVBQVk7TUFDdkIsSUFBSXZRLElBQUksR0FBRyxJQUFJO01BQ2YsT0FBT0EsSUFBSSxDQUFDNlAsa0JBQWtCLENBQUMsQ0FBQyxDQUFDak4sS0FBSyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVEeEIsT0FBTyxFQUFFLFNBQUFBLENBQVVrQixRQUFRLEVBQUVrTyxPQUFPLEVBQUU7TUFDcEMsSUFBSXhRLElBQUksR0FBRyxJQUFJO01BQ2YsTUFBTXlRLFNBQVMsR0FBR25RLE1BQU0sQ0FBQ29RLE1BQU0sQ0FBQ3BPLFFBQVEsQ0FBQzs7TUFFekM7TUFDQXRDLElBQUksQ0FBQzJRLE9BQU8sQ0FBQyxDQUFDOztNQUVkO01BQ0E7TUFDQTtNQUNBLElBQUk1RixLQUFLLEdBQUcsQ0FBQztNQUNiLE9BQU8sSUFBSSxFQUFFO1FBQ1gsSUFBSTZFLEdBQUcsR0FBRzVQLElBQUksQ0FBQ3VRLFdBQVcsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQ1gsR0FBRyxFQUFFO1FBQ1ZhLFNBQVMsQ0FBQ0csSUFBSSxDQUFDSixPQUFPLEVBQUVaLEdBQUcsRUFBRTdFLEtBQUssRUFBRSxFQUFFL0ssSUFBSSxDQUFDb1AsaUJBQWlCLENBQUM7TUFDL0Q7SUFDRixDQUFDO0lBRUQ7SUFDQW5TLEdBQUcsRUFBRSxTQUFBQSxDQUFVcUYsUUFBUSxFQUFFa08sT0FBTyxFQUFFO01BQ2hDLElBQUl4USxJQUFJLEdBQUcsSUFBSTtNQUNmLE1BQU15USxTQUFTLEdBQUduUSxNQUFNLENBQUNvUSxNQUFNLENBQUNwTyxRQUFRLENBQUM7TUFDekMsSUFBSXVPLEdBQUcsR0FBRyxFQUFFO01BQ1o3USxJQUFJLENBQUNvQixPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRTdFLEtBQUssRUFBRTtRQUNqQzhGLEdBQUcsQ0FBQ0MsSUFBSSxDQUFDTCxTQUFTLENBQUNHLElBQUksQ0FBQ0osT0FBTyxFQUFFWixHQUFHLEVBQUU3RSxLQUFLLEVBQUUvSyxJQUFJLENBQUNvUCxpQkFBaUIsQ0FBQyxDQUFDO01BQ3ZFLENBQUMsQ0FBQztNQUNGLE9BQU95QixHQUFHO0lBQ1osQ0FBQztJQUVERixPQUFPLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO01BQ25CLElBQUkzUSxJQUFJLEdBQUcsSUFBSTs7TUFFZjtNQUNBQSxJQUFJLENBQUNtUCxTQUFTLENBQUM0QixNQUFNLENBQUMsQ0FBQztNQUV2Qi9RLElBQUksQ0FBQ3dQLFdBQVcsR0FBRyxJQUFJcEssZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7SUFDL0MsQ0FBQztJQUVEO0lBQ0EzTSxLQUFLLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO01BQ2pCLElBQUk5QyxJQUFJLEdBQUcsSUFBSTtNQUVmQSxJQUFJLENBQUNtUCxTQUFTLENBQUNyTSxLQUFLLENBQUMsQ0FBQztJQUN4QixDQUFDO0lBRURrTyxLQUFLLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO01BQ2pCLElBQUloUixJQUFJLEdBQUcsSUFBSTtNQUNmLE9BQU9BLElBQUksQ0FBQy9DLEdBQUcsQ0FBQ0YsQ0FBQyxDQUFDa1UsUUFBUSxDQUFDO0lBQzdCLENBQUM7SUFFRHZFLEtBQUssRUFBRSxTQUFBQSxDQUFBLEVBQVk7TUFDakIsSUFBSTFNLElBQUksR0FBRyxJQUFJO01BQ2YsT0FBT0EsSUFBSSxDQUFDdVAsaUJBQWlCLENBQUMsQ0FBQyxDQUFDcE0sSUFBSSxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVEO0lBQ0ErTixhQUFhLEVBQUUsU0FBQUEsQ0FBVXJELE9BQU8sRUFBRTtNQUNoQyxJQUFJN04sSUFBSSxHQUFHLElBQUk7TUFDZixJQUFJNk4sT0FBTyxFQUFFO1FBQ1gsT0FBTzdOLElBQUksQ0FBQ2dSLEtBQUssQ0FBQyxDQUFDO01BQ3JCLENBQUMsTUFBTTtRQUNMLElBQUlHLE9BQU8sR0FBRyxJQUFJL0wsZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7UUFDeEN6UCxJQUFJLENBQUNvQixPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRTtVQUMxQnVCLE9BQU8sQ0FBQ3JCLEdBQUcsQ0FBQ0YsR0FBRyxDQUFDckssR0FBRyxFQUFFcUssR0FBRyxDQUFDO1FBQzNCLENBQUMsQ0FBQztRQUNGLE9BQU91QixPQUFPO01BQ2hCO0lBQ0Y7RUFDRixDQUFDLENBQUM7RUFFRmpDLGlCQUFpQixDQUFDMVIsU0FBUyxDQUFDbVAsTUFBTSxDQUFDQyxRQUFRLENBQUMsR0FBRyxZQUFZO0lBQ3pELElBQUk1TSxJQUFJLEdBQUcsSUFBSTs7SUFFZjtJQUNBQSxJQUFJLENBQUMyUSxPQUFPLENBQUMsQ0FBQztJQUVkLE9BQU87TUFDTGhCLElBQUlBLENBQUEsRUFBRztRQUNMLE1BQU1DLEdBQUcsR0FBRzVQLElBQUksQ0FBQ3VRLFdBQVcsQ0FBQyxDQUFDO1FBQzlCLE9BQU9YLEdBQUcsR0FBRztVQUNYdlMsS0FBSyxFQUFFdVM7UUFDVCxDQUFDLEdBQUc7VUFDRndCLElBQUksRUFBRTtRQUNSLENBQUM7TUFDSDtJQUNGLENBQUM7RUFDSCxDQUFDO0VBRURsQyxpQkFBaUIsQ0FBQzFSLFNBQVMsQ0FBQ21QLE1BQU0sQ0FBQ0UsYUFBYSxDQUFDLEdBQUcsWUFBWTtJQUM5RCxNQUFNd0UsVUFBVSxHQUFHLElBQUksQ0FBQzFFLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUMxQyxPQUFPO01BQ0MrQyxJQUFJQSxDQUFBO1FBQUEsT0FBQWhOLE9BQUEsQ0FBQThILFVBQUEsT0FBRztVQUNYLE9BQU85SCxPQUFPLENBQUNzSyxPQUFPLENBQUNvRSxVQUFVLENBQUMxQixJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzNDLENBQUM7TUFBQTtJQUNILENBQUM7RUFDSCxDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBalEsZUFBZSxDQUFDbEMsU0FBUyxDQUFDOFQsSUFBSSxHQUFHLFVBQVV0RixpQkFBaUIsRUFBRXVGLFdBQVcsRUFBRXZCLFNBQVMsRUFBRTtJQUNwRixJQUFJaFEsSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJLENBQUNnTSxpQkFBaUIsQ0FBQ3BNLE9BQU8sQ0FBQzBNLFFBQVEsRUFDckMsTUFBTSxJQUFJdkosS0FBSyxDQUFDLGlDQUFpQyxDQUFDO0lBRXBELElBQUlzSixNQUFNLEdBQUdyTSxJQUFJLENBQUN1TSx3QkFBd0IsQ0FBQ1AsaUJBQWlCLENBQUM7SUFFN0QsSUFBSXdGLE9BQU8sR0FBRyxLQUFLO0lBQ25CLElBQUlDLE1BQU07SUFDVixJQUFJQyxJQUFJLEdBQUcsU0FBQUEsQ0FBQSxFQUFZO01BQ3JCLElBQUk5QixHQUFHLEdBQUcsSUFBSTtNQUNkLE9BQU8sSUFBSSxFQUFFO1FBQ1gsSUFBSTRCLE9BQU8sRUFDVDtRQUNGLElBQUk7VUFDRjVCLEdBQUcsR0FBR3ZELE1BQU0sQ0FBQzBELDZCQUE2QixDQUFDQyxTQUFTLENBQUMsQ0FBQ3BOLEtBQUssQ0FBQyxDQUFDO1FBQy9ELENBQUMsQ0FBQyxPQUFPK0IsR0FBRyxFQUFFO1VBQ1o7VUFDQTtVQUNBO1VBQ0E7VUFDQWlMLEdBQUcsR0FBRyxJQUFJO1FBQ1o7UUFDQTtRQUNBO1FBQ0EsSUFBSTRCLE9BQU8sRUFDVDtRQUNGLElBQUk1QixHQUFHLEVBQUU7VUFDUDtVQUNBO1VBQ0E7VUFDQTtVQUNBNkIsTUFBTSxHQUFHN0IsR0FBRyxDQUFDZCxFQUFFO1VBQ2Z5QyxXQUFXLENBQUMzQixHQUFHLENBQUM7UUFDbEIsQ0FBQyxNQUFNO1VBQ0wsSUFBSStCLFdBQVcsR0FBRzVVLENBQUMsQ0FBQ1UsS0FBSyxDQUFDdU8saUJBQWlCLENBQUNqRyxRQUFRLENBQUM7VUFDckQsSUFBSTBMLE1BQU0sRUFBRTtZQUNWRSxXQUFXLENBQUM3QyxFQUFFLEdBQUc7Y0FBQzhDLEdBQUcsRUFBRUg7WUFBTSxDQUFDO1VBQ2hDO1VBQ0FwRixNQUFNLEdBQUdyTSxJQUFJLENBQUN1TSx3QkFBd0IsQ0FBQyxJQUFJaEMsaUJBQWlCLENBQzFEeUIsaUJBQWlCLENBQUMzSSxjQUFjLEVBQ2hDc08sV0FBVyxFQUNYM0YsaUJBQWlCLENBQUNwTSxPQUFPLENBQUMsQ0FBQztVQUM3QjtVQUNBO1VBQ0E7VUFDQVUsTUFBTSxDQUFDK1AsVUFBVSxDQUFDcUIsSUFBSSxFQUFFLEdBQUcsQ0FBQztVQUM1QjtRQUNGO01BQ0Y7SUFDRixDQUFDO0lBRURwUixNQUFNLENBQUN1UixLQUFLLENBQUNILElBQUksQ0FBQztJQUVsQixPQUFPO01BQ0x6TyxJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ2hCdU8sT0FBTyxHQUFHLElBQUk7UUFDZG5GLE1BQU0sQ0FBQ3ZKLEtBQUssQ0FBQyxDQUFDO01BQ2hCO0lBQ0YsQ0FBQztFQUNILENBQUM7RUFFRHBELGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ3lRLGVBQWUsR0FBRyxVQUN4Q2pDLGlCQUFpQixFQUFFNkIsT0FBTyxFQUFFSixTQUFTLEVBQUVTLG9CQUFvQixFQUFFO0lBQy9ELElBQUlsTyxJQUFJLEdBQUcsSUFBSTtJQUVmLElBQUlnTSxpQkFBaUIsQ0FBQ3BNLE9BQU8sQ0FBQzBNLFFBQVEsRUFBRTtNQUN0QyxPQUFPdE0sSUFBSSxDQUFDOFIsdUJBQXVCLENBQUM5RixpQkFBaUIsRUFBRTZCLE9BQU8sRUFBRUosU0FBUyxDQUFDO0lBQzVFOztJQUVBO0lBQ0E7SUFDQSxNQUFNc0UsYUFBYSxHQUFHL0YsaUJBQWlCLENBQUNwTSxPQUFPLENBQUMyTyxVQUFVLElBQUl2QyxpQkFBaUIsQ0FBQ3BNLE9BQU8sQ0FBQzRPLE1BQU07SUFDOUYsSUFBSXVELGFBQWEsS0FDWkEsYUFBYSxDQUFDeE0sR0FBRyxLQUFLLENBQUMsSUFDdkJ3TSxhQUFhLENBQUN4TSxHQUFHLEtBQUssS0FBSyxDQUFDLEVBQUU7TUFDakMsTUFBTXhDLEtBQUssQ0FBQyxzREFBc0QsQ0FBQztJQUNyRTtJQUVBLElBQUlpUCxVQUFVLEdBQUdyVCxLQUFLLENBQUNzVCxTQUFTLENBQzlCbFYsQ0FBQyxDQUFDb0osTUFBTSxDQUFDO01BQUMwSCxPQUFPLEVBQUVBO0lBQU8sQ0FBQyxFQUFFN0IsaUJBQWlCLENBQUMsQ0FBQztJQUVsRCxJQUFJa0csV0FBVyxFQUFFQyxhQUFhO0lBQzlCLElBQUlDLFdBQVcsR0FBRyxLQUFLOztJQUV2QjtJQUNBO0lBQ0E7SUFDQTlSLE1BQU0sQ0FBQytSLGdCQUFnQixDQUFDLFlBQVk7TUFDbEMsSUFBSXRWLENBQUMsQ0FBQytELEdBQUcsQ0FBQ2QsSUFBSSxDQUFDQyxvQkFBb0IsRUFBRStSLFVBQVUsQ0FBQyxFQUFFO1FBQ2hERSxXQUFXLEdBQUdsUyxJQUFJLENBQUNDLG9CQUFvQixDQUFDK1IsVUFBVSxDQUFDO01BQ3JELENBQUMsTUFBTTtRQUNMSSxXQUFXLEdBQUcsSUFBSTtRQUNsQjtRQUNBRixXQUFXLEdBQUcsSUFBSUksa0JBQWtCLENBQUM7VUFDbkN6RSxPQUFPLEVBQUVBLE9BQU87VUFDaEIwRSxNQUFNLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1lBQ2xCLE9BQU92UyxJQUFJLENBQUNDLG9CQUFvQixDQUFDK1IsVUFBVSxDQUFDO1lBQzVDRyxhQUFhLENBQUNsUCxJQUFJLENBQUMsQ0FBQztVQUN0QjtRQUNGLENBQUMsQ0FBQztRQUNGakQsSUFBSSxDQUFDQyxvQkFBb0IsQ0FBQytSLFVBQVUsQ0FBQyxHQUFHRSxXQUFXO01BQ3JEO0lBQ0YsQ0FBQyxDQUFDO0lBRUYsSUFBSU0sYUFBYSxHQUFHLElBQUlDLGFBQWEsQ0FBQ1AsV0FBVyxFQUMvQ3pFLFNBQVMsRUFDVFMsb0JBQ0YsQ0FBQztJQUVELElBQUlrRSxXQUFXLEVBQUU7TUFDZixJQUFJTSxPQUFPLEVBQUVDLE1BQU07TUFDbkIsSUFBSUMsV0FBVyxHQUFHN1YsQ0FBQyxDQUFDOFYsR0FBRyxDQUFDLENBQ3RCLFlBQVk7UUFDVjtRQUNBO1FBQ0E7UUFDQSxPQUFPN1MsSUFBSSxDQUFDNEIsWUFBWSxJQUFJLENBQUNpTSxPQUFPLElBQ2xDLENBQUNKLFNBQVMsQ0FBQ3FGLHFCQUFxQjtNQUNwQyxDQUFDLEVBQUUsWUFBWTtRQUNiO1FBQ0E7UUFDQSxJQUFJO1VBQ0ZKLE9BQU8sR0FBRyxJQUFJSyxTQUFTLENBQUNDLE9BQU8sQ0FBQ2hILGlCQUFpQixDQUFDakcsUUFBUSxDQUFDO1VBQzNELE9BQU8sSUFBSTtRQUNiLENBQUMsQ0FBQyxPQUFPYixDQUFDLEVBQUU7VUFDVjtVQUNBO1VBQ0EsT0FBTyxLQUFLO1FBQ2Q7TUFDRixDQUFDLEVBQUUsWUFBWTtRQUNiO1FBQ0EsT0FBTytOLGtCQUFrQixDQUFDQyxlQUFlLENBQUNsSCxpQkFBaUIsRUFBRTBHLE9BQU8sQ0FBQztNQUN2RSxDQUFDLEVBQUUsWUFBWTtRQUNiO1FBQ0E7UUFDQSxJQUFJLENBQUMxRyxpQkFBaUIsQ0FBQ3BNLE9BQU8sQ0FBQ3lPLElBQUksRUFDakMsT0FBTyxJQUFJO1FBQ2IsSUFBSTtVQUNGc0UsTUFBTSxHQUFHLElBQUlJLFNBQVMsQ0FBQ0ksTUFBTSxDQUFDbkgsaUJBQWlCLENBQUNwTSxPQUFPLENBQUN5TyxJQUFJLENBQUM7VUFDN0QsT0FBTyxJQUFJO1FBQ2IsQ0FBQyxDQUFDLE9BQU9uSixDQUFDLEVBQUU7VUFDVjtVQUNBO1VBQ0EsT0FBTyxLQUFLO1FBQ2Q7TUFDRixDQUFDLENBQUMsRUFBRSxVQUFVa08sQ0FBQyxFQUFFO1FBQUUsT0FBT0EsQ0FBQyxDQUFDLENBQUM7TUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFFOztNQUV0QyxJQUFJQyxXQUFXLEdBQUdULFdBQVcsR0FBR0ssa0JBQWtCLEdBQUdLLG9CQUFvQjtNQUN6RW5CLGFBQWEsR0FBRyxJQUFJa0IsV0FBVyxDQUFDO1FBQzlCckgsaUJBQWlCLEVBQUVBLGlCQUFpQjtRQUNwQ3VILFdBQVcsRUFBRXZULElBQUk7UUFDakJrUyxXQUFXLEVBQUVBLFdBQVc7UUFDeEJyRSxPQUFPLEVBQUVBLE9BQU87UUFDaEI2RSxPQUFPLEVBQUVBLE9BQU87UUFBRztRQUNuQkMsTUFBTSxFQUFFQSxNQUFNO1FBQUc7UUFDakJHLHFCQUFxQixFQUFFckYsU0FBUyxDQUFDcUY7TUFDbkMsQ0FBQyxDQUFDOztNQUVGO01BQ0FaLFdBQVcsQ0FBQ3NCLGNBQWMsR0FBR3JCLGFBQWE7SUFDNUM7O0lBRUE7SUFDQUQsV0FBVyxDQUFDdUIsMkJBQTJCLENBQUNqQixhQUFhLENBQUM7SUFFdEQsT0FBT0EsYUFBYTtFQUN0QixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0VBRUFrQixTQUFTLEdBQUcsU0FBQUEsQ0FBVTFILGlCQUFpQixFQUFFMkgsY0FBYyxFQUFFO0lBQ3ZELElBQUlDLFNBQVMsR0FBRyxFQUFFO0lBQ2xCQyxjQUFjLENBQUM3SCxpQkFBaUIsRUFBRSxVQUFVOEgsT0FBTyxFQUFFO01BQ25ERixTQUFTLENBQUM5QyxJQUFJLENBQUM3TSxTQUFTLENBQUM4UCxxQkFBcUIsQ0FBQ0MsTUFBTSxDQUNuREYsT0FBTyxFQUFFSCxjQUFjLENBQUMsQ0FBQztJQUM3QixDQUFDLENBQUM7SUFFRixPQUFPO01BQ0wxUSxJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ2hCbEcsQ0FBQyxDQUFDSyxJQUFJLENBQUN3VyxTQUFTLEVBQUUsVUFBVUssUUFBUSxFQUFFO1VBQ3BDQSxRQUFRLENBQUNoUixJQUFJLENBQUMsQ0FBQztRQUNqQixDQUFDLENBQUM7TUFDSjtJQUNGLENBQUM7RUFDSCxDQUFDO0VBRUQ0USxjQUFjLEdBQUcsU0FBQUEsQ0FBVTdILGlCQUFpQixFQUFFa0ksZUFBZSxFQUFFO0lBQzdELElBQUk1VyxHQUFHLEdBQUc7TUFBQ2dHLFVBQVUsRUFBRTBJLGlCQUFpQixDQUFDM0k7SUFBYyxDQUFDO0lBQ3hELElBQUk0QyxXQUFXLEdBQUdiLGVBQWUsQ0FBQ2MscUJBQXFCLENBQ3JEOEYsaUJBQWlCLENBQUNqRyxRQUFRLENBQUM7SUFDN0IsSUFBSUUsV0FBVyxFQUFFO01BQ2ZsSixDQUFDLENBQUNLLElBQUksQ0FBQzZJLFdBQVcsRUFBRSxVQUFVWCxFQUFFLEVBQUU7UUFDaEM0TyxlQUFlLENBQUNuWCxDQUFDLENBQUNvSixNQUFNLENBQUM7VUFBQ2IsRUFBRSxFQUFFQTtRQUFFLENBQUMsRUFBRWhJLEdBQUcsQ0FBQyxDQUFDO01BQzFDLENBQUMsQ0FBQztNQUNGNFcsZUFBZSxDQUFDblgsQ0FBQyxDQUFDb0osTUFBTSxDQUFDO1FBQUNVLGNBQWMsRUFBRSxJQUFJO1FBQUV2QixFQUFFLEVBQUU7TUFBSSxDQUFDLEVBQUVoSSxHQUFHLENBQUMsQ0FBQztJQUNsRSxDQUFDLE1BQU07TUFDTDRXLGVBQWUsQ0FBQzVXLEdBQUcsQ0FBQztJQUN0QjtJQUNBO0lBQ0E0VyxlQUFlLENBQUM7TUFBRWxOLFlBQVksRUFBRTtJQUFLLENBQUMsQ0FBQztFQUN6QyxDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0F0SCxlQUFlLENBQUNsQyxTQUFTLENBQUNzVSx1QkFBdUIsR0FBRyxVQUNoRDlGLGlCQUFpQixFQUFFNkIsT0FBTyxFQUFFSixTQUFTLEVBQUU7SUFDekMsSUFBSXpOLElBQUksR0FBRyxJQUFJOztJQUVmO0lBQ0E7SUFDQSxJQUFLNk4sT0FBTyxJQUFJLENBQUNKLFNBQVMsQ0FBQzBHLFdBQVcsSUFDakMsQ0FBQ3RHLE9BQU8sSUFBSSxDQUFDSixTQUFTLENBQUMyRyxLQUFNLEVBQUU7TUFDbEMsTUFBTSxJQUFJclIsS0FBSyxDQUFDLG1CQUFtQixJQUFJOEssT0FBTyxHQUFHLFNBQVMsR0FBRyxXQUFXLENBQUMsR0FDdkQsNkJBQTZCLElBQzVCQSxPQUFPLEdBQUcsYUFBYSxHQUFHLE9BQU8sQ0FBQyxHQUFHLFdBQVcsQ0FBQztJQUN0RTtJQUVBLE9BQU83TixJQUFJLENBQUNzUixJQUFJLENBQUN0RixpQkFBaUIsRUFBRSxVQUFVNEQsR0FBRyxFQUFFO01BQ2pELElBQUl0SyxFQUFFLEdBQUdzSyxHQUFHLENBQUNySyxHQUFHO01BQ2hCLE9BQU9xSyxHQUFHLENBQUNySyxHQUFHO01BQ2Q7TUFDQSxPQUFPcUssR0FBRyxDQUFDZCxFQUFFO01BQ2IsSUFBSWpCLE9BQU8sRUFBRTtRQUNYSixTQUFTLENBQUMwRyxXQUFXLENBQUM3TyxFQUFFLEVBQUVzSyxHQUFHLEVBQUUsSUFBSSxDQUFDO01BQ3RDLENBQUMsTUFBTTtRQUNMbkMsU0FBUyxDQUFDMkcsS0FBSyxDQUFDOU8sRUFBRSxFQUFFc0ssR0FBRyxDQUFDO01BQzFCO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQTFULGNBQWMsQ0FBQ21ZLGNBQWMsR0FBR3ZZLE9BQU8sQ0FBQ3lCLFNBQVM7RUFFakRyQixjQUFjLENBQUNvWSxVQUFVLEdBQUc1VSxlQUFlO0FBQUMsRUFBQWtSLElBQUEsT0FBQXJVLE1BQUEsRTs7Ozs7Ozs7Ozs7QUN0aEQ1QyxJQUFJUixnQkFBZ0I7QUFBQ1EsTUFBTSxDQUFDbkIsSUFBSSxDQUFDLGtCQUFrQixFQUFDO0VBQUNXLGdCQUFnQkEsQ0FBQ1QsQ0FBQyxFQUFDO0lBQUNTLGdCQUFnQixHQUFDVCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQWhHLElBQUlVLE1BQU0sR0FBR0MsR0FBRyxDQUFDTCxPQUFPLENBQUMsZUFBZSxDQUFDO0FBR3pDLE1BQU07RUFBRTJZO0FBQUssQ0FBQyxHQUFHeFksZ0JBQWdCO0FBRWpDOFMsZ0JBQWdCLEdBQUcsVUFBVTtBQUU3QixJQUFJMkYsY0FBYyxHQUFHQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsMkJBQTJCLElBQUksSUFBSTtBQUNwRSxJQUFJQyxZQUFZLEdBQUcsQ0FBQ0gsT0FBTyxDQUFDQyxHQUFHLENBQUNHLHlCQUF5QixJQUFJLEtBQUs7QUFFbEUsSUFBSUMsTUFBTSxHQUFHLFNBQUFBLENBQVVoRyxFQUFFLEVBQUU7RUFDekIsT0FBTyxZQUFZLEdBQUdBLEVBQUUsQ0FBQ2lHLFdBQVcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHakcsRUFBRSxDQUFDa0csVUFBVSxDQUFDLENBQUMsR0FBRyxHQUFHO0FBQ3ZFLENBQUM7QUFFREMsT0FBTyxHQUFHLFNBQUFBLENBQVVDLEVBQUUsRUFBRTtFQUN0QixJQUFJQSxFQUFFLENBQUNBLEVBQUUsS0FBSyxHQUFHLEVBQ2YsT0FBT0EsRUFBRSxDQUFDQyxDQUFDLENBQUM1UCxHQUFHLENBQUMsS0FDYixJQUFJMlAsRUFBRSxDQUFDQSxFQUFFLEtBQUssR0FBRyxFQUNwQixPQUFPQSxFQUFFLENBQUNDLENBQUMsQ0FBQzVQLEdBQUcsQ0FBQyxLQUNiLElBQUkyUCxFQUFFLENBQUNBLEVBQUUsS0FBSyxHQUFHLEVBQ3BCLE9BQU9BLEVBQUUsQ0FBQ0UsRUFBRSxDQUFDN1AsR0FBRyxDQUFDLEtBQ2QsSUFBSTJQLEVBQUUsQ0FBQ0EsRUFBRSxLQUFLLEdBQUcsRUFDcEIsTUFBTW5TLEtBQUssQ0FBQyxpREFBaUQsR0FDakRwRSxLQUFLLENBQUNzVCxTQUFTLENBQUNpRCxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBRWpDLE1BQU1uUyxLQUFLLENBQUMsY0FBYyxHQUFHcEUsS0FBSyxDQUFDc1QsU0FBUyxDQUFDaUQsRUFBRSxDQUFDLENBQUM7QUFDckQsQ0FBQztBQUVEelMsV0FBVyxHQUFHLFNBQUFBLENBQVVGLFFBQVEsRUFBRThTLE1BQU0sRUFBRTtFQUN4QyxJQUFJclYsSUFBSSxHQUFHLElBQUk7RUFDZkEsSUFBSSxDQUFDc1YsU0FBUyxHQUFHL1MsUUFBUTtFQUN6QnZDLElBQUksQ0FBQ3VWLE9BQU8sR0FBR0YsTUFBTTtFQUVyQnJWLElBQUksQ0FBQ3dWLHlCQUF5QixHQUFHLElBQUk7RUFDckN4VixJQUFJLENBQUN5VixvQkFBb0IsR0FBRyxJQUFJO0VBQ2hDelYsSUFBSSxDQUFDMFYsUUFBUSxHQUFHLEtBQUs7RUFDckIxVixJQUFJLENBQUMyVixXQUFXLEdBQUcsSUFBSTtFQUN2QjNWLElBQUksQ0FBQzRWLFlBQVksR0FBRyxJQUFJNVosTUFBTSxDQUFDLENBQUM7RUFDaENnRSxJQUFJLENBQUM2VixTQUFTLEdBQUcsSUFBSTVSLFNBQVMsQ0FBQzZSLFNBQVMsQ0FBQztJQUN2Q0MsV0FBVyxFQUFFLGdCQUFnQjtJQUFFQyxRQUFRLEVBQUU7RUFDM0MsQ0FBQyxDQUFDO0VBQ0ZoVyxJQUFJLENBQUNpVyxrQkFBa0IsR0FBRztJQUN4QkMsRUFBRSxFQUFFLElBQUlDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FDdEI3VixNQUFNLENBQUM4VixhQUFhLENBQUNwVyxJQUFJLENBQUN1VixPQUFPLEdBQUcsR0FBRyxDQUFDLEVBQ3hDalYsTUFBTSxDQUFDOFYsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUNuQyxDQUFDNVUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUVsQjZVLEdBQUcsRUFBRSxDQUNIO01BQUVuQixFQUFFLEVBQUU7UUFBRW9CLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRztNQUFFO0lBQUUsQ0FBQztJQUNoQztJQUNBO01BQUVwQixFQUFFLEVBQUUsR0FBRztNQUFFLFFBQVEsRUFBRTtRQUFFcUIsT0FBTyxFQUFFO01BQUs7SUFBRSxDQUFDLEVBQ3hDO01BQUVyQixFQUFFLEVBQUUsR0FBRztNQUFFLGdCQUFnQixFQUFFO0lBQUUsQ0FBQyxFQUNoQztNQUFFQSxFQUFFLEVBQUUsR0FBRztNQUFFLFlBQVksRUFBRTtRQUFFcUIsT0FBTyxFQUFFO01BQUs7SUFBRSxDQUFDO0VBRWhELENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0F2VyxJQUFJLENBQUN3VyxrQkFBa0IsR0FBRyxFQUFFO0VBQzVCeFcsSUFBSSxDQUFDeVcsZ0JBQWdCLEdBQUcsSUFBSTtFQUU1QnpXLElBQUksQ0FBQzBXLHFCQUFxQixHQUFHLElBQUl2VyxJQUFJLENBQUM7SUFDcEN3VyxvQkFBb0IsRUFBRTtFQUN4QixDQUFDLENBQUM7RUFFRjNXLElBQUksQ0FBQzRXLFdBQVcsR0FBRyxJQUFJdFcsTUFBTSxDQUFDdVcsaUJBQWlCLENBQUMsQ0FBQztFQUNqRDdXLElBQUksQ0FBQzhXLGFBQWEsR0FBRyxLQUFLO0VBRTFCOVcsSUFBSSxDQUFDK1csYUFBYSxDQUFDLENBQUM7QUFDdEIsQ0FBQztBQUVEcFcsTUFBTSxDQUFDQyxNQUFNLENBQUM2QixXQUFXLENBQUNqRixTQUFTLEVBQUU7RUFDbkN5RixJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ2hCLElBQUlqRCxJQUFJLEdBQUcsSUFBSTtJQUNmLElBQUlBLElBQUksQ0FBQzBWLFFBQVEsRUFDZjtJQUNGMVYsSUFBSSxDQUFDMFYsUUFBUSxHQUFHLElBQUk7SUFDcEIsSUFBSTFWLElBQUksQ0FBQzJWLFdBQVcsRUFDbEIzVixJQUFJLENBQUMyVixXQUFXLENBQUMxUyxJQUFJLENBQUMsQ0FBQztJQUN6QjtFQUNGLENBQUM7RUFDRCtULFlBQVksRUFBRSxTQUFBQSxDQUFVbEQsT0FBTyxFQUFFeFIsUUFBUSxFQUFFO0lBQ3pDLElBQUl0QyxJQUFJLEdBQUcsSUFBSTtJQUNmLElBQUlBLElBQUksQ0FBQzBWLFFBQVEsRUFDZixNQUFNLElBQUkzUyxLQUFLLENBQUMsd0NBQXdDLENBQUM7O0lBRTNEO0lBQ0EvQyxJQUFJLENBQUM0VixZQUFZLENBQUN6UyxJQUFJLENBQUMsQ0FBQztJQUV4QixJQUFJOFQsZ0JBQWdCLEdBQUczVSxRQUFRO0lBQy9CQSxRQUFRLEdBQUdoQyxNQUFNLENBQUMyQixlQUFlLENBQUMsVUFBVWlWLFlBQVksRUFBRTtNQUN4REQsZ0JBQWdCLENBQUNDLFlBQVksQ0FBQztJQUNoQyxDQUFDLEVBQUUsVUFBVXZTLEdBQUcsRUFBRTtNQUNoQnJFLE1BQU0sQ0FBQzZXLE1BQU0sQ0FBQyx5QkFBeUIsRUFBRXhTLEdBQUcsQ0FBQztJQUMvQyxDQUFDLENBQUM7SUFDRixJQUFJeVMsWUFBWSxHQUFHcFgsSUFBSSxDQUFDNlYsU0FBUyxDQUFDN0IsTUFBTSxDQUFDRixPQUFPLEVBQUV4UixRQUFRLENBQUM7SUFDM0QsT0FBTztNQUNMVyxJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ2hCbVUsWUFBWSxDQUFDblUsSUFBSSxDQUFDLENBQUM7TUFDckI7SUFDRixDQUFDO0VBQ0gsQ0FBQztFQUNEO0VBQ0E7RUFDQW9VLGdCQUFnQixFQUFFLFNBQUFBLENBQVUvVSxRQUFRLEVBQUU7SUFDcEMsSUFBSXRDLElBQUksR0FBRyxJQUFJO0lBQ2YsSUFBSUEsSUFBSSxDQUFDMFYsUUFBUSxFQUNmLE1BQU0sSUFBSTNTLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztJQUMvRCxPQUFPL0MsSUFBSSxDQUFDMFcscUJBQXFCLENBQUNuUyxRQUFRLENBQUNqQyxRQUFRLENBQUM7RUFDdEQsQ0FBQztFQUNEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQWdWLGlCQUFpQixFQUFFLFNBQUFBLENBQUEsRUFBWTtJQUM3QixJQUFJdFgsSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJQSxJQUFJLENBQUMwVixRQUFRLEVBQ2YsTUFBTSxJQUFJM1MsS0FBSyxDQUFDLDZDQUE2QyxDQUFDOztJQUVoRTtJQUNBO0lBQ0EvQyxJQUFJLENBQUM0VixZQUFZLENBQUN6UyxJQUFJLENBQUMsQ0FBQztJQUN4QixJQUFJb1UsU0FBUztJQUViLE9BQU8sQ0FBQ3ZYLElBQUksQ0FBQzBWLFFBQVEsRUFBRTtNQUNyQjtNQUNBO01BQ0E7TUFDQSxJQUFJO1FBQ0Y2QixTQUFTLEdBQUd2WCxJQUFJLENBQUN3Vix5QkFBeUIsQ0FBQzVLLE9BQU8sQ0FDaERpRSxnQkFBZ0IsRUFBRTdPLElBQUksQ0FBQ2lXLGtCQUFrQixFQUN6QztVQUFDMUgsVUFBVSxFQUFFO1lBQUNPLEVBQUUsRUFBRTtVQUFDLENBQUM7VUFBRVQsSUFBSSxFQUFFO1lBQUNtSixRQUFRLEVBQUUsQ0FBQztVQUFDO1FBQUMsQ0FBQyxDQUFDO1FBQzlDO01BQ0YsQ0FBQyxDQUFDLE9BQU90UyxDQUFDLEVBQUU7UUFDVjtRQUNBO1FBQ0E1RSxNQUFNLENBQUM2VyxNQUFNLENBQUMsd0NBQXdDLEVBQUVqUyxDQUFDLENBQUM7UUFDMUQ1RSxNQUFNLENBQUNtWCxXQUFXLENBQUMsR0FBRyxDQUFDO01BQ3pCO0lBQ0Y7SUFFQSxJQUFJelgsSUFBSSxDQUFDMFYsUUFBUSxFQUNmO0lBRUYsSUFBSSxDQUFDNkIsU0FBUyxFQUFFO01BQ2Q7TUFDQTtJQUNGO0lBRUEsSUFBSXpJLEVBQUUsR0FBR3lJLFNBQVMsQ0FBQ3pJLEVBQUU7SUFDckIsSUFBSSxDQUFDQSxFQUFFLEVBQ0wsTUFBTS9MLEtBQUssQ0FBQywwQkFBMEIsR0FBR3BFLEtBQUssQ0FBQ3NULFNBQVMsQ0FBQ3NGLFNBQVMsQ0FBQyxDQUFDO0lBRXRFLElBQUl2WCxJQUFJLENBQUN5VyxnQkFBZ0IsSUFBSTNILEVBQUUsQ0FBQzRJLGVBQWUsQ0FBQzFYLElBQUksQ0FBQ3lXLGdCQUFnQixDQUFDLEVBQUU7TUFDdEU7TUFDQTtJQUNGOztJQUdBO0lBQ0E7SUFDQTtJQUNBLElBQUlrQixXQUFXLEdBQUczWCxJQUFJLENBQUN3VyxrQkFBa0IsQ0FBQzdOLE1BQU07SUFDaEQsT0FBT2dQLFdBQVcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJM1gsSUFBSSxDQUFDd1csa0JBQWtCLENBQUNtQixXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUM3SSxFQUFFLENBQUM4SSxXQUFXLENBQUM5SSxFQUFFLENBQUMsRUFBRTtNQUN6RjZJLFdBQVcsRUFBRTtJQUNmO0lBQ0EsSUFBSXZFLENBQUMsR0FBRyxJQUFJcFgsTUFBTSxDQUFELENBQUM7SUFDbEJnRSxJQUFJLENBQUN3VyxrQkFBa0IsQ0FBQ3FCLE1BQU0sQ0FBQ0YsV0FBVyxFQUFFLENBQUMsRUFBRTtNQUFDN0ksRUFBRSxFQUFFQSxFQUFFO01BQUVwTCxNQUFNLEVBQUUwUDtJQUFDLENBQUMsQ0FBQztJQUNuRUEsQ0FBQyxDQUFDalEsSUFBSSxDQUFDLENBQUM7RUFDVixDQUFDO0VBQ0Q0VCxhQUFhLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ3pCLElBQUkvVyxJQUFJLEdBQUcsSUFBSTtJQUNmO0lBQ0EsSUFBSThYLFVBQVUsR0FBRzdiLEdBQUcsQ0FBQ0wsT0FBTyxDQUFDLGFBQWEsQ0FBQztJQUMzQyxJQUFJa2MsVUFBVSxDQUFDQyxLQUFLLENBQUMvWCxJQUFJLENBQUNzVixTQUFTLENBQUMsQ0FBQzBDLFFBQVEsS0FBSyxPQUFPLEVBQUU7TUFDekQsTUFBTWpWLEtBQUssQ0FBQywwREFBMEQsR0FDMUQscUJBQXFCLENBQUM7SUFDcEM7O0lBRUE7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBL0MsSUFBSSxDQUFDeVYsb0JBQW9CLEdBQUcsSUFBSS9WLGVBQWUsQ0FDN0NNLElBQUksQ0FBQ3NWLFNBQVMsRUFBRTtNQUFDdlUsV0FBVyxFQUFFLENBQUM7TUFBRUMsV0FBVyxFQUFFO0lBQUMsQ0FBQyxDQUFDO0lBQ25EO0lBQ0E7SUFDQTtJQUNBaEIsSUFBSSxDQUFDd1YseUJBQXlCLEdBQUcsSUFBSTlWLGVBQWUsQ0FDbERNLElBQUksQ0FBQ3NWLFNBQVMsRUFBRTtNQUFDdlUsV0FBVyxFQUFFLENBQUM7TUFBRUMsV0FBVyxFQUFFO0lBQUMsQ0FBQyxDQUFDOztJQUVuRDtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUlvUyxDQUFDLEdBQUcsSUFBSXBYLE1BQU0sQ0FBRCxDQUFDO0lBQ2xCZ0UsSUFBSSxDQUFDd1YseUJBQXlCLENBQUM3VCxFQUFFLENBQUNzVyxLQUFLLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQy9DO01BQUVDLFFBQVEsRUFBRTtJQUFFLENBQUMsRUFBRS9FLENBQUMsQ0FBQ3RQLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDaEMsSUFBSXNVLFdBQVcsR0FBR2hGLENBQUMsQ0FBQ2pRLElBQUksQ0FBQyxDQUFDO0lBRTFCLElBQUksRUFBRWlWLFdBQVcsSUFBSUEsV0FBVyxDQUFDQyxPQUFPLENBQUMsRUFBRTtNQUN6QyxNQUFNdFYsS0FBSyxDQUFDLDBEQUEwRCxHQUMxRCxxQkFBcUIsQ0FBQztJQUNwQzs7SUFFQTtJQUNBLElBQUl1VixjQUFjLEdBQUd0WSxJQUFJLENBQUN3Vix5QkFBeUIsQ0FBQzVLLE9BQU8sQ0FDekRpRSxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsRUFBRTtNQUFDUixJQUFJLEVBQUU7UUFBQ21KLFFBQVEsRUFBRSxDQUFDO01BQUMsQ0FBQztNQUFFakosVUFBVSxFQUFFO1FBQUNPLEVBQUUsRUFBRTtNQUFDO0lBQUMsQ0FBQyxDQUFDO0lBRXBFLElBQUl5SixhQUFhLEdBQUd4YixDQUFDLENBQUNVLEtBQUssQ0FBQ3VDLElBQUksQ0FBQ2lXLGtCQUFrQixDQUFDO0lBQ3BELElBQUlxQyxjQUFjLEVBQUU7TUFDbEI7TUFDQUMsYUFBYSxDQUFDekosRUFBRSxHQUFHO1FBQUM4QyxHQUFHLEVBQUUwRyxjQUFjLENBQUN4SjtNQUFFLENBQUM7TUFDM0M7TUFDQTtNQUNBO01BQ0E5TyxJQUFJLENBQUN5VyxnQkFBZ0IsR0FBRzZCLGNBQWMsQ0FBQ3hKLEVBQUU7SUFDM0M7SUFFQSxJQUFJOUMsaUJBQWlCLEdBQUcsSUFBSXpCLGlCQUFpQixDQUMzQ3NFLGdCQUFnQixFQUFFMEosYUFBYSxFQUFFO01BQUNqTSxRQUFRLEVBQUU7SUFBSSxDQUFDLENBQUM7O0lBRXBEO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBdE0sSUFBSSxDQUFDMlYsV0FBVyxHQUFHM1YsSUFBSSxDQUFDeVYsb0JBQW9CLENBQUNuRSxJQUFJLENBQy9DdEYsaUJBQWlCLEVBQ2pCLFVBQVU0RCxHQUFHLEVBQUU7TUFDYjVQLElBQUksQ0FBQzRXLFdBQVcsQ0FBQzlGLElBQUksQ0FBQ2xCLEdBQUcsQ0FBQztNQUMxQjVQLElBQUksQ0FBQ3dZLGlCQUFpQixDQUFDLENBQUM7SUFDMUIsQ0FBQyxFQUNENUQsWUFDRixDQUFDO0lBQ0Q1VSxJQUFJLENBQUM0VixZQUFZLENBQUM2QyxNQUFNLENBQUMsQ0FBQztFQUM1QixDQUFDO0VBRURELGlCQUFpQixFQUFFLFNBQUFBLENBQUEsRUFBWTtJQUM3QixJQUFJeFksSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJQSxJQUFJLENBQUM4VyxhQUFhLEVBQUU7SUFDeEI5VyxJQUFJLENBQUM4VyxhQUFhLEdBQUcsSUFBSTtJQUV6QnhXLE1BQU0sQ0FBQ3VSLEtBQUssQ0FBQyxZQUFZO01BQ3ZCO01BQ0EsU0FBUzZHLFNBQVNBLENBQUM5SSxHQUFHLEVBQUU7UUFDdEIsSUFBSUEsR0FBRyxDQUFDc0csRUFBRSxLQUFLLFlBQVksRUFBRTtVQUMzQixJQUFJdEcsR0FBRyxDQUFDdUYsQ0FBQyxDQUFDd0QsUUFBUSxFQUFFO1lBQ2xCO1lBQ0E7WUFDQSxJQUFJQyxhQUFhLEdBQUdoSixHQUFHLENBQUNkLEVBQUU7WUFDMUJjLEdBQUcsQ0FBQ3VGLENBQUMsQ0FBQ3dELFFBQVEsQ0FBQ3ZYLE9BQU8sQ0FBQzhULEVBQUUsSUFBSTtjQUMzQjtjQUNBLElBQUksQ0FBQ0EsRUFBRSxDQUFDcEcsRUFBRSxFQUFFO2dCQUNWb0csRUFBRSxDQUFDcEcsRUFBRSxHQUFHOEosYUFBYTtnQkFDckJBLGFBQWEsR0FBR0EsYUFBYSxDQUFDQyxHQUFHLENBQUN0RSxJQUFJLENBQUN1RSxHQUFHLENBQUM7Y0FDN0M7Y0FDQUosU0FBUyxDQUFDeEQsRUFBRSxDQUFDO1lBQ2YsQ0FBQyxDQUFDO1lBQ0Y7VUFDRjtVQUNBLE1BQU0sSUFBSW5TLEtBQUssQ0FBQyxrQkFBa0IsR0FBR3BFLEtBQUssQ0FBQ3NULFNBQVMsQ0FBQ3JDLEdBQUcsQ0FBQyxDQUFDO1FBQzVEO1FBRUEsTUFBTWtFLE9BQU8sR0FBRztVQUNkak4sY0FBYyxFQUFFLEtBQUs7VUFDckJHLFlBQVksRUFBRSxLQUFLO1VBQ25Ca08sRUFBRSxFQUFFdEY7UUFDTixDQUFDO1FBRUQsSUFBSSxPQUFPQSxHQUFHLENBQUNzRyxFQUFFLEtBQUssUUFBUSxJQUMxQnRHLEdBQUcsQ0FBQ3NHLEVBQUUsQ0FBQ3pOLFVBQVUsQ0FBQ3pJLElBQUksQ0FBQ3VWLE9BQU8sR0FBRyxHQUFHLENBQUMsRUFBRTtVQUN6Q3pCLE9BQU8sQ0FBQ3hRLFVBQVUsR0FBR3NNLEdBQUcsQ0FBQ3NHLEVBQUUsQ0FBQzZDLEtBQUssQ0FBQy9ZLElBQUksQ0FBQ3VWLE9BQU8sQ0FBQzVNLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDNUQ7O1FBRUE7UUFDQTtRQUNBLElBQUltTCxPQUFPLENBQUN4USxVQUFVLEtBQUssTUFBTSxFQUFFO1VBQ2pDLElBQUlzTSxHQUFHLENBQUN1RixDQUFDLENBQUNuTyxZQUFZLEVBQUU7WUFDdEIsT0FBTzhNLE9BQU8sQ0FBQ3hRLFVBQVU7WUFDekJ3USxPQUFPLENBQUM5TSxZQUFZLEdBQUcsSUFBSTtVQUM3QixDQUFDLE1BQU0sSUFBSWpLLENBQUMsQ0FBQytELEdBQUcsQ0FBQzhPLEdBQUcsQ0FBQ3VGLENBQUMsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUMvQnJCLE9BQU8sQ0FBQ3hRLFVBQVUsR0FBR3NNLEdBQUcsQ0FBQ3VGLENBQUMsQ0FBQ3JPLElBQUk7WUFDL0JnTixPQUFPLENBQUNqTixjQUFjLEdBQUcsSUFBSTtZQUM3QmlOLE9BQU8sQ0FBQ3hPLEVBQUUsR0FBRyxJQUFJO1VBQ25CLENBQUMsTUFBTSxJQUFJLFFBQVEsSUFBSXNLLEdBQUcsQ0FBQ3VGLENBQUMsSUFBSSxTQUFTLElBQUl2RixHQUFHLENBQUN1RixDQUFDLEVBQUU7WUFDbEQ7WUFDQTtVQUFBLENBQ0QsTUFBTTtZQUNMLE1BQU1wUyxLQUFLLENBQUMsa0JBQWtCLEdBQUdwRSxLQUFLLENBQUNzVCxTQUFTLENBQUNyQyxHQUFHLENBQUMsQ0FBQztVQUN4RDtRQUVGLENBQUMsTUFBTTtVQUNMO1VBQ0FrRSxPQUFPLENBQUN4TyxFQUFFLEdBQUcyUCxPQUFPLENBQUNyRixHQUFHLENBQUM7UUFDM0I7UUFFQTVQLElBQUksQ0FBQzZWLFNBQVMsQ0FBQ21ELElBQUksQ0FBQ2xGLE9BQU8sQ0FBQztNQUM5QjtNQUVBLElBQUk7UUFDRixPQUFPLENBQUU5VCxJQUFJLENBQUMwVixRQUFRLElBQ2YsQ0FBRTFWLElBQUksQ0FBQzRXLFdBQVcsQ0FBQ3FDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7VUFDbkM7VUFDQTtVQUNBLElBQUlqWixJQUFJLENBQUM0VyxXQUFXLENBQUNqTyxNQUFNLEdBQUc2TCxjQUFjLEVBQUU7WUFDNUMsSUFBSStDLFNBQVMsR0FBR3ZYLElBQUksQ0FBQzRXLFdBQVcsQ0FBQ3NDLEdBQUcsQ0FBQyxDQUFDO1lBQ3RDbFosSUFBSSxDQUFDNFcsV0FBVyxDQUFDdUMsS0FBSyxDQUFDLENBQUM7WUFFeEJuWixJQUFJLENBQUMwVyxxQkFBcUIsQ0FBQ3RaLElBQUksQ0FBQyxVQUFVa0YsUUFBUSxFQUFFO2NBQ2xEQSxRQUFRLENBQUMsQ0FBQztjQUNWLE9BQU8sSUFBSTtZQUNiLENBQUMsQ0FBQzs7WUFFRjtZQUNBO1lBQ0F0QyxJQUFJLENBQUNvWixtQkFBbUIsQ0FBQzdCLFNBQVMsQ0FBQ3pJLEVBQUUsQ0FBQztZQUN0QztVQUNGO1VBRUEsTUFBTWMsR0FBRyxHQUFHNVAsSUFBSSxDQUFDNFcsV0FBVyxDQUFDeUMsS0FBSyxDQUFDLENBQUM7O1VBRXBDO1VBQ0FYLFNBQVMsQ0FBQzlJLEdBQUcsQ0FBQzs7VUFFZDtVQUNBO1VBQ0EsSUFBSUEsR0FBRyxDQUFDZCxFQUFFLEVBQUU7WUFDVjlPLElBQUksQ0FBQ29aLG1CQUFtQixDQUFDeEosR0FBRyxDQUFDZCxFQUFFLENBQUM7VUFDbEMsQ0FBQyxNQUFNO1lBQ0wsTUFBTS9MLEtBQUssQ0FBQywwQkFBMEIsR0FBR3BFLEtBQUssQ0FBQ3NULFNBQVMsQ0FBQ3JDLEdBQUcsQ0FBQyxDQUFDO1VBQ2hFO1FBQ0Y7TUFDRixDQUFDLFNBQVM7UUFDUjVQLElBQUksQ0FBQzhXLGFBQWEsR0FBRyxLQUFLO01BQzVCO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEc0MsbUJBQW1CLEVBQUUsU0FBQUEsQ0FBVXRLLEVBQUUsRUFBRTtJQUNqQyxJQUFJOU8sSUFBSSxHQUFHLElBQUk7SUFDZkEsSUFBSSxDQUFDeVcsZ0JBQWdCLEdBQUczSCxFQUFFO0lBQzFCLE9BQU8sQ0FBQy9SLENBQUMsQ0FBQ2tjLE9BQU8sQ0FBQ2paLElBQUksQ0FBQ3dXLGtCQUFrQixDQUFDLElBQUl4VyxJQUFJLENBQUN3VyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzFILEVBQUUsQ0FBQzRJLGVBQWUsQ0FBQzFYLElBQUksQ0FBQ3lXLGdCQUFnQixDQUFDLEVBQUU7TUFDbEgsSUFBSTZDLFNBQVMsR0FBR3RaLElBQUksQ0FBQ3dXLGtCQUFrQixDQUFDNkMsS0FBSyxDQUFDLENBQUM7TUFDL0NDLFNBQVMsQ0FBQzVWLE1BQU0sQ0FBQytVLE1BQU0sQ0FBQyxDQUFDO0lBQzNCO0VBQ0YsQ0FBQztFQUVEO0VBQ0FjLG1CQUFtQixFQUFFLFNBQUFBLENBQVNsYyxLQUFLLEVBQUU7SUFDbkNtWCxjQUFjLEdBQUduWCxLQUFLO0VBQ3hCLENBQUM7RUFDRG1jLGtCQUFrQixFQUFFLFNBQUFBLENBQUEsRUFBVztJQUM3QmhGLGNBQWMsR0FBR0MsT0FBTyxDQUFDQyxHQUFHLENBQUNDLDJCQUEyQixJQUFJLElBQUk7RUFDbEU7QUFDRixDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7O0FDNVhGLElBQUk4RSx3QkFBd0I7QUFBQ2xkLE1BQU0sQ0FBQ25CLElBQUksQ0FBQyxnREFBZ0QsRUFBQztFQUFDQyxPQUFPQSxDQUFDQyxDQUFDLEVBQUM7SUFBQ21lLHdCQUF3QixHQUFDbmUsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFySSxJQUFJVSxNQUFNLEdBQUdDLEdBQUcsQ0FBQ0wsT0FBTyxDQUFDLGVBQWUsQ0FBQztBQUV6QzBXLGtCQUFrQixHQUFHLFNBQUFBLENBQVUxUyxPQUFPLEVBQUU7RUFDdEMsSUFBSUksSUFBSSxHQUFHLElBQUk7RUFFZixJQUFJLENBQUNKLE9BQU8sSUFBSSxDQUFDN0MsQ0FBQyxDQUFDK0QsR0FBRyxDQUFDbEIsT0FBTyxFQUFFLFNBQVMsQ0FBQyxFQUN4QyxNQUFNbUQsS0FBSyxDQUFDLHdCQUF3QixDQUFDO0VBRXZDUCxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUlBLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQ2tYLEtBQUssQ0FBQ0MsbUJBQW1CLENBQ3RFLGdCQUFnQixFQUFFLHNCQUFzQixFQUFFLENBQUMsQ0FBQztFQUU5QzNaLElBQUksQ0FBQzRaLFFBQVEsR0FBR2hhLE9BQU8sQ0FBQ2lPLE9BQU87RUFDL0I3TixJQUFJLENBQUM2WixPQUFPLEdBQUdqYSxPQUFPLENBQUMyUyxNQUFNLElBQUksWUFBWSxDQUFDLENBQUM7RUFDL0N2UyxJQUFJLENBQUM4WixNQUFNLEdBQUcsSUFBSXhaLE1BQU0sQ0FBQ3laLGlCQUFpQixDQUFDLENBQUM7RUFDNUMvWixJQUFJLENBQUNnYSxRQUFRLEdBQUcsQ0FBQyxDQUFDO0VBQ2xCaGEsSUFBSSxDQUFDNFYsWUFBWSxHQUFHLElBQUk1WixNQUFNLENBQUQsQ0FBQztFQUM5QmdFLElBQUksQ0FBQ2lhLE1BQU0sR0FBRyxJQUFJN1UsZUFBZSxDQUFDOFUsc0JBQXNCLENBQUM7SUFDdkRyTSxPQUFPLEVBQUVqTyxPQUFPLENBQUNpTztFQUFPLENBQUMsQ0FBQztFQUM1QjtFQUNBO0VBQ0E7RUFDQTdOLElBQUksQ0FBQ21hLHVDQUF1QyxHQUFHLENBQUM7RUFFaERwZCxDQUFDLENBQUNLLElBQUksQ0FBQzRDLElBQUksQ0FBQ29hLGFBQWEsQ0FBQyxDQUFDLEVBQUUsVUFBVUMsWUFBWSxFQUFFO0lBQ25EcmEsSUFBSSxDQUFDcWEsWUFBWSxDQUFDLEdBQUcsU0FBVTtJQUFBLEdBQVc7TUFDeENyYSxJQUFJLENBQUNzYSxjQUFjLENBQUNELFlBQVksRUFBRXRkLENBQUMsQ0FBQ3dkLE9BQU8sQ0FBQzNSLFNBQVMsQ0FBQyxDQUFDO0lBQ3pELENBQUM7RUFDSCxDQUFDLENBQUM7QUFDSixDQUFDO0FBRUQ3TCxDQUFDLENBQUNvSixNQUFNLENBQUNtTSxrQkFBa0IsQ0FBQzlVLFNBQVMsRUFBRTtFQUNyQ2lXLDJCQUEyQixFQUFFLFNBQUFBLENBQVUrRyxNQUFNLEVBQUU7SUFDN0MsSUFBSXhhLElBQUksR0FBRyxJQUFJOztJQUVmO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSSxDQUFDQSxJQUFJLENBQUM4WixNQUFNLENBQUNXLGFBQWEsQ0FBQyxDQUFDLEVBQzlCLE1BQU0sSUFBSTFYLEtBQUssQ0FBQyxzRUFBc0UsQ0FBQztJQUN6RixFQUFFL0MsSUFBSSxDQUFDbWEsdUNBQXVDO0lBRTlDM1gsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUNrWCxLQUFLLENBQUNDLG1CQUFtQixDQUN0RSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUM7SUFFekMzWixJQUFJLENBQUM4WixNQUFNLENBQUNZLE9BQU8sQ0FBQyxZQUFZO01BQzlCMWEsSUFBSSxDQUFDZ2EsUUFBUSxDQUFDUSxNQUFNLENBQUNqVixHQUFHLENBQUMsR0FBR2lWLE1BQU07TUFDbEM7TUFDQTtNQUNBeGEsSUFBSSxDQUFDMmEsU0FBUyxDQUFDSCxNQUFNLENBQUM7TUFDdEIsRUFBRXhhLElBQUksQ0FBQ21hLHVDQUF1QztJQUNoRCxDQUFDLENBQUM7SUFDRjtJQUNBbmEsSUFBSSxDQUFDNFYsWUFBWSxDQUFDelMsSUFBSSxDQUFDLENBQUM7RUFDMUIsQ0FBQztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBeVgsWUFBWSxFQUFFLFNBQUFBLENBQVV0VixFQUFFLEVBQUU7SUFDMUIsSUFBSXRGLElBQUksR0FBRyxJQUFJOztJQUVmO0lBQ0E7SUFDQTtJQUNBLElBQUksQ0FBQ0EsSUFBSSxDQUFDNmEsTUFBTSxDQUFDLENBQUMsRUFDaEIsTUFBTSxJQUFJOVgsS0FBSyxDQUFDLG1EQUFtRCxDQUFDO0lBRXRFLE9BQU8vQyxJQUFJLENBQUNnYSxRQUFRLENBQUMxVSxFQUFFLENBQUM7SUFFeEI5QyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUlBLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQ2tYLEtBQUssQ0FBQ0MsbUJBQW1CLENBQ3RFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRTFDLElBQUk1YyxDQUFDLENBQUNrYyxPQUFPLENBQUNqWixJQUFJLENBQUNnYSxRQUFRLENBQUMsSUFDeEJoYSxJQUFJLENBQUNtYSx1Q0FBdUMsS0FBSyxDQUFDLEVBQUU7TUFDdERuYSxJQUFJLENBQUM4YSxLQUFLLENBQUMsQ0FBQztJQUNkO0VBQ0YsQ0FBQztFQUNEQSxLQUFLLEVBQUUsU0FBQUEsQ0FBVWxiLE9BQU8sRUFBRTtJQUN4QixJQUFJSSxJQUFJLEdBQUcsSUFBSTtJQUNmSixPQUFPLEdBQUdBLE9BQU8sSUFBSSxDQUFDLENBQUM7O0lBRXZCO0lBQ0E7SUFDQSxJQUFJLENBQUVJLElBQUksQ0FBQzZhLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBRWpiLE9BQU8sQ0FBQ21iLGNBQWMsRUFDN0MsTUFBTWhZLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQzs7SUFFNUM7SUFDQTtJQUNBL0MsSUFBSSxDQUFDNlosT0FBTyxDQUFDLENBQUM7SUFDZHJYLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDa1gsS0FBSyxDQUFDQyxtQkFBbUIsQ0FDdEUsZ0JBQWdCLEVBQUUsc0JBQXNCLEVBQUUsQ0FBQyxDQUFDLENBQUM7O0lBRS9DO0lBQ0E7SUFDQTNaLElBQUksQ0FBQ2dhLFFBQVEsR0FBRyxJQUFJO0VBQ3RCLENBQUM7RUFFRDtFQUNBO0VBQ0FnQixLQUFLLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ2pCLElBQUloYixJQUFJLEdBQUcsSUFBSTtJQUNmQSxJQUFJLENBQUM4WixNQUFNLENBQUNtQixTQUFTLENBQUMsWUFBWTtNQUNoQyxJQUFJamIsSUFBSSxDQUFDNmEsTUFBTSxDQUFDLENBQUMsRUFDZixNQUFNOVgsS0FBSyxDQUFDLDBDQUEwQyxDQUFDO01BQ3pEL0MsSUFBSSxDQUFDNFYsWUFBWSxDQUFDNkMsTUFBTSxDQUFDLENBQUM7SUFDNUIsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBeUMsVUFBVSxFQUFFLFNBQUFBLENBQVV2VyxHQUFHLEVBQUU7SUFDekIsSUFBSTNFLElBQUksR0FBRyxJQUFJO0lBQ2ZBLElBQUksQ0FBQzhaLE1BQU0sQ0FBQ1ksT0FBTyxDQUFDLFlBQVk7TUFDOUIsSUFBSTFhLElBQUksQ0FBQzZhLE1BQU0sQ0FBQyxDQUFDLEVBQ2YsTUFBTTlYLEtBQUssQ0FBQyxpREFBaUQsQ0FBQztNQUNoRS9DLElBQUksQ0FBQzhhLEtBQUssQ0FBQztRQUFDQyxjQUFjLEVBQUU7TUFBSSxDQUFDLENBQUM7TUFDbEMvYSxJQUFJLENBQUM0VixZQUFZLENBQUN1RixLQUFLLENBQUN4VyxHQUFHLENBQUM7SUFDOUIsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEO0VBQ0E7RUFDQTtFQUNBeVcsT0FBTyxFQUFFLFNBQUFBLENBQVV4VSxFQUFFLEVBQUU7SUFDckIsSUFBSTVHLElBQUksR0FBRyxJQUFJO0lBQ2ZBLElBQUksQ0FBQzhaLE1BQU0sQ0FBQ21CLFNBQVMsQ0FBQyxZQUFZO01BQ2hDLElBQUksQ0FBQ2piLElBQUksQ0FBQzZhLE1BQU0sQ0FBQyxDQUFDLEVBQ2hCLE1BQU05WCxLQUFLLENBQUMsdURBQXVELENBQUM7TUFDdEU2RCxFQUFFLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQztFQUNKLENBQUM7RUFDRHdULGFBQWEsRUFBRSxTQUFBQSxDQUFBLEVBQVk7SUFDekIsSUFBSXBhLElBQUksR0FBRyxJQUFJO0lBQ2YsSUFBSUEsSUFBSSxDQUFDNFosUUFBUSxFQUNmLE9BQU8sQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUU1RCxPQUFPLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUM7RUFDMUMsQ0FBQztFQUNEaUIsTUFBTSxFQUFFLFNBQUFBLENBQUEsRUFBWTtJQUNsQixPQUFPLElBQUksQ0FBQ2pGLFlBQVksQ0FBQ3lGLFVBQVUsQ0FBQyxDQUFDO0VBQ3ZDLENBQUM7RUFDRGYsY0FBYyxFQUFFLFNBQUFBLENBQVVELFlBQVksRUFBRWxQLElBQUksRUFBRTtJQUM1QyxJQUFJbkwsSUFBSSxHQUFHLElBQUk7SUFDZkEsSUFBSSxDQUFDOFosTUFBTSxDQUFDbUIsU0FBUyxDQUFDLFlBQVk7TUFDaEM7TUFDQSxJQUFJLENBQUNqYixJQUFJLENBQUNnYSxRQUFRLEVBQ2hCOztNQUVGO01BQ0FoYSxJQUFJLENBQUNpYSxNQUFNLENBQUNxQixXQUFXLENBQUNqQixZQUFZLENBQUMsQ0FBQ2xRLEtBQUssQ0FBQyxJQUFJLEVBQUVnQixJQUFJLENBQUM7O01BRXZEO01BQ0E7TUFDQSxJQUFJLENBQUNuTCxJQUFJLENBQUM2YSxNQUFNLENBQUMsQ0FBQyxJQUNiUixZQUFZLEtBQUssT0FBTyxJQUFJQSxZQUFZLEtBQUssYUFBYyxFQUFFO1FBQ2hFLE1BQU0sSUFBSXRYLEtBQUssQ0FBQyxNQUFNLEdBQUdzWCxZQUFZLEdBQUcsc0JBQXNCLENBQUM7TUFDakU7O01BRUE7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBdGQsQ0FBQyxDQUFDSyxJQUFJLENBQUNMLENBQUMsQ0FBQ3lMLElBQUksQ0FBQ3hJLElBQUksQ0FBQ2dhLFFBQVEsQ0FBQyxFQUFFLFVBQVV1QixRQUFRLEVBQUU7UUFDaEQsSUFBSWYsTUFBTSxHQUFHeGEsSUFBSSxDQUFDZ2EsUUFBUSxJQUFJaGEsSUFBSSxDQUFDZ2EsUUFBUSxDQUFDdUIsUUFBUSxDQUFDO1FBQ3JELElBQUksQ0FBQ2YsTUFBTSxFQUNUO1FBQ0YsSUFBSWxZLFFBQVEsR0FBR2tZLE1BQU0sQ0FBQyxHQUFHLEdBQUdILFlBQVksQ0FBQztRQUN6QztRQUNBL1gsUUFBUSxJQUFJQSxRQUFRLENBQUM2SCxLQUFLLENBQUMsSUFBSSxFQUM3QnFRLE1BQU0sQ0FBQ3RNLG9CQUFvQixHQUFHL0MsSUFBSSxHQUFHeE0sS0FBSyxDQUFDbEIsS0FBSyxDQUFDME4sSUFBSSxDQUFDLENBQUM7TUFDM0QsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0F3UCxTQUFTLEVBQUUsU0FBQUEsQ0FBVUgsTUFBTSxFQUFFO0lBQzNCLElBQUl4YSxJQUFJLEdBQUcsSUFBSTtJQUNmLElBQUlBLElBQUksQ0FBQzhaLE1BQU0sQ0FBQ1csYUFBYSxDQUFDLENBQUMsRUFDN0IsTUFBTTFYLEtBQUssQ0FBQyxrREFBa0QsQ0FBQztJQUNqRSxJQUFJOFYsR0FBRyxHQUFHN1ksSUFBSSxDQUFDNFosUUFBUSxHQUFHWSxNQUFNLENBQUNnQixZQUFZLEdBQUdoQixNQUFNLENBQUNpQixNQUFNO0lBQzdELElBQUksQ0FBQzVDLEdBQUcsRUFDTjtJQUNGO0lBQ0E3WSxJQUFJLENBQUNpYSxNQUFNLENBQUN5QixJQUFJLENBQUN0YSxPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRXRLLEVBQUUsRUFBRTtNQUMxQyxJQUFJLENBQUN2SSxDQUFDLENBQUMrRCxHQUFHLENBQUNkLElBQUksQ0FBQ2dhLFFBQVEsRUFBRVEsTUFBTSxDQUFDalYsR0FBRyxDQUFDLEVBQ25DLE1BQU14QyxLQUFLLENBQUMsaURBQWlELENBQUM7TUFDaEUsTUFBQTdCLElBQUEsR0FBMkJzWixNQUFNLENBQUN0TSxvQkFBb0IsR0FBRzBCLEdBQUcsR0FDeERqUixLQUFLLENBQUNsQixLQUFLLENBQUNtUyxHQUFHLENBQUM7UUFEZDtVQUFFcks7UUFBZSxDQUFDLEdBQUFyRSxJQUFBO1FBQVJzTixNQUFNLEdBQUFpTCx3QkFBQSxDQUFBdlksSUFBQSxFQUFBeWEsU0FBQTtNQUV0QixJQUFJM2IsSUFBSSxDQUFDNFosUUFBUSxFQUNmZixHQUFHLENBQUN2VCxFQUFFLEVBQUVrSixNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztNQUFBLEtBRXZCcUssR0FBRyxDQUFDdlQsRUFBRSxFQUFFa0osTUFBTSxDQUFDO0lBQ25CLENBQUMsQ0FBQztFQUNKO0FBQ0YsQ0FBQyxDQUFDO0FBR0YsSUFBSW9OLG1CQUFtQixHQUFHLENBQUM7O0FBRTNCO0FBQ0FuSixhQUFhLEdBQUcsU0FBQUEsQ0FBVVAsV0FBVyxFQUFFekUsU0FBUyxFQUFnQztFQUFBLElBQTlCUyxvQkFBb0IsR0FBQXRGLFNBQUEsQ0FBQUQsTUFBQSxRQUFBQyxTQUFBLFFBQUEvSixTQUFBLEdBQUErSixTQUFBLE1BQUcsS0FBSztFQUM1RSxJQUFJNUksSUFBSSxHQUFHLElBQUk7RUFDZjtFQUNBO0VBQ0FBLElBQUksQ0FBQzZiLFlBQVksR0FBRzNKLFdBQVc7RUFDL0JuVixDQUFDLENBQUNLLElBQUksQ0FBQzhVLFdBQVcsQ0FBQ2tJLGFBQWEsQ0FBQyxDQUFDLEVBQUUsVUFBVXpjLElBQUksRUFBRTtJQUNsRCxJQUFJOFAsU0FBUyxDQUFDOVAsSUFBSSxDQUFDLEVBQUU7TUFDbkJxQyxJQUFJLENBQUMsR0FBRyxHQUFHckMsSUFBSSxDQUFDLEdBQUc4UCxTQUFTLENBQUM5UCxJQUFJLENBQUM7SUFDcEMsQ0FBQyxNQUFNLElBQUlBLElBQUksS0FBSyxhQUFhLElBQUk4UCxTQUFTLENBQUMyRyxLQUFLLEVBQUU7TUFDcEQ7TUFDQTtNQUNBO01BQ0E7TUFDQXBVLElBQUksQ0FBQ3diLFlBQVksR0FBRyxVQUFVbFcsRUFBRSxFQUFFa0osTUFBTSxFQUFFc04sTUFBTSxFQUFFO1FBQ2hEck8sU0FBUyxDQUFDMkcsS0FBSyxDQUFDOU8sRUFBRSxFQUFFa0osTUFBTSxDQUFDO01BQzdCLENBQUM7SUFDSDtFQUNGLENBQUMsQ0FBQztFQUNGeE8sSUFBSSxDQUFDMFYsUUFBUSxHQUFHLEtBQUs7RUFDckIxVixJQUFJLENBQUN1RixHQUFHLEdBQUdxVyxtQkFBbUIsRUFBRTtFQUNoQzViLElBQUksQ0FBQ2tPLG9CQUFvQixHQUFHQSxvQkFBb0I7QUFDbEQsQ0FBQztBQUNEdUUsYUFBYSxDQUFDalYsU0FBUyxDQUFDeUYsSUFBSSxHQUFHLFlBQVk7RUFDekMsSUFBSWpELElBQUksR0FBRyxJQUFJO0VBQ2YsSUFBSUEsSUFBSSxDQUFDMFYsUUFBUSxFQUNmO0VBQ0YxVixJQUFJLENBQUMwVixRQUFRLEdBQUcsSUFBSTtFQUNwQjFWLElBQUksQ0FBQzZiLFlBQVksQ0FBQ2pCLFlBQVksQ0FBQzVhLElBQUksQ0FBQ3VGLEdBQUcsQ0FBQztBQUMxQyxDQUFDLEM7Ozs7Ozs7Ozs7O0FDaFBEaEosTUFBTSxDQUFDd2YsTUFBTSxDQUFDO0VBQUN2Z0IsVUFBVSxFQUFDQSxDQUFBLEtBQUlBO0FBQVUsQ0FBQyxDQUFDO0FBQTFDLElBQUl3Z0IsS0FBSyxHQUFHL2YsR0FBRyxDQUFDTCxPQUFPLENBQUMsUUFBUSxDQUFDO0FBRTFCLE1BQU1KLFVBQVUsQ0FBQztFQUN0QnlnQixXQUFXQSxDQUFDQyxlQUFlLEVBQUU7SUFDM0IsSUFBSSxDQUFDQyxnQkFBZ0IsR0FBR0QsZUFBZTtJQUN2QztJQUNBLElBQUksQ0FBQ0UsZUFBZSxHQUFHLElBQUlDLEdBQUcsQ0FBRCxDQUFDO0VBQ2hDOztFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBckwsS0FBS0EsQ0FBQzNOLGNBQWMsRUFBRWlDLEVBQUUsRUFBRTRQLEVBQUUsRUFBRTVTLFFBQVEsRUFBRTtJQUN0QyxNQUFNdEMsSUFBSSxHQUFHLElBQUk7SUFHakJzYyxLQUFLLENBQUNqWixjQUFjLEVBQUVrWixNQUFNLENBQUM7SUFDN0JELEtBQUssQ0FBQ3BILEVBQUUsRUFBRXZVLE1BQU0sQ0FBQzs7SUFHakI7SUFDQTtJQUNBLElBQUlYLElBQUksQ0FBQ29jLGVBQWUsQ0FBQ3RiLEdBQUcsQ0FBQ29VLEVBQUUsQ0FBQyxFQUFFO01BQ2hDbFYsSUFBSSxDQUFDb2MsZUFBZSxDQUFDalksR0FBRyxDQUFDK1EsRUFBRSxDQUFDLENBQUNwRSxJQUFJLENBQUN4TyxRQUFRLENBQUM7TUFDM0M7SUFDRjtJQUVBLE1BQU1tTCxTQUFTLEdBQUcsQ0FBQ25MLFFBQVEsQ0FBQztJQUM1QnRDLElBQUksQ0FBQ29jLGVBQWUsQ0FBQ3RNLEdBQUcsQ0FBQ29GLEVBQUUsRUFBRXpILFNBQVMsQ0FBQztJQUV2Q3VPLEtBQUssQ0FBQyxZQUFZO01BQ2hCLElBQUk7UUFDRixJQUFJcE0sR0FBRyxHQUFHNVAsSUFBSSxDQUFDbWMsZ0JBQWdCLENBQUN2UixPQUFPLENBQ3JDdkgsY0FBYyxFQUFFO1VBQUNrQyxHQUFHLEVBQUVEO1FBQUUsQ0FBQyxDQUFDLElBQUksSUFBSTtRQUNwQztRQUNBO1FBQ0EsT0FBT21JLFNBQVMsQ0FBQzlFLE1BQU0sR0FBRyxDQUFDLEVBQUU7VUFDM0I7VUFDQTtVQUNBO1VBQ0E7VUFDQThFLFNBQVMsQ0FBQ3lMLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFdmEsS0FBSyxDQUFDbEIsS0FBSyxDQUFDbVMsR0FBRyxDQUFDLENBQUM7UUFDekM7TUFDRixDQUFDLENBQUMsT0FBTzFLLENBQUMsRUFBRTtRQUNWLE9BQU91SSxTQUFTLENBQUM5RSxNQUFNLEdBQUcsQ0FBQyxFQUFFO1VBQzNCOEUsU0FBUyxDQUFDeUwsR0FBRyxDQUFDLENBQUMsQ0FBQ2hVLENBQUMsQ0FBQztRQUNwQjtNQUNGLENBQUMsU0FBUztRQUNSO1FBQ0E7UUFDQWxGLElBQUksQ0FBQ29jLGVBQWUsQ0FBQ0ksTUFBTSxDQUFDdEgsRUFBRSxDQUFDO01BQ2pDO0lBQ0YsQ0FBQyxDQUFDLENBQUN1SCxHQUFHLENBQUMsQ0FBQztFQUNWO0FBQ0YsQzs7Ozs7Ozs7Ozs7QUM1REEsSUFBSUMsbUJBQW1CLEdBQUcsQ0FBQ2pJLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDaUksMEJBQTBCLElBQUksRUFBRTtBQUN2RSxJQUFJQyxtQkFBbUIsR0FBRyxDQUFDbkksT0FBTyxDQUFDQyxHQUFHLENBQUNtSSwwQkFBMEIsSUFBSSxFQUFFLEdBQUcsSUFBSTtBQUU5RXZKLG9CQUFvQixHQUFHLFNBQUFBLENBQVUxVCxPQUFPLEVBQUU7RUFDeEMsSUFBSUksSUFBSSxHQUFHLElBQUk7RUFFZkEsSUFBSSxDQUFDa00sa0JBQWtCLEdBQUd0TSxPQUFPLENBQUNvTSxpQkFBaUI7RUFDbkRoTSxJQUFJLENBQUM4YyxZQUFZLEdBQUdsZCxPQUFPLENBQUMyVCxXQUFXO0VBQ3ZDdlQsSUFBSSxDQUFDNFosUUFBUSxHQUFHaGEsT0FBTyxDQUFDaU8sT0FBTztFQUMvQjdOLElBQUksQ0FBQzZiLFlBQVksR0FBR2pjLE9BQU8sQ0FBQ3NTLFdBQVc7RUFDdkNsUyxJQUFJLENBQUMrYyxjQUFjLEdBQUcsRUFBRTtFQUN4Qi9jLElBQUksQ0FBQzBWLFFBQVEsR0FBRyxLQUFLO0VBRXJCMVYsSUFBSSxDQUFDbU0sa0JBQWtCLEdBQUduTSxJQUFJLENBQUM4YyxZQUFZLENBQUN2USx3QkFBd0IsQ0FDbEV2TSxJQUFJLENBQUNrTSxrQkFBa0IsQ0FBQzs7RUFFMUI7RUFDQTtFQUNBbE0sSUFBSSxDQUFDZ2QsUUFBUSxHQUFHLElBQUk7O0VBRXBCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0FoZCxJQUFJLENBQUNpZCw0QkFBNEIsR0FBRyxDQUFDO0VBQ3JDamQsSUFBSSxDQUFDa2QsY0FBYyxHQUFHLEVBQUUsQ0FBQyxDQUFDOztFQUUxQjtFQUNBO0VBQ0FsZCxJQUFJLENBQUNtZCxzQkFBc0IsR0FBR3BnQixDQUFDLENBQUNxZ0IsUUFBUSxDQUN0Q3BkLElBQUksQ0FBQ3FkLGlDQUFpQyxFQUN0Q3JkLElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDdE0sT0FBTyxDQUFDMGQsaUJBQWlCLElBQUlaLG1CQUFtQixDQUFDLFFBQVEsQ0FBQzs7RUFFcEY7RUFDQTFjLElBQUksQ0FBQ3VkLFVBQVUsR0FBRyxJQUFJamQsTUFBTSxDQUFDeVosaUJBQWlCLENBQUMsQ0FBQztFQUVoRCxJQUFJeUQsZUFBZSxHQUFHOUosU0FBUyxDQUM3QjFULElBQUksQ0FBQ2tNLGtCQUFrQixFQUFFLFVBQVVnTCxZQUFZLEVBQUU7SUFDL0M7SUFDQTtJQUNBO0lBQ0EsSUFBSWxULEtBQUssR0FBR0MsU0FBUyxDQUFDQyxrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDLENBQUM7SUFDOUMsSUFBSUgsS0FBSyxFQUNQaEUsSUFBSSxDQUFDa2QsY0FBYyxDQUFDcE0sSUFBSSxDQUFDOU0sS0FBSyxDQUFDSSxVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQzlDO0lBQ0E7SUFDQTtJQUNBLElBQUlwRSxJQUFJLENBQUNpZCw0QkFBNEIsS0FBSyxDQUFDLEVBQ3pDamQsSUFBSSxDQUFDbWQsc0JBQXNCLENBQUMsQ0FBQztFQUNqQyxDQUNGLENBQUM7RUFDRG5kLElBQUksQ0FBQytjLGNBQWMsQ0FBQ2pNLElBQUksQ0FBQyxZQUFZO0lBQUUwTSxlQUFlLENBQUN2YSxJQUFJLENBQUMsQ0FBQztFQUFFLENBQUMsQ0FBQzs7RUFFakU7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJckQsT0FBTyxDQUFDa1QscUJBQXFCLEVBQUU7SUFDakM5UyxJQUFJLENBQUM4UyxxQkFBcUIsR0FBR2xULE9BQU8sQ0FBQ2tULHFCQUFxQjtFQUM1RCxDQUFDLE1BQU07SUFDTCxJQUFJMkssZUFBZSxHQUNiemQsSUFBSSxDQUFDa00sa0JBQWtCLENBQUN0TSxPQUFPLENBQUM4ZCxpQkFBaUIsSUFDakQxZCxJQUFJLENBQUNrTSxrQkFBa0IsQ0FBQ3RNLE9BQU8sQ0FBQytkLGdCQUFnQjtJQUFJO0lBQ3BEZixtQkFBbUI7SUFDekIsSUFBSWdCLGNBQWMsR0FBR3RkLE1BQU0sQ0FBQ3VkLFdBQVcsQ0FDckM5Z0IsQ0FBQyxDQUFDRyxJQUFJLENBQUM4QyxJQUFJLENBQUNtZCxzQkFBc0IsRUFBRW5kLElBQUksQ0FBQyxFQUFFeWQsZUFBZSxDQUFDO0lBQzdEemQsSUFBSSxDQUFDK2MsY0FBYyxDQUFDak0sSUFBSSxDQUFDLFlBQVk7TUFDbkN4USxNQUFNLENBQUN3ZCxhQUFhLENBQUNGLGNBQWMsQ0FBQztJQUN0QyxDQUFDLENBQUM7RUFDSjs7RUFFQTtFQUNBNWQsSUFBSSxDQUFDcWQsaUNBQWlDLENBQUMsQ0FBQztFQUV4QzdhLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDa1gsS0FBSyxDQUFDQyxtQkFBbUIsQ0FDdEUsZ0JBQWdCLEVBQUUseUJBQXlCLEVBQUUsQ0FBQyxDQUFDO0FBQ25ELENBQUM7QUFFRDVjLENBQUMsQ0FBQ29KLE1BQU0sQ0FBQ21OLG9CQUFvQixDQUFDOVYsU0FBUyxFQUFFO0VBQ3ZDO0VBQ0E2ZixpQ0FBaUMsRUFBRSxTQUFBQSxDQUFBLEVBQVk7SUFDN0MsSUFBSXJkLElBQUksR0FBRyxJQUFJO0lBQ2YsSUFBSUEsSUFBSSxDQUFDaWQsNEJBQTRCLEdBQUcsQ0FBQyxFQUN2QztJQUNGLEVBQUVqZCxJQUFJLENBQUNpZCw0QkFBNEI7SUFDbkNqZCxJQUFJLENBQUN1ZCxVQUFVLENBQUN0QyxTQUFTLENBQUMsWUFBWTtNQUNwQ2piLElBQUksQ0FBQytkLFVBQVUsQ0FBQyxDQUFDO0lBQ25CLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0FDLGVBQWUsRUFBRSxTQUFBQSxDQUFBLEVBQVc7SUFDMUIsSUFBSWhlLElBQUksR0FBRyxJQUFJO0lBQ2Y7SUFDQTtJQUNBLEVBQUVBLElBQUksQ0FBQ2lkLDRCQUE0QjtJQUNuQztJQUNBamQsSUFBSSxDQUFDdWQsVUFBVSxDQUFDN0MsT0FBTyxDQUFDLFlBQVcsQ0FBQyxDQUFDLENBQUM7O0lBRXRDO0lBQ0E7SUFDQSxJQUFJMWEsSUFBSSxDQUFDaWQsNEJBQTRCLEtBQUssQ0FBQyxFQUN6QyxNQUFNLElBQUlsYSxLQUFLLENBQUMsa0NBQWtDLEdBQ2xDL0MsSUFBSSxDQUFDaWQsNEJBQTRCLENBQUM7RUFDdEQsQ0FBQztFQUNEZ0IsY0FBYyxFQUFFLFNBQUFBLENBQUEsRUFBVztJQUN6QixJQUFJamUsSUFBSSxHQUFHLElBQUk7SUFDZjtJQUNBLElBQUlBLElBQUksQ0FBQ2lkLDRCQUE0QixLQUFLLENBQUMsRUFDekMsTUFBTSxJQUFJbGEsS0FBSyxDQUFDLGtDQUFrQyxHQUNsQy9DLElBQUksQ0FBQ2lkLDRCQUE0QixDQUFDO0lBQ3BEO0lBQ0E7SUFDQWpkLElBQUksQ0FBQ3VkLFVBQVUsQ0FBQzdDLE9BQU8sQ0FBQyxZQUFZO01BQ2xDMWEsSUFBSSxDQUFDK2QsVUFBVSxDQUFDLENBQUM7SUFDbkIsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEQSxVQUFVLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ3RCLElBQUkvZCxJQUFJLEdBQUcsSUFBSTtJQUNmLEVBQUVBLElBQUksQ0FBQ2lkLDRCQUE0QjtJQUVuQyxJQUFJamQsSUFBSSxDQUFDMFYsUUFBUSxFQUNmO0lBRUYsSUFBSXdJLEtBQUssR0FBRyxLQUFLO0lBQ2pCLElBQUlDLFVBQVU7SUFDZCxJQUFJQyxVQUFVLEdBQUdwZSxJQUFJLENBQUNnZCxRQUFRO0lBQzlCLElBQUksQ0FBQ29CLFVBQVUsRUFBRTtNQUNmRixLQUFLLEdBQUcsSUFBSTtNQUNaO01BQ0FFLFVBQVUsR0FBR3BlLElBQUksQ0FBQzRaLFFBQVEsR0FBRyxFQUFFLEdBQUcsSUFBSXhVLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO0lBQzlEO0lBRUF6UCxJQUFJLENBQUM4UyxxQkFBcUIsSUFBSTlTLElBQUksQ0FBQzhTLHFCQUFxQixDQUFDLENBQUM7O0lBRTFEO0lBQ0EsSUFBSXVMLGNBQWMsR0FBR3JlLElBQUksQ0FBQ2tkLGNBQWM7SUFDeENsZCxJQUFJLENBQUNrZCxjQUFjLEdBQUcsRUFBRTs7SUFFeEI7SUFDQSxJQUFJO01BQ0ZpQixVQUFVLEdBQUduZSxJQUFJLENBQUNtTSxrQkFBa0IsQ0FBQytFLGFBQWEsQ0FBQ2xSLElBQUksQ0FBQzRaLFFBQVEsQ0FBQztJQUNuRSxDQUFDLENBQUMsT0FBTzFVLENBQUMsRUFBRTtNQUNWLElBQUlnWixLQUFLLElBQUksT0FBT2haLENBQUMsQ0FBQ29aLElBQUssS0FBSyxRQUFRLEVBQUU7UUFDeEM7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBdGUsSUFBSSxDQUFDNmIsWUFBWSxDQUFDWCxVQUFVLENBQzFCLElBQUluWSxLQUFLLENBQ1AsZ0NBQWdDLEdBQzlCd2IsSUFBSSxDQUFDdE0sU0FBUyxDQUFDalMsSUFBSSxDQUFDa00sa0JBQWtCLENBQUMsR0FBRyxJQUFJLEdBQUdoSCxDQUFDLENBQUNzWixPQUFPLENBQUMsQ0FBQztRQUNsRTtNQUNGOztNQUVBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBcFQsS0FBSyxDQUFDNU4sU0FBUyxDQUFDc1QsSUFBSSxDQUFDM0csS0FBSyxDQUFDbkssSUFBSSxDQUFDa2QsY0FBYyxFQUFFbUIsY0FBYyxDQUFDO01BQy9EL2QsTUFBTSxDQUFDNlcsTUFBTSxDQUFDLGdDQUFnQyxHQUNoQ29ILElBQUksQ0FBQ3RNLFNBQVMsQ0FBQ2pTLElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDLEVBQUVoSCxDQUFDLENBQUM7TUFDekQ7SUFDRjs7SUFFQTtJQUNBLElBQUksQ0FBQ2xGLElBQUksQ0FBQzBWLFFBQVEsRUFBRTtNQUNsQnRRLGVBQWUsQ0FBQ3FaLGlCQUFpQixDQUMvQnplLElBQUksQ0FBQzRaLFFBQVEsRUFBRXdFLFVBQVUsRUFBRUQsVUFBVSxFQUFFbmUsSUFBSSxDQUFDNmIsWUFBWSxDQUFDO0lBQzdEOztJQUVBO0lBQ0E7SUFDQTtJQUNBLElBQUlxQyxLQUFLLEVBQ1BsZSxJQUFJLENBQUM2YixZQUFZLENBQUNiLEtBQUssQ0FBQyxDQUFDOztJQUUzQjtJQUNBO0lBQ0E7SUFDQWhiLElBQUksQ0FBQ2dkLFFBQVEsR0FBR21CLFVBQVU7O0lBRTFCO0lBQ0E7SUFDQTtJQUNBO0lBQ0FuZSxJQUFJLENBQUM2YixZQUFZLENBQUNULE9BQU8sQ0FBQyxZQUFZO01BQ3BDcmUsQ0FBQyxDQUFDSyxJQUFJLENBQUNpaEIsY0FBYyxFQUFFLFVBQVVLLENBQUMsRUFBRTtRQUNsQ0EsQ0FBQyxDQUFDcmEsU0FBUyxDQUFDLENBQUM7TUFDZixDQUFDLENBQUM7SUFDSixDQUFDLENBQUM7RUFDSixDQUFDO0VBRURwQixJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ2hCLElBQUlqRCxJQUFJLEdBQUcsSUFBSTtJQUNmQSxJQUFJLENBQUMwVixRQUFRLEdBQUcsSUFBSTtJQUNwQjNZLENBQUMsQ0FBQ0ssSUFBSSxDQUFDNEMsSUFBSSxDQUFDK2MsY0FBYyxFQUFFLFVBQVU0QixDQUFDLEVBQUU7TUFBRUEsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDbEQ7SUFDQTVoQixDQUFDLENBQUNLLElBQUksQ0FBQzRDLElBQUksQ0FBQ2tkLGNBQWMsRUFBRSxVQUFVd0IsQ0FBQyxFQUFFO01BQ3ZDQSxDQUFDLENBQUNyYSxTQUFTLENBQUMsQ0FBQztJQUNmLENBQUMsQ0FBQztJQUNGN0IsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUNrWCxLQUFLLENBQUNDLG1CQUFtQixDQUN0RSxnQkFBZ0IsRUFBRSx5QkFBeUIsRUFBRSxDQUFDLENBQUMsQ0FBQztFQUNwRDtBQUNGLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7OztBQzdORixJQUFJaUYsa0JBQWtCO0FBQUNyaUIsTUFBTSxDQUFDbkIsSUFBSSxDQUFDLHNCQUFzQixFQUFDO0VBQUN3akIsa0JBQWtCQSxDQUFDdGpCLENBQUMsRUFBQztJQUFDc2pCLGtCQUFrQixHQUFDdGpCLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFFMUcsSUFBSVUsTUFBTSxHQUFHQyxHQUFHLENBQUNMLE9BQU8sQ0FBQyxlQUFlLENBQUM7QUFFekMsSUFBSWlqQixLQUFLLEdBQUc7RUFDVkMsUUFBUSxFQUFFLFVBQVU7RUFDcEJDLFFBQVEsRUFBRSxVQUFVO0VBQ3BCQyxNQUFNLEVBQUU7QUFDVixDQUFDOztBQUVEO0FBQ0E7QUFDQSxJQUFJQyxlQUFlLEdBQUcsU0FBQUEsQ0FBQSxFQUFZLENBQUMsQ0FBQztBQUNwQyxJQUFJQyx1QkFBdUIsR0FBRyxTQUFBQSxDQUFVOUwsQ0FBQyxFQUFFO0VBQ3pDLE9BQU8sWUFBWTtJQUNqQixJQUFJO01BQ0ZBLENBQUMsQ0FBQ2pKLEtBQUssQ0FBQyxJQUFJLEVBQUV2QixTQUFTLENBQUM7SUFDMUIsQ0FBQyxDQUFDLE9BQU8xRCxDQUFDLEVBQUU7TUFDVixJQUFJLEVBQUVBLENBQUMsWUFBWStaLGVBQWUsQ0FBQyxFQUNqQyxNQUFNL1osQ0FBQztJQUNYO0VBQ0YsQ0FBQztBQUNILENBQUM7QUFFRCxJQUFJaWEsU0FBUyxHQUFHLENBQUM7O0FBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQWxNLGtCQUFrQixHQUFHLFNBQUFBLENBQVVyVCxPQUFPLEVBQUU7RUFDdEMsSUFBSUksSUFBSSxHQUFHLElBQUk7RUFDZkEsSUFBSSxDQUFDb2YsVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFFOztFQUV6QnBmLElBQUksQ0FBQ3VGLEdBQUcsR0FBRzRaLFNBQVM7RUFDcEJBLFNBQVMsRUFBRTtFQUVYbmYsSUFBSSxDQUFDa00sa0JBQWtCLEdBQUd0TSxPQUFPLENBQUNvTSxpQkFBaUI7RUFDbkRoTSxJQUFJLENBQUM4YyxZQUFZLEdBQUdsZCxPQUFPLENBQUMyVCxXQUFXO0VBQ3ZDdlQsSUFBSSxDQUFDNmIsWUFBWSxHQUFHamMsT0FBTyxDQUFDc1MsV0FBVztFQUV2QyxJQUFJdFMsT0FBTyxDQUFDaU8sT0FBTyxFQUFFO0lBQ25CLE1BQU05SyxLQUFLLENBQUMsMkRBQTJELENBQUM7RUFDMUU7RUFFQSxJQUFJNFAsTUFBTSxHQUFHL1MsT0FBTyxDQUFDK1MsTUFBTTtFQUMzQjtFQUNBO0VBQ0EsSUFBSTBNLFVBQVUsR0FBRzFNLE1BQU0sSUFBSUEsTUFBTSxDQUFDMk0sYUFBYSxDQUFDLENBQUM7RUFFakQsSUFBSTFmLE9BQU8sQ0FBQ29NLGlCQUFpQixDQUFDcE0sT0FBTyxDQUFDOEssS0FBSyxFQUFFO0lBQzNDO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0lBRUEsSUFBSTZVLFdBQVcsR0FBRztNQUFFQyxLQUFLLEVBQUVwYSxlQUFlLENBQUNxSztJQUFPLENBQUM7SUFDbkR6UCxJQUFJLENBQUN5ZixNQUFNLEdBQUd6ZixJQUFJLENBQUNrTSxrQkFBa0IsQ0FBQ3RNLE9BQU8sQ0FBQzhLLEtBQUs7SUFDbkQxSyxJQUFJLENBQUMwZixXQUFXLEdBQUdMLFVBQVU7SUFDN0JyZixJQUFJLENBQUMyZixPQUFPLEdBQUdoTixNQUFNO0lBQ3JCM1MsSUFBSSxDQUFDNGYsa0JBQWtCLEdBQUcsSUFBSUMsVUFBVSxDQUFDUixVQUFVLEVBQUVFLFdBQVcsQ0FBQztJQUNqRTtJQUNBdmYsSUFBSSxDQUFDOGYsVUFBVSxHQUFHLElBQUlDLE9BQU8sQ0FBQ1YsVUFBVSxFQUFFRSxXQUFXLENBQUM7RUFDeEQsQ0FBQyxNQUFNO0lBQ0x2ZixJQUFJLENBQUN5ZixNQUFNLEdBQUcsQ0FBQztJQUNmemYsSUFBSSxDQUFDMGYsV0FBVyxHQUFHLElBQUk7SUFDdkIxZixJQUFJLENBQUMyZixPQUFPLEdBQUcsSUFBSTtJQUNuQjNmLElBQUksQ0FBQzRmLGtCQUFrQixHQUFHLElBQUk7SUFDOUI1ZixJQUFJLENBQUM4ZixVQUFVLEdBQUcsSUFBSTFhLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO0VBQzlDOztFQUVBO0VBQ0E7RUFDQTtFQUNBelAsSUFBSSxDQUFDZ2dCLG1CQUFtQixHQUFHLEtBQUs7RUFFaENoZ0IsSUFBSSxDQUFDMFYsUUFBUSxHQUFHLEtBQUs7RUFDckIxVixJQUFJLENBQUNpZ0IsWUFBWSxHQUFHLEVBQUU7RUFFdEJ6ZCxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUlBLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQ2tYLEtBQUssQ0FBQ0MsbUJBQW1CLENBQ3RFLGdCQUFnQixFQUFFLHVCQUF1QixFQUFFLENBQUMsQ0FBQztFQUUvQzNaLElBQUksQ0FBQ2tnQixvQkFBb0IsQ0FBQ3JCLEtBQUssQ0FBQ0MsUUFBUSxDQUFDO0VBRXpDOWUsSUFBSSxDQUFDbWdCLFFBQVEsR0FBR3ZnQixPQUFPLENBQUM4UyxPQUFPO0VBQy9CO0VBQ0E7RUFDQSxJQUFJbkUsVUFBVSxHQUFHdk8sSUFBSSxDQUFDa00sa0JBQWtCLENBQUN0TSxPQUFPLENBQUM0TyxNQUFNLElBQUl4TyxJQUFJLENBQUNrTSxrQkFBa0IsQ0FBQ3RNLE9BQU8sQ0FBQzJPLFVBQVUsSUFBSSxDQUFDLENBQUM7RUFDM0d2TyxJQUFJLENBQUNvZ0IsYUFBYSxHQUFHaGIsZUFBZSxDQUFDaWIsa0JBQWtCLENBQUM5UixVQUFVLENBQUM7RUFDbkU7RUFDQTtFQUNBdk8sSUFBSSxDQUFDc2dCLGlCQUFpQixHQUFHdGdCLElBQUksQ0FBQ21nQixRQUFRLENBQUNJLHFCQUFxQixDQUFDaFMsVUFBVSxDQUFDO0VBQ3hFLElBQUlvRSxNQUFNLEVBQ1IzUyxJQUFJLENBQUNzZ0IsaUJBQWlCLEdBQUczTixNQUFNLENBQUM0TixxQkFBcUIsQ0FBQ3ZnQixJQUFJLENBQUNzZ0IsaUJBQWlCLENBQUM7RUFDL0V0Z0IsSUFBSSxDQUFDd2dCLG1CQUFtQixHQUFHcGIsZUFBZSxDQUFDaWIsa0JBQWtCLENBQzNEcmdCLElBQUksQ0FBQ3NnQixpQkFBaUIsQ0FBQztFQUV6QnRnQixJQUFJLENBQUN5Z0IsWUFBWSxHQUFHLElBQUlyYixlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQztFQUM5Q3pQLElBQUksQ0FBQzBnQixrQkFBa0IsR0FBRyxJQUFJO0VBQzlCMWdCLElBQUksQ0FBQzJnQixnQkFBZ0IsR0FBRyxDQUFDO0VBRXpCM2dCLElBQUksQ0FBQzRnQix5QkFBeUIsR0FBRyxLQUFLO0VBQ3RDNWdCLElBQUksQ0FBQzZnQixnQ0FBZ0MsR0FBRyxFQUFFOztFQUUxQztFQUNBO0VBQ0E3Z0IsSUFBSSxDQUFDaWdCLFlBQVksQ0FBQ25QLElBQUksQ0FBQzlRLElBQUksQ0FBQzhjLFlBQVksQ0FBQ2xiLFlBQVksQ0FBQ3lWLGdCQUFnQixDQUNwRTZILHVCQUF1QixDQUFDLFlBQVk7SUFDbENsZixJQUFJLENBQUM4Z0IsZ0JBQWdCLENBQUMsQ0FBQztFQUN6QixDQUFDLENBQ0gsQ0FBQyxDQUFDO0VBRUZqTixjQUFjLENBQUM3VCxJQUFJLENBQUNrTSxrQkFBa0IsRUFBRSxVQUFVNEgsT0FBTyxFQUFFO0lBQ3pEOVQsSUFBSSxDQUFDaWdCLFlBQVksQ0FBQ25QLElBQUksQ0FBQzlRLElBQUksQ0FBQzhjLFlBQVksQ0FBQ2xiLFlBQVksQ0FBQ29WLFlBQVksQ0FDaEVsRCxPQUFPLEVBQUUsVUFBVW9ELFlBQVksRUFBRTtNQUMvQjVXLE1BQU0sQ0FBQytSLGdCQUFnQixDQUFDNk0sdUJBQXVCLENBQUMsWUFBWTtRQUMxRCxJQUFJaEssRUFBRSxHQUFHZ0MsWUFBWSxDQUFDaEMsRUFBRTtRQUN4QixJQUFJZ0MsWUFBWSxDQUFDclEsY0FBYyxJQUFJcVEsWUFBWSxDQUFDbFEsWUFBWSxFQUFFO1VBQzVEO1VBQ0E7VUFDQTtVQUNBaEgsSUFBSSxDQUFDOGdCLGdCQUFnQixDQUFDLENBQUM7UUFDekIsQ0FBQyxNQUFNO1VBQ0w7VUFDQSxJQUFJOWdCLElBQUksQ0FBQytnQixNQUFNLEtBQUtsQyxLQUFLLENBQUNDLFFBQVEsRUFBRTtZQUNsQzllLElBQUksQ0FBQ2doQix5QkFBeUIsQ0FBQzlMLEVBQUUsQ0FBQztVQUNwQyxDQUFDLE1BQU07WUFDTGxWLElBQUksQ0FBQ2loQixpQ0FBaUMsQ0FBQy9MLEVBQUUsQ0FBQztVQUM1QztRQUNGO01BQ0YsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUNGLENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQzs7RUFFRjtFQUNBbFYsSUFBSSxDQUFDaWdCLFlBQVksQ0FBQ25QLElBQUksQ0FBQzRDLFNBQVMsQ0FDOUIxVCxJQUFJLENBQUNrTSxrQkFBa0IsRUFBRSxVQUFVZ0wsWUFBWSxFQUFFO0lBQy9DO0lBQ0EsSUFBSWxULEtBQUssR0FBR0MsU0FBUyxDQUFDQyxrQkFBa0IsQ0FBQ0MsR0FBRyxDQUFDLENBQUM7SUFDOUMsSUFBSSxDQUFDSCxLQUFLLElBQUlBLEtBQUssQ0FBQ2tkLEtBQUssRUFDdkI7SUFFRixJQUFJbGQsS0FBSyxDQUFDbWQsb0JBQW9CLEVBQUU7TUFDOUJuZCxLQUFLLENBQUNtZCxvQkFBb0IsQ0FBQ25oQixJQUFJLENBQUN1RixHQUFHLENBQUMsR0FBR3ZGLElBQUk7TUFDM0M7SUFDRjtJQUVBZ0UsS0FBSyxDQUFDbWQsb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO0lBQy9CbmQsS0FBSyxDQUFDbWQsb0JBQW9CLENBQUNuaEIsSUFBSSxDQUFDdUYsR0FBRyxDQUFDLEdBQUd2RixJQUFJO0lBRTNDZ0UsS0FBSyxDQUFDb2QsWUFBWSxDQUFDLFlBQVk7TUFDN0IsSUFBSUMsT0FBTyxHQUFHcmQsS0FBSyxDQUFDbWQsb0JBQW9CO01BQ3hDLE9BQU9uZCxLQUFLLENBQUNtZCxvQkFBb0I7O01BRWpDO01BQ0E7TUFDQW5oQixJQUFJLENBQUM4YyxZQUFZLENBQUNsYixZQUFZLENBQUMwVixpQkFBaUIsQ0FBQyxDQUFDO01BRWxEdmEsQ0FBQyxDQUFDSyxJQUFJLENBQUNpa0IsT0FBTyxFQUFFLFVBQVVDLE1BQU0sRUFBRTtRQUNoQyxJQUFJQSxNQUFNLENBQUM1TCxRQUFRLEVBQ2pCO1FBRUYsSUFBSWpSLEtBQUssR0FBR1QsS0FBSyxDQUFDSSxVQUFVLENBQUMsQ0FBQztRQUM5QixJQUFJa2QsTUFBTSxDQUFDUCxNQUFNLEtBQUtsQyxLQUFLLENBQUNHLE1BQU0sRUFBRTtVQUNsQztVQUNBO1VBQ0E7VUFDQXNDLE1BQU0sQ0FBQ3pGLFlBQVksQ0FBQ1QsT0FBTyxDQUFDLFlBQVk7WUFDdEMzVyxLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO1VBQ25CLENBQUMsQ0FBQztRQUNKLENBQUMsTUFBTTtVQUNMaWQsTUFBTSxDQUFDVCxnQ0FBZ0MsQ0FBQy9QLElBQUksQ0FBQ3JNLEtBQUssQ0FBQztRQUNyRDtNQUNGLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztFQUNKLENBQ0YsQ0FBQyxDQUFDOztFQUVGO0VBQ0E7RUFDQXpFLElBQUksQ0FBQ2lnQixZQUFZLENBQUNuUCxJQUFJLENBQUM5USxJQUFJLENBQUM4YyxZQUFZLENBQUN4WSxXQUFXLENBQUM0YSx1QkFBdUIsQ0FDMUUsWUFBWTtJQUNWbGYsSUFBSSxDQUFDOGdCLGdCQUFnQixDQUFDLENBQUM7RUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7RUFFTjtFQUNBO0VBQ0F4Z0IsTUFBTSxDQUFDdVIsS0FBSyxDQUFDcU4sdUJBQXVCLENBQUMsWUFBWTtJQUMvQ2xmLElBQUksQ0FBQ3VoQixnQkFBZ0IsQ0FBQyxDQUFDO0VBQ3pCLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEeGtCLENBQUMsQ0FBQ29KLE1BQU0sQ0FBQzhNLGtCQUFrQixDQUFDelYsU0FBUyxFQUFFO0VBQ3JDZ2tCLGFBQWEsRUFBRSxTQUFBQSxDQUFVbGMsRUFBRSxFQUFFc0ssR0FBRyxFQUFFO0lBQ2hDLElBQUk1UCxJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDLElBQUk3RCxNQUFNLEdBQUd6UixDQUFDLENBQUNVLEtBQUssQ0FBQ21TLEdBQUcsQ0FBQztNQUN6QixPQUFPcEIsTUFBTSxDQUFDakosR0FBRztNQUNqQnZGLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ2hRLEdBQUcsQ0FBQ3hLLEVBQUUsRUFBRXRGLElBQUksQ0FBQ3dnQixtQkFBbUIsQ0FBQzVRLEdBQUcsQ0FBQyxDQUFDO01BQ3RENVAsSUFBSSxDQUFDNmIsWUFBWSxDQUFDekgsS0FBSyxDQUFDOU8sRUFBRSxFQUFFdEYsSUFBSSxDQUFDb2dCLGFBQWEsQ0FBQzVSLE1BQU0sQ0FBQyxDQUFDOztNQUV2RDtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUl4TyxJQUFJLENBQUN5ZixNQUFNLElBQUl6ZixJQUFJLENBQUM4ZixVQUFVLENBQUNwaEIsSUFBSSxDQUFDLENBQUMsR0FBR3NCLElBQUksQ0FBQ3lmLE1BQU0sRUFBRTtRQUN2RDtRQUNBLElBQUl6ZixJQUFJLENBQUM4ZixVQUFVLENBQUNwaEIsSUFBSSxDQUFDLENBQUMsS0FBS3NCLElBQUksQ0FBQ3lmLE1BQU0sR0FBRyxDQUFDLEVBQUU7VUFDOUMsTUFBTSxJQUFJMWMsS0FBSyxDQUFDLDZCQUE2QixJQUM1Qi9DLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ3BoQixJQUFJLENBQUMsQ0FBQyxHQUFHc0IsSUFBSSxDQUFDeWYsTUFBTSxDQUFDLEdBQ3RDLG9DQUFvQyxDQUFDO1FBQ3ZEO1FBRUEsSUFBSWdDLGdCQUFnQixHQUFHemhCLElBQUksQ0FBQzhmLFVBQVUsQ0FBQzRCLFlBQVksQ0FBQyxDQUFDO1FBQ3JELElBQUlDLGNBQWMsR0FBRzNoQixJQUFJLENBQUM4ZixVQUFVLENBQUMzYixHQUFHLENBQUNzZCxnQkFBZ0IsQ0FBQztRQUUxRCxJQUFJOWlCLEtBQUssQ0FBQ2lqQixNQUFNLENBQUNILGdCQUFnQixFQUFFbmMsRUFBRSxDQUFDLEVBQUU7VUFDdEMsTUFBTSxJQUFJdkMsS0FBSyxDQUFDLDBEQUEwRCxDQUFDO1FBQzdFO1FBRUEvQyxJQUFJLENBQUM4ZixVQUFVLENBQUMrQixNQUFNLENBQUNKLGdCQUFnQixDQUFDO1FBQ3hDemhCLElBQUksQ0FBQzZiLFlBQVksQ0FBQ2lHLE9BQU8sQ0FBQ0wsZ0JBQWdCLENBQUM7UUFDM0N6aEIsSUFBSSxDQUFDK2hCLFlBQVksQ0FBQ04sZ0JBQWdCLEVBQUVFLGNBQWMsQ0FBQztNQUNyRDtJQUNGLENBQUMsQ0FBQztFQUNKLENBQUM7RUFDREssZ0JBQWdCLEVBQUUsU0FBQUEsQ0FBVTFjLEVBQUUsRUFBRTtJQUM5QixJQUFJdEYsSUFBSSxHQUFHLElBQUk7SUFDZk0sTUFBTSxDQUFDK1IsZ0JBQWdCLENBQUMsWUFBWTtNQUNsQ3JTLElBQUksQ0FBQzhmLFVBQVUsQ0FBQytCLE1BQU0sQ0FBQ3ZjLEVBQUUsQ0FBQztNQUMxQnRGLElBQUksQ0FBQzZiLFlBQVksQ0FBQ2lHLE9BQU8sQ0FBQ3hjLEVBQUUsQ0FBQztNQUM3QixJQUFJLENBQUV0RixJQUFJLENBQUN5ZixNQUFNLElBQUl6ZixJQUFJLENBQUM4ZixVQUFVLENBQUNwaEIsSUFBSSxDQUFDLENBQUMsS0FBS3NCLElBQUksQ0FBQ3lmLE1BQU0sRUFDekQ7TUFFRixJQUFJemYsSUFBSSxDQUFDOGYsVUFBVSxDQUFDcGhCLElBQUksQ0FBQyxDQUFDLEdBQUdzQixJQUFJLENBQUN5ZixNQUFNLEVBQ3RDLE1BQU0xYyxLQUFLLENBQUMsNkJBQTZCLENBQUM7O01BRTVDO01BQ0E7O01BRUEsSUFBSSxDQUFDL0MsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUNxQyxLQUFLLENBQUMsQ0FBQyxFQUFFO1FBQ3BDO1FBQ0E7UUFDQSxJQUFJQyxRQUFRLEdBQUdsaUIsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUN1QyxZQUFZLENBQUMsQ0FBQztRQUNyRCxJQUFJcGEsTUFBTSxHQUFHL0gsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUN6YixHQUFHLENBQUMrZCxRQUFRLENBQUM7UUFDbERsaUIsSUFBSSxDQUFDb2lCLGVBQWUsQ0FBQ0YsUUFBUSxDQUFDO1FBQzlCbGlCLElBQUksQ0FBQ3doQixhQUFhLENBQUNVLFFBQVEsRUFBRW5hLE1BQU0sQ0FBQztRQUNwQztNQUNGOztNQUVBOztNQUVBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJL0gsSUFBSSxDQUFDK2dCLE1BQU0sS0FBS2xDLEtBQUssQ0FBQ0MsUUFBUSxFQUNoQzs7TUFFRjtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUk5ZSxJQUFJLENBQUNnZ0IsbUJBQW1CLEVBQzFCOztNQUVGO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTs7TUFFQSxNQUFNLElBQUlqZCxLQUFLLENBQUMsMkJBQTJCLENBQUM7SUFDOUMsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNEc2YsZ0JBQWdCLEVBQUUsU0FBQUEsQ0FBVS9jLEVBQUUsRUFBRWdkLE1BQU0sRUFBRXZhLE1BQU0sRUFBRTtJQUM5QyxJQUFJL0gsSUFBSSxHQUFHLElBQUk7SUFDZk0sTUFBTSxDQUFDK1IsZ0JBQWdCLENBQUMsWUFBWTtNQUNsQ3JTLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ2hRLEdBQUcsQ0FBQ3hLLEVBQUUsRUFBRXRGLElBQUksQ0FBQ3dnQixtQkFBbUIsQ0FBQ3pZLE1BQU0sQ0FBQyxDQUFDO01BQ3pELElBQUl3YSxZQUFZLEdBQUd2aUIsSUFBSSxDQUFDb2dCLGFBQWEsQ0FBQ3JZLE1BQU0sQ0FBQztNQUM3QyxJQUFJeWEsWUFBWSxHQUFHeGlCLElBQUksQ0FBQ29nQixhQUFhLENBQUNrQyxNQUFNLENBQUM7TUFDN0MsSUFBSUcsT0FBTyxHQUFHQyxZQUFZLENBQUNDLGlCQUFpQixDQUMxQ0osWUFBWSxFQUFFQyxZQUFZLENBQUM7TUFDN0IsSUFBSSxDQUFDemxCLENBQUMsQ0FBQ2tjLE9BQU8sQ0FBQ3dKLE9BQU8sQ0FBQyxFQUNyQnppQixJQUFJLENBQUM2YixZQUFZLENBQUM0RyxPQUFPLENBQUNuZCxFQUFFLEVBQUVtZCxPQUFPLENBQUM7SUFDMUMsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNEVixZQUFZLEVBQUUsU0FBQUEsQ0FBVXpjLEVBQUUsRUFBRXNLLEdBQUcsRUFBRTtJQUMvQixJQUFJNVAsSUFBSSxHQUFHLElBQUk7SUFDZk0sTUFBTSxDQUFDK1IsZ0JBQWdCLENBQUMsWUFBWTtNQUNsQ3JTLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDOVAsR0FBRyxDQUFDeEssRUFBRSxFQUFFdEYsSUFBSSxDQUFDd2dCLG1CQUFtQixDQUFDNVEsR0FBRyxDQUFDLENBQUM7O01BRTlEO01BQ0EsSUFBSTVQLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDbGhCLElBQUksQ0FBQyxDQUFDLEdBQUdzQixJQUFJLENBQUN5ZixNQUFNLEVBQUU7UUFDaEQsSUFBSW1ELGFBQWEsR0FBRzVpQixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzhCLFlBQVksQ0FBQyxDQUFDO1FBRTFEMWhCLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDaUMsTUFBTSxDQUFDZSxhQUFhLENBQUM7O1FBRTdDO1FBQ0E7UUFDQTVpQixJQUFJLENBQUNnZ0IsbUJBQW1CLEdBQUcsS0FBSztNQUNsQztJQUNGLENBQUMsQ0FBQztFQUNKLENBQUM7RUFDRDtFQUNBO0VBQ0FvQyxlQUFlLEVBQUUsU0FBQUEsQ0FBVTljLEVBQUUsRUFBRTtJQUM3QixJQUFJdEYsSUFBSSxHQUFHLElBQUk7SUFDZk0sTUFBTSxDQUFDK1IsZ0JBQWdCLENBQUMsWUFBWTtNQUNsQ3JTLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDaUMsTUFBTSxDQUFDdmMsRUFBRSxDQUFDO01BQ2xDO01BQ0E7TUFDQTtNQUNBLElBQUksQ0FBRXRGLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDbGhCLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBRXNCLElBQUksQ0FBQ2dnQixtQkFBbUIsRUFDaEVoZ0IsSUFBSSxDQUFDOGdCLGdCQUFnQixDQUFDLENBQUM7SUFDM0IsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNEO0VBQ0E7RUFDQTtFQUNBK0IsWUFBWSxFQUFFLFNBQUFBLENBQVVqVCxHQUFHLEVBQUU7SUFDM0IsSUFBSTVQLElBQUksR0FBRyxJQUFJO0lBQ2ZNLE1BQU0sQ0FBQytSLGdCQUFnQixDQUFDLFlBQVk7TUFDbEMsSUFBSS9NLEVBQUUsR0FBR3NLLEdBQUcsQ0FBQ3JLLEdBQUc7TUFDaEIsSUFBSXZGLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ2hmLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQyxFQUN6QixNQUFNdkMsS0FBSyxDQUFDLDJDQUEyQyxHQUFHdUMsRUFBRSxDQUFDO01BQy9ELElBQUl0RixJQUFJLENBQUN5ZixNQUFNLElBQUl6ZixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzllLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQyxFQUNoRCxNQUFNdkMsS0FBSyxDQUFDLG1EQUFtRCxHQUFHdUMsRUFBRSxDQUFDO01BRXZFLElBQUlvRixLQUFLLEdBQUcxSyxJQUFJLENBQUN5ZixNQUFNO01BQ3ZCLElBQUlKLFVBQVUsR0FBR3JmLElBQUksQ0FBQzBmLFdBQVc7TUFDakMsSUFBSW9ELFlBQVksR0FBSXBZLEtBQUssSUFBSTFLLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ3BoQixJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FDckRzQixJQUFJLENBQUM4ZixVQUFVLENBQUMzYixHQUFHLENBQUNuRSxJQUFJLENBQUM4ZixVQUFVLENBQUM0QixZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSTtNQUM1RCxJQUFJcUIsV0FBVyxHQUFJclksS0FBSyxJQUFJMUssSUFBSSxDQUFDNGYsa0JBQWtCLENBQUNsaEIsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQzFEc0IsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUN6YixHQUFHLENBQUNuRSxJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzhCLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FDbkUsSUFBSTtNQUNSO01BQ0E7TUFDQTtNQUNBLElBQUlzQixTQUFTLEdBQUcsQ0FBRXRZLEtBQUssSUFBSTFLLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ3BoQixJQUFJLENBQUMsQ0FBQyxHQUFHZ00sS0FBSyxJQUN2RDJVLFVBQVUsQ0FBQ3pQLEdBQUcsRUFBRWtULFlBQVksQ0FBQyxHQUFHLENBQUM7O01BRW5DO01BQ0E7TUFDQTtNQUNBLElBQUlHLGlCQUFpQixHQUFHLENBQUNELFNBQVMsSUFBSWhqQixJQUFJLENBQUNnZ0IsbUJBQW1CLElBQzVEaGdCLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDbGhCLElBQUksQ0FBQyxDQUFDLEdBQUdnTSxLQUFLOztNQUV4QztNQUNBO01BQ0EsSUFBSXdZLG1CQUFtQixHQUFHLENBQUNGLFNBQVMsSUFBSUQsV0FBVyxJQUNqRDFELFVBQVUsQ0FBQ3pQLEdBQUcsRUFBRW1ULFdBQVcsQ0FBQyxJQUFJLENBQUM7TUFFbkMsSUFBSUksUUFBUSxHQUFHRixpQkFBaUIsSUFBSUMsbUJBQW1CO01BRXZELElBQUlGLFNBQVMsRUFBRTtRQUNiaGpCLElBQUksQ0FBQ3doQixhQUFhLENBQUNsYyxFQUFFLEVBQUVzSyxHQUFHLENBQUM7TUFDN0IsQ0FBQyxNQUFNLElBQUl1VCxRQUFRLEVBQUU7UUFDbkJuakIsSUFBSSxDQUFDK2hCLFlBQVksQ0FBQ3pjLEVBQUUsRUFBRXNLLEdBQUcsQ0FBQztNQUM1QixDQUFDLE1BQU07UUFDTDtRQUNBNVAsSUFBSSxDQUFDZ2dCLG1CQUFtQixHQUFHLEtBQUs7TUFDbEM7SUFDRixDQUFDLENBQUM7RUFDSixDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0FvRCxlQUFlLEVBQUUsU0FBQUEsQ0FBVTlkLEVBQUUsRUFBRTtJQUM3QixJQUFJdEYsSUFBSSxHQUFHLElBQUk7SUFDZk0sTUFBTSxDQUFDK1IsZ0JBQWdCLENBQUMsWUFBWTtNQUNsQyxJQUFJLENBQUVyUyxJQUFJLENBQUM4ZixVQUFVLENBQUNoZixHQUFHLENBQUN3RSxFQUFFLENBQUMsSUFBSSxDQUFFdEYsSUFBSSxDQUFDeWYsTUFBTSxFQUM1QyxNQUFNMWMsS0FBSyxDQUFDLG9EQUFvRCxHQUFHdUMsRUFBRSxDQUFDO01BRXhFLElBQUl0RixJQUFJLENBQUM4ZixVQUFVLENBQUNoZixHQUFHLENBQUN3RSxFQUFFLENBQUMsRUFBRTtRQUMzQnRGLElBQUksQ0FBQ2dpQixnQkFBZ0IsQ0FBQzFjLEVBQUUsQ0FBQztNQUMzQixDQUFDLE1BQU0sSUFBSXRGLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDOWUsR0FBRyxDQUFDd0UsRUFBRSxDQUFDLEVBQUU7UUFDMUN0RixJQUFJLENBQUNvaUIsZUFBZSxDQUFDOWMsRUFBRSxDQUFDO01BQzFCO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNEK2QsVUFBVSxFQUFFLFNBQUFBLENBQVUvZCxFQUFFLEVBQUV5QyxNQUFNLEVBQUU7SUFDaEMsSUFBSS9ILElBQUksR0FBRyxJQUFJO0lBQ2ZNLE1BQU0sQ0FBQytSLGdCQUFnQixDQUFDLFlBQVk7TUFDbEMsSUFBSWlSLFVBQVUsR0FBR3ZiLE1BQU0sSUFBSS9ILElBQUksQ0FBQ21nQixRQUFRLENBQUNvRCxlQUFlLENBQUN4YixNQUFNLENBQUMsQ0FBQ25ELE1BQU07TUFFdkUsSUFBSTRlLGVBQWUsR0FBR3hqQixJQUFJLENBQUM4ZixVQUFVLENBQUNoZixHQUFHLENBQUN3RSxFQUFFLENBQUM7TUFDN0MsSUFBSW1lLGNBQWMsR0FBR3pqQixJQUFJLENBQUN5ZixNQUFNLElBQUl6ZixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzllLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQztNQUNuRSxJQUFJb2UsWUFBWSxHQUFHRixlQUFlLElBQUlDLGNBQWM7TUFFcEQsSUFBSUgsVUFBVSxJQUFJLENBQUNJLFlBQVksRUFBRTtRQUMvQjFqQixJQUFJLENBQUM2aUIsWUFBWSxDQUFDOWEsTUFBTSxDQUFDO01BQzNCLENBQUMsTUFBTSxJQUFJMmIsWUFBWSxJQUFJLENBQUNKLFVBQVUsRUFBRTtRQUN0Q3RqQixJQUFJLENBQUNvakIsZUFBZSxDQUFDOWQsRUFBRSxDQUFDO01BQzFCLENBQUMsTUFBTSxJQUFJb2UsWUFBWSxJQUFJSixVQUFVLEVBQUU7UUFDckMsSUFBSWhCLE1BQU0sR0FBR3RpQixJQUFJLENBQUM4ZixVQUFVLENBQUMzYixHQUFHLENBQUNtQixFQUFFLENBQUM7UUFDcEMsSUFBSStaLFVBQVUsR0FBR3JmLElBQUksQ0FBQzBmLFdBQVc7UUFDakMsSUFBSWlFLFdBQVcsR0FBRzNqQixJQUFJLENBQUN5ZixNQUFNLElBQUl6ZixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQ2xoQixJQUFJLENBQUMsQ0FBQyxJQUM3RHNCLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDemIsR0FBRyxDQUFDbkUsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUN1QyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQ3JFLElBQUlZLFdBQVc7UUFFZixJQUFJUyxlQUFlLEVBQUU7VUFDbkI7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsSUFBSUksZ0JBQWdCLEdBQUcsQ0FBRTVqQixJQUFJLENBQUN5ZixNQUFNLElBQ2xDemYsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUNsaEIsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQ3BDMmdCLFVBQVUsQ0FBQ3RYLE1BQU0sRUFBRTRiLFdBQVcsQ0FBQyxJQUFJLENBQUM7VUFFdEMsSUFBSUMsZ0JBQWdCLEVBQUU7WUFDcEI1akIsSUFBSSxDQUFDcWlCLGdCQUFnQixDQUFDL2MsRUFBRSxFQUFFZ2QsTUFBTSxFQUFFdmEsTUFBTSxDQUFDO1VBQzNDLENBQUMsTUFBTTtZQUNMO1lBQ0EvSCxJQUFJLENBQUNnaUIsZ0JBQWdCLENBQUMxYyxFQUFFLENBQUM7WUFDekI7WUFDQXlkLFdBQVcsR0FBRy9pQixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQ3piLEdBQUcsQ0FDdkNuRSxJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzhCLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFFekMsSUFBSXlCLFFBQVEsR0FBR25qQixJQUFJLENBQUNnZ0IsbUJBQW1CLElBQ2hDK0MsV0FBVyxJQUFJMUQsVUFBVSxDQUFDdFgsTUFBTSxFQUFFZ2IsV0FBVyxDQUFDLElBQUksQ0FBRTtZQUUzRCxJQUFJSSxRQUFRLEVBQUU7Y0FDWm5qQixJQUFJLENBQUMraEIsWUFBWSxDQUFDemMsRUFBRSxFQUFFeUMsTUFBTSxDQUFDO1lBQy9CLENBQUMsTUFBTTtjQUNMO2NBQ0EvSCxJQUFJLENBQUNnZ0IsbUJBQW1CLEdBQUcsS0FBSztZQUNsQztVQUNGO1FBQ0YsQ0FBQyxNQUFNLElBQUl5RCxjQUFjLEVBQUU7VUFDekJuQixNQUFNLEdBQUd0aUIsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUN6YixHQUFHLENBQUNtQixFQUFFLENBQUM7VUFDeEM7VUFDQTtVQUNBO1VBQ0E7VUFDQXRGLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDaUMsTUFBTSxDQUFDdmMsRUFBRSxDQUFDO1VBRWxDLElBQUl3ZCxZQUFZLEdBQUc5aUIsSUFBSSxDQUFDOGYsVUFBVSxDQUFDM2IsR0FBRyxDQUNwQ25FLElBQUksQ0FBQzhmLFVBQVUsQ0FBQzRCLFlBQVksQ0FBQyxDQUFDLENBQUM7VUFDakNxQixXQUFXLEdBQUcvaUIsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUNsaEIsSUFBSSxDQUFDLENBQUMsSUFDdENzQixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQ3piLEdBQUcsQ0FDekJuRSxJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzhCLFlBQVksQ0FBQyxDQUFDLENBQUM7O1VBRS9DO1VBQ0EsSUFBSXNCLFNBQVMsR0FBRzNELFVBQVUsQ0FBQ3RYLE1BQU0sRUFBRSthLFlBQVksQ0FBQyxHQUFHLENBQUM7O1VBRXBEO1VBQ0EsSUFBSWUsYUFBYSxHQUFJLENBQUViLFNBQVMsSUFBSWhqQixJQUFJLENBQUNnZ0IsbUJBQW1CLElBQ3JELENBQUNnRCxTQUFTLElBQUlELFdBQVcsSUFDekIxRCxVQUFVLENBQUN0WCxNQUFNLEVBQUVnYixXQUFXLENBQUMsSUFBSSxDQUFFO1VBRTVDLElBQUlDLFNBQVMsRUFBRTtZQUNiaGpCLElBQUksQ0FBQ3doQixhQUFhLENBQUNsYyxFQUFFLEVBQUV5QyxNQUFNLENBQUM7VUFDaEMsQ0FBQyxNQUFNLElBQUk4YixhQUFhLEVBQUU7WUFDeEI7WUFDQTdqQixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzlQLEdBQUcsQ0FBQ3hLLEVBQUUsRUFBRXlDLE1BQU0sQ0FBQztVQUN6QyxDQUFDLE1BQU07WUFDTDtZQUNBL0gsSUFBSSxDQUFDZ2dCLG1CQUFtQixHQUFHLEtBQUs7WUFDaEM7WUFDQTtZQUNBLElBQUksQ0FBRWhnQixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQ2xoQixJQUFJLENBQUMsQ0FBQyxFQUFFO2NBQ3BDc0IsSUFBSSxDQUFDOGdCLGdCQUFnQixDQUFDLENBQUM7WUFDekI7VUFDRjtRQUNGLENBQUMsTUFBTTtVQUNMLE1BQU0sSUFBSS9kLEtBQUssQ0FBQywyRUFBMkUsQ0FBQztRQUM5RjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUNEK2dCLHVCQUF1QixFQUFFLFNBQUFBLENBQUEsRUFBWTtJQUNuQyxJQUFJOWpCLElBQUksR0FBRyxJQUFJO0lBQ2ZNLE1BQU0sQ0FBQytSLGdCQUFnQixDQUFDLFlBQVk7TUFDbENyUyxJQUFJLENBQUNrZ0Isb0JBQW9CLENBQUNyQixLQUFLLENBQUNFLFFBQVEsQ0FBQztNQUN6QztNQUNBO01BQ0F6ZSxNQUFNLENBQUN1UixLQUFLLENBQUNxTix1QkFBdUIsQ0FBQyxZQUFZO1FBQy9DLE9BQU8sQ0FBQ2xmLElBQUksQ0FBQzBWLFFBQVEsSUFBSSxDQUFDMVYsSUFBSSxDQUFDeWdCLFlBQVksQ0FBQ3dCLEtBQUssQ0FBQyxDQUFDLEVBQUU7VUFDbkQsSUFBSWppQixJQUFJLENBQUMrZ0IsTUFBTSxLQUFLbEMsS0FBSyxDQUFDQyxRQUFRLEVBQUU7WUFDbEM7WUFDQTtZQUNBO1lBQ0E7VUFDRjs7VUFFQTtVQUNBLElBQUk5ZSxJQUFJLENBQUMrZ0IsTUFBTSxLQUFLbEMsS0FBSyxDQUFDRSxRQUFRLEVBQ2hDLE1BQU0sSUFBSWhjLEtBQUssQ0FBQyxtQ0FBbUMsR0FBRy9DLElBQUksQ0FBQytnQixNQUFNLENBQUM7VUFFcEUvZ0IsSUFBSSxDQUFDMGdCLGtCQUFrQixHQUFHMWdCLElBQUksQ0FBQ3lnQixZQUFZO1VBQzNDLElBQUlzRCxjQUFjLEdBQUcsRUFBRS9qQixJQUFJLENBQUMyZ0IsZ0JBQWdCO1VBQzVDM2dCLElBQUksQ0FBQ3lnQixZQUFZLEdBQUcsSUFBSXJiLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO1VBQzlDLElBQUl1VSxPQUFPLEdBQUcsQ0FBQztVQUNmLElBQUlDLEdBQUcsR0FBRyxJQUFJam9CLE1BQU0sQ0FBRCxDQUFDO1VBQ3BCO1VBQ0E7VUFDQWdFLElBQUksQ0FBQzBnQixrQkFBa0IsQ0FBQ3RmLE9BQU8sQ0FBQyxVQUFVOFQsRUFBRSxFQUFFNVAsRUFBRSxFQUFFO1lBQ2hEMGUsT0FBTyxFQUFFO1lBQ1Roa0IsSUFBSSxDQUFDOGMsWUFBWSxDQUFDamIsV0FBVyxDQUFDbVAsS0FBSyxDQUNqQ2hSLElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDN0ksY0FBYyxFQUFFaUMsRUFBRSxFQUFFNFAsRUFBRSxFQUM5Q2dLLHVCQUF1QixDQUFDLFVBQVV2YSxHQUFHLEVBQUVpTCxHQUFHLEVBQUU7Y0FDMUMsSUFBSTtnQkFDRixJQUFJakwsR0FBRyxFQUFFO2tCQUNQckUsTUFBTSxDQUFDNlcsTUFBTSxDQUFDLHdDQUF3QyxFQUN4Q3hTLEdBQUcsQ0FBQztrQkFDbEI7a0JBQ0E7a0JBQ0E7a0JBQ0E7a0JBQ0EsSUFBSTNFLElBQUksQ0FBQytnQixNQUFNLEtBQUtsQyxLQUFLLENBQUNDLFFBQVEsRUFBRTtvQkFDbEM5ZSxJQUFJLENBQUM4Z0IsZ0JBQWdCLENBQUMsQ0FBQztrQkFDekI7Z0JBQ0YsQ0FBQyxNQUFNLElBQUksQ0FBQzlnQixJQUFJLENBQUMwVixRQUFRLElBQUkxVixJQUFJLENBQUMrZ0IsTUFBTSxLQUFLbEMsS0FBSyxDQUFDRSxRQUFRLElBQzdDL2UsSUFBSSxDQUFDMmdCLGdCQUFnQixLQUFLb0QsY0FBYyxFQUFFO2tCQUN0RDtrQkFDQTtrQkFDQTtrQkFDQTtrQkFDQS9qQixJQUFJLENBQUNxakIsVUFBVSxDQUFDL2QsRUFBRSxFQUFFc0ssR0FBRyxDQUFDO2dCQUMxQjtjQUNGLENBQUMsU0FBUztnQkFDUm9VLE9BQU8sRUFBRTtnQkFDVDtnQkFDQTtnQkFDQTtnQkFDQSxJQUFJQSxPQUFPLEtBQUssQ0FBQyxFQUNmQyxHQUFHLENBQUN4TCxNQUFNLENBQUMsQ0FBQztjQUNoQjtZQUNGLENBQUMsQ0FBQyxDQUFDO1VBQ1AsQ0FBQyxDQUFDO1VBQ0Z3TCxHQUFHLENBQUM5Z0IsSUFBSSxDQUFDLENBQUM7VUFDVjtVQUNBLElBQUluRCxJQUFJLENBQUMrZ0IsTUFBTSxLQUFLbEMsS0FBSyxDQUFDQyxRQUFRLEVBQ2hDO1VBQ0Y5ZSxJQUFJLENBQUMwZ0Isa0JBQWtCLEdBQUcsSUFBSTtRQUNoQztRQUNBO1FBQ0E7UUFDQSxJQUFJMWdCLElBQUksQ0FBQytnQixNQUFNLEtBQUtsQyxLQUFLLENBQUNDLFFBQVEsRUFDaEM5ZSxJQUFJLENBQUNra0IsU0FBUyxDQUFDLENBQUM7TUFDcEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUM7RUFDSixDQUFDO0VBQ0RBLFNBQVMsRUFBRSxTQUFBQSxDQUFBLEVBQVk7SUFDckIsSUFBSWxrQixJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDclMsSUFBSSxDQUFDa2dCLG9CQUFvQixDQUFDckIsS0FBSyxDQUFDRyxNQUFNLENBQUM7TUFDdkMsSUFBSW1GLE1BQU0sR0FBR25rQixJQUFJLENBQUM2Z0IsZ0NBQWdDO01BQ2xEN2dCLElBQUksQ0FBQzZnQixnQ0FBZ0MsR0FBRyxFQUFFO01BQzFDN2dCLElBQUksQ0FBQzZiLFlBQVksQ0FBQ1QsT0FBTyxDQUFDLFlBQVk7UUFDcENyZSxDQUFDLENBQUNLLElBQUksQ0FBQyttQixNQUFNLEVBQUUsVUFBVXpGLENBQUMsRUFBRTtVQUMxQkEsQ0FBQyxDQUFDcmEsU0FBUyxDQUFDLENBQUM7UUFDZixDQUFDLENBQUM7TUFDSixDQUFDLENBQUM7SUFDSixDQUFDLENBQUM7RUFDSixDQUFDO0VBQ0QyYyx5QkFBeUIsRUFBRSxTQUFBQSxDQUFVOUwsRUFBRSxFQUFFO0lBQ3ZDLElBQUlsVixJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDclMsSUFBSSxDQUFDeWdCLFlBQVksQ0FBQzNRLEdBQUcsQ0FBQ21GLE9BQU8sQ0FBQ0MsRUFBRSxDQUFDLEVBQUVBLEVBQUUsQ0FBQztJQUN4QyxDQUFDLENBQUM7RUFDSixDQUFDO0VBQ0QrTCxpQ0FBaUMsRUFBRSxTQUFBQSxDQUFVL0wsRUFBRSxFQUFFO0lBQy9DLElBQUlsVixJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDLElBQUkvTSxFQUFFLEdBQUcyUCxPQUFPLENBQUNDLEVBQUUsQ0FBQztNQUNwQjtNQUNBO01BQ0EsSUFBSWxWLElBQUksQ0FBQytnQixNQUFNLEtBQUtsQyxLQUFLLENBQUNFLFFBQVEsS0FDNUIvZSxJQUFJLENBQUMwZ0Isa0JBQWtCLElBQUkxZ0IsSUFBSSxDQUFDMGdCLGtCQUFrQixDQUFDNWYsR0FBRyxDQUFDd0UsRUFBRSxDQUFDLElBQzNEdEYsSUFBSSxDQUFDeWdCLFlBQVksQ0FBQzNmLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQyxDQUFDLEVBQUU7UUFDL0J0RixJQUFJLENBQUN5Z0IsWUFBWSxDQUFDM1EsR0FBRyxDQUFDeEssRUFBRSxFQUFFNFAsRUFBRSxDQUFDO1FBQzdCO01BQ0Y7TUFFQSxJQUFJQSxFQUFFLENBQUNBLEVBQUUsS0FBSyxHQUFHLEVBQUU7UUFDakIsSUFBSWxWLElBQUksQ0FBQzhmLFVBQVUsQ0FBQ2hmLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQyxJQUN0QnRGLElBQUksQ0FBQ3lmLE1BQU0sSUFBSXpmLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDOWUsR0FBRyxDQUFDd0UsRUFBRSxDQUFFLEVBQ2xEdEYsSUFBSSxDQUFDb2pCLGVBQWUsQ0FBQzlkLEVBQUUsQ0FBQztNQUM1QixDQUFDLE1BQU0sSUFBSTRQLEVBQUUsQ0FBQ0EsRUFBRSxLQUFLLEdBQUcsRUFBRTtRQUN4QixJQUFJbFYsSUFBSSxDQUFDOGYsVUFBVSxDQUFDaGYsR0FBRyxDQUFDd0UsRUFBRSxDQUFDLEVBQ3pCLE1BQU0sSUFBSXZDLEtBQUssQ0FBQyxtREFBbUQsQ0FBQztRQUN0RSxJQUFJL0MsSUFBSSxDQUFDNGYsa0JBQWtCLElBQUk1ZixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzllLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQyxFQUM1RCxNQUFNLElBQUl2QyxLQUFLLENBQUMsZ0RBQWdELENBQUM7O1FBRW5FO1FBQ0E7UUFDQSxJQUFJL0MsSUFBSSxDQUFDbWdCLFFBQVEsQ0FBQ29ELGVBQWUsQ0FBQ3JPLEVBQUUsQ0FBQ0MsQ0FBQyxDQUFDLENBQUN2USxNQUFNLEVBQzVDNUUsSUFBSSxDQUFDNmlCLFlBQVksQ0FBQzNOLEVBQUUsQ0FBQ0MsQ0FBQyxDQUFDO01BQzNCLENBQUMsTUFBTSxJQUFJRCxFQUFFLENBQUNBLEVBQUUsS0FBSyxHQUFHLEVBQUU7UUFDeEI7UUFDQTtRQUNBQSxFQUFFLENBQUNDLENBQUMsR0FBR3lKLGtCQUFrQixDQUFDMUosRUFBRSxDQUFDQyxDQUFDLENBQUM7UUFDL0I7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSWlQLFNBQVMsR0FBRyxDQUFDcm5CLENBQUMsQ0FBQytELEdBQUcsQ0FBQ29VLEVBQUUsQ0FBQ0MsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUNwWSxDQUFDLENBQUMrRCxHQUFHLENBQUNvVSxFQUFFLENBQUNDLENBQUMsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDcFksQ0FBQyxDQUFDK0QsR0FBRyxDQUFDb1UsRUFBRSxDQUFDQyxDQUFDLEVBQUUsUUFBUSxDQUFDO1FBQ3RGO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSWtQLG9CQUFvQixHQUN0QixDQUFDRCxTQUFTLElBQUlFLDRCQUE0QixDQUFDcFAsRUFBRSxDQUFDQyxDQUFDLENBQUM7UUFFbEQsSUFBSXFPLGVBQWUsR0FBR3hqQixJQUFJLENBQUM4ZixVQUFVLENBQUNoZixHQUFHLENBQUN3RSxFQUFFLENBQUM7UUFDN0MsSUFBSW1lLGNBQWMsR0FBR3pqQixJQUFJLENBQUN5ZixNQUFNLElBQUl6ZixJQUFJLENBQUM0ZixrQkFBa0IsQ0FBQzllLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQztRQUVuRSxJQUFJOGUsU0FBUyxFQUFFO1VBQ2Jwa0IsSUFBSSxDQUFDcWpCLFVBQVUsQ0FBQy9kLEVBQUUsRUFBRXZJLENBQUMsQ0FBQ29KLE1BQU0sQ0FBQztZQUFDWixHQUFHLEVBQUVEO1VBQUUsQ0FBQyxFQUFFNFAsRUFBRSxDQUFDQyxDQUFDLENBQUMsQ0FBQztRQUNoRCxDQUFDLE1BQU0sSUFBSSxDQUFDcU8sZUFBZSxJQUFJQyxjQUFjLEtBQ2xDWSxvQkFBb0IsRUFBRTtVQUMvQjtVQUNBO1VBQ0EsSUFBSXRjLE1BQU0sR0FBRy9ILElBQUksQ0FBQzhmLFVBQVUsQ0FBQ2hmLEdBQUcsQ0FBQ3dFLEVBQUUsQ0FBQyxHQUNoQ3RGLElBQUksQ0FBQzhmLFVBQVUsQ0FBQzNiLEdBQUcsQ0FBQ21CLEVBQUUsQ0FBQyxHQUFHdEYsSUFBSSxDQUFDNGYsa0JBQWtCLENBQUN6YixHQUFHLENBQUNtQixFQUFFLENBQUM7VUFDN0R5QyxNQUFNLEdBQUdwSixLQUFLLENBQUNsQixLQUFLLENBQUNzSyxNQUFNLENBQUM7VUFFNUJBLE1BQU0sQ0FBQ3hDLEdBQUcsR0FBR0QsRUFBRTtVQUNmLElBQUk7WUFDRkYsZUFBZSxDQUFDbWYsT0FBTyxDQUFDeGMsTUFBTSxFQUFFbU4sRUFBRSxDQUFDQyxDQUFDLENBQUM7VUFDdkMsQ0FBQyxDQUFDLE9BQU9qUSxDQUFDLEVBQUU7WUFDVixJQUFJQSxDQUFDLENBQUN2SCxJQUFJLEtBQUssZ0JBQWdCLEVBQzdCLE1BQU11SCxDQUFDO1lBQ1Q7WUFDQWxGLElBQUksQ0FBQ3lnQixZQUFZLENBQUMzUSxHQUFHLENBQUN4SyxFQUFFLEVBQUU0UCxFQUFFLENBQUM7WUFDN0IsSUFBSWxWLElBQUksQ0FBQytnQixNQUFNLEtBQUtsQyxLQUFLLENBQUNHLE1BQU0sRUFBRTtjQUNoQ2hmLElBQUksQ0FBQzhqQix1QkFBdUIsQ0FBQyxDQUFDO1lBQ2hDO1lBQ0E7VUFDRjtVQUNBOWpCLElBQUksQ0FBQ3FqQixVQUFVLENBQUMvZCxFQUFFLEVBQUV0RixJQUFJLENBQUN3Z0IsbUJBQW1CLENBQUN6WSxNQUFNLENBQUMsQ0FBQztRQUN2RCxDQUFDLE1BQU0sSUFBSSxDQUFDc2Msb0JBQW9CLElBQ3JCcmtCLElBQUksQ0FBQ21nQixRQUFRLENBQUNxRSx1QkFBdUIsQ0FBQ3RQLEVBQUUsQ0FBQ0MsQ0FBQyxDQUFDLElBQzFDblYsSUFBSSxDQUFDMmYsT0FBTyxJQUFJM2YsSUFBSSxDQUFDMmYsT0FBTyxDQUFDOEUsa0JBQWtCLENBQUN2UCxFQUFFLENBQUNDLENBQUMsQ0FBRSxFQUFFO1VBQ2xFblYsSUFBSSxDQUFDeWdCLFlBQVksQ0FBQzNRLEdBQUcsQ0FBQ3hLLEVBQUUsRUFBRTRQLEVBQUUsQ0FBQztVQUM3QixJQUFJbFYsSUFBSSxDQUFDK2dCLE1BQU0sS0FBS2xDLEtBQUssQ0FBQ0csTUFBTSxFQUM5QmhmLElBQUksQ0FBQzhqQix1QkFBdUIsQ0FBQyxDQUFDO1FBQ2xDO01BQ0YsQ0FBQyxNQUFNO1FBQ0wsTUFBTS9nQixLQUFLLENBQUMsNEJBQTRCLEdBQUdtUyxFQUFFLENBQUM7TUFDaEQ7SUFDRixDQUFDLENBQUM7RUFDSixDQUFDO0VBQ0Q7RUFDQXFNLGdCQUFnQixFQUFFLFNBQUFBLENBQUEsRUFBWTtJQUM1QixJQUFJdmhCLElBQUksR0FBRyxJQUFJO0lBQ2YsSUFBSUEsSUFBSSxDQUFDMFYsUUFBUSxFQUNmLE1BQU0sSUFBSTNTLEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQztJQUVyRC9DLElBQUksQ0FBQzBrQixTQUFTLENBQUM7TUFBQ0MsT0FBTyxFQUFFO0lBQUksQ0FBQyxDQUFDLENBQUMsQ0FBRTs7SUFFbEMsSUFBSTNrQixJQUFJLENBQUMwVixRQUFRLEVBQ2YsT0FBTyxDQUFFOztJQUVYO0lBQ0E7SUFDQTFWLElBQUksQ0FBQzZiLFlBQVksQ0FBQ2IsS0FBSyxDQUFDLENBQUM7SUFFekJoYixJQUFJLENBQUM0a0IsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFFO0VBQ3pCLENBQUM7RUFFRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0FDLFVBQVUsRUFBRSxTQUFBQSxDQUFBLEVBQVk7SUFDdEIsSUFBSTdrQixJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDLElBQUlyUyxJQUFJLENBQUMwVixRQUFRLEVBQ2Y7O01BRUY7TUFDQTFWLElBQUksQ0FBQ3lnQixZQUFZLEdBQUcsSUFBSXJiLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO01BQzlDelAsSUFBSSxDQUFDMGdCLGtCQUFrQixHQUFHLElBQUk7TUFDOUIsRUFBRTFnQixJQUFJLENBQUMyZ0IsZ0JBQWdCLENBQUMsQ0FBRTtNQUMxQjNnQixJQUFJLENBQUNrZ0Isb0JBQW9CLENBQUNyQixLQUFLLENBQUNDLFFBQVEsQ0FBQzs7TUFFekM7TUFDQTtNQUNBeGUsTUFBTSxDQUFDdVIsS0FBSyxDQUFDLFlBQVk7UUFDdkI3UixJQUFJLENBQUMwa0IsU0FBUyxDQUFDLENBQUM7UUFDaEIxa0IsSUFBSSxDQUFDNGtCLGFBQWEsQ0FBQyxDQUFDO01BQ3RCLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFRDtFQUNBRixTQUFTLEVBQUUsU0FBQUEsQ0FBVTlrQixPQUFPLEVBQUU7SUFDNUIsSUFBSUksSUFBSSxHQUFHLElBQUk7SUFDZkosT0FBTyxHQUFHQSxPQUFPLElBQUksQ0FBQyxDQUFDO0lBQ3ZCLElBQUl1ZSxVQUFVLEVBQUUyRyxTQUFTOztJQUV6QjtJQUNBLE9BQU8sSUFBSSxFQUFFO01BQ1g7TUFDQSxJQUFJOWtCLElBQUksQ0FBQzBWLFFBQVEsRUFDZjtNQUVGeUksVUFBVSxHQUFHLElBQUkvWSxlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQztNQUN2Q3FWLFNBQVMsR0FBRyxJQUFJMWYsZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7O01BRXRDO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSXBELE1BQU0sR0FBR3JNLElBQUksQ0FBQytrQixlQUFlLENBQUM7UUFBRXJhLEtBQUssRUFBRTFLLElBQUksQ0FBQ3lmLE1BQU0sR0FBRztNQUFFLENBQUMsQ0FBQztNQUM3RCxJQUFJO1FBQ0ZwVCxNQUFNLENBQUNqTCxPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRW9WLENBQUMsRUFBRTtVQUFHO1VBQ2xDLElBQUksQ0FBQ2hsQixJQUFJLENBQUN5ZixNQUFNLElBQUl1RixDQUFDLEdBQUdobEIsSUFBSSxDQUFDeWYsTUFBTSxFQUFFO1lBQ25DdEIsVUFBVSxDQUFDck8sR0FBRyxDQUFDRixHQUFHLENBQUNySyxHQUFHLEVBQUVxSyxHQUFHLENBQUM7VUFDOUIsQ0FBQyxNQUFNO1lBQ0xrVixTQUFTLENBQUNoVixHQUFHLENBQUNGLEdBQUcsQ0FBQ3JLLEdBQUcsRUFBRXFLLEdBQUcsQ0FBQztVQUM3QjtRQUNGLENBQUMsQ0FBQztRQUNGO01BQ0YsQ0FBQyxDQUFDLE9BQU8xSyxDQUFDLEVBQUU7UUFDVixJQUFJdEYsT0FBTyxDQUFDK2tCLE9BQU8sSUFBSSxPQUFPemYsQ0FBQyxDQUFDb1osSUFBSyxLQUFLLFFBQVEsRUFBRTtVQUNsRDtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0F0ZSxJQUFJLENBQUM2YixZQUFZLENBQUNYLFVBQVUsQ0FBQ2hXLENBQUMsQ0FBQztVQUMvQjtRQUNGOztRQUVBO1FBQ0E7UUFDQTVFLE1BQU0sQ0FBQzZXLE1BQU0sQ0FBQyxtQ0FBbUMsRUFBRWpTLENBQUMsQ0FBQztRQUNyRDVFLE1BQU0sQ0FBQ21YLFdBQVcsQ0FBQyxHQUFHLENBQUM7TUFDekI7SUFDRjtJQUVBLElBQUl6WCxJQUFJLENBQUMwVixRQUFRLEVBQ2Y7SUFFRjFWLElBQUksQ0FBQ2lsQixrQkFBa0IsQ0FBQzlHLFVBQVUsRUFBRTJHLFNBQVMsQ0FBQztFQUNoRCxDQUFDO0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0FoRSxnQkFBZ0IsRUFBRSxTQUFBQSxDQUFBLEVBQVk7SUFDNUIsSUFBSTlnQixJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDLElBQUlyUyxJQUFJLENBQUMwVixRQUFRLEVBQ2Y7O01BRUY7TUFDQTtNQUNBLElBQUkxVixJQUFJLENBQUMrZ0IsTUFBTSxLQUFLbEMsS0FBSyxDQUFDQyxRQUFRLEVBQUU7UUFDbEM5ZSxJQUFJLENBQUM2a0IsVUFBVSxDQUFDLENBQUM7UUFDakIsTUFBTSxJQUFJNUYsZUFBZSxDQUFELENBQUM7TUFDM0I7O01BRUE7TUFDQTtNQUNBamYsSUFBSSxDQUFDNGdCLHlCQUF5QixHQUFHLElBQUk7SUFDdkMsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEO0VBQ0FnRSxhQUFhLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ3pCLElBQUk1a0IsSUFBSSxHQUFHLElBQUk7SUFFZixJQUFJQSxJQUFJLENBQUMwVixRQUFRLEVBQ2Y7SUFDRjFWLElBQUksQ0FBQzhjLFlBQVksQ0FBQ2xiLFlBQVksQ0FBQzBWLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFFO0lBQ3JELElBQUl0WCxJQUFJLENBQUMwVixRQUFRLEVBQ2Y7SUFDRixJQUFJMVYsSUFBSSxDQUFDK2dCLE1BQU0sS0FBS2xDLEtBQUssQ0FBQ0MsUUFBUSxFQUNoQyxNQUFNL2IsS0FBSyxDQUFDLHFCQUFxQixHQUFHL0MsSUFBSSxDQUFDK2dCLE1BQU0sQ0FBQztJQUVsRHpnQixNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDLElBQUlyUyxJQUFJLENBQUM0Z0IseUJBQXlCLEVBQUU7UUFDbEM1Z0IsSUFBSSxDQUFDNGdCLHlCQUF5QixHQUFHLEtBQUs7UUFDdEM1Z0IsSUFBSSxDQUFDNmtCLFVBQVUsQ0FBQyxDQUFDO01BQ25CLENBQUMsTUFBTSxJQUFJN2tCLElBQUksQ0FBQ3lnQixZQUFZLENBQUN3QixLQUFLLENBQUMsQ0FBQyxFQUFFO1FBQ3BDamlCLElBQUksQ0FBQ2trQixTQUFTLENBQUMsQ0FBQztNQUNsQixDQUFDLE1BQU07UUFDTGxrQixJQUFJLENBQUM4akIsdUJBQXVCLENBQUMsQ0FBQztNQUNoQztJQUNGLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFRGlCLGVBQWUsRUFBRSxTQUFBQSxDQUFVRyxnQkFBZ0IsRUFBRTtJQUMzQyxJQUFJbGxCLElBQUksR0FBRyxJQUFJO0lBQ2YsT0FBT00sTUFBTSxDQUFDK1IsZ0JBQWdCLENBQUMsWUFBWTtNQUN6QztNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSXpTLE9BQU8sR0FBRzdDLENBQUMsQ0FBQ1UsS0FBSyxDQUFDdUMsSUFBSSxDQUFDa00sa0JBQWtCLENBQUN0TSxPQUFPLENBQUM7O01BRXREO01BQ0E7TUFDQTdDLENBQUMsQ0FBQ29KLE1BQU0sQ0FBQ3ZHLE9BQU8sRUFBRXNsQixnQkFBZ0IsQ0FBQztNQUVuQ3RsQixPQUFPLENBQUM0TyxNQUFNLEdBQUd4TyxJQUFJLENBQUNzZ0IsaUJBQWlCO01BQ3ZDLE9BQU8xZ0IsT0FBTyxDQUFDd04sU0FBUztNQUN4QjtNQUNBLElBQUkrWCxXQUFXLEdBQUcsSUFBSTVhLGlCQUFpQixDQUNyQ3ZLLElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDN0ksY0FBYyxFQUN0Q3JELElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDbkcsUUFBUSxFQUNoQ25HLE9BQU8sQ0FBQztNQUNWLE9BQU8sSUFBSTBLLE1BQU0sQ0FBQ3RLLElBQUksQ0FBQzhjLFlBQVksRUFBRXFJLFdBQVcsQ0FBQztJQUNuRCxDQUFDLENBQUM7RUFDSixDQUFDO0VBR0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQUYsa0JBQWtCLEVBQUUsU0FBQUEsQ0FBVTlHLFVBQVUsRUFBRTJHLFNBQVMsRUFBRTtJQUNuRCxJQUFJOWtCLElBQUksR0FBRyxJQUFJO0lBQ2ZNLE1BQU0sQ0FBQytSLGdCQUFnQixDQUFDLFlBQVk7TUFFbEM7TUFDQTtNQUNBLElBQUlyUyxJQUFJLENBQUN5ZixNQUFNLEVBQUU7UUFDZnpmLElBQUksQ0FBQzRmLGtCQUFrQixDQUFDekcsS0FBSyxDQUFDLENBQUM7TUFDakM7O01BRUE7TUFDQTtNQUNBLElBQUlpTSxXQUFXLEdBQUcsRUFBRTtNQUNwQnBsQixJQUFJLENBQUM4ZixVQUFVLENBQUMxZSxPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRXRLLEVBQUUsRUFBRTtRQUN6QyxJQUFJLENBQUM2WSxVQUFVLENBQUNyZCxHQUFHLENBQUN3RSxFQUFFLENBQUMsRUFDckI4ZixXQUFXLENBQUN0VSxJQUFJLENBQUN4TCxFQUFFLENBQUM7TUFDeEIsQ0FBQyxDQUFDO01BQ0Z2SSxDQUFDLENBQUNLLElBQUksQ0FBQ2dvQixXQUFXLEVBQUUsVUFBVTlmLEVBQUUsRUFBRTtRQUNoQ3RGLElBQUksQ0FBQ2dpQixnQkFBZ0IsQ0FBQzFjLEVBQUUsQ0FBQztNQUMzQixDQUFDLENBQUM7O01BRUY7TUFDQTtNQUNBO01BQ0E2WSxVQUFVLENBQUMvYyxPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRXRLLEVBQUUsRUFBRTtRQUNwQ3RGLElBQUksQ0FBQ3FqQixVQUFVLENBQUMvZCxFQUFFLEVBQUVzSyxHQUFHLENBQUM7TUFDMUIsQ0FBQyxDQUFDOztNQUVGO01BQ0E7TUFDQTtNQUNBLElBQUk1UCxJQUFJLENBQUM4ZixVQUFVLENBQUNwaEIsSUFBSSxDQUFDLENBQUMsS0FBS3lmLFVBQVUsQ0FBQ3pmLElBQUksQ0FBQyxDQUFDLEVBQUU7UUFDaEQ0QixNQUFNLENBQUM2VyxNQUFNLENBQUMsd0RBQXdELEdBQ3BFLHVEQUF1RCxFQUN2RG5YLElBQUksQ0FBQ2tNLGtCQUFrQixDQUFDO01BQzVCO01BRUFsTSxJQUFJLENBQUM4ZixVQUFVLENBQUMxZSxPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRXRLLEVBQUUsRUFBRTtRQUN6QyxJQUFJLENBQUM2WSxVQUFVLENBQUNyZCxHQUFHLENBQUN3RSxFQUFFLENBQUMsRUFDckIsTUFBTXZDLEtBQUssQ0FBQyxnREFBZ0QsR0FBR3VDLEVBQUUsQ0FBQztNQUN0RSxDQUFDLENBQUM7O01BRUY7TUFDQXdmLFNBQVMsQ0FBQzFqQixPQUFPLENBQUMsVUFBVXdPLEdBQUcsRUFBRXRLLEVBQUUsRUFBRTtRQUNuQ3RGLElBQUksQ0FBQytoQixZQUFZLENBQUN6YyxFQUFFLEVBQUVzSyxHQUFHLENBQUM7TUFDNUIsQ0FBQyxDQUFDO01BRUY1UCxJQUFJLENBQUNnZ0IsbUJBQW1CLEdBQUc4RSxTQUFTLENBQUNwbUIsSUFBSSxDQUFDLENBQUMsR0FBR3NCLElBQUksQ0FBQ3lmLE1BQU07SUFDM0QsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBeGMsSUFBSSxFQUFFLFNBQUFBLENBQUEsRUFBWTtJQUNoQixJQUFJakQsSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJQSxJQUFJLENBQUMwVixRQUFRLEVBQ2Y7SUFDRjFWLElBQUksQ0FBQzBWLFFBQVEsR0FBRyxJQUFJO0lBQ3BCM1ksQ0FBQyxDQUFDSyxJQUFJLENBQUM0QyxJQUFJLENBQUNpZ0IsWUFBWSxFQUFFLFVBQVV6RixNQUFNLEVBQUU7TUFDMUNBLE1BQU0sQ0FBQ3ZYLElBQUksQ0FBQyxDQUFDO0lBQ2YsQ0FBQyxDQUFDOztJQUVGO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQWxHLENBQUMsQ0FBQ0ssSUFBSSxDQUFDNEMsSUFBSSxDQUFDNmdCLGdDQUFnQyxFQUFFLFVBQVVuQyxDQUFDLEVBQUU7TUFDekRBLENBQUMsQ0FBQ3JhLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBRTtJQUNsQixDQUFDLENBQUM7SUFDRnJFLElBQUksQ0FBQzZnQixnQ0FBZ0MsR0FBRyxJQUFJOztJQUU1QztJQUNBN2dCLElBQUksQ0FBQzhmLFVBQVUsR0FBRyxJQUFJO0lBQ3RCOWYsSUFBSSxDQUFDNGYsa0JBQWtCLEdBQUcsSUFBSTtJQUM5QjVmLElBQUksQ0FBQ3lnQixZQUFZLEdBQUcsSUFBSTtJQUN4QnpnQixJQUFJLENBQUMwZ0Isa0JBQWtCLEdBQUcsSUFBSTtJQUM5QjFnQixJQUFJLENBQUNxbEIsaUJBQWlCLEdBQUcsSUFBSTtJQUM3QnJsQixJQUFJLENBQUNzbEIsZ0JBQWdCLEdBQUcsSUFBSTtJQUU1QjlpQixPQUFPLENBQUMsWUFBWSxDQUFDLElBQUlBLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQ2tYLEtBQUssQ0FBQ0MsbUJBQW1CLENBQ3RFLGdCQUFnQixFQUFFLHVCQUF1QixFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ2xELENBQUM7RUFFRHVHLG9CQUFvQixFQUFFLFNBQUFBLENBQVVxRixLQUFLLEVBQUU7SUFDckMsSUFBSXZsQixJQUFJLEdBQUcsSUFBSTtJQUNmTSxNQUFNLENBQUMrUixnQkFBZ0IsQ0FBQyxZQUFZO01BQ2xDLElBQUltVCxHQUFHLEdBQUcsSUFBSUMsSUFBSSxDQUFELENBQUM7TUFFbEIsSUFBSXpsQixJQUFJLENBQUMrZ0IsTUFBTSxFQUFFO1FBQ2YsSUFBSTJFLFFBQVEsR0FBR0YsR0FBRyxHQUFHeGxCLElBQUksQ0FBQzJsQixlQUFlO1FBQ3pDbmpCLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDa1gsS0FBSyxDQUFDQyxtQkFBbUIsQ0FDdEUsZ0JBQWdCLEVBQUUsZ0JBQWdCLEdBQUczWixJQUFJLENBQUMrZ0IsTUFBTSxHQUFHLFFBQVEsRUFBRTJFLFFBQVEsQ0FBQztNQUMxRTtNQUVBMWxCLElBQUksQ0FBQytnQixNQUFNLEdBQUd3RSxLQUFLO01BQ25CdmxCLElBQUksQ0FBQzJsQixlQUFlLEdBQUdILEdBQUc7SUFDNUIsQ0FBQyxDQUFDO0VBQ0o7QUFDRixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0F2UyxrQkFBa0IsQ0FBQ0MsZUFBZSxHQUFHLFVBQVVsSCxpQkFBaUIsRUFBRTBHLE9BQU8sRUFBRTtFQUN6RTtFQUNBLElBQUk5UyxPQUFPLEdBQUdvTSxpQkFBaUIsQ0FBQ3BNLE9BQU87O0VBRXZDO0VBQ0E7RUFDQSxJQUFJQSxPQUFPLENBQUNnbUIsWUFBWSxJQUFJaG1CLE9BQU8sQ0FBQ2ltQixhQUFhLEVBQy9DLE9BQU8sS0FBSzs7RUFFZDtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlqbUIsT0FBTyxDQUFDME8sSUFBSSxJQUFLMU8sT0FBTyxDQUFDOEssS0FBSyxJQUFJLENBQUM5SyxPQUFPLENBQUN5TyxJQUFLLEVBQUUsT0FBTyxLQUFLOztFQUVsRTtFQUNBO0VBQ0EsTUFBTUcsTUFBTSxHQUFHNU8sT0FBTyxDQUFDNE8sTUFBTSxJQUFJNU8sT0FBTyxDQUFDMk8sVUFBVTtFQUNuRCxJQUFJQyxNQUFNLEVBQUU7SUFDVixJQUFJO01BQ0ZwSixlQUFlLENBQUMwZ0IseUJBQXlCLENBQUN0WCxNQUFNLENBQUM7SUFDbkQsQ0FBQyxDQUFDLE9BQU90SixDQUFDLEVBQUU7TUFDVixJQUFJQSxDQUFDLENBQUN2SCxJQUFJLEtBQUssZ0JBQWdCLEVBQUU7UUFDL0IsT0FBTyxLQUFLO01BQ2QsQ0FBQyxNQUFNO1FBQ0wsTUFBTXVILENBQUM7TUFDVDtJQUNGO0VBQ0Y7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE9BQU8sQ0FBQ3dOLE9BQU8sQ0FBQ3FULFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQ3JULE9BQU8sQ0FBQ3NULFdBQVcsQ0FBQyxDQUFDO0FBQ3RELENBQUM7QUFFRCxJQUFJMUIsNEJBQTRCLEdBQUcsU0FBQUEsQ0FBVTJCLFFBQVEsRUFBRTtFQUNyRCxPQUFPbHBCLENBQUMsQ0FBQzhWLEdBQUcsQ0FBQ29ULFFBQVEsRUFBRSxVQUFVelgsTUFBTSxFQUFFMFgsU0FBUyxFQUFFO0lBQ2xELE9BQU9ucEIsQ0FBQyxDQUFDOFYsR0FBRyxDQUFDckUsTUFBTSxFQUFFLFVBQVVuUixLQUFLLEVBQUU4b0IsS0FBSyxFQUFFO01BQzNDLE9BQU8sQ0FBQyxTQUFTLENBQUNDLElBQUksQ0FBQ0QsS0FBSyxDQUFDO0lBQy9CLENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQztBQUNKLENBQUM7QUFFRGpxQixjQUFjLENBQUMrVyxrQkFBa0IsR0FBR0Esa0JBQWtCLEM7Ozs7Ozs7Ozs7O0FDdC9CdEQxVyxNQUFNLENBQUN3ZixNQUFNLENBQUM7RUFBQzZDLGtCQUFrQixFQUFDQSxDQUFBLEtBQUlBO0FBQWtCLENBQUMsQ0FBQztBQUExRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU3BkLElBQUlBLENBQUM2a0IsTUFBTSxFQUFFL29CLEdBQUcsRUFBRTtFQUN6QixPQUFPK29CLE1BQU0sTUFBQUMsTUFBQSxDQUFNRCxNQUFNLE9BQUFDLE1BQUEsQ0FBSWhwQixHQUFHLElBQUtBLEdBQUc7QUFDMUM7QUFFQSxNQUFNaXBCLHFCQUFxQixHQUFHLGVBQWU7QUFFN0MsU0FBU0Msa0JBQWtCQSxDQUFDTCxLQUFLLEVBQUU7RUFDakMsT0FBT0kscUJBQXFCLENBQUNILElBQUksQ0FBQ0QsS0FBSyxDQUFDO0FBQzFDO0FBRUEsU0FBU00sZUFBZUEsQ0FBQ0MsUUFBUSxFQUFFO0VBQ2pDLE9BQU9BLFFBQVEsQ0FBQ0MsQ0FBQyxLQUFLLElBQUksSUFBSWhtQixNQUFNLENBQUM2SCxJQUFJLENBQUNrZSxRQUFRLENBQUMsQ0FBQ0UsS0FBSyxDQUFDSixrQkFBa0IsQ0FBQztBQUMvRTtBQUVBLFNBQVNLLGlCQUFpQkEsQ0FBQ0MsTUFBTSxFQUFFQyxNQUFNLEVBQUVWLE1BQU0sRUFBRTtFQUNqRCxJQUFJamIsS0FBSyxDQUFDcE8sT0FBTyxDQUFDK3BCLE1BQU0sQ0FBQyxJQUFJLE9BQU9BLE1BQU0sS0FBSyxRQUFRLElBQUlBLE1BQU0sS0FBSyxJQUFJLElBQ3RFQSxNQUFNLFlBQVkxb0IsS0FBSyxDQUFDRCxRQUFRLEVBQUU7SUFDcEMwb0IsTUFBTSxDQUFDVCxNQUFNLENBQUMsR0FBR1UsTUFBTTtFQUN6QixDQUFDLE1BQU07SUFDTCxNQUFNOWxCLE9BQU8sR0FBR04sTUFBTSxDQUFDTSxPQUFPLENBQUM4bEIsTUFBTSxDQUFDO0lBQ3RDLElBQUk5bEIsT0FBTyxDQUFDMEgsTUFBTSxFQUFFO01BQ2xCMUgsT0FBTyxDQUFDRyxPQUFPLENBQUNGLElBQUEsSUFBa0I7UUFBQSxJQUFqQixDQUFDNUQsR0FBRyxFQUFFRCxLQUFLLENBQUMsR0FBQTZELElBQUE7UUFDM0IybEIsaUJBQWlCLENBQUNDLE1BQU0sRUFBRXpwQixLQUFLLEVBQUVtRSxJQUFJLENBQUM2a0IsTUFBTSxFQUFFL29CLEdBQUcsQ0FBQyxDQUFDO01BQ3JELENBQUMsQ0FBQztJQUNKLENBQUMsTUFBTTtNQUNMd3BCLE1BQU0sQ0FBQ1QsTUFBTSxDQUFDLEdBQUdVLE1BQU07SUFDekI7RUFDRjtBQUNGO0FBRUEsTUFBTUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDdlMsT0FBTyxDQUFDQyxHQUFHLENBQUN1UyxxQkFBcUI7QUFFNUQsU0FBU0MsZ0JBQWdCQSxDQUFDQyxVQUFVLEVBQUVDLElBQUksRUFBRWYsTUFBTSxFQUFFO0VBQ2xELElBQUlXLGdCQUFnQixFQUFFO0lBQ3BCSyxPQUFPLENBQUNDLEdBQUcscUJBQUFoQixNQUFBLENBQXFCL0gsSUFBSSxDQUFDdE0sU0FBUyxDQUFDa1YsVUFBVSxDQUFDLFFBQUFiLE1BQUEsQ0FBSy9ILElBQUksQ0FBQ3RNLFNBQVMsQ0FBQ21WLElBQUksQ0FBQyxRQUFBZCxNQUFBLENBQUsvSCxJQUFJLENBQUN0TSxTQUFTLENBQUNvVSxNQUFNLENBQUMsTUFBRyxDQUFDO0VBQ3BIO0VBRUExbEIsTUFBTSxDQUFDTSxPQUFPLENBQUNtbUIsSUFBSSxDQUFDLENBQUNobUIsT0FBTyxDQUFDQyxLQUFBLElBQXNCO0lBQUEsSUFBckIsQ0FBQ2ttQixPQUFPLEVBQUVscUIsS0FBSyxDQUFDLEdBQUFnRSxLQUFBO0lBQzVDLElBQUlrbUIsT0FBTyxLQUFLLEdBQUcsRUFBRTtNQUFBLElBQUFDLGtCQUFBO01BQ25CO01BQ0EsQ0FBQUEsa0JBQUEsR0FBQUwsVUFBVSxDQUFDTSxNQUFNLGNBQUFELGtCQUFBLGNBQUFBLGtCQUFBLEdBQWpCTCxVQUFVLENBQUNNLE1BQU0sR0FBSyxDQUFDLENBQUM7TUFDeEI5bUIsTUFBTSxDQUFDNkgsSUFBSSxDQUFDbkwsS0FBSyxDQUFDLENBQUMrRCxPQUFPLENBQUM5RCxHQUFHLElBQUk7UUFDaEM2cEIsVUFBVSxDQUFDTSxNQUFNLENBQUNqbUIsSUFBSSxDQUFDNmtCLE1BQU0sRUFBRS9vQixHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUk7TUFDN0MsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxNQUFNLElBQUlpcUIsT0FBTyxLQUFLLEdBQUcsRUFBRTtNQUFBLElBQUFHLGdCQUFBO01BQzFCO01BQ0EsQ0FBQUEsZ0JBQUEsR0FBQVAsVUFBVSxDQUFDUSxJQUFJLGNBQUFELGdCQUFBLGNBQUFBLGdCQUFBLEdBQWZQLFVBQVUsQ0FBQ1EsSUFBSSxHQUFLLENBQUMsQ0FBQztNQUN0QmQsaUJBQWlCLENBQUNNLFVBQVUsQ0FBQ1EsSUFBSSxFQUFFdHFCLEtBQUssRUFBRWdwQixNQUFNLENBQUM7SUFDbkQsQ0FBQyxNQUFNLElBQUlrQixPQUFPLEtBQUssR0FBRyxFQUFFO01BQUEsSUFBQUssaUJBQUE7TUFDMUI7TUFDQSxDQUFBQSxpQkFBQSxHQUFBVCxVQUFVLENBQUNRLElBQUksY0FBQUMsaUJBQUEsY0FBQUEsaUJBQUEsR0FBZlQsVUFBVSxDQUFDUSxJQUFJLEdBQUssQ0FBQyxDQUFDO01BQ3RCaG5CLE1BQU0sQ0FBQ00sT0FBTyxDQUFDNUQsS0FBSyxDQUFDLENBQUMrRCxPQUFPLENBQUN1RSxLQUFBLElBQWtCO1FBQUEsSUFBakIsQ0FBQ3JJLEdBQUcsRUFBRUQsS0FBSyxDQUFDLEdBQUFzSSxLQUFBO1FBQ3pDd2hCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDbm1CLElBQUksQ0FBQzZrQixNQUFNLEVBQUUvb0IsR0FBRyxDQUFDLENBQUMsR0FBR0QsS0FBSztNQUM1QyxDQUFDLENBQUM7SUFDSixDQUFDLE1BQU07TUFDTDtNQUNBLE1BQU1DLEdBQUcsR0FBR2lxQixPQUFPLENBQUN4TyxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQzVCLElBQUkwTixlQUFlLENBQUNwcEIsS0FBSyxDQUFDLEVBQUU7UUFDMUI7UUFDQXNELE1BQU0sQ0FBQ00sT0FBTyxDQUFDNUQsS0FBSyxDQUFDLENBQUMrRCxPQUFPLENBQUNrRixLQUFBLElBQXVCO1VBQUEsSUFBdEIsQ0FBQ3VoQixRQUFRLEVBQUV4cUIsS0FBSyxDQUFDLEdBQUFpSixLQUFBO1VBQzlDLElBQUl1aEIsUUFBUSxLQUFLLEdBQUcsRUFBRTtZQUNwQjtVQUNGO1VBRUEsTUFBTUMsV0FBVyxHQUFHdG1CLElBQUksQ0FBQ0EsSUFBSSxDQUFDNmtCLE1BQU0sRUFBRS9vQixHQUFHLENBQUMsRUFBRXVxQixRQUFRLENBQUM5TyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFDOUQsSUFBSThPLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7WUFDdkJYLGdCQUFnQixDQUFDQyxVQUFVLEVBQUU5cEIsS0FBSyxFQUFFeXFCLFdBQVcsQ0FBQztVQUNsRCxDQUFDLE1BQU0sSUFBSXpxQixLQUFLLEtBQUssSUFBSSxFQUFFO1lBQUEsSUFBQTBxQixtQkFBQTtZQUN6QixDQUFBQSxtQkFBQSxHQUFBWixVQUFVLENBQUNNLE1BQU0sY0FBQU0sbUJBQUEsY0FBQUEsbUJBQUEsR0FBakJaLFVBQVUsQ0FBQ00sTUFBTSxHQUFLLENBQUMsQ0FBQztZQUN4Qk4sVUFBVSxDQUFDTSxNQUFNLENBQUNLLFdBQVcsQ0FBQyxHQUFHLElBQUk7VUFDdkMsQ0FBQyxNQUFNO1lBQUEsSUFBQUUsaUJBQUE7WUFDTCxDQUFBQSxpQkFBQSxHQUFBYixVQUFVLENBQUNRLElBQUksY0FBQUssaUJBQUEsY0FBQUEsaUJBQUEsR0FBZmIsVUFBVSxDQUFDUSxJQUFJLEdBQUssQ0FBQyxDQUFDO1lBQ3RCUixVQUFVLENBQUNRLElBQUksQ0FBQ0csV0FBVyxDQUFDLEdBQUd6cUIsS0FBSztVQUN0QztRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTSxJQUFJQyxHQUFHLEVBQUU7UUFDZDtRQUNBNHBCLGdCQUFnQixDQUFDQyxVQUFVLEVBQUU5cEIsS0FBSyxFQUFFbUUsSUFBSSxDQUFDNmtCLE1BQU0sRUFBRS9vQixHQUFHLENBQUMsQ0FBQztNQUN4RDtJQUNGO0VBQ0YsQ0FBQyxDQUFDO0FBQ0o7QUFFTyxTQUFTc2hCLGtCQUFrQkEsQ0FBQ3VJLFVBQVUsRUFBRTtFQUM3QztFQUNBLElBQUlBLFVBQVUsQ0FBQ2MsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDZCxVQUFVLENBQUNDLElBQUksRUFBRTtJQUMzQyxPQUFPRCxVQUFVO0VBQ25CO0VBRUEsTUFBTWUsbUJBQW1CLEdBQUc7SUFBRUQsRUFBRSxFQUFFO0VBQUUsQ0FBQztFQUNyQ2YsZ0JBQWdCLENBQUNnQixtQkFBbUIsRUFBRWYsVUFBVSxDQUFDQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0VBQzFELE9BQU9jLG1CQUFtQjtBQUM1QixDOzs7Ozs7Ozs7OztBQzlIQTNyQixNQUFNLENBQUN3ZixNQUFNLENBQUM7RUFBQ29NLHFCQUFxQixFQUFDQSxDQUFBLEtBQUlBO0FBQXFCLENBQUMsQ0FBQztBQUN6RCxNQUFNQSxxQkFBcUIsR0FBRyxJQUFLLE1BQU1BLHFCQUFxQixDQUFDO0VBQ3BFbE0sV0FBV0EsQ0FBQSxFQUFHO0lBQ1osSUFBSSxDQUFDbU0saUJBQWlCLEdBQUd6bkIsTUFBTSxDQUFDMG5CLE1BQU0sQ0FBQyxJQUFJLENBQUM7RUFDOUM7RUFFQUMsSUFBSUEsQ0FBQzNxQixJQUFJLEVBQUU0cUIsSUFBSSxFQUFFO0lBQ2YsSUFBSSxDQUFFNXFCLElBQUksRUFBRTtNQUNWLE9BQU8sSUFBSXlILGVBQWUsQ0FBRCxDQUFDO0lBQzVCO0lBRUEsSUFBSSxDQUFFbWpCLElBQUksRUFBRTtNQUNWLE9BQU9DLGdCQUFnQixDQUFDN3FCLElBQUksRUFBRSxJQUFJLENBQUN5cUIsaUJBQWlCLENBQUM7SUFDdkQ7SUFFQSxJQUFJLENBQUVHLElBQUksQ0FBQ0UsMkJBQTJCLEVBQUU7TUFDdENGLElBQUksQ0FBQ0UsMkJBQTJCLEdBQUc5bkIsTUFBTSxDQUFDMG5CLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDeEQ7O0lBRUE7SUFDQTtJQUNBLE9BQU9HLGdCQUFnQixDQUFDN3FCLElBQUksRUFBRTRxQixJQUFJLENBQUNFLDJCQUEyQixDQUFDO0VBQ2pFO0FBQ0YsQ0FBQyxFQUFDO0FBRUYsU0FBU0QsZ0JBQWdCQSxDQUFDN3FCLElBQUksRUFBRStxQixXQUFXLEVBQUU7RUFDM0MsT0FBUS9xQixJQUFJLElBQUkrcUIsV0FBVyxHQUN2QkEsV0FBVyxDQUFDL3FCLElBQUksQ0FBQyxHQUNqQitxQixXQUFXLENBQUMvcUIsSUFBSSxDQUFDLEdBQUcsSUFBSXlILGVBQWUsQ0FBQ3pILElBQUksQ0FBQztBQUNuRCxDOzs7Ozs7Ozs7OztBQzdCQSxJQUFJZ3JCLHdCQUF3QixFQUFDanRCLGtCQUFrQjtBQUFDYSxNQUFNLENBQUNuQixJQUFJLENBQUMsNEJBQTRCLEVBQUM7RUFBQ3V0Qix3QkFBd0JBLENBQUNydEIsQ0FBQyxFQUFDO0lBQUNxdEIsd0JBQXdCLEdBQUNydEIsQ0FBQztFQUFBLENBQUM7RUFBQ0ksa0JBQWtCQSxDQUFDSixDQUFDLEVBQUM7SUFBQ0ksa0JBQWtCLEdBQUNKLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFLak1ZLGNBQWMsQ0FBQzBzQixzQkFBc0IsR0FBRyxVQUN0Q0MsU0FBUyxFQUFFanBCLE9BQU8sRUFBRTtFQUNwQixJQUFJSSxJQUFJLEdBQUcsSUFBSTtFQUNmQSxJQUFJLENBQUNTLEtBQUssR0FBRyxJQUFJZixlQUFlLENBQUNtcEIsU0FBUyxFQUFFanBCLE9BQU8sQ0FBQztBQUN0RCxDQUFDO0FBRUQsTUFBTWtwQix5QkFBeUIsR0FBRyxDQUNoQyx5QkFBeUIsRUFDekIsWUFBWSxFQUNaLGNBQWMsRUFDZCxhQUFhLEVBQ2IsZ0JBQWdCLEVBQ2hCLGdCQUFnQixFQUNoQix3QkFBd0IsRUFDeEIsTUFBTSxFQUNOLFNBQVMsRUFDVCxRQUFRLEVBQ1IsZUFBZSxFQUNmLFFBQVEsRUFDUixRQUFRLEVBQ1IsUUFBUSxDQUNUO0FBRURub0IsTUFBTSxDQUFDQyxNQUFNLENBQUMxRSxjQUFjLENBQUMwc0Isc0JBQXNCLENBQUNwckIsU0FBUyxFQUFFO0VBQzdEOHFCLElBQUksRUFBRSxTQUFBQSxDQUFVM3FCLElBQUksRUFBRTtJQUNwQixJQUFJcUMsSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJN0MsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNaMnJCLHlCQUF5QixDQUFDMW5CLE9BQU8sQ0FDL0IsVUFBVTJuQixDQUFDLEVBQUU7TUFDWDVyQixHQUFHLENBQUM0ckIsQ0FBQyxDQUFDLEdBQUdoc0IsQ0FBQyxDQUFDRyxJQUFJLENBQUM4QyxJQUFJLENBQUNTLEtBQUssQ0FBQ3NvQixDQUFDLENBQUMsRUFBRS9vQixJQUFJLENBQUNTLEtBQUssRUFBRTlDLElBQUksQ0FBQztNQUVoRCxJQUFJLENBQUNnckIsd0JBQXdCLENBQUNLLFFBQVEsQ0FBQ0QsQ0FBQyxDQUFDLEVBQUU7TUFDM0MsTUFBTUUsZUFBZSxHQUFHdnRCLGtCQUFrQixDQUFDcXRCLENBQUMsQ0FBQztNQUM3QzVyQixHQUFHLENBQUM4ckIsZUFBZSxDQUFDLEdBQUcsWUFBbUI7UUFDeEMsSUFBSTtVQUNGLE9BQU90bUIsT0FBTyxDQUFDc0ssT0FBTyxDQUFDOVAsR0FBRyxDQUFDNHJCLENBQUMsQ0FBQyxDQUFDLEdBQUFuZ0IsU0FBTyxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLE9BQU9ULEtBQUssRUFBRTtVQUNkLE9BQU94RixPQUFPLENBQUN1SyxNQUFNLENBQUMvRSxLQUFLLENBQUM7UUFDOUI7TUFDRixDQUFDO0lBQ0gsQ0FBQyxDQUFDO0lBQ0osT0FBT2hMLEdBQUc7RUFDWjtBQUNGLENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0E7QUFDQWpCLGNBQWMsQ0FBQ2d0Qiw2QkFBNkIsR0FBR25zQixDQUFDLENBQUNvc0IsSUFBSSxDQUFDLFlBQVk7RUFDaEUsSUFBSUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO0VBRTFCLElBQUlDLFFBQVEsR0FBRzVVLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDNFUsU0FBUztFQUVwQyxJQUFJN1UsT0FBTyxDQUFDQyxHQUFHLENBQUM2VSxlQUFlLEVBQUU7SUFDL0JILGlCQUFpQixDQUFDN21CLFFBQVEsR0FBR2tTLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDNlUsZUFBZTtFQUMxRDtFQUVBLElBQUksQ0FBRUYsUUFBUSxFQUNaLE1BQU0sSUFBSXRtQixLQUFLLENBQUMsc0NBQXNDLENBQUM7RUFFekQsTUFBTXVlLE1BQU0sR0FBRyxJQUFJcGxCLGNBQWMsQ0FBQzBzQixzQkFBc0IsQ0FBQ1MsUUFBUSxFQUFFRCxpQkFBaUIsQ0FBQzs7RUFFckY7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOW9CLE1BQU0sQ0FBQ2twQixPQUFPLENBQUMsTUFBTTtJQUNuQjdtQixPQUFPLENBQUNDLEtBQUssQ0FBQzBlLE1BQU0sQ0FBQzdnQixLQUFLLENBQUNxQixNQUFNLENBQUNlLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0VBRUYsT0FBT3llLE1BQU07QUFDZixDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7O0VDN0VGLElBQUlwbUIsYUFBYTtFQUFDQyxPQUFPLENBQUNDLElBQUksQ0FBQyxzQ0FBc0MsRUFBQztJQUFDQyxPQUFPQSxDQUFDQyxDQUFDLEVBQUM7TUFBQ0osYUFBYSxHQUFDSSxDQUFDO0lBQUE7RUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBQXRHSCxPQUFPLENBQUM0Z0IsTUFBTSxDQUFDO0lBQUMwTixlQUFlLEVBQUNBLENBQUEsS0FBSUE7RUFBZSxDQUFDLENBQUM7RUFBQyxJQUFJZCx3QkFBd0IsRUFBQ2p0QixrQkFBa0I7RUFBQ1AsT0FBTyxDQUFDQyxJQUFJLENBQUMsNEJBQTRCLEVBQUM7SUFBQ3V0Qix3QkFBd0JBLENBQUNydEIsQ0FBQyxFQUFDO01BQUNxdEIsd0JBQXdCLEdBQUNydEIsQ0FBQztJQUFBLENBQUM7SUFBQ0ksa0JBQWtCQSxDQUFDSixDQUFDLEVBQUM7TUFBQ0ksa0JBQWtCLEdBQUNKLENBQUM7SUFBQTtFQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7RUFBQyxJQUFJQyxtQkFBbUI7RUFBQ0osT0FBTyxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0lBQUNHLG1CQUFtQkEsQ0FBQ0QsQ0FBQyxFQUFDO01BQUNDLG1CQUFtQixHQUFDRCxDQUFDO0lBQUE7RUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0VBUXpWLFNBQVNtdUIsZUFBZUEsQ0FBQzNjLFVBQVUsRUFBRXpKLGNBQWMsRUFBRTJKLGlCQUFpQixFQUFFO0lBQzdFLElBQ0V5SCxPQUFPLENBQUNDLEdBQUcsQ0FBQ2dWLHVCQUF1QjtJQUFJO0lBQ3ZDLENBQUMxYyxpQkFBaUIsQ0FBQztJQUFBLEVBQ25CO01BQ0EsSUFBSTNKLGNBQWMsS0FBS3hFLFNBQVMsSUFBSXdFLGNBQWMsQ0FBQzJsQixRQUFRLENBQUMsT0FBTyxDQUFDLEVBQ2xFO01BQ0YzQixPQUFPLENBQUNzQyxJQUFJLDZCQUFBckQsTUFBQSxDQUVJampCLGNBQWMsT0FBQWlqQixNQUFBLENBQUl4WixVQUFVLGlIQUU3QixDQUFDO01BQ2hCdWEsT0FBTyxDQUFDdUMsS0FBSyxDQUFDLENBQUM7SUFDakI7RUFDRjtFQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0F2ckIsS0FBSyxHQUFHLENBQUMsQ0FBQzs7RUFFVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0FBLEtBQUssQ0FBQ3lOLFVBQVUsR0FBRyxTQUFTQSxVQUFVQSxDQUFDbk8sSUFBSSxFQUFFaUMsT0FBTyxFQUFFO0lBQ3BELElBQUksQ0FBQ2pDLElBQUksSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtNQUMxQjJDLE1BQU0sQ0FBQzZXLE1BQU0sQ0FDWCx5REFBeUQsR0FDdkQseURBQXlELEdBQ3pELGdEQUNKLENBQUM7TUFDRHhaLElBQUksR0FBRyxJQUFJO0lBQ2I7SUFFQSxJQUFJQSxJQUFJLEtBQUssSUFBSSxJQUFJLE9BQU9BLElBQUksS0FBSyxRQUFRLEVBQUU7TUFDN0MsTUFBTSxJQUFJb0YsS0FBSyxDQUNiLGlFQUNGLENBQUM7SUFDSDtJQUVBLElBQUluRCxPQUFPLElBQUlBLE9BQU8sQ0FBQ2dPLE9BQU8sRUFBRTtNQUM5QjtNQUNBO01BQ0E7TUFDQTtNQUNBaE8sT0FBTyxHQUFHO1FBQUVpcUIsVUFBVSxFQUFFanFCO01BQVEsQ0FBQztJQUNuQztJQUNBO0lBQ0EsSUFBSUEsT0FBTyxJQUFJQSxPQUFPLENBQUNrcUIsT0FBTyxJQUFJLENBQUNscUIsT0FBTyxDQUFDaXFCLFVBQVUsRUFBRTtNQUNyRGpxQixPQUFPLENBQUNpcUIsVUFBVSxHQUFHanFCLE9BQU8sQ0FBQ2txQixPQUFPO0lBQ3RDO0lBRUFscUIsT0FBTyxHQUFBMUUsYUFBQTtNQUNMMnVCLFVBQVUsRUFBRWhyQixTQUFTO01BQ3JCa3JCLFlBQVksRUFBRSxRQUFRO01BQ3RCM2MsU0FBUyxFQUFFLElBQUk7TUFDZjRjLE9BQU8sRUFBRW5yQixTQUFTO01BQ2xCb3JCLG1CQUFtQixFQUFFO0lBQUssR0FDdkJycUIsT0FBTyxDQUNYO0lBRUQsUUFBUUEsT0FBTyxDQUFDbXFCLFlBQVk7TUFDMUIsS0FBSyxPQUFPO1FBQ1YsSUFBSSxDQUFDRyxVQUFVLEdBQUcsWUFBVztVQUMzQixJQUFJQyxHQUFHLEdBQUd4c0IsSUFBSSxHQUNWeXNCLEdBQUcsQ0FBQ0MsWUFBWSxDQUFDLGNBQWMsR0FBRzFzQixJQUFJLENBQUMsR0FDdkMyc0IsTUFBTSxDQUFDQyxRQUFRO1VBQ25CLE9BQU8sSUFBSWxzQixLQUFLLENBQUNELFFBQVEsQ0FBQytyQixHQUFHLENBQUNLLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5QyxDQUFDO1FBQ0Q7TUFDRixLQUFLLFFBQVE7TUFDYjtRQUNFLElBQUksQ0FBQ04sVUFBVSxHQUFHLFlBQVc7VUFDM0IsSUFBSUMsR0FBRyxHQUFHeHNCLElBQUksR0FDVnlzQixHQUFHLENBQUNDLFlBQVksQ0FBQyxjQUFjLEdBQUcxc0IsSUFBSSxDQUFDLEdBQ3ZDMnNCLE1BQU0sQ0FBQ0MsUUFBUTtVQUNuQixPQUFPSixHQUFHLENBQUM3a0IsRUFBRSxDQUFDLENBQUM7UUFDakIsQ0FBQztRQUNEO0lBQ0o7SUFFQSxJQUFJLENBQUMrSixVQUFVLEdBQUdqSyxlQUFlLENBQUNrSyxhQUFhLENBQUMxUCxPQUFPLENBQUN3TixTQUFTLENBQUM7SUFFbEUsSUFBSSxDQUFDelAsSUFBSSxJQUFJaUMsT0FBTyxDQUFDaXFCLFVBQVUsS0FBSyxJQUFJO01BQ3RDO01BQ0EsSUFBSSxDQUFDWSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQ3JCLElBQUk3cUIsT0FBTyxDQUFDaXFCLFVBQVUsRUFBRSxJQUFJLENBQUNZLFdBQVcsR0FBRzdxQixPQUFPLENBQUNpcUIsVUFBVSxDQUFDLEtBQzlELElBQUl2cEIsTUFBTSxDQUFDb3FCLFFBQVEsRUFBRSxJQUFJLENBQUNELFdBQVcsR0FBR25xQixNQUFNLENBQUN1cEIsVUFBVSxDQUFDLEtBQzFELElBQUksQ0FBQ1ksV0FBVyxHQUFHbnFCLE1BQU0sQ0FBQ3FxQixNQUFNO0lBRXJDLElBQUksQ0FBQy9xQixPQUFPLENBQUNvcUIsT0FBTyxFQUFFO01BQ3BCO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFDRXJzQixJQUFJLElBQ0osSUFBSSxDQUFDOHNCLFdBQVcsS0FBS25xQixNQUFNLENBQUNxcUIsTUFBTSxJQUNsQyxPQUFPenVCLGNBQWMsS0FBSyxXQUFXLElBQ3JDQSxjQUFjLENBQUNndEIsNkJBQTZCLEVBQzVDO1FBQ0F0cEIsT0FBTyxDQUFDb3FCLE9BQU8sR0FBRzl0QixjQUFjLENBQUNndEIsNkJBQTZCLENBQUMsQ0FBQztNQUNsRSxDQUFDLE1BQU07UUFDTCxNQUFNO1VBQUVmO1FBQXNCLENBQUMsR0FBR3ZzQixPQUFPLENBQUMsOEJBQThCLENBQUM7UUFDekVnRSxPQUFPLENBQUNvcUIsT0FBTyxHQUFHN0IscUJBQXFCO01BQ3pDO0lBQ0Y7SUFFQSxJQUFJLENBQUN5QyxXQUFXLEdBQUdockIsT0FBTyxDQUFDb3FCLE9BQU8sQ0FBQzFCLElBQUksQ0FBQzNxQixJQUFJLEVBQUUsSUFBSSxDQUFDOHNCLFdBQVcsQ0FBQztJQUMvRCxJQUFJLENBQUNJLEtBQUssR0FBR2x0QixJQUFJO0lBQ2pCLElBQUksQ0FBQ3FzQixPQUFPLEdBQUdwcUIsT0FBTyxDQUFDb3FCLE9BQU87SUFFOUIsSUFBSSxDQUFDYyxzQkFBc0IsQ0FBQ250QixJQUFJLEVBQUVpQyxPQUFPLENBQUM7O0lBRTFDO0lBQ0E7SUFDQTtJQUNBLElBQUlBLE9BQU8sQ0FBQ21yQixxQkFBcUIsS0FBSyxLQUFLLEVBQUU7TUFDM0MsSUFBSTtRQUNGLElBQUksQ0FBQ0Msc0JBQXNCLENBQUM7VUFDMUJDLFdBQVcsRUFBRXJyQixPQUFPLENBQUNzckIsc0JBQXNCLEtBQUs7UUFDbEQsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU8vaUIsS0FBSyxFQUFFO1FBQ2Q7UUFDQSxJQUNFQSxLQUFLLENBQUNxVyxPQUFPLHlCQUFBOEgsTUFBQSxDQUF5QjNvQixJQUFJLGdDQUE2QixFQUV2RSxNQUFNLElBQUlvRixLQUFLLDBDQUFBdWpCLE1BQUEsQ0FBeUMzb0IsSUFBSSxPQUFHLENBQUM7UUFDbEUsTUFBTXdLLEtBQUs7TUFDYjtJQUNGOztJQUVBO0lBQ0EsSUFDRTNGLE9BQU8sQ0FBQzJvQixXQUFXLElBQ25CLENBQUN2ckIsT0FBTyxDQUFDcXFCLG1CQUFtQixJQUM1QixJQUFJLENBQUNRLFdBQVcsSUFDaEIsSUFBSSxDQUFDQSxXQUFXLENBQUNXLE9BQU8sRUFDeEI7TUFDQSxJQUFJLENBQUNYLFdBQVcsQ0FBQ1csT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLElBQUksQ0FBQy9nQixJQUFJLENBQUMsQ0FBQyxFQUFFO1FBQ2hEZ2hCLE9BQU8sRUFBRTtNQUNYLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FBQztFQUVEMXFCLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDdkMsS0FBSyxDQUFDeU4sVUFBVSxDQUFDdE8sU0FBUyxFQUFFO0lBQ3hDc3RCLHNCQUFzQkEsQ0FBQ250QixJQUFJLEVBQUEwRCxLQUFBLEVBQXNDO01BQUEsSUFBcEM7UUFBRTZwQixzQkFBc0IsR0FBRztNQUFNLENBQUMsR0FBQTdwQixLQUFBO01BQzdELE1BQU1yQixJQUFJLEdBQUcsSUFBSTtNQUNqQixJQUFJLEVBQUVBLElBQUksQ0FBQ3lxQixXQUFXLElBQUl6cUIsSUFBSSxDQUFDeXFCLFdBQVcsQ0FBQ2EsYUFBYSxDQUFDLEVBQUU7UUFDekQ7TUFDRjs7TUFFQTtNQUNBO01BQ0E7TUFDQSxNQUFNQyxFQUFFLEdBQUd2ckIsSUFBSSxDQUFDeXFCLFdBQVcsQ0FBQ2EsYUFBYSxDQUFDM3RCLElBQUksRUFBRTtRQUM5QztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBNnRCLFdBQVdBLENBQUNDLFNBQVMsRUFBRUMsS0FBSyxFQUFFO1VBQzVCO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQSxJQUFJRCxTQUFTLEdBQUcsQ0FBQyxJQUFJQyxLQUFLLEVBQUUxckIsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ2UsY0FBYyxDQUFDLENBQUM7VUFFN0QsSUFBSUQsS0FBSyxFQUFFMXJCLElBQUksQ0FBQzRxQixXQUFXLENBQUMvSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEMsQ0FBQztRQUVEO1FBQ0E7UUFDQXpYLE1BQU1BLENBQUN3aEIsR0FBRyxFQUFFO1VBQ1YsSUFBSUMsT0FBTyxHQUFHQyxPQUFPLENBQUNDLE9BQU8sQ0FBQ0gsR0FBRyxDQUFDdG1CLEVBQUUsQ0FBQztVQUNyQyxJQUFJc0ssR0FBRyxHQUFHNVAsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ29CLEtBQUssQ0FBQzduQixHQUFHLENBQUMwbkIsT0FBTyxDQUFDOztVQUU3QztVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQSxJQUFJdnJCLE1BQU0sQ0FBQ29xQixRQUFRLEVBQUU7WUFDbkIsSUFBSWtCLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLE9BQU8sSUFBSWhjLEdBQUcsRUFBRTtjQUM5QmdjLEdBQUcsQ0FBQ0EsR0FBRyxHQUFHLFNBQVM7WUFDckIsQ0FBQyxNQUFNLElBQUlBLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLFNBQVMsSUFBSSxDQUFDaGMsR0FBRyxFQUFFO2NBQ3hDO1lBQ0YsQ0FBQyxNQUFNLElBQUlnYyxHQUFHLENBQUNBLEdBQUcsS0FBSyxTQUFTLElBQUksQ0FBQ2hjLEdBQUcsRUFBRTtjQUN4Q2djLEdBQUcsQ0FBQ0EsR0FBRyxHQUFHLE9BQU87Y0FDakIxcUIsSUFBSSxHQUFHMHFCLEdBQUcsQ0FBQ3BkLE1BQU07Y0FDakIsS0FBSzJYLEtBQUssSUFBSWpsQixJQUFJLEVBQUU7Z0JBQ2xCN0QsS0FBSyxHQUFHNkQsSUFBSSxDQUFDaWxCLEtBQUssQ0FBQztnQkFDbkIsSUFBSTlvQixLQUFLLEtBQUssS0FBSyxDQUFDLEVBQUU7a0JBQ3BCLE9BQU91dUIsR0FBRyxDQUFDcGQsTUFBTSxDQUFDMlgsS0FBSyxDQUFDO2dCQUMxQjtjQUNGO1lBQ0Y7VUFDRjs7VUFFQTtVQUNBO1VBQ0E7VUFDQSxJQUFJeUYsR0FBRyxDQUFDQSxHQUFHLEtBQUssU0FBUyxFQUFFO1lBQ3pCLElBQUlycUIsT0FBTyxHQUFHcXFCLEdBQUcsQ0FBQ3JxQixPQUFPO1lBQ3pCLElBQUksQ0FBQ0EsT0FBTyxFQUFFO2NBQ1osSUFBSXFPLEdBQUcsRUFBRTVQLElBQUksQ0FBQzRxQixXQUFXLENBQUMvSSxNQUFNLENBQUNnSyxPQUFPLENBQUM7WUFDM0MsQ0FBQyxNQUFNLElBQUksQ0FBQ2pjLEdBQUcsRUFBRTtjQUNmNVAsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ3FCLE1BQU0sQ0FBQzFxQixPQUFPLENBQUM7WUFDbEMsQ0FBQyxNQUFNO2NBQ0w7Y0FDQXZCLElBQUksQ0FBQzRxQixXQUFXLENBQUN4Z0IsTUFBTSxDQUFDeWhCLE9BQU8sRUFBRXRxQixPQUFPLENBQUM7WUFDM0M7WUFDQTtVQUNGLENBQUMsTUFBTSxJQUFJcXFCLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLE9BQU8sRUFBRTtZQUM5QixJQUFJaGMsR0FBRyxFQUFFO2NBQ1AsTUFBTSxJQUFJN00sS0FBSyxDQUNiLDREQUNGLENBQUM7WUFDSDtZQUNBL0MsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ3FCLE1BQU0sQ0FBQS93QixhQUFBO2NBQUdxSyxHQUFHLEVBQUVzbUI7WUFBTyxHQUFLRCxHQUFHLENBQUNwZCxNQUFNLENBQUUsQ0FBQztVQUMxRCxDQUFDLE1BQU0sSUFBSW9kLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLFNBQVMsRUFBRTtZQUNoQyxJQUFJLENBQUNoYyxHQUFHLEVBQ04sTUFBTSxJQUFJN00sS0FBSyxDQUNiLHlEQUNGLENBQUM7WUFDSC9DLElBQUksQ0FBQzRxQixXQUFXLENBQUMvSSxNQUFNLENBQUNnSyxPQUFPLENBQUM7VUFDbEMsQ0FBQyxNQUFNLElBQUlELEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLFNBQVMsRUFBRTtZQUNoQyxJQUFJLENBQUNoYyxHQUFHLEVBQUUsTUFBTSxJQUFJN00sS0FBSyxDQUFDLHVDQUF1QyxDQUFDO1lBQ2xFLE1BQU15RixJQUFJLEdBQUc3SCxNQUFNLENBQUM2SCxJQUFJLENBQUNvakIsR0FBRyxDQUFDcGQsTUFBTSxDQUFDO1lBQ3BDLElBQUloRyxJQUFJLENBQUNHLE1BQU0sR0FBRyxDQUFDLEVBQUU7Y0FDbkIsSUFBSXNkLFFBQVEsR0FBRyxDQUFDLENBQUM7Y0FDakJ6ZCxJQUFJLENBQUNwSCxPQUFPLENBQUM5RCxHQUFHLElBQUk7Z0JBQ2xCLE1BQU1ELEtBQUssR0FBR3V1QixHQUFHLENBQUNwZCxNQUFNLENBQUNsUixHQUFHLENBQUM7Z0JBQzdCLElBQUlxQixLQUFLLENBQUNpakIsTUFBTSxDQUFDaFMsR0FBRyxDQUFDdFMsR0FBRyxDQUFDLEVBQUVELEtBQUssQ0FBQyxFQUFFO2tCQUNqQztnQkFDRjtnQkFDQSxJQUFJLE9BQU9BLEtBQUssS0FBSyxXQUFXLEVBQUU7a0JBQ2hDLElBQUksQ0FBQzRvQixRQUFRLENBQUN3QixNQUFNLEVBQUU7b0JBQ3BCeEIsUUFBUSxDQUFDd0IsTUFBTSxHQUFHLENBQUMsQ0FBQztrQkFDdEI7a0JBQ0F4QixRQUFRLENBQUN3QixNQUFNLENBQUNucUIsR0FBRyxDQUFDLEdBQUcsQ0FBQztnQkFDMUIsQ0FBQyxNQUFNO2tCQUNMLElBQUksQ0FBQzJvQixRQUFRLENBQUMwQixJQUFJLEVBQUU7b0JBQ2xCMUIsUUFBUSxDQUFDMEIsSUFBSSxHQUFHLENBQUMsQ0FBQztrQkFDcEI7a0JBQ0ExQixRQUFRLENBQUMwQixJQUFJLENBQUNycUIsR0FBRyxDQUFDLEdBQUdELEtBQUs7Z0JBQzVCO2NBQ0YsQ0FBQyxDQUFDO2NBQ0YsSUFBSXNELE1BQU0sQ0FBQzZILElBQUksQ0FBQ3lkLFFBQVEsQ0FBQyxDQUFDdGQsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDcEMzSSxJQUFJLENBQUM0cUIsV0FBVyxDQUFDeGdCLE1BQU0sQ0FBQ3loQixPQUFPLEVBQUU1RixRQUFRLENBQUM7Y0FDNUM7WUFDRjtVQUNGLENBQUMsTUFBTTtZQUNMLE1BQU0sSUFBSWxqQixLQUFLLENBQUMsNENBQTRDLENBQUM7VUFDL0Q7UUFDRixDQUFDO1FBRUQ7UUFDQW1wQixTQUFTQSxDQUFBLEVBQUc7VUFDVmxzQixJQUFJLENBQUM0cUIsV0FBVyxDQUFDdUIsZUFBZSxDQUFDLENBQUM7UUFDcEMsQ0FBQztRQUVEO1FBQ0E7UUFDQUMsYUFBYUEsQ0FBQSxFQUFHO1VBQ2Rwc0IsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ3dCLGFBQWEsQ0FBQyxDQUFDO1FBQ2xDLENBQUM7UUFDREMsaUJBQWlCQSxDQUFBLEVBQUc7VUFDbEIsT0FBT3JzQixJQUFJLENBQUM0cUIsV0FBVyxDQUFDeUIsaUJBQWlCLENBQUMsQ0FBQztRQUM3QyxDQUFDO1FBRUQ7UUFDQUMsTUFBTUEsQ0FBQ2huQixFQUFFLEVBQUU7VUFDVCxPQUFPdEYsSUFBSSxDQUFDNEssT0FBTyxDQUFDdEYsRUFBRSxDQUFDO1FBQ3pCLENBQUM7UUFFRDtRQUNBaW5CLGNBQWNBLENBQUEsRUFBRztVQUNmLE9BQU92c0IsSUFBSTtRQUNiO01BQ0YsQ0FBQyxDQUFDO01BRUYsSUFBSSxDQUFDdXJCLEVBQUUsRUFBRTtRQUNQLE1BQU0vTSxPQUFPLDRDQUFBOEgsTUFBQSxDQUEyQzNvQixJQUFJLE9BQUc7UUFDL0QsSUFBSXV0QixzQkFBc0IsS0FBSyxJQUFJLEVBQUU7VUFDbkM7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTdELE9BQU8sQ0FBQ3NDLElBQUksR0FBR3RDLE9BQU8sQ0FBQ3NDLElBQUksQ0FBQ25MLE9BQU8sQ0FBQyxHQUFHNkksT0FBTyxDQUFDQyxHQUFHLENBQUM5SSxPQUFPLENBQUM7UUFDN0QsQ0FBQyxNQUFNO1VBQ0wsTUFBTSxJQUFJemIsS0FBSyxDQUFDeWIsT0FBTyxDQUFDO1FBQzFCO01BQ0Y7SUFDRixDQUFDO0lBRUQ7SUFDQTtJQUNBO0lBQ0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDRXZULGNBQWNBLENBQUEsRUFBVTtNQUN0QixPQUFPLElBQUksQ0FBQzJmLFdBQVcsQ0FBQzNmLGNBQWMsQ0FBQyxHQUFBckMsU0FBTyxDQUFDO0lBQ2pELENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDRTJDLHNCQUFzQkEsQ0FBQSxFQUFVO01BQzlCLE9BQU8sSUFBSSxDQUFDcWYsV0FBVyxDQUFDcmYsc0JBQXNCLENBQUMsR0FBQTNDLFNBQU8sQ0FBQztJQUN6RCxDQUFDO0lBRUQ0akIsZ0JBQWdCQSxDQUFDcmhCLElBQUksRUFBRTtNQUNyQixJQUFJQSxJQUFJLENBQUN4QyxNQUFNLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FDM0IsT0FBT3dDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDckIsQ0FBQztJQUVEc2hCLGVBQWVBLENBQUN0aEIsSUFBSSxFQUFFO01BQ3BCLE1BQU0sR0FBR3ZMLE9BQU8sQ0FBQyxHQUFHdUwsSUFBSSxJQUFJLEVBQUU7TUFDOUIsTUFBTXVoQixVQUFVLEdBQUdueEIsbUJBQW1CLENBQUNxRSxPQUFPLENBQUM7TUFFL0MsSUFBSUksSUFBSSxHQUFHLElBQUk7TUFDZixJQUFJbUwsSUFBSSxDQUFDeEMsTUFBTSxHQUFHLENBQUMsRUFBRTtRQUNuQixPQUFPO1VBQUV5RSxTQUFTLEVBQUVwTixJQUFJLENBQUNxUDtRQUFXLENBQUM7TUFDdkMsQ0FBQyxNQUFNO1FBQ0xpTixLQUFLLENBQ0hvUSxVQUFVLEVBQ1ZDLEtBQUssQ0FBQ0MsUUFBUSxDQUNaRCxLQUFLLENBQUNFLGVBQWUsQ0FBQztVQUNwQnRlLFVBQVUsRUFBRW9lLEtBQUssQ0FBQ0MsUUFBUSxDQUFDRCxLQUFLLENBQUNHLEtBQUssQ0FBQ25zQixNQUFNLEVBQUU5QixTQUFTLENBQUMsQ0FBQztVQUMxRHdQLElBQUksRUFBRXNlLEtBQUssQ0FBQ0MsUUFBUSxDQUNsQkQsS0FBSyxDQUFDRyxLQUFLLENBQUNuc0IsTUFBTSxFQUFFeUssS0FBSyxFQUFFakUsUUFBUSxFQUFFdEksU0FBUyxDQUNoRCxDQUFDO1VBQ0Q2TCxLQUFLLEVBQUVpaUIsS0FBSyxDQUFDQyxRQUFRLENBQUNELEtBQUssQ0FBQ0csS0FBSyxDQUFDQyxNQUFNLEVBQUVsdUIsU0FBUyxDQUFDLENBQUM7VUFDckR5UCxJQUFJLEVBQUVxZSxLQUFLLENBQUNDLFFBQVEsQ0FBQ0QsS0FBSyxDQUFDRyxLQUFLLENBQUNDLE1BQU0sRUFBRWx1QixTQUFTLENBQUM7UUFDckQsQ0FBQyxDQUNILENBQ0YsQ0FBQztRQUVELE9BQUEzRCxhQUFBO1VBQ0VrUyxTQUFTLEVBQUVwTixJQUFJLENBQUNxUDtRQUFVLEdBQ3ZCcWQsVUFBVTtNQUVqQjtJQUNGLENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNFcmlCLElBQUlBLENBQUEsRUFBVTtNQUFBLFNBQUFhLElBQUEsR0FBQXRDLFNBQUEsQ0FBQUQsTUFBQSxFQUFOd0MsSUFBSSxPQUFBQyxLQUFBLENBQUFGLElBQUEsR0FBQUcsSUFBQSxNQUFBQSxJQUFBLEdBQUFILElBQUEsRUFBQUcsSUFBQTtRQUFKRixJQUFJLENBQUFFLElBQUEsSUFBQXpDLFNBQUEsQ0FBQXlDLElBQUE7TUFBQTtNQUNWO01BQ0E7TUFDQTtNQUNBLE9BQU8sSUFBSSxDQUFDdWYsV0FBVyxDQUFDdmdCLElBQUksQ0FDMUIsSUFBSSxDQUFDbWlCLGdCQUFnQixDQUFDcmhCLElBQUksQ0FBQyxFQUMzQixJQUFJLENBQUNzaEIsZUFBZSxDQUFDdGhCLElBQUksQ0FDM0IsQ0FBQztJQUNILENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNFUCxPQUFPQSxDQUFBLEVBQVU7TUFDZjtNQUNBO01BQ0E2ZSxlQUFlLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQ29CLEtBQUssRUFBRSxJQUFJLENBQUNqZ0IsT0FBTyxDQUFDb0MsaUJBQWlCLENBQUM7TUFDdEUsSUFBSSxDQUFDcEMsT0FBTyxDQUFDb0MsaUJBQWlCLEdBQUcsS0FBSztNQUFDLFNBQUF4QixLQUFBLEdBQUE1QyxTQUFBLENBQUFELE1BQUEsRUFKOUJ3QyxJQUFJLE9BQUFDLEtBQUEsQ0FBQUksS0FBQSxHQUFBQyxLQUFBLE1BQUFBLEtBQUEsR0FBQUQsS0FBQSxFQUFBQyxLQUFBO1FBQUpOLElBQUksQ0FBQU0sS0FBQSxJQUFBN0MsU0FBQSxDQUFBNkMsS0FBQTtNQUFBO01BTWIsT0FBTyxJQUFJLENBQUNtZixXQUFXLENBQUNoZ0IsT0FBTyxDQUM3QixJQUFJLENBQUM0aEIsZ0JBQWdCLENBQUNyaEIsSUFBSSxDQUFDLEVBQzNCLElBQUksQ0FBQ3NoQixlQUFlLENBQUN0aEIsSUFBSSxDQUMzQixDQUFDO0lBQ0g7RUFDRixDQUFDLENBQUM7RUFFRnhLLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDdkMsS0FBSyxDQUFDeU4sVUFBVSxFQUFFO0lBQzlCdUIsY0FBY0EsQ0FBQ2hCLE1BQU0sRUFBRWlCLEdBQUcsRUFBRWhLLFVBQVUsRUFBRTtNQUN0QyxJQUFJa1AsYUFBYSxHQUFHbkcsTUFBTSxDQUFDc0IsY0FBYyxDQUN2QztRQUNFeUcsS0FBSyxFQUFFLFNBQUFBLENBQVM5TyxFQUFFLEVBQUVrSixNQUFNLEVBQUU7VUFDMUJsQixHQUFHLENBQUM4RyxLQUFLLENBQUM5USxVQUFVLEVBQUVnQyxFQUFFLEVBQUVrSixNQUFNLENBQUM7UUFDbkMsQ0FBQztRQUNEaVUsT0FBTyxFQUFFLFNBQUFBLENBQVNuZCxFQUFFLEVBQUVrSixNQUFNLEVBQUU7VUFDNUJsQixHQUFHLENBQUNtVixPQUFPLENBQUNuZixVQUFVLEVBQUVnQyxFQUFFLEVBQUVrSixNQUFNLENBQUM7UUFDckMsQ0FBQztRQUNEc1QsT0FBTyxFQUFFLFNBQUFBLENBQVN4YyxFQUFFLEVBQUU7VUFDcEJnSSxHQUFHLENBQUN3VSxPQUFPLENBQUN4ZSxVQUFVLEVBQUVnQyxFQUFFLENBQUM7UUFDN0I7TUFDRixDQUFDO01BQ0Q7TUFDQTtNQUNBO1FBQUU0SSxvQkFBb0IsRUFBRTtNQUFLLENBQy9CLENBQUM7O01BRUQ7TUFDQTs7TUFFQTtNQUNBWixHQUFHLENBQUNpRixNQUFNLENBQUMsWUFBVztRQUNwQkMsYUFBYSxDQUFDdlAsSUFBSSxDQUFDLENBQUM7TUFDdEIsQ0FBQyxDQUFDOztNQUVGO01BQ0EsT0FBT3VQLGFBQWE7SUFDdEIsQ0FBQztJQUVEO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQXpHLGdCQUFnQkEsQ0FBQ2hHLFFBQVEsRUFBdUI7TUFBQSxJQUFyQjtRQUFFaW5CO01BQVcsQ0FBQyxHQUFBcGtCLFNBQUEsQ0FBQUQsTUFBQSxRQUFBQyxTQUFBLFFBQUEvSixTQUFBLEdBQUErSixTQUFBLE1BQUcsQ0FBQyxDQUFDO01BQzVDO01BQ0EsSUFBSXhELGVBQWUsQ0FBQzZuQixhQUFhLENBQUNsbkIsUUFBUSxDQUFDLEVBQUVBLFFBQVEsR0FBRztRQUFFUixHQUFHLEVBQUVRO01BQVMsQ0FBQztNQUV6RSxJQUFJcUYsS0FBSyxDQUFDcE8sT0FBTyxDQUFDK0ksUUFBUSxDQUFDLEVBQUU7UUFDM0I7UUFDQTtRQUNBLE1BQU0sSUFBSWhELEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQztNQUN0RDtNQUVBLElBQUksQ0FBQ2dELFFBQVEsSUFBSyxLQUFLLElBQUlBLFFBQVEsSUFBSSxDQUFDQSxRQUFRLENBQUNSLEdBQUksRUFBRTtRQUNyRDtRQUNBLE9BQU87VUFBRUEsR0FBRyxFQUFFeW5CLFVBQVUsSUFBSTFDLE1BQU0sQ0FBQ2hsQixFQUFFLENBQUM7UUFBRSxDQUFDO01BQzNDO01BRUEsT0FBT1MsUUFBUTtJQUNqQjtFQUNGLENBQUMsQ0FBQztFQUVGcEYsTUFBTSxDQUFDQyxNQUFNLENBQUN2QyxLQUFLLENBQUN5TixVQUFVLENBQUN0TyxTQUFTLEVBQUU7SUFDeEM7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTs7SUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDRXl1QixNQUFNQSxDQUFDcmMsR0FBRyxFQUFFdE4sUUFBUSxFQUFFO01BQ3BCO01BQ0EsSUFBSSxDQUFDc04sR0FBRyxFQUFFO1FBQ1IsTUFBTSxJQUFJN00sS0FBSyxDQUFDLDZCQUE2QixDQUFDO01BQ2hEOztNQUVBO01BQ0E7TUFDQTBtQixlQUFlLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQ29CLEtBQUssRUFBRSxJQUFJLENBQUNvQixNQUFNLENBQUNqZixpQkFBaUIsQ0FBQztNQUNwRSxJQUFJLENBQUNpZixNQUFNLENBQUNqZixpQkFBaUIsR0FBRyxLQUFLOztNQUVyQztNQUNBNEMsR0FBRyxHQUFHalAsTUFBTSxDQUFDMG5CLE1BQU0sQ0FDakIxbkIsTUFBTSxDQUFDdXNCLGNBQWMsQ0FBQ3RkLEdBQUcsQ0FBQyxFQUMxQmpQLE1BQU0sQ0FBQ3dzQix5QkFBeUIsQ0FBQ3ZkLEdBQUcsQ0FDdEMsQ0FBQztNQUVELElBQUksS0FBSyxJQUFJQSxHQUFHLEVBQUU7UUFDaEIsSUFDRSxDQUFDQSxHQUFHLENBQUNySyxHQUFHLElBQ1IsRUFBRSxPQUFPcUssR0FBRyxDQUFDckssR0FBRyxLQUFLLFFBQVEsSUFBSXFLLEdBQUcsQ0FBQ3JLLEdBQUcsWUFBWWxILEtBQUssQ0FBQ0QsUUFBUSxDQUFDLEVBQ25FO1VBQ0EsTUFBTSxJQUFJMkUsS0FBSyxDQUNiLDBFQUNGLENBQUM7UUFDSDtNQUNGLENBQUMsTUFBTTtRQUNMLElBQUlxcUIsVUFBVSxHQUFHLElBQUk7O1FBRXJCO1FBQ0E7UUFDQTtRQUNBLElBQUksSUFBSSxDQUFDQyxtQkFBbUIsQ0FBQyxDQUFDLEVBQUU7VUFDOUIsTUFBTUMsU0FBUyxHQUFHbEQsR0FBRyxDQUFDbUQsd0JBQXdCLENBQUNwcEIsR0FBRyxDQUFDLENBQUM7VUFDcEQsSUFBSSxDQUFDbXBCLFNBQVMsRUFBRTtZQUNkRixVQUFVLEdBQUcsS0FBSztVQUNwQjtRQUNGO1FBRUEsSUFBSUEsVUFBVSxFQUFFO1VBQ2R4ZCxHQUFHLENBQUNySyxHQUFHLEdBQUcsSUFBSSxDQUFDMmtCLFVBQVUsQ0FBQyxDQUFDO1FBQzdCO01BQ0Y7O01BRUE7TUFDQTtNQUNBLElBQUlzRCxxQ0FBcUMsR0FBRyxTQUFBQSxDQUFTNW9CLE1BQU0sRUFBRTtRQUMzRCxJQUFJZ0wsR0FBRyxDQUFDckssR0FBRyxFQUFFO1VBQ1gsT0FBT3FLLEdBQUcsQ0FBQ3JLLEdBQUc7UUFDaEI7O1FBRUE7UUFDQTtRQUNBO1FBQ0FxSyxHQUFHLENBQUNySyxHQUFHLEdBQUdYLE1BQU07UUFFaEIsT0FBT0EsTUFBTTtNQUNmLENBQUM7TUFFRCxNQUFNNm9CLGVBQWUsR0FBR0MsWUFBWSxDQUNsQ3ByQixRQUFRLEVBQ1JrckIscUNBQ0YsQ0FBQztNQUVELElBQUksSUFBSSxDQUFDSCxtQkFBbUIsQ0FBQyxDQUFDLEVBQUU7UUFDOUIsTUFBTXpvQixNQUFNLEdBQUcsSUFBSSxDQUFDK29CLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxDQUFDL2QsR0FBRyxDQUFDLEVBQUU2ZCxlQUFlLENBQUM7UUFDeEUsT0FBT0QscUNBQXFDLENBQUM1b0IsTUFBTSxDQUFDO01BQ3REOztNQUVBO01BQ0E7TUFDQSxJQUFJO1FBQ0Y7UUFDQTtRQUNBO1FBQ0EsTUFBTUEsTUFBTSxHQUFHLElBQUksQ0FBQ2dtQixXQUFXLENBQUNxQixNQUFNLENBQUNyYyxHQUFHLEVBQUU2ZCxlQUFlLENBQUM7UUFDNUQsT0FBT0QscUNBQXFDLENBQUM1b0IsTUFBTSxDQUFDO01BQ3RELENBQUMsQ0FBQyxPQUFPTSxDQUFDLEVBQUU7UUFDVixJQUFJNUMsUUFBUSxFQUFFO1VBQ1pBLFFBQVEsQ0FBQzRDLENBQUMsQ0FBQztVQUNYLE9BQU8sSUFBSTtRQUNiO1FBQ0EsTUFBTUEsQ0FBQztNQUNUO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDRWtGLE1BQU1BLENBQUNyRSxRQUFRLEVBQUVrZ0IsUUFBUSxFQUF5QjtNQUFBLFNBQUEySCxLQUFBLEdBQUFobEIsU0FBQSxDQUFBRCxNQUFBLEVBQXBCa2xCLGtCQUFrQixPQUFBemlCLEtBQUEsQ0FBQXdpQixLQUFBLE9BQUFBLEtBQUEsV0FBQUUsS0FBQSxNQUFBQSxLQUFBLEdBQUFGLEtBQUEsRUFBQUUsS0FBQTtRQUFsQkQsa0JBQWtCLENBQUFDLEtBQUEsUUFBQWxsQixTQUFBLENBQUFrbEIsS0FBQTtNQUFBO01BQzlDLE1BQU14ckIsUUFBUSxHQUFHeXJCLG1CQUFtQixDQUFDRixrQkFBa0IsQ0FBQzs7TUFFeEQ7TUFDQTtNQUNBLE1BQU1qdUIsT0FBTyxHQUFBMUUsYUFBQSxLQUFTMnlCLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBRztNQUN0RCxJQUFJam9CLFVBQVU7TUFDZCxJQUFJaEcsT0FBTyxJQUFJQSxPQUFPLENBQUMwSCxNQUFNLEVBQUU7UUFDN0I7UUFDQSxJQUFJMUgsT0FBTyxDQUFDZ0csVUFBVSxFQUFFO1VBQ3RCLElBQ0UsRUFDRSxPQUFPaEcsT0FBTyxDQUFDZ0csVUFBVSxLQUFLLFFBQVEsSUFDdENoRyxPQUFPLENBQUNnRyxVQUFVLFlBQVl2SCxLQUFLLENBQUNELFFBQVEsQ0FDN0MsRUFFRCxNQUFNLElBQUkyRSxLQUFLLENBQUMsdUNBQXVDLENBQUM7VUFDMUQ2QyxVQUFVLEdBQUdoRyxPQUFPLENBQUNnRyxVQUFVO1FBQ2pDLENBQUMsTUFBTSxJQUFJLENBQUNHLFFBQVEsSUFBSSxDQUFDQSxRQUFRLENBQUNSLEdBQUcsRUFBRTtVQUNyQ0ssVUFBVSxHQUFHLElBQUksQ0FBQ3NrQixVQUFVLENBQUMsQ0FBQztVQUM5QnRxQixPQUFPLENBQUNxSSxXQUFXLEdBQUcsSUFBSTtVQUMxQnJJLE9BQU8sQ0FBQ2dHLFVBQVUsR0FBR0EsVUFBVTtRQUNqQztNQUNGOztNQUVBO01BQ0E7TUFDQTZqQixlQUFlLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQ29CLEtBQUssRUFBRSxJQUFJLENBQUN6Z0IsTUFBTSxDQUFDNEMsaUJBQWlCLENBQUM7TUFDcEUsSUFBSSxDQUFDNUMsTUFBTSxDQUFDNEMsaUJBQWlCLEdBQUcsS0FBSztNQUVyQ2pILFFBQVEsR0FBRzFILEtBQUssQ0FBQ3lOLFVBQVUsQ0FBQ0MsZ0JBQWdCLENBQUNoRyxRQUFRLEVBQUU7UUFDckRpbkIsVUFBVSxFQUFFcG5CO01BQ2QsQ0FBQyxDQUFDO01BRUYsTUFBTTZuQixlQUFlLEdBQUdDLFlBQVksQ0FBQ3ByQixRQUFRLENBQUM7TUFFOUMsSUFBSSxJQUFJLENBQUMrcUIsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO1FBQzlCLE1BQU1saUIsSUFBSSxHQUFHLENBQUNwRixRQUFRLEVBQUVrZ0IsUUFBUSxFQUFFcm1CLE9BQU8sQ0FBQztRQUUxQyxPQUFPLElBQUksQ0FBQyt0QixrQkFBa0IsQ0FBQyxRQUFRLEVBQUV4aUIsSUFBSSxFQUFFc2lCLGVBQWUsQ0FBQztNQUNqRTs7TUFFQTtNQUNBO01BQ0EsSUFBSTtRQUNGO1FBQ0E7UUFDQTtRQUNBLE9BQU8sSUFBSSxDQUFDN0MsV0FBVyxDQUFDeGdCLE1BQU0sQ0FDNUJyRSxRQUFRLEVBQ1JrZ0IsUUFBUSxFQUNScm1CLE9BQU8sRUFDUDZ0QixlQUNGLENBQUM7TUFDSCxDQUFDLENBQUMsT0FBT3ZvQixDQUFDLEVBQUU7UUFDVixJQUFJNUMsUUFBUSxFQUFFO1VBQ1pBLFFBQVEsQ0FBQzRDLENBQUMsQ0FBQztVQUNYLE9BQU8sSUFBSTtRQUNiO1FBQ0EsTUFBTUEsQ0FBQztNQUNUO0lBQ0YsQ0FBQztJQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNFMmMsTUFBTUEsQ0FBQzliLFFBQVEsRUFBRXpELFFBQVEsRUFBRTtNQUN6QnlELFFBQVEsR0FBRzFILEtBQUssQ0FBQ3lOLFVBQVUsQ0FBQ0MsZ0JBQWdCLENBQUNoRyxRQUFRLENBQUM7TUFFdEQsTUFBTTBuQixlQUFlLEdBQUdDLFlBQVksQ0FBQ3ByQixRQUFRLENBQUM7TUFFOUMsSUFBSSxJQUFJLENBQUMrcUIsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO1FBQzlCLE9BQU8sSUFBSSxDQUFDTSxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQzVuQixRQUFRLENBQUMsRUFBRTBuQixlQUFlLENBQUM7TUFDdkU7O01BRUE7TUFDQTtNQUNBaEUsZUFBZSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUNvQixLQUFLLEVBQUUsSUFBSSxDQUFDaEosTUFBTSxDQUFDN1UsaUJBQWlCLENBQUM7TUFDcEUsSUFBSSxDQUFDNlUsTUFBTSxDQUFDN1UsaUJBQWlCLEdBQUcsS0FBSztNQUNyQztNQUNBO01BQ0EsSUFBSTtRQUNGO1FBQ0E7UUFDQTtRQUNBLE9BQU8sSUFBSSxDQUFDNGQsV0FBVyxDQUFDL0ksTUFBTSxDQUFDOWIsUUFBUSxFQUFFMG5CLGVBQWUsQ0FBQztNQUMzRCxDQUFDLENBQUMsT0FBT3ZvQixDQUFDLEVBQUU7UUFDVixJQUFJNUMsUUFBUSxFQUFFO1VBQ1pBLFFBQVEsQ0FBQzRDLENBQUMsQ0FBQztVQUNYLE9BQU8sSUFBSTtRQUNiO1FBQ0EsTUFBTUEsQ0FBQztNQUNUO0lBQ0YsQ0FBQztJQUVEO0lBQ0E7SUFDQW1vQixtQkFBbUJBLENBQUEsRUFBRztNQUNwQjtNQUNBLE9BQU8sSUFBSSxDQUFDNUMsV0FBVyxJQUFJLElBQUksQ0FBQ0EsV0FBVyxLQUFLbnFCLE1BQU0sQ0FBQ3FxQixNQUFNO0lBQy9ELENBQUM7SUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDRXJqQixNQUFNQSxDQUFDdkIsUUFBUSxFQUFFa2dCLFFBQVEsRUFBRXJtQixPQUFPLEVBQUUwQyxRQUFRLEVBQUU7TUFDNUMsSUFBSSxDQUFDQSxRQUFRLElBQUksT0FBTzFDLE9BQU8sS0FBSyxVQUFVLEVBQUU7UUFDOUMwQyxRQUFRLEdBQUcxQyxPQUFPO1FBQ2xCQSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BQ2Q7O01BRUE7TUFDQTtNQUNBNnBCLGVBQWUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDb0IsS0FBSyxFQUFFLElBQUksQ0FBQ3ZqQixNQUFNLENBQUMwRixpQkFBaUIsQ0FBQztNQUNwRSxJQUFJLENBQUMxRixNQUFNLENBQUMwRixpQkFBaUIsR0FBRyxLQUFLO01BQ3JDO01BQ0EsSUFBSSxDQUFDNUMsTUFBTSxDQUFDNEMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLENBQUM7TUFDdEMsT0FBTyxJQUFJLENBQUM1QyxNQUFNLENBQ2hCckUsUUFBUSxFQUNSa2dCLFFBQVEsRUFBQS9xQixhQUFBLENBQUFBLGFBQUEsS0FFSDBFLE9BQU87UUFDVndJLGFBQWEsRUFBRSxJQUFJO1FBQ25CZCxNQUFNLEVBQUU7TUFBSSxJQUVkaEYsUUFDRixDQUFDO0lBQ0gsQ0FBQztJQUVEO0lBQ0E7SUFDQW9KLFlBQVlBLENBQUNYLEtBQUssRUFBRW5MLE9BQU8sRUFBRTtNQUMzQixJQUFJSSxJQUFJLEdBQUcsSUFBSTtNQUNmLElBQUksQ0FBQ0EsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ2xmLFlBQVksSUFBSSxDQUFDMUwsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQzVmLFdBQVcsRUFDakUsTUFBTSxJQUFJakksS0FBSyxDQUFDLGlEQUFpRCxDQUFDO01BQ3BFLElBQUkvQyxJQUFJLENBQUM0cUIsV0FBVyxDQUFDNWYsV0FBVyxFQUFFO1FBQ2hDaEwsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQzVmLFdBQVcsQ0FBQ0QsS0FBSyxFQUFFbkwsT0FBTyxDQUFDO01BQzlDLENBQUMsTUFBTTtRQXB5QlgsSUFBSW91QixHQUFHO1FBQUM3eUIsT0FBTyxDQUFDQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUM7VUFBQzR5QixHQUFHQSxDQUFDMXlCLENBQUMsRUFBQztZQUFDMHlCLEdBQUcsR0FBQzF5QixDQUFDO1VBQUE7UUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1FBc3lCbEQweUIsR0FBRyxDQUFDQyxLQUFLLDhFQUFBM0gsTUFBQSxDQUVMMW1CLE9BQU8sYUFBUEEsT0FBTyxlQUFQQSxPQUFPLENBQUVqQyxJQUFJLG9CQUFBMm9CLE1BQUEsQ0FDUTFtQixPQUFPLENBQUNqQyxJQUFJLGdCQUFBMm9CLE1BQUEsQ0FDakIvSCxJQUFJLENBQUN0TSxTQUFTLENBQUNsSCxLQUFLLENBQUMsQ0FBRSxDQUUzQyxDQUFDO1FBQ0QvSyxJQUFJLENBQUM0cUIsV0FBVyxDQUFDbGYsWUFBWSxDQUFDWCxLQUFLLEVBQUVuTCxPQUFPLENBQUM7TUFDL0M7SUFDRixDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0VvTCxXQUFXQSxDQUFDRCxLQUFLLEVBQUVuTCxPQUFPLEVBQUU7TUFDMUIsSUFBSUksSUFBSSxHQUFHLElBQUk7TUFDZixJQUFJLENBQUNBLElBQUksQ0FBQzRxQixXQUFXLENBQUM1ZixXQUFXLEVBQy9CLE1BQU0sSUFBSWpJLEtBQUssQ0FBQyxpREFBaUQsQ0FBQztNQUNwRTtNQUNBO01BQ0EwbUIsZUFBZSxDQUNiLGFBQWEsRUFDYnpwQixJQUFJLENBQUM2cUIsS0FBSyxFQUNWN3FCLElBQUksQ0FBQ2dMLFdBQVcsQ0FBQ2dDLGlCQUNuQixDQUFDO01BQ0RoTixJQUFJLENBQUNnTCxXQUFXLENBQUNnQyxpQkFBaUIsR0FBRyxLQUFLO01BQzFDLElBQUk7UUFDRmhOLElBQUksQ0FBQzRxQixXQUFXLENBQUM1ZixXQUFXLENBQUNELEtBQUssRUFBRW5MLE9BQU8sQ0FBQztNQUM5QyxDQUFDLENBQUMsT0FBT3NGLENBQUMsRUFBRTtRQUFBLElBQUFyRixnQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQTtRQUNWLElBQ0VtRixDQUFDLENBQUNzWixPQUFPLENBQUN3SyxRQUFRLENBQ2hCLDhFQUNGLENBQUMsS0FBQW5wQixnQkFBQSxHQUNEUyxNQUFNLENBQUNDLFFBQVEsY0FBQVYsZ0JBQUEsZ0JBQUFDLHFCQUFBLEdBQWZELGdCQUFBLENBQWlCVyxRQUFRLGNBQUFWLHFCQUFBLGdCQUFBQyxzQkFBQSxHQUF6QkQscUJBQUEsQ0FBMkJXLEtBQUssY0FBQVYsc0JBQUEsZUFBaENBLHNCQUFBLENBQWtDbXVCLDZCQUE2QixFQUMvRDtVQWoxQlIsSUFBSUYsR0FBRztVQUFDN3lCLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLGdCQUFnQixFQUFDO1lBQUM0eUIsR0FBR0EsQ0FBQzF5QixDQUFDLEVBQUM7Y0FBQzB5QixHQUFHLEdBQUMxeUIsQ0FBQztZQUFBO1VBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztVQW8xQmhEMHlCLEdBQUcsQ0FBQ0csSUFBSSxzQkFBQTdILE1BQUEsQ0FDZXZiLEtBQUssV0FBQXViLE1BQUEsQ0FBUXRtQixJQUFJLENBQUM2cUIsS0FBSyw4QkFDOUMsQ0FBQztVQUNEN3FCLElBQUksQ0FBQzRxQixXQUFXLENBQUNqZixVQUFVLENBQUNaLEtBQUssQ0FBQztVQUNsQy9LLElBQUksQ0FBQzRxQixXQUFXLENBQUM1ZixXQUFXLENBQUNELEtBQUssRUFBRW5MLE9BQU8sQ0FBQztRQUM5QyxDQUFDLE1BQU07VUFDTCxNQUFNLElBQUlVLE1BQU0sQ0FBQ3lDLEtBQUssOERBQUF1akIsTUFBQSxDQUN3Q3RtQixJQUFJLENBQUM2cUIsS0FBSyxRQUFBdkUsTUFBQSxDQUFLcGhCLENBQUMsQ0FBQ3NaLE9BQU8sQ0FDdEYsQ0FBQztRQUNIO01BQ0Y7SUFDRixDQUFDO0lBRUQ3UyxVQUFVQSxDQUFDWixLQUFLLEVBQUU7TUFDaEIsSUFBSS9LLElBQUksR0FBRyxJQUFJO01BQ2YsSUFBSSxDQUFDQSxJQUFJLENBQUM0cUIsV0FBVyxDQUFDamYsVUFBVSxFQUM5QixNQUFNLElBQUk1SSxLQUFLLENBQUMsZ0RBQWdELENBQUM7TUFDbkUvQyxJQUFJLENBQUM0cUIsV0FBVyxDQUFDamYsVUFBVSxDQUFDWixLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUVEcEUsZUFBZUEsQ0FBQSxFQUFHO01BQ2hCLElBQUkzRyxJQUFJLEdBQUcsSUFBSTtNQUNmLElBQUksQ0FBQ0EsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQy9qQixjQUFjLEVBQ2xDLE1BQU0sSUFBSTlELEtBQUssQ0FBQyxxREFBcUQsQ0FBQztNQUN4RS9DLElBQUksQ0FBQzRxQixXQUFXLENBQUMvakIsY0FBYyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVEdEQsdUJBQXVCQSxDQUFDQyxRQUFRLEVBQUVDLFlBQVksRUFBRTtNQUM5QyxJQUFJekQsSUFBSSxHQUFHLElBQUk7TUFDZixJQUFJLENBQUNBLElBQUksQ0FBQzRxQixXQUFXLENBQUNybkIsdUJBQXVCLEVBQzNDLE1BQU0sSUFBSVIsS0FBSyxDQUNiLDZEQUNGLENBQUM7O01BRUg7TUFDQTtNQUNBMG1CLGVBQWUsQ0FDYix5QkFBeUIsRUFDekJ6cEIsSUFBSSxDQUFDNnFCLEtBQUssRUFDVjdxQixJQUFJLENBQUN1RCx1QkFBdUIsQ0FBQ3lKLGlCQUMvQixDQUFDO01BQ0RoTixJQUFJLENBQUN1RCx1QkFBdUIsQ0FBQ3lKLGlCQUFpQixHQUFHLEtBQUs7TUFDdERoTixJQUFJLENBQUM0cUIsV0FBVyxDQUFDcm5CLHVCQUF1QixDQUFDQyxRQUFRLEVBQUVDLFlBQVksQ0FBQztJQUNsRSxDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0VMLGFBQWFBLENBQUEsRUFBRztNQUNkLElBQUlwRCxJQUFJLEdBQUcsSUFBSTtNQUNmLElBQUksQ0FBQ0EsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ3huQixhQUFhLEVBQUU7UUFDbkMsTUFBTSxJQUFJTCxLQUFLLENBQUMsbURBQW1ELENBQUM7TUFDdEU7TUFDQSxPQUFPL0MsSUFBSSxDQUFDNHFCLFdBQVcsQ0FBQ3huQixhQUFhLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0VnckIsV0FBV0EsQ0FBQSxFQUFHO01BQ1osSUFBSXB1QixJQUFJLEdBQUcsSUFBSTtNQUNmLElBQUksRUFBRUEsSUFBSSxDQUFDZ3FCLE9BQU8sQ0FBQ3ZwQixLQUFLLElBQUlULElBQUksQ0FBQ2dxQixPQUFPLENBQUN2cEIsS0FBSyxDQUFDa0IsRUFBRSxDQUFDLEVBQUU7UUFDbEQsTUFBTSxJQUFJb0IsS0FBSyxDQUFDLGlEQUFpRCxDQUFDO01BQ3BFO01BQ0EsT0FBTy9DLElBQUksQ0FBQ2dxQixPQUFPLENBQUN2cEIsS0FBSyxDQUFDa0IsRUFBRTtJQUM5QjtFQUNGLENBQUMsQ0FBQzs7RUFFRjtFQUNBLFNBQVMrckIsWUFBWUEsQ0FBQ3ByQixRQUFRLEVBQUUrckIsYUFBYSxFQUFFO0lBQzdDLE9BQ0UvckIsUUFBUSxJQUNSLFVBQVM2RixLQUFLLEVBQUV2RCxNQUFNLEVBQUU7TUFDdEIsSUFBSXVELEtBQUssRUFBRTtRQUNUN0YsUUFBUSxDQUFDNkYsS0FBSyxDQUFDO01BQ2pCLENBQUMsTUFBTSxJQUFJLE9BQU9rbUIsYUFBYSxLQUFLLFVBQVUsRUFBRTtRQUM5Qy9yQixRQUFRLENBQUM2RixLQUFLLEVBQUVrbUIsYUFBYSxDQUFDenBCLE1BQU0sQ0FBQyxDQUFDO01BQ3hDLENBQUMsTUFBTTtRQUNMdEMsUUFBUSxDQUFDNkYsS0FBSyxFQUFFdkQsTUFBTSxDQUFDO01BQ3pCO0lBQ0YsQ0FBQztFQUVMOztFQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNBdkcsS0FBSyxDQUFDRCxRQUFRLEdBQUcwdEIsT0FBTyxDQUFDMXRCLFFBQVE7O0VBRWpDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDQUMsS0FBSyxDQUFDaU0sTUFBTSxHQUFHbEYsZUFBZSxDQUFDa0YsTUFBTTs7RUFFckM7QUFDQTtBQUNBO0VBQ0FqTSxLQUFLLENBQUN5TixVQUFVLENBQUN4QixNQUFNLEdBQUdqTSxLQUFLLENBQUNpTSxNQUFNOztFQUV0QztBQUNBO0FBQ0E7RUFDQWpNLEtBQUssQ0FBQ3lOLFVBQVUsQ0FBQzFOLFFBQVEsR0FBR0MsS0FBSyxDQUFDRCxRQUFROztFQUUxQztBQUNBO0FBQ0E7RUFDQWtDLE1BQU0sQ0FBQ3dMLFVBQVUsR0FBR3pOLEtBQUssQ0FBQ3lOLFVBQVU7O0VBRXBDO0VBQ0FuTCxNQUFNLENBQUNDLE1BQU0sQ0FBQ3ZDLEtBQUssQ0FBQ3lOLFVBQVUsQ0FBQ3RPLFNBQVMsRUFBRTh3QixTQUFTLENBQUNDLG1CQUFtQixDQUFDO0VBRXhFLFNBQVNSLG1CQUFtQkEsQ0FBQzVpQixJQUFJLEVBQUU7SUFDakM7SUFDQTtJQUNBLElBQ0VBLElBQUksQ0FBQ3hDLE1BQU0sS0FDVndDLElBQUksQ0FBQ0EsSUFBSSxDQUFDeEMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLOUosU0FBUyxJQUNsQ3NNLElBQUksQ0FBQ0EsSUFBSSxDQUFDeEMsTUFBTSxHQUFHLENBQUMsQ0FBQyxZQUFZeEIsUUFBUSxDQUFDLEVBQzVDO01BQ0EsT0FBT2dFLElBQUksQ0FBQytOLEdBQUcsQ0FBQyxDQUFDO0lBQ25CO0VBQ0Y7RUFFQXlQLHdCQUF3QixDQUFDdm5CLE9BQU8sQ0FBQzBMLFVBQVUsSUFBSTtJQUM3QyxNQUFNQyxlQUFlLEdBQUdyUixrQkFBa0IsQ0FBQ29SLFVBQVUsQ0FBQztJQUN0RHpPLEtBQUssQ0FBQ3lOLFVBQVUsQ0FBQ3RPLFNBQVMsQ0FBQ3VQLGVBQWUsQ0FBQyxHQUFHLFlBQWtCO01BQzlELElBQUk7UUFDRjtRQUNBLElBQUksQ0FBQ0QsVUFBVSxDQUFDLENBQUNFLGlCQUFpQixHQUFHLElBQUk7UUFDekMsT0FBT3JLLE9BQU8sQ0FBQ3NLLE9BQU8sQ0FBQyxJQUFJLENBQUNILFVBQVUsQ0FBQyxDQUFDLEdBQUFsRSxTQUFPLENBQUMsQ0FBQztNQUNuRCxDQUFDLENBQUMsT0FBT1QsS0FBSyxFQUFFO1FBQ2QsT0FBT3hGLE9BQU8sQ0FBQ3VLLE1BQU0sQ0FBQy9FLEtBQUssQ0FBQztNQUM5QjtJQUNGLENBQUM7RUFDSCxDQUFDLENBQUM7QUFBQyxFQUFBeUksSUFBQSxPQUFBclUsTUFBQSxFOzs7Ozs7Ozs7OztBQ3QrQkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E4QixLQUFLLENBQUNtd0Isb0JBQW9CLEdBQUcsU0FBU0Esb0JBQW9CQSxDQUFFNXVCLE9BQU8sRUFBRTtFQUNuRTBjLEtBQUssQ0FBQzFjLE9BQU8sRUFBRWUsTUFBTSxDQUFDO0VBQ3RCdEMsS0FBSyxDQUFDZ0Msa0JBQWtCLEdBQUdULE9BQU87QUFDcEMsQ0FBQyxDOzs7Ozs7Ozs7Ozs7QUNURCxJQUFJMUUsYUFBYTtBQUFDcUIsTUFBTSxDQUFDbkIsSUFBSSxDQUFDLHNDQUFzQyxFQUFDO0VBQUNDLE9BQU9BLENBQUNDLENBQUMsRUFBQztJQUFDSixhQUFhLEdBQUNJLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJbWUsd0JBQXdCO0FBQUNsZCxNQUFNLENBQUNuQixJQUFJLENBQUMsZ0RBQWdELEVBQUM7RUFBQ0MsT0FBT0EsQ0FBQ0MsQ0FBQyxFQUFDO0lBQUNtZSx3QkFBd0IsR0FBQ25lLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBM09pQixNQUFNLENBQUN3ZixNQUFNLENBQUM7RUFBQ3hnQixtQkFBbUIsRUFBQ0EsQ0FBQSxLQUFJQTtBQUFtQixDQUFDLENBQUM7QUFBckQsTUFBTUEsbUJBQW1CLEdBQUdxRSxPQUFPLElBQUk7RUFDNUM7RUFDQSxNQUFBc0IsSUFBQSxHQUFnRHRCLE9BQU8sSUFBSSxDQUFDLENBQUM7SUFBdkQ7TUFBRTRPLE1BQU07TUFBRUQ7SUFBNEIsQ0FBQyxHQUFBck4sSUFBQTtJQUFkdXRCLFlBQVksR0FBQWhWLHdCQUFBLENBQUF2WSxJQUFBLEVBQUF5YSxTQUFBO0VBQzNDO0VBQ0E7O0VBRUEsT0FBQXpnQixhQUFBLENBQUFBLGFBQUEsS0FDS3V6QixZQUFZLEdBQ1hsZ0IsVUFBVSxJQUFJQyxNQUFNLEdBQUc7SUFBRUQsVUFBVSxFQUFFQyxNQUFNLElBQUlEO0VBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUV4RSxDQUFDLEMiLCJmaWxlIjoiL3BhY2thZ2VzL21vbmdvLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbm9ybWFsaXplUHJvamVjdGlvbiB9IGZyb20gXCIuL21vbmdvX3V0aWxzXCI7XG5cbi8qKlxuICogUHJvdmlkZSBhIHN5bmNocm9ub3VzIENvbGxlY3Rpb24gQVBJIHVzaW5nIGZpYmVycywgYmFja2VkIGJ5XG4gKiBNb25nb0RCLiAgVGhpcyBpcyBvbmx5IGZvciB1c2Ugb24gdGhlIHNlcnZlciwgYW5kIG1vc3RseSBpZGVudGljYWxcbiAqIHRvIHRoZSBjbGllbnQgQVBJLlxuICpcbiAqIE5PVEU6IHRoZSBwdWJsaWMgQVBJIG1ldGhvZHMgbXVzdCBiZSBydW4gd2l0aGluIGEgZmliZXIuIElmIHlvdSBjYWxsXG4gKiB0aGVzZSBvdXRzaWRlIG9mIGEgZmliZXIgdGhleSB3aWxsIGV4cGxvZGUhXG4gKi9cblxuY29uc3QgcGF0aCA9IHJlcXVpcmUoXCJwYXRoXCIpO1xuY29uc3QgdXRpbCA9IHJlcXVpcmUoXCJ1dGlsXCIpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnbW9uZ29kYicpfSAqL1xudmFyIE1vbmdvREIgPSBOcG1Nb2R1bGVNb25nb2RiO1xudmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKCdmaWJlcnMvZnV0dXJlJyk7XG5pbXBvcnQgeyBEb2NGZXRjaGVyIH0gZnJvbSBcIi4vZG9jX2ZldGNoZXIuanNcIjtcbmltcG9ydCB7XG4gIEFTWU5DX0NVUlNPUl9NRVRIT0RTLFxuICBnZXRBc3luY01ldGhvZE5hbWVcbn0gZnJvbSBcIm1ldGVvci9taW5pbW9uZ28vY29uc3RhbnRzXCI7XG5cbk1vbmdvSW50ZXJuYWxzID0ge307XG5cbk1vbmdvSW50ZXJuYWxzLk5wbU1vZHVsZXMgPSB7XG4gIG1vbmdvZGI6IHtcbiAgICB2ZXJzaW9uOiBOcG1Nb2R1bGVNb25nb2RiVmVyc2lvbixcbiAgICBtb2R1bGU6IE1vbmdvREJcbiAgfVxufTtcblxuLy8gT2xkZXIgdmVyc2lvbiBvZiB3aGF0IGlzIG5vdyBhdmFpbGFibGUgdmlhXG4vLyBNb25nb0ludGVybmFscy5OcG1Nb2R1bGVzLm1vbmdvZGIubW9kdWxlLiAgSXQgd2FzIG5ldmVyIGRvY3VtZW50ZWQsIGJ1dFxuLy8gcGVvcGxlIGRvIHVzZSBpdC5cbi8vIFhYWCBDT01QQVQgV0lUSCAxLjAuMy4yXG5Nb25nb0ludGVybmFscy5OcG1Nb2R1bGUgPSBNb25nb0RCO1xuXG5jb25zdCBGSUxFX0FTU0VUX1NVRkZJWCA9ICdBc3NldCc7XG5jb25zdCBBU1NFVFNfRk9MREVSID0gJ2Fzc2V0cyc7XG5jb25zdCBBUFBfRk9MREVSID0gJ2FwcCc7XG5cbi8vIFRoaXMgaXMgdXNlZCB0byBhZGQgb3IgcmVtb3ZlIEVKU09OIGZyb20gdGhlIGJlZ2lubmluZyBvZiBldmVyeXRoaW5nIG5lc3RlZFxuLy8gaW5zaWRlIGFuIEVKU09OIGN1c3RvbSB0eXBlLiBJdCBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gcHVyZSBKU09OIVxudmFyIHJlcGxhY2VOYW1lcyA9IGZ1bmN0aW9uIChmaWx0ZXIsIHRoaW5nKSB7XG4gIGlmICh0eXBlb2YgdGhpbmcgPT09IFwib2JqZWN0XCIgJiYgdGhpbmcgIT09IG51bGwpIHtcbiAgICBpZiAoXy5pc0FycmF5KHRoaW5nKSkge1xuICAgICAgcmV0dXJuIF8ubWFwKHRoaW5nLCBfLmJpbmQocmVwbGFjZU5hbWVzLCBudWxsLCBmaWx0ZXIpKTtcbiAgICB9XG4gICAgdmFyIHJldCA9IHt9O1xuICAgIF8uZWFjaCh0aGluZywgZnVuY3Rpb24gKHZhbHVlLCBrZXkpIHtcbiAgICAgIHJldFtmaWx0ZXIoa2V5KV0gPSByZXBsYWNlTmFtZXMoZmlsdGVyLCB2YWx1ZSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHJldDtcbiAgfVxuICByZXR1cm4gdGhpbmc7XG59O1xuXG4vLyBFbnN1cmUgdGhhdCBFSlNPTi5jbG9uZSBrZWVwcyBhIFRpbWVzdGFtcCBhcyBhIFRpbWVzdGFtcCAoaW5zdGVhZCBvZiBqdXN0XG4vLyBkb2luZyBhIHN0cnVjdHVyYWwgY2xvbmUpLlxuLy8gWFhYIGhvdyBvayBpcyB0aGlzPyB3aGF0IGlmIHRoZXJlIGFyZSBtdWx0aXBsZSBjb3BpZXMgb2YgTW9uZ29EQiBsb2FkZWQ/XG5Nb25nb0RCLlRpbWVzdGFtcC5wcm90b3R5cGUuY2xvbmUgPSBmdW5jdGlvbiAoKSB7XG4gIC8vIFRpbWVzdGFtcHMgc2hvdWxkIGJlIGltbXV0YWJsZS5cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG52YXIgbWFrZU1vbmdvTGVnYWwgPSBmdW5jdGlvbiAobmFtZSkgeyByZXR1cm4gXCJFSlNPTlwiICsgbmFtZTsgfTtcbnZhciB1bm1ha2VNb25nb0xlZ2FsID0gZnVuY3Rpb24gKG5hbWUpIHsgcmV0dXJuIG5hbWUuc3Vic3RyKDUpOyB9O1xuXG52YXIgcmVwbGFjZU1vbmdvQXRvbVdpdGhNZXRlb3IgPSBmdW5jdGlvbiAoZG9jdW1lbnQpIHtcbiAgaWYgKGRvY3VtZW50IGluc3RhbmNlb2YgTW9uZ29EQi5CaW5hcnkpIHtcbiAgICAvLyBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHlcbiAgICBpZiAoZG9jdW1lbnQuc3ViX3R5cGUgIT09IDApIHtcbiAgICAgIHJldHVybiBkb2N1bWVudDtcbiAgICB9XG4gICAgdmFyIGJ1ZmZlciA9IGRvY3VtZW50LnZhbHVlKHRydWUpO1xuICAgIHJldHVybiBuZXcgVWludDhBcnJheShidWZmZXIpO1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvREIuT2JqZWN0SUQpIHtcbiAgICByZXR1cm4gbmV3IE1vbmdvLk9iamVjdElEKGRvY3VtZW50LnRvSGV4U3RyaW5nKCkpO1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvREIuRGVjaW1hbDEyOCkge1xuICAgIHJldHVybiBEZWNpbWFsKGRvY3VtZW50LnRvU3RyaW5nKCkpO1xuICB9XG4gIGlmIChkb2N1bWVudFtcIkVKU09OJHR5cGVcIl0gJiYgZG9jdW1lbnRbXCJFSlNPTiR2YWx1ZVwiXSAmJiBfLnNpemUoZG9jdW1lbnQpID09PSAyKSB7XG4gICAgcmV0dXJuIEVKU09OLmZyb21KU09OVmFsdWUocmVwbGFjZU5hbWVzKHVubWFrZU1vbmdvTGVnYWwsIGRvY3VtZW50KSk7XG4gIH1cbiAgaWYgKGRvY3VtZW50IGluc3RhbmNlb2YgTW9uZ29EQi5UaW1lc3RhbXApIHtcbiAgICAvLyBGb3Igbm93LCB0aGUgTWV0ZW9yIHJlcHJlc2VudGF0aW9uIG9mIGEgTW9uZ28gdGltZXN0YW1wIHR5cGUgKG5vdCBhIGRhdGUhXG4gICAgLy8gdGhpcyBpcyBhIHdlaXJkIGludGVybmFsIHRoaW5nIHVzZWQgaW4gdGhlIG9wbG9nISkgaXMgdGhlIHNhbWUgYXMgdGhlXG4gICAgLy8gTW9uZ28gcmVwcmVzZW50YXRpb24uIFdlIG5lZWQgdG8gZG8gdGhpcyBleHBsaWNpdGx5IG9yIGVsc2Ugd2Ugd291bGQgZG8gYVxuICAgIC8vIHN0cnVjdHVyYWwgY2xvbmUgYW5kIGxvc2UgdGhlIHByb3RvdHlwZS5cbiAgICByZXR1cm4gZG9jdW1lbnQ7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5cbnZhciByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyA9IGZ1bmN0aW9uIChkb2N1bWVudCkge1xuICBpZiAoRUpTT04uaXNCaW5hcnkoZG9jdW1lbnQpKSB7XG4gICAgLy8gVGhpcyBkb2VzIG1vcmUgY29waWVzIHRoYW4gd2UnZCBsaWtlLCBidXQgaXMgbmVjZXNzYXJ5IGJlY2F1c2VcbiAgICAvLyBNb25nb0RCLkJTT04gb25seSBsb29rcyBsaWtlIGl0IHRha2VzIGEgVWludDhBcnJheSAoYW5kIGRvZXNuJ3QgYWN0dWFsbHlcbiAgICAvLyBzZXJpYWxpemUgaXQgY29ycmVjdGx5KS5cbiAgICByZXR1cm4gbmV3IE1vbmdvREIuQmluYXJ5KEJ1ZmZlci5mcm9tKGRvY3VtZW50KSk7XG4gIH1cbiAgaWYgKGRvY3VtZW50IGluc3RhbmNlb2YgTW9uZ29EQi5CaW5hcnkpIHtcbiAgICAgcmV0dXJuIGRvY3VtZW50O1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEKSB7XG4gICAgcmV0dXJuIG5ldyBNb25nb0RCLk9iamVjdElEKGRvY3VtZW50LnRvSGV4U3RyaW5nKCkpO1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvREIuVGltZXN0YW1wKSB7XG4gICAgLy8gRm9yIG5vdywgdGhlIE1ldGVvciByZXByZXNlbnRhdGlvbiBvZiBhIE1vbmdvIHRpbWVzdGFtcCB0eXBlIChub3QgYSBkYXRlIVxuICAgIC8vIHRoaXMgaXMgYSB3ZWlyZCBpbnRlcm5hbCB0aGluZyB1c2VkIGluIHRoZSBvcGxvZyEpIGlzIHRoZSBzYW1lIGFzIHRoZVxuICAgIC8vIE1vbmdvIHJlcHJlc2VudGF0aW9uLiBXZSBuZWVkIHRvIGRvIHRoaXMgZXhwbGljaXRseSBvciBlbHNlIHdlIHdvdWxkIGRvIGFcbiAgICAvLyBzdHJ1Y3R1cmFsIGNsb25lIGFuZCBsb3NlIHRoZSBwcm90b3R5cGUuXG4gICAgcmV0dXJuIGRvY3VtZW50O1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIERlY2ltYWwpIHtcbiAgICByZXR1cm4gTW9uZ29EQi5EZWNpbWFsMTI4LmZyb21TdHJpbmcoZG9jdW1lbnQudG9TdHJpbmcoKSk7XG4gIH1cbiAgaWYgKEVKU09OLl9pc0N1c3RvbVR5cGUoZG9jdW1lbnQpKSB7XG4gICAgcmV0dXJuIHJlcGxhY2VOYW1lcyhtYWtlTW9uZ29MZWdhbCwgRUpTT04udG9KU09OVmFsdWUoZG9jdW1lbnQpKTtcbiAgfVxuICAvLyBJdCBpcyBub3Qgb3JkaW5hcmlseSBwb3NzaWJsZSB0byBzdGljayBkb2xsYXItc2lnbiBrZXlzIGludG8gbW9uZ29cbiAgLy8gc28gd2UgZG9uJ3QgYm90aGVyIGNoZWNraW5nIGZvciB0aGluZ3MgdGhhdCBuZWVkIGVzY2FwaW5nIGF0IHRoaXMgdGltZS5cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5cbnZhciByZXBsYWNlVHlwZXMgPSBmdW5jdGlvbiAoZG9jdW1lbnQsIGF0b21UcmFuc2Zvcm1lcikge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAnb2JqZWN0JyB8fCBkb2N1bWVudCA9PT0gbnVsbClcbiAgICByZXR1cm4gZG9jdW1lbnQ7XG5cbiAgdmFyIHJlcGxhY2VkVG9wTGV2ZWxBdG9tID0gYXRvbVRyYW5zZm9ybWVyKGRvY3VtZW50KTtcbiAgaWYgKHJlcGxhY2VkVG9wTGV2ZWxBdG9tICE9PSB1bmRlZmluZWQpXG4gICAgcmV0dXJuIHJlcGxhY2VkVG9wTGV2ZWxBdG9tO1xuXG4gIHZhciByZXQgPSBkb2N1bWVudDtcbiAgXy5lYWNoKGRvY3VtZW50LCBmdW5jdGlvbiAodmFsLCBrZXkpIHtcbiAgICB2YXIgdmFsUmVwbGFjZWQgPSByZXBsYWNlVHlwZXModmFsLCBhdG9tVHJhbnNmb3JtZXIpO1xuICAgIGlmICh2YWwgIT09IHZhbFJlcGxhY2VkKSB7XG4gICAgICAvLyBMYXp5IGNsb25lLiBTaGFsbG93IGNvcHkuXG4gICAgICBpZiAocmV0ID09PSBkb2N1bWVudClcbiAgICAgICAgcmV0ID0gXy5jbG9uZShkb2N1bWVudCk7XG4gICAgICByZXRba2V5XSA9IHZhbFJlcGxhY2VkO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiByZXQ7XG59O1xuXG5cbk1vbmdvQ29ubmVjdGlvbiA9IGZ1bmN0aW9uICh1cmwsIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgc2VsZi5fb2JzZXJ2ZU11bHRpcGxleGVycyA9IHt9O1xuICBzZWxmLl9vbkZhaWxvdmVySG9vayA9IG5ldyBIb29rO1xuXG4gIGNvbnN0IHVzZXJPcHRpb25zID0ge1xuICAgIC4uLihNb25nby5fY29ubmVjdGlvbk9wdGlvbnMgfHwge30pLFxuICAgIC4uLihNZXRlb3Iuc2V0dGluZ3M/LnBhY2thZ2VzPy5tb25nbz8ub3B0aW9ucyB8fCB7fSlcbiAgfTtcblxuICB2YXIgbW9uZ29PcHRpb25zID0gT2JqZWN0LmFzc2lnbih7XG4gICAgaWdub3JlVW5kZWZpbmVkOiB0cnVlLFxuICB9LCB1c2VyT3B0aW9ucyk7XG5cblxuXG4gIC8vIEludGVybmFsbHkgdGhlIG9wbG9nIGNvbm5lY3Rpb25zIHNwZWNpZnkgdGhlaXIgb3duIG1heFBvb2xTaXplXG4gIC8vIHdoaWNoIHdlIGRvbid0IHdhbnQgdG8gb3ZlcndyaXRlIHdpdGggYW55IHVzZXIgZGVmaW5lZCB2YWx1ZVxuICBpZiAoXy5oYXMob3B0aW9ucywgJ21heFBvb2xTaXplJykpIHtcbiAgICAvLyBJZiB3ZSBqdXN0IHNldCB0aGlzIGZvciBcInNlcnZlclwiLCByZXBsU2V0IHdpbGwgb3ZlcnJpZGUgaXQuIElmIHdlIGp1c3RcbiAgICAvLyBzZXQgaXQgZm9yIHJlcGxTZXQsIGl0IHdpbGwgYmUgaWdub3JlZCBpZiB3ZSdyZSBub3QgdXNpbmcgYSByZXBsU2V0LlxuICAgIG1vbmdvT3B0aW9ucy5tYXhQb29sU2l6ZSA9IG9wdGlvbnMubWF4UG9vbFNpemU7XG4gIH1cbiAgaWYgKF8uaGFzKG9wdGlvbnMsICdtaW5Qb29sU2l6ZScpKSB7XG4gICAgbW9uZ29PcHRpb25zLm1pblBvb2xTaXplID0gb3B0aW9ucy5taW5Qb29sU2l6ZTtcbiAgfVxuXG4gIC8vIFRyYW5zZm9ybSBvcHRpb25zIGxpa2UgXCJ0bHNDQUZpbGVBc3NldFwiOiBcImZpbGVuYW1lLnBlbVwiIGludG9cbiAgLy8gXCJ0bHNDQUZpbGVcIjogXCIvPGZ1bGxwYXRoPi9maWxlbmFtZS5wZW1cIlxuICBPYmplY3QuZW50cmllcyhtb25nb09wdGlvbnMgfHwge30pXG4gICAgLmZpbHRlcigoW2tleV0pID0+IGtleSAmJiBrZXkuZW5kc1dpdGgoRklMRV9BU1NFVF9TVUZGSVgpKVxuICAgIC5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgIGNvbnN0IG9wdGlvbk5hbWUgPSBrZXkucmVwbGFjZShGSUxFX0FTU0VUX1NVRkZJWCwgJycpO1xuICAgICAgbW9uZ29PcHRpb25zW29wdGlvbk5hbWVdID0gcGF0aC5qb2luKEFzc2V0cy5nZXRTZXJ2ZXJEaXIoKSxcbiAgICAgICAgQVNTRVRTX0ZPTERFUiwgQVBQX0ZPTERFUiwgdmFsdWUpO1xuICAgICAgZGVsZXRlIG1vbmdvT3B0aW9uc1trZXldO1xuICAgIH0pO1xuXG4gIHNlbGYuZGIgPSBudWxsO1xuICBzZWxmLl9vcGxvZ0hhbmRsZSA9IG51bGw7XG4gIHNlbGYuX2RvY0ZldGNoZXIgPSBudWxsO1xuXG4gIHNlbGYuY2xpZW50ID0gbmV3IE1vbmdvREIuTW9uZ29DbGllbnQodXJsLCBtb25nb09wdGlvbnMpO1xuICBzZWxmLmRiID0gc2VsZi5jbGllbnQuZGIoKTtcblxuICBzZWxmLmNsaWVudC5vbignc2VydmVyRGVzY3JpcHRpb25DaGFuZ2VkJywgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChldmVudCA9PiB7XG4gICAgLy8gV2hlbiB0aGUgY29ubmVjdGlvbiBpcyBubyBsb25nZXIgYWdhaW5zdCB0aGUgcHJpbWFyeSBub2RlLCBleGVjdXRlIGFsbFxuICAgIC8vIGZhaWxvdmVyIGhvb2tzLiBUaGlzIGlzIGltcG9ydGFudCBmb3IgdGhlIGRyaXZlciBhcyBpdCBoYXMgdG8gcmUtcG9vbCB0aGVcbiAgICAvLyBxdWVyeSB3aGVuIGl0IGhhcHBlbnMuXG4gICAgaWYgKFxuICAgICAgZXZlbnQucHJldmlvdXNEZXNjcmlwdGlvbi50eXBlICE9PSAnUlNQcmltYXJ5JyAmJlxuICAgICAgZXZlbnQubmV3RGVzY3JpcHRpb24udHlwZSA9PT0gJ1JTUHJpbWFyeSdcbiAgICApIHtcbiAgICAgIHNlbGYuX29uRmFpbG92ZXJIb29rLmVhY2goY2FsbGJhY2sgPT4ge1xuICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSkpO1xuXG4gIGlmIChvcHRpb25zLm9wbG9nVXJsICYmICEgUGFja2FnZVsnZGlzYWJsZS1vcGxvZyddKSB7XG4gICAgc2VsZi5fb3Bsb2dIYW5kbGUgPSBuZXcgT3Bsb2dIYW5kbGUob3B0aW9ucy5vcGxvZ1VybCwgc2VsZi5kYi5kYXRhYmFzZU5hbWUpO1xuICAgIHNlbGYuX2RvY0ZldGNoZXIgPSBuZXcgRG9jRmV0Y2hlcihzZWxmKTtcbiAgfVxuICBQcm9taXNlLmF3YWl0KHNlbGYuY2xpZW50LmNvbm5lY3QoKSlcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuY2xvc2UgPSBmdW5jdGlvbigpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIGlmICghIHNlbGYuZGIpXG4gICAgdGhyb3cgRXJyb3IoXCJjbG9zZSBjYWxsZWQgYmVmb3JlIENvbm5lY3Rpb24gY3JlYXRlZD9cIik7XG5cbiAgLy8gWFhYIHByb2JhYmx5IHVudGVzdGVkXG4gIHZhciBvcGxvZ0hhbmRsZSA9IHNlbGYuX29wbG9nSGFuZGxlO1xuICBzZWxmLl9vcGxvZ0hhbmRsZSA9IG51bGw7XG4gIGlmIChvcGxvZ0hhbmRsZSlcbiAgICBvcGxvZ0hhbmRsZS5zdG9wKCk7XG5cbiAgLy8gVXNlIEZ1dHVyZS53cmFwIHNvIHRoYXQgZXJyb3JzIGdldCB0aHJvd24uIFRoaXMgaGFwcGVucyB0b1xuICAvLyB3b3JrIGV2ZW4gb3V0c2lkZSBhIGZpYmVyIHNpbmNlIHRoZSAnY2xvc2UnIG1ldGhvZCBpcyBub3RcbiAgLy8gYWN0dWFsbHkgYXN5bmNocm9ub3VzLlxuICBGdXR1cmUud3JhcChfLmJpbmQoc2VsZi5jbGllbnQuY2xvc2UsIHNlbGYuY2xpZW50KSkodHJ1ZSkud2FpdCgpO1xufTtcblxuLy8gUmV0dXJucyB0aGUgTW9uZ28gQ29sbGVjdGlvbiBvYmplY3Q7IG1heSB5aWVsZC5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUucmF3Q29sbGVjdGlvbiA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKCEgc2VsZi5kYilcbiAgICB0aHJvdyBFcnJvcihcInJhd0NvbGxlY3Rpb24gY2FsbGVkIGJlZm9yZSBDb25uZWN0aW9uIGNyZWF0ZWQ/XCIpO1xuXG4gIHJldHVybiBzZWxmLmRiLmNvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fY3JlYXRlQ2FwcGVkQ29sbGVjdGlvbiA9IGZ1bmN0aW9uIChcbiAgICBjb2xsZWN0aW9uTmFtZSwgYnl0ZVNpemUsIG1heERvY3VtZW50cykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKCEgc2VsZi5kYilcbiAgICB0aHJvdyBFcnJvcihcIl9jcmVhdGVDYXBwZWRDb2xsZWN0aW9uIGNhbGxlZCBiZWZvcmUgQ29ubmVjdGlvbiBjcmVhdGVkP1wiKTtcblxuXG4gIHZhciBmdXR1cmUgPSBuZXcgRnV0dXJlKCk7XG4gIHNlbGYuZGIuY3JlYXRlQ29sbGVjdGlvbihcbiAgICBjb2xsZWN0aW9uTmFtZSxcbiAgICB7IGNhcHBlZDogdHJ1ZSwgc2l6ZTogYnl0ZVNpemUsIG1heDogbWF4RG9jdW1lbnRzIH0sXG4gICAgZnV0dXJlLnJlc29sdmVyKCkpO1xuICBmdXR1cmUud2FpdCgpO1xufTtcblxuLy8gVGhpcyBzaG91bGQgYmUgY2FsbGVkIHN5bmNocm9ub3VzbHkgd2l0aCBhIHdyaXRlLCB0byBjcmVhdGUgYVxuLy8gdHJhbnNhY3Rpb24gb24gdGhlIGN1cnJlbnQgd3JpdGUgZmVuY2UsIGlmIGFueS4gQWZ0ZXIgd2UgY2FuIHJlYWRcbi8vIHRoZSB3cml0ZSwgYW5kIGFmdGVyIG9ic2VydmVycyBoYXZlIGJlZW4gbm90aWZpZWQgKG9yIGF0IGxlYXN0LFxuLy8gYWZ0ZXIgdGhlIG9ic2VydmVyIG5vdGlmaWVycyBoYXZlIGFkZGVkIHRoZW1zZWx2ZXMgdG8gdGhlIHdyaXRlXG4vLyBmZW5jZSksIHlvdSBzaG91bGQgY2FsbCAnY29tbWl0dGVkKCknIG9uIHRoZSBvYmplY3QgcmV0dXJuZWQuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9tYXliZUJlZ2luV3JpdGUgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBmZW5jZSA9IEREUFNlcnZlci5fQ3VycmVudFdyaXRlRmVuY2UuZ2V0KCk7XG4gIGlmIChmZW5jZSkge1xuICAgIHJldHVybiBmZW5jZS5iZWdpbldyaXRlKCk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHtjb21taXR0ZWQ6IGZ1bmN0aW9uICgpIHt9fTtcbiAgfVxufTtcblxuLy8gSW50ZXJuYWwgaW50ZXJmYWNlOiBhZGRzIGEgY2FsbGJhY2sgd2hpY2ggaXMgY2FsbGVkIHdoZW4gdGhlIE1vbmdvIHByaW1hcnlcbi8vIGNoYW5nZXMuIFJldHVybnMgYSBzdG9wIGhhbmRsZS5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX29uRmFpbG92ZXIgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgcmV0dXJuIHRoaXMuX29uRmFpbG92ZXJIb29rLnJlZ2lzdGVyKGNhbGxiYWNrKTtcbn07XG5cblxuLy8vLy8vLy8vLy8vIFB1YmxpYyBBUEkgLy8vLy8vLy8vL1xuXG4vLyBUaGUgd3JpdGUgbWV0aG9kcyBibG9jayB1bnRpbCB0aGUgZGF0YWJhc2UgaGFzIGNvbmZpcm1lZCB0aGUgd3JpdGUgKGl0IG1heVxuLy8gbm90IGJlIHJlcGxpY2F0ZWQgb3Igc3RhYmxlIG9uIGRpc2ssIGJ1dCBvbmUgc2VydmVyIGhhcyBjb25maXJtZWQgaXQpIGlmIG5vXG4vLyBjYWxsYmFjayBpcyBwcm92aWRlZC4gSWYgYSBjYWxsYmFjayBpcyBwcm92aWRlZCwgdGhlbiB0aGV5IGNhbGwgdGhlIGNhbGxiYWNrXG4vLyB3aGVuIHRoZSB3cml0ZSBpcyBjb25maXJtZWQuIFRoZXkgcmV0dXJuIG5vdGhpbmcgb24gc3VjY2VzcywgYW5kIHJhaXNlIGFuXG4vLyBleGNlcHRpb24gb24gZmFpbHVyZS5cbi8vXG4vLyBBZnRlciBtYWtpbmcgYSB3cml0ZSAod2l0aCBpbnNlcnQsIHVwZGF0ZSwgcmVtb3ZlKSwgb2JzZXJ2ZXJzIGFyZVxuLy8gbm90aWZpZWQgYXN5bmNocm9ub3VzbHkuIElmIHlvdSB3YW50IHRvIHJlY2VpdmUgYSBjYWxsYmFjayBvbmNlIGFsbFxuLy8gb2YgdGhlIG9ic2VydmVyIG5vdGlmaWNhdGlvbnMgaGF2ZSBsYW5kZWQgZm9yIHlvdXIgd3JpdGUsIGRvIHRoZVxuLy8gd3JpdGVzIGluc2lkZSBhIHdyaXRlIGZlbmNlIChzZXQgRERQU2VydmVyLl9DdXJyZW50V3JpdGVGZW5jZSB0byBhIG5ld1xuLy8gX1dyaXRlRmVuY2UsIGFuZCB0aGVuIHNldCBhIGNhbGxiYWNrIG9uIHRoZSB3cml0ZSBmZW5jZS4pXG4vL1xuLy8gU2luY2Ugb3VyIGV4ZWN1dGlvbiBlbnZpcm9ubWVudCBpcyBzaW5nbGUtdGhyZWFkZWQsIHRoaXMgaXNcbi8vIHdlbGwtZGVmaW5lZCAtLSBhIHdyaXRlIFwiaGFzIGJlZW4gbWFkZVwiIGlmIGl0J3MgcmV0dXJuZWQsIGFuZCBhblxuLy8gb2JzZXJ2ZXIgXCJoYXMgYmVlbiBub3RpZmllZFwiIGlmIGl0cyBjYWxsYmFjayBoYXMgcmV0dXJuZWQuXG5cbnZhciB3cml0ZUNhbGxiYWNrID0gZnVuY3Rpb24gKHdyaXRlLCByZWZyZXNoLCBjYWxsYmFjaykge1xuICByZXR1cm4gZnVuY3Rpb24gKGVyciwgcmVzdWx0KSB7XG4gICAgaWYgKCEgZXJyKSB7XG4gICAgICAvLyBYWFggV2UgZG9uJ3QgaGF2ZSB0byBydW4gdGhpcyBvbiBlcnJvciwgcmlnaHQ/XG4gICAgICB0cnkge1xuICAgICAgICByZWZyZXNoKCk7XG4gICAgICB9IGNhdGNoIChyZWZyZXNoRXJyKSB7XG4gICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgIGNhbGxiYWNrKHJlZnJlc2hFcnIpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyByZWZyZXNoRXJyO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgY2FsbGJhY2soZXJyLCByZXN1bHQpO1xuICAgIH0gZWxzZSBpZiAoZXJyKSB7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9O1xufTtcblxudmFyIGJpbmRFbnZpcm9ubWVudEZvcldyaXRlID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gIHJldHVybiBNZXRlb3IuYmluZEVudmlyb25tZW50KGNhbGxiYWNrLCBcIk1vbmdvIHdyaXRlXCIpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5faW5zZXJ0ID0gZnVuY3Rpb24gKGNvbGxlY3Rpb25fbmFtZSwgZG9jdW1lbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2spIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIHZhciBzZW5kRXJyb3IgPSBmdW5jdGlvbiAoZSkge1xuICAgIGlmIChjYWxsYmFjaylcbiAgICAgIHJldHVybiBjYWxsYmFjayhlKTtcbiAgICB0aHJvdyBlO1xuICB9O1xuXG4gIGlmIChjb2xsZWN0aW9uX25hbWUgPT09IFwiX19fbWV0ZW9yX2ZhaWx1cmVfdGVzdF9jb2xsZWN0aW9uXCIpIHtcbiAgICB2YXIgZSA9IG5ldyBFcnJvcihcIkZhaWx1cmUgdGVzdFwiKTtcbiAgICBlLl9leHBlY3RlZEJ5VGVzdCA9IHRydWU7XG4gICAgc2VuZEVycm9yKGUpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmICghKExvY2FsQ29sbGVjdGlvbi5faXNQbGFpbk9iamVjdChkb2N1bWVudCkgJiZcbiAgICAgICAgIUVKU09OLl9pc0N1c3RvbVR5cGUoZG9jdW1lbnQpKSkge1xuICAgIHNlbmRFcnJvcihuZXcgRXJyb3IoXG4gICAgICBcIk9ubHkgcGxhaW4gb2JqZWN0cyBtYXkgYmUgaW5zZXJ0ZWQgaW50byBNb25nb0RCXCIpKTtcbiAgICByZXR1cm47XG4gIH1cblxuICB2YXIgd3JpdGUgPSBzZWxmLl9tYXliZUJlZ2luV3JpdGUoKTtcbiAgdmFyIHJlZnJlc2ggPSBmdW5jdGlvbiAoKSB7XG4gICAgTWV0ZW9yLnJlZnJlc2goe2NvbGxlY3Rpb246IGNvbGxlY3Rpb25fbmFtZSwgaWQ6IGRvY3VtZW50Ll9pZCB9KTtcbiAgfTtcbiAgY2FsbGJhY2sgPSBiaW5kRW52aXJvbm1lbnRGb3JXcml0ZSh3cml0ZUNhbGxiYWNrKHdyaXRlLCByZWZyZXNoLCBjYWxsYmFjaykpO1xuICB0cnkge1xuICAgIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25fbmFtZSk7XG4gICAgY29sbGVjdGlvbi5pbnNlcnRPbmUoXG4gICAgICByZXBsYWNlVHlwZXMoZG9jdW1lbnQsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSxcbiAgICAgIHtcbiAgICAgICAgc2FmZTogdHJ1ZSxcbiAgICAgIH1cbiAgICApLnRoZW4oKHtpbnNlcnRlZElkfSkgPT4ge1xuICAgICAgY2FsbGJhY2sobnVsbCwgaW5zZXJ0ZWRJZCk7XG4gICAgfSkuY2F0Y2goKGUpID0+IHtcbiAgICAgIGNhbGxiYWNrKGUsIG51bGwpXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgIHRocm93IGVycjtcbiAgfVxufTtcblxuLy8gQ2F1c2UgcXVlcmllcyB0aGF0IG1heSBiZSBhZmZlY3RlZCBieSB0aGUgc2VsZWN0b3IgdG8gcG9sbCBpbiB0aGlzIHdyaXRlXG4vLyBmZW5jZS5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX3JlZnJlc2ggPSBmdW5jdGlvbiAoY29sbGVjdGlvbk5hbWUsIHNlbGVjdG9yKSB7XG4gIHZhciByZWZyZXNoS2V5ID0ge2NvbGxlY3Rpb246IGNvbGxlY3Rpb25OYW1lfTtcbiAgLy8gSWYgd2Uga25vdyB3aGljaCBkb2N1bWVudHMgd2UncmUgcmVtb3ZpbmcsIGRvbid0IHBvbGwgcXVlcmllcyB0aGF0IGFyZVxuICAvLyBzcGVjaWZpYyB0byBvdGhlciBkb2N1bWVudHMuIChOb3RlIHRoYXQgbXVsdGlwbGUgbm90aWZpY2F0aW9ucyBoZXJlIHNob3VsZFxuICAvLyBub3QgY2F1c2UgbXVsdGlwbGUgcG9sbHMsIHNpbmNlIGFsbCBvdXIgbGlzdGVuZXIgaXMgZG9pbmcgaXMgZW5xdWV1ZWluZyBhXG4gIC8vIHBvbGwuKVxuICB2YXIgc3BlY2lmaWNJZHMgPSBMb2NhbENvbGxlY3Rpb24uX2lkc01hdGNoZWRCeVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgaWYgKHNwZWNpZmljSWRzKSB7XG4gICAgXy5lYWNoKHNwZWNpZmljSWRzLCBmdW5jdGlvbiAoaWQpIHtcbiAgICAgIE1ldGVvci5yZWZyZXNoKF8uZXh0ZW5kKHtpZDogaWR9LCByZWZyZXNoS2V5KSk7XG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgTWV0ZW9yLnJlZnJlc2gocmVmcmVzaEtleSk7XG4gIH1cbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX3JlbW92ZSA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uX25hbWUsIHNlbGVjdG9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICBpZiAoY29sbGVjdGlvbl9uYW1lID09PSBcIl9fX21ldGVvcl9mYWlsdXJlX3Rlc3RfY29sbGVjdGlvblwiKSB7XG4gICAgdmFyIGUgPSBuZXcgRXJyb3IoXCJGYWlsdXJlIHRlc3RcIik7XG4gICAgZS5fZXhwZWN0ZWRCeVRlc3QgPSB0cnVlO1xuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgcmV0dXJuIGNhbGxiYWNrKGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfVxuXG4gIHZhciB3cml0ZSA9IHNlbGYuX21heWJlQmVnaW5Xcml0ZSgpO1xuICB2YXIgcmVmcmVzaCA9IGZ1bmN0aW9uICgpIHtcbiAgICBzZWxmLl9yZWZyZXNoKGNvbGxlY3Rpb25fbmFtZSwgc2VsZWN0b3IpO1xuICB9O1xuICBjYWxsYmFjayA9IGJpbmRFbnZpcm9ubWVudEZvcldyaXRlKHdyaXRlQ2FsbGJhY2sod3JpdGUsIHJlZnJlc2gsIGNhbGxiYWNrKSk7XG5cbiAgdHJ5IHtcbiAgICB2YXIgY29sbGVjdGlvbiA9IHNlbGYucmF3Q29sbGVjdGlvbihjb2xsZWN0aW9uX25hbWUpO1xuICAgIGNvbGxlY3Rpb25cbiAgICAgIC5kZWxldGVNYW55KHJlcGxhY2VUeXBlcyhzZWxlY3RvciwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLCB7XG4gICAgICAgIHNhZmU6IHRydWUsXG4gICAgICB9KVxuICAgICAgLnRoZW4oKHsgZGVsZXRlZENvdW50IH0pID0+IHtcbiAgICAgICAgY2FsbGJhY2sobnVsbCwgdHJhbnNmb3JtUmVzdWx0KHsgcmVzdWx0IDoge21vZGlmaWVkQ291bnQgOiBkZWxldGVkQ291bnR9IH0pLm51bWJlckFmZmVjdGVkKTtcbiAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgIHRocm93IGVycjtcbiAgfVxufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fZHJvcENvbGxlY3Rpb24gPSBmdW5jdGlvbiAoY29sbGVjdGlvbk5hbWUsIGNiKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuXG4gIHZhciB3cml0ZSA9IHNlbGYuX21heWJlQmVnaW5Xcml0ZSgpO1xuICB2YXIgcmVmcmVzaCA9IGZ1bmN0aW9uICgpIHtcbiAgICBNZXRlb3IucmVmcmVzaCh7Y29sbGVjdGlvbjogY29sbGVjdGlvbk5hbWUsIGlkOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICBkcm9wQ29sbGVjdGlvbjogdHJ1ZX0pO1xuICB9O1xuXG5cbiAgY2IgPSBiaW5kRW52aXJvbm1lbnRGb3JXcml0ZSh3cml0ZUNhbGxiYWNrKHdyaXRlLCByZWZyZXNoLCBjYikpO1xuXG4gIHRyeSB7XG4gICAgdmFyIGNvbGxlY3Rpb24gPSBzZWxmLnJhd0NvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUpO1xuICAgIGNvbGxlY3Rpb24uZHJvcChjYik7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB3cml0ZS5jb21taXR0ZWQoKTtcbiAgICB0aHJvdyBlO1xuICB9XG59O1xuXG4vLyBGb3IgdGVzdGluZyBvbmx5LiAgU2xpZ2h0bHkgYmV0dGVyIHRoYW4gYGMucmF3RGF0YWJhc2UoKS5kcm9wRGF0YWJhc2UoKWBcbi8vIGJlY2F1c2UgaXQgbGV0cyB0aGUgdGVzdCdzIGZlbmNlIHdhaXQgZm9yIGl0IHRvIGJlIGNvbXBsZXRlLlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fZHJvcERhdGFiYXNlID0gZnVuY3Rpb24gKGNiKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICB2YXIgd3JpdGUgPSBzZWxmLl9tYXliZUJlZ2luV3JpdGUoKTtcbiAgdmFyIHJlZnJlc2ggPSBmdW5jdGlvbiAoKSB7XG4gICAgTWV0ZW9yLnJlZnJlc2goeyBkcm9wRGF0YWJhc2U6IHRydWUgfSk7XG4gIH07XG4gIGNiID0gYmluZEVudmlyb25tZW50Rm9yV3JpdGUod3JpdGVDYWxsYmFjayh3cml0ZSwgcmVmcmVzaCwgY2IpKTtcblxuICB0cnkge1xuICAgIHNlbGYuZGIuZHJvcERhdGFiYXNlKGNiKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgIHRocm93IGU7XG4gIH1cbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX3VwZGF0ZSA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uX25hbWUsIHNlbGVjdG9yLCBtb2QsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucywgY2FsbGJhY2spIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG5cblxuICBpZiAoISBjYWxsYmFjayAmJiBvcHRpb25zIGluc3RhbmNlb2YgRnVuY3Rpb24pIHtcbiAgICBjYWxsYmFjayA9IG9wdGlvbnM7XG4gICAgb3B0aW9ucyA9IG51bGw7XG4gIH1cblxuICBpZiAoY29sbGVjdGlvbl9uYW1lID09PSBcIl9fX21ldGVvcl9mYWlsdXJlX3Rlc3RfY29sbGVjdGlvblwiKSB7XG4gICAgdmFyIGUgPSBuZXcgRXJyb3IoXCJGYWlsdXJlIHRlc3RcIik7XG4gICAgZS5fZXhwZWN0ZWRCeVRlc3QgPSB0cnVlO1xuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgcmV0dXJuIGNhbGxiYWNrKGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfVxuXG4gIC8vIGV4cGxpY2l0IHNhZmV0eSBjaGVjay4gbnVsbCBhbmQgdW5kZWZpbmVkIGNhbiBjcmFzaCB0aGUgbW9uZ29cbiAgLy8gZHJpdmVyLiBBbHRob3VnaCB0aGUgbm9kZSBkcml2ZXIgYW5kIG1pbmltb25nbyBkbyAnc3VwcG9ydCdcbiAgLy8gbm9uLW9iamVjdCBtb2RpZmllciBpbiB0aGF0IHRoZXkgZG9uJ3QgY3Jhc2gsIHRoZXkgYXJlIG5vdFxuICAvLyBtZWFuaW5nZnVsIG9wZXJhdGlvbnMgYW5kIGRvIG5vdCBkbyBhbnl0aGluZy4gRGVmZW5zaXZlbHkgdGhyb3cgYW5cbiAgLy8gZXJyb3IgaGVyZS5cbiAgaWYgKCFtb2QgfHwgdHlwZW9mIG1vZCAhPT0gJ29iamVjdCcpXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBtb2RpZmllci4gTW9kaWZpZXIgbXVzdCBiZSBhbiBvYmplY3QuXCIpO1xuXG4gIGlmICghKExvY2FsQ29sbGVjdGlvbi5faXNQbGFpbk9iamVjdChtb2QpICYmXG4gICAgICAgICFFSlNPTi5faXNDdXN0b21UeXBlKG1vZCkpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgXCJPbmx5IHBsYWluIG9iamVjdHMgbWF5IGJlIHVzZWQgYXMgcmVwbGFjZW1lbnRcIiArXG4gICAgICAgIFwiIGRvY3VtZW50cyBpbiBNb25nb0RCXCIpO1xuICB9XG5cbiAgaWYgKCFvcHRpb25zKSBvcHRpb25zID0ge307XG5cbiAgdmFyIHdyaXRlID0gc2VsZi5fbWF5YmVCZWdpbldyaXRlKCk7XG4gIHZhciByZWZyZXNoID0gZnVuY3Rpb24gKCkge1xuICAgIHNlbGYuX3JlZnJlc2goY29sbGVjdGlvbl9uYW1lLCBzZWxlY3Rvcik7XG4gIH07XG4gIGNhbGxiYWNrID0gd3JpdGVDYWxsYmFjayh3cml0ZSwgcmVmcmVzaCwgY2FsbGJhY2spO1xuICB0cnkge1xuICAgIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25fbmFtZSk7XG4gICAgdmFyIG1vbmdvT3B0cyA9IHtzYWZlOiB0cnVlfTtcbiAgICAvLyBBZGQgc3VwcG9ydCBmb3IgZmlsdGVyZWQgcG9zaXRpb25hbCBvcGVyYXRvclxuICAgIGlmIChvcHRpb25zLmFycmF5RmlsdGVycyAhPT0gdW5kZWZpbmVkKSBtb25nb09wdHMuYXJyYXlGaWx0ZXJzID0gb3B0aW9ucy5hcnJheUZpbHRlcnM7XG4gICAgLy8gZXhwbGljdGx5IGVudW1lcmF0ZSBvcHRpb25zIHRoYXQgbWluaW1vbmdvIHN1cHBvcnRzXG4gICAgaWYgKG9wdGlvbnMudXBzZXJ0KSBtb25nb09wdHMudXBzZXJ0ID0gdHJ1ZTtcbiAgICBpZiAob3B0aW9ucy5tdWx0aSkgbW9uZ29PcHRzLm11bHRpID0gdHJ1ZTtcbiAgICAvLyBMZXRzIHlvdSBnZXQgYSBtb3JlIG1vcmUgZnVsbCByZXN1bHQgZnJvbSBNb25nb0RCLiBVc2Ugd2l0aCBjYXV0aW9uOlxuICAgIC8vIG1pZ2h0IG5vdCB3b3JrIHdpdGggQy51cHNlcnQgKGFzIG9wcG9zZWQgdG8gQy51cGRhdGUoe3Vwc2VydDp0cnVlfSkgb3JcbiAgICAvLyB3aXRoIHNpbXVsYXRlZCB1cHNlcnQuXG4gICAgaWYgKG9wdGlvbnMuZnVsbFJlc3VsdCkgbW9uZ29PcHRzLmZ1bGxSZXN1bHQgPSB0cnVlO1xuXG4gICAgdmFyIG1vbmdvU2VsZWN0b3IgPSByZXBsYWNlVHlwZXMoc2VsZWN0b3IsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKTtcbiAgICB2YXIgbW9uZ29Nb2QgPSByZXBsYWNlVHlwZXMobW9kLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyk7XG5cbiAgICB2YXIgaXNNb2RpZnkgPSBMb2NhbENvbGxlY3Rpb24uX2lzTW9kaWZpY2F0aW9uTW9kKG1vbmdvTW9kKTtcblxuICAgIGlmIChvcHRpb25zLl9mb3JiaWRSZXBsYWNlICYmICFpc01vZGlmeSkge1xuICAgICAgdmFyIGVyciA9IG5ldyBFcnJvcihcIkludmFsaWQgbW9kaWZpZXIuIFJlcGxhY2VtZW50cyBhcmUgZm9yYmlkZGVuLlwiKTtcbiAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICByZXR1cm4gY2FsbGJhY2soZXJyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBXZSd2ZSBhbHJlYWR5IHJ1biByZXBsYWNlVHlwZXMvcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28gb25cbiAgICAvLyBzZWxlY3RvciBhbmQgbW9kLiAgV2UgYXNzdW1lIGl0IGRvZXNuJ3QgbWF0dGVyLCBhcyBmYXIgYXNcbiAgICAvLyB0aGUgYmVoYXZpb3Igb2YgbW9kaWZpZXJzIGlzIGNvbmNlcm5lZCwgd2hldGhlciBgX21vZGlmeWBcbiAgICAvLyBpcyBydW4gb24gRUpTT04gb3Igb24gbW9uZ28tY29udmVydGVkIEVKU09OLlxuXG4gICAgLy8gUnVuIHRoaXMgY29kZSB1cCBmcm9udCBzbyB0aGF0IGl0IGZhaWxzIGZhc3QgaWYgc29tZW9uZSB1c2VzXG4gICAgLy8gYSBNb25nbyB1cGRhdGUgb3BlcmF0b3Igd2UgZG9uJ3Qgc3VwcG9ydC5cbiAgICBsZXQga25vd25JZDtcbiAgICBpZiAob3B0aW9ucy51cHNlcnQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxldCBuZXdEb2MgPSBMb2NhbENvbGxlY3Rpb24uX2NyZWF0ZVVwc2VydERvY3VtZW50KHNlbGVjdG9yLCBtb2QpO1xuICAgICAgICBrbm93bklkID0gbmV3RG9jLl9pZDtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgICAgICByZXR1cm4gY2FsbGJhY2soZXJyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAob3B0aW9ucy51cHNlcnQgJiZcbiAgICAgICAgISBpc01vZGlmeSAmJlxuICAgICAgICAhIGtub3duSWQgJiZcbiAgICAgICAgb3B0aW9ucy5pbnNlcnRlZElkICYmXG4gICAgICAgICEgKG9wdGlvbnMuaW5zZXJ0ZWRJZCBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEICYmXG4gICAgICAgICAgIG9wdGlvbnMuZ2VuZXJhdGVkSWQpKSB7XG4gICAgICAvLyBJbiBjYXNlIG9mIGFuIHVwc2VydCB3aXRoIGEgcmVwbGFjZW1lbnQsIHdoZXJlIHRoZXJlIGlzIG5vIF9pZCBkZWZpbmVkXG4gICAgICAvLyBpbiBlaXRoZXIgdGhlIHF1ZXJ5IG9yIHRoZSByZXBsYWNlbWVudCBkb2MsIG1vbmdvIHdpbGwgZ2VuZXJhdGUgYW4gaWQgaXRzZWxmLlxuICAgICAgLy8gVGhlcmVmb3JlIHdlIG5lZWQgdGhpcyBzcGVjaWFsIHN0cmF0ZWd5IGlmIHdlIHdhbnQgdG8gY29udHJvbCB0aGUgaWQgb3Vyc2VsdmVzLlxuXG4gICAgICAvLyBXZSBkb24ndCBuZWVkIHRvIGRvIHRoaXMgd2hlbjpcbiAgICAgIC8vIC0gVGhpcyBpcyBub3QgYSByZXBsYWNlbWVudCwgc28gd2UgY2FuIGFkZCBhbiBfaWQgdG8gJHNldE9uSW5zZXJ0XG4gICAgICAvLyAtIFRoZSBpZCBpcyBkZWZpbmVkIGJ5IHF1ZXJ5IG9yIG1vZCB3ZSBjYW4ganVzdCBhZGQgaXQgdG8gdGhlIHJlcGxhY2VtZW50IGRvY1xuICAgICAgLy8gLSBUaGUgdXNlciBkaWQgbm90IHNwZWNpZnkgYW55IGlkIHByZWZlcmVuY2UgYW5kIHRoZSBpZCBpcyBhIE1vbmdvIE9iamVjdElkLFxuICAgICAgLy8gICAgIHRoZW4gd2UgY2FuIGp1c3QgbGV0IE1vbmdvIGdlbmVyYXRlIHRoZSBpZFxuXG4gICAgICBzaW11bGF0ZVVwc2VydFdpdGhJbnNlcnRlZElkKFxuICAgICAgICBjb2xsZWN0aW9uLCBtb25nb1NlbGVjdG9yLCBtb25nb01vZCwgb3B0aW9ucyxcbiAgICAgICAgLy8gVGhpcyBjYWxsYmFjayBkb2VzIG5vdCBuZWVkIHRvIGJlIGJpbmRFbnZpcm9ubWVudCdlZCBiZWNhdXNlXG4gICAgICAgIC8vIHNpbXVsYXRlVXBzZXJ0V2l0aEluc2VydGVkSWQoKSB3cmFwcyBpdCBhbmQgdGhlbiBwYXNzZXMgaXQgdGhyb3VnaFxuICAgICAgICAvLyBiaW5kRW52aXJvbm1lbnRGb3JXcml0ZS5cbiAgICAgICAgZnVuY3Rpb24gKGVycm9yLCByZXN1bHQpIHtcbiAgICAgICAgICAvLyBJZiB3ZSBnb3QgaGVyZSB2aWEgYSB1cHNlcnQoKSBjYWxsLCB0aGVuIG9wdGlvbnMuX3JldHVybk9iamVjdCB3aWxsXG4gICAgICAgICAgLy8gYmUgc2V0IGFuZCB3ZSBzaG91bGQgcmV0dXJuIHRoZSB3aG9sZSBvYmplY3QuIE90aGVyd2lzZSwgd2Ugc2hvdWxkXG4gICAgICAgICAgLy8ganVzdCByZXR1cm4gdGhlIG51bWJlciBvZiBhZmZlY3RlZCBkb2NzIHRvIG1hdGNoIHRoZSBtb25nbyBBUEkuXG4gICAgICAgICAgaWYgKHJlc3VsdCAmJiAhIG9wdGlvbnMuX3JldHVybk9iamVjdCkge1xuICAgICAgICAgICAgY2FsbGJhY2soZXJyb3IsIHJlc3VsdC5udW1iZXJBZmZlY3RlZCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKGVycm9yLCByZXN1bHQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuXG4gICAgICBpZiAob3B0aW9ucy51cHNlcnQgJiYgIWtub3duSWQgJiYgb3B0aW9ucy5pbnNlcnRlZElkICYmIGlzTW9kaWZ5KSB7XG4gICAgICAgIGlmICghbW9uZ29Nb2QuaGFzT3duUHJvcGVydHkoJyRzZXRPbkluc2VydCcpKSB7XG4gICAgICAgICAgbW9uZ29Nb2QuJHNldE9uSW5zZXJ0ID0ge307XG4gICAgICAgIH1cbiAgICAgICAga25vd25JZCA9IG9wdGlvbnMuaW5zZXJ0ZWRJZDtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihtb25nb01vZC4kc2V0T25JbnNlcnQsIHJlcGxhY2VUeXBlcyh7X2lkOiBvcHRpb25zLmluc2VydGVkSWR9LCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbykpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzdHJpbmdzID0gT2JqZWN0LmtleXMobW9uZ29Nb2QpLmZpbHRlcigoa2V5KSA9PiAha2V5LnN0YXJ0c1dpdGgoXCIkXCIpKTtcbiAgICAgIGxldCB1cGRhdGVNZXRob2QgPSBzdHJpbmdzLmxlbmd0aCA+IDAgPyAncmVwbGFjZU9uZScgOiAndXBkYXRlTWFueSc7XG4gICAgICB1cGRhdGVNZXRob2QgPVxuICAgICAgICB1cGRhdGVNZXRob2QgPT09ICd1cGRhdGVNYW55JyAmJiAhbW9uZ29PcHRzLm11bHRpXG4gICAgICAgICAgPyAndXBkYXRlT25lJ1xuICAgICAgICAgIDogdXBkYXRlTWV0aG9kO1xuICAgICAgY29sbGVjdGlvblt1cGRhdGVNZXRob2RdLmJpbmQoY29sbGVjdGlvbikoXG4gICAgICAgIG1vbmdvU2VsZWN0b3IsIG1vbmdvTW9kLCBtb25nb09wdHMsXG4gICAgICAgICAgLy8gbW9uZ28gZHJpdmVyIG5vdyByZXR1cm5zIHVuZGVmaW5lZCBmb3IgZXJyIGluIHRoZSBjYWxsYmFja1xuICAgICAgICAgIGJpbmRFbnZpcm9ubWVudEZvcldyaXRlKGZ1bmN0aW9uIChlcnIgPSBudWxsLCByZXN1bHQpIHtcbiAgICAgICAgICBpZiAoISBlcnIpIHtcbiAgICAgICAgICAgIHZhciBtZXRlb3JSZXN1bHQgPSB0cmFuc2Zvcm1SZXN1bHQoe3Jlc3VsdH0pO1xuICAgICAgICAgICAgaWYgKG1ldGVvclJlc3VsdCAmJiBvcHRpb25zLl9yZXR1cm5PYmplY3QpIHtcbiAgICAgICAgICAgICAgLy8gSWYgdGhpcyB3YXMgYW4gdXBzZXJ0KCkgY2FsbCwgYW5kIHdlIGVuZGVkIHVwXG4gICAgICAgICAgICAgIC8vIGluc2VydGluZyBhIG5ldyBkb2MgYW5kIHdlIGtub3cgaXRzIGlkLCB0aGVuXG4gICAgICAgICAgICAgIC8vIHJldHVybiB0aGF0IGlkIGFzIHdlbGwuXG4gICAgICAgICAgICAgIGlmIChvcHRpb25zLnVwc2VydCAmJiBtZXRlb3JSZXN1bHQuaW5zZXJ0ZWRJZCkge1xuICAgICAgICAgICAgICAgIGlmIChrbm93bklkKSB7XG4gICAgICAgICAgICAgICAgICBtZXRlb3JSZXN1bHQuaW5zZXJ0ZWRJZCA9IGtub3duSWQ7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChtZXRlb3JSZXN1bHQuaW5zZXJ0ZWRJZCBpbnN0YW5jZW9mIE1vbmdvREIuT2JqZWN0SUQpIHtcbiAgICAgICAgICAgICAgICAgIG1ldGVvclJlc3VsdC5pbnNlcnRlZElkID0gbmV3IE1vbmdvLk9iamVjdElEKG1ldGVvclJlc3VsdC5pbnNlcnRlZElkLnRvSGV4U3RyaW5nKCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGNhbGxiYWNrKGVyciwgbWV0ZW9yUmVzdWx0KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrKGVyciwgbWV0ZW9yUmVzdWx0Lm51bWJlckFmZmVjdGVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB3cml0ZS5jb21taXR0ZWQoKTtcbiAgICB0aHJvdyBlO1xuICB9XG59O1xuXG52YXIgdHJhbnNmb3JtUmVzdWx0ID0gZnVuY3Rpb24gKGRyaXZlclJlc3VsdCkge1xuICB2YXIgbWV0ZW9yUmVzdWx0ID0geyBudW1iZXJBZmZlY3RlZDogMCB9O1xuICBpZiAoZHJpdmVyUmVzdWx0KSB7XG4gICAgdmFyIG1vbmdvUmVzdWx0ID0gZHJpdmVyUmVzdWx0LnJlc3VsdDtcbiAgICAvLyBPbiB1cGRhdGVzIHdpdGggdXBzZXJ0OnRydWUsIHRoZSBpbnNlcnRlZCB2YWx1ZXMgY29tZSBhcyBhIGxpc3Qgb2ZcbiAgICAvLyB1cHNlcnRlZCB2YWx1ZXMgLS0gZXZlbiB3aXRoIG9wdGlvbnMubXVsdGksIHdoZW4gdGhlIHVwc2VydCBkb2VzIGluc2VydCxcbiAgICAvLyBpdCBvbmx5IGluc2VydHMgb25lIGVsZW1lbnQuXG4gICAgaWYgKG1vbmdvUmVzdWx0LnVwc2VydGVkQ291bnQpIHtcbiAgICAgIG1ldGVvclJlc3VsdC5udW1iZXJBZmZlY3RlZCA9IG1vbmdvUmVzdWx0LnVwc2VydGVkQ291bnQ7XG5cbiAgICAgIGlmIChtb25nb1Jlc3VsdC51cHNlcnRlZElkKSB7XG4gICAgICAgIG1ldGVvclJlc3VsdC5pbnNlcnRlZElkID0gbW9uZ29SZXN1bHQudXBzZXJ0ZWRJZDtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gbiB3YXMgdXNlZCBiZWZvcmUgTW9uZ28gNS4wLCBpbiBNb25nbyA1LjAgd2UgYXJlIG5vdCByZWNlaXZpbmcgdGhpcyBuXG4gICAgICAvLyBmaWVsZCBhbmQgc28gd2UgYXJlIHVzaW5nIG1vZGlmaWVkQ291bnQgaW5zdGVhZFxuICAgICAgbWV0ZW9yUmVzdWx0Lm51bWJlckFmZmVjdGVkID0gbW9uZ29SZXN1bHQubiB8fCBtb25nb1Jlc3VsdC5tYXRjaGVkQ291bnQgfHwgbW9uZ29SZXN1bHQubW9kaWZpZWRDb3VudDtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbWV0ZW9yUmVzdWx0O1xufTtcblxuXG52YXIgTlVNX09QVElNSVNUSUNfVFJJRVMgPSAzO1xuXG4vLyBleHBvc2VkIGZvciB0ZXN0aW5nXG5Nb25nb0Nvbm5lY3Rpb24uX2lzQ2Fubm90Q2hhbmdlSWRFcnJvciA9IGZ1bmN0aW9uIChlcnIpIHtcblxuICAvLyBNb25nbyAzLjIuKiByZXR1cm5zIGVycm9yIGFzIG5leHQgT2JqZWN0OlxuICAvLyB7bmFtZTogU3RyaW5nLCBjb2RlOiBOdW1iZXIsIGVycm1zZzogU3RyaW5nfVxuICAvLyBPbGRlciBNb25nbyByZXR1cm5zOlxuICAvLyB7bmFtZTogU3RyaW5nLCBjb2RlOiBOdW1iZXIsIGVycjogU3RyaW5nfVxuICB2YXIgZXJyb3IgPSBlcnIuZXJybXNnIHx8IGVyci5lcnI7XG5cbiAgLy8gV2UgZG9uJ3QgdXNlIHRoZSBlcnJvciBjb2RlIGhlcmVcbiAgLy8gYmVjYXVzZSB0aGUgZXJyb3IgY29kZSB3ZSBvYnNlcnZlZCBpdCBwcm9kdWNpbmcgKDE2ODM3KSBhcHBlYXJzIHRvIGJlXG4gIC8vIGEgZmFyIG1vcmUgZ2VuZXJpYyBlcnJvciBjb2RlIGJhc2VkIG9uIGV4YW1pbmluZyB0aGUgc291cmNlLlxuICBpZiAoZXJyb3IuaW5kZXhPZignVGhlIF9pZCBmaWVsZCBjYW5ub3QgYmUgY2hhbmdlZCcpID09PSAwXG4gICAgfHwgZXJyb3IuaW5kZXhPZihcInRoZSAoaW1tdXRhYmxlKSBmaWVsZCAnX2lkJyB3YXMgZm91bmQgdG8gaGF2ZSBiZWVuIGFsdGVyZWQgdG8gX2lkXCIpICE9PSAtMSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxudmFyIHNpbXVsYXRlVXBzZXJ0V2l0aEluc2VydGVkSWQgPSBmdW5jdGlvbiAoY29sbGVjdGlvbiwgc2VsZWN0b3IsIG1vZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnMsIGNhbGxiYWNrKSB7XG4gIC8vIFNUUkFURUdZOiBGaXJzdCB0cnkgZG9pbmcgYW4gdXBzZXJ0IHdpdGggYSBnZW5lcmF0ZWQgSUQuXG4gIC8vIElmIHRoaXMgdGhyb3dzIGFuIGVycm9yIGFib3V0IGNoYW5naW5nIHRoZSBJRCBvbiBhbiBleGlzdGluZyBkb2N1bWVudFxuICAvLyB0aGVuIHdpdGhvdXQgYWZmZWN0aW5nIHRoZSBkYXRhYmFzZSwgd2Uga25vdyB3ZSBzaG91bGQgcHJvYmFibHkgdHJ5XG4gIC8vIGFuIHVwZGF0ZSB3aXRob3V0IHRoZSBnZW5lcmF0ZWQgSUQuIElmIGl0IGFmZmVjdGVkIDAgZG9jdW1lbnRzLFxuICAvLyB0aGVuIHdpdGhvdXQgYWZmZWN0aW5nIHRoZSBkYXRhYmFzZSwgd2UgdGhlIGRvY3VtZW50IHRoYXQgZmlyc3RcbiAgLy8gZ2F2ZSB0aGUgZXJyb3IgaXMgcHJvYmFibHkgcmVtb3ZlZCBhbmQgd2UgbmVlZCB0byB0cnkgYW4gaW5zZXJ0IGFnYWluXG4gIC8vIFdlIGdvIGJhY2sgdG8gc3RlcCBvbmUgYW5kIHJlcGVhdC5cbiAgLy8gTGlrZSBhbGwgXCJvcHRpbWlzdGljIHdyaXRlXCIgc2NoZW1lcywgd2UgcmVseSBvbiB0aGUgZmFjdCB0aGF0IGl0J3NcbiAgLy8gdW5saWtlbHkgb3VyIHdyaXRlcyB3aWxsIGNvbnRpbnVlIHRvIGJlIGludGVyZmVyZWQgd2l0aCB1bmRlciBub3JtYWxcbiAgLy8gY2lyY3Vtc3RhbmNlcyAodGhvdWdoIHN1ZmZpY2llbnRseSBoZWF2eSBjb250ZW50aW9uIHdpdGggd3JpdGVyc1xuICAvLyBkaXNhZ3JlZWluZyBvbiB0aGUgZXhpc3RlbmNlIG9mIGFuIG9iamVjdCB3aWxsIGNhdXNlIHdyaXRlcyB0byBmYWlsXG4gIC8vIGluIHRoZW9yeSkuXG5cbiAgdmFyIGluc2VydGVkSWQgPSBvcHRpb25zLmluc2VydGVkSWQ7IC8vIG11c3QgZXhpc3RcbiAgdmFyIG1vbmdvT3B0c0ZvclVwZGF0ZSA9IHtcbiAgICBzYWZlOiB0cnVlLFxuICAgIG11bHRpOiBvcHRpb25zLm11bHRpXG4gIH07XG4gIHZhciBtb25nb09wdHNGb3JJbnNlcnQgPSB7XG4gICAgc2FmZTogdHJ1ZSxcbiAgICB1cHNlcnQ6IHRydWVcbiAgfTtcblxuICB2YXIgcmVwbGFjZW1lbnRXaXRoSWQgPSBPYmplY3QuYXNzaWduKFxuICAgIHJlcGxhY2VUeXBlcyh7X2lkOiBpbnNlcnRlZElkfSwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLFxuICAgIG1vZCk7XG5cbiAgdmFyIHRyaWVzID0gTlVNX09QVElNSVNUSUNfVFJJRVM7XG5cbiAgdmFyIGRvVXBkYXRlID0gZnVuY3Rpb24gKCkge1xuICAgIHRyaWVzLS07XG4gICAgaWYgKCEgdHJpZXMpIHtcbiAgICAgIGNhbGxiYWNrKG5ldyBFcnJvcihcIlVwc2VydCBmYWlsZWQgYWZ0ZXIgXCIgKyBOVU1fT1BUSU1JU1RJQ19UUklFUyArIFwiIHRyaWVzLlwiKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCBtZXRob2QgPSBjb2xsZWN0aW9uLnVwZGF0ZU1hbnk7XG4gICAgICBpZighT2JqZWN0LmtleXMobW9kKS5zb21lKGtleSA9PiBrZXkuc3RhcnRzV2l0aChcIiRcIikpKXtcbiAgICAgICAgbWV0aG9kID0gY29sbGVjdGlvbi5yZXBsYWNlT25lLmJpbmQoY29sbGVjdGlvbik7XG4gICAgICB9XG4gICAgICBtZXRob2QoXG4gICAgICAgIHNlbGVjdG9yLFxuICAgICAgICBtb2QsXG4gICAgICAgIG1vbmdvT3B0c0ZvclVwZGF0ZSxcbiAgICAgICAgYmluZEVudmlyb25tZW50Rm9yV3JpdGUoZnVuY3Rpb24oZXJyLCByZXN1bHQpIHtcbiAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICBjYWxsYmFjayhlcnIpO1xuICAgICAgICAgIH0gZWxzZSBpZiAocmVzdWx0ICYmIChyZXN1bHQubW9kaWZpZWRDb3VudCB8fCByZXN1bHQudXBzZXJ0ZWRDb3VudCkpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHtcbiAgICAgICAgICAgICAgbnVtYmVyQWZmZWN0ZWQ6IHJlc3VsdC5tb2RpZmllZENvdW50IHx8IHJlc3VsdC51cHNlcnRlZENvdW50LFxuICAgICAgICAgICAgICBpbnNlcnRlZElkOiByZXN1bHQudXBzZXJ0ZWRJZCB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZG9Db25kaXRpb25hbEluc2VydCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfVxuICB9O1xuXG4gIHZhciBkb0NvbmRpdGlvbmFsSW5zZXJ0ID0gZnVuY3Rpb24oKSB7XG4gICAgY29sbGVjdGlvbi5yZXBsYWNlT25lKFxuICAgICAgc2VsZWN0b3IsXG4gICAgICByZXBsYWNlbWVudFdpdGhJZCxcbiAgICAgIG1vbmdvT3B0c0Zvckluc2VydCxcbiAgICAgIGJpbmRFbnZpcm9ubWVudEZvcldyaXRlKGZ1bmN0aW9uKGVyciwgcmVzdWx0KSB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAvLyBmaWd1cmUgb3V0IGlmIHRoaXMgaXMgYVxuICAgICAgICAgIC8vIFwiY2Fubm90IGNoYW5nZSBfaWQgb2YgZG9jdW1lbnRcIiBlcnJvciwgYW5kXG4gICAgICAgICAgLy8gaWYgc28sIHRyeSBkb1VwZGF0ZSgpIGFnYWluLCB1cCB0byAzIHRpbWVzLlxuICAgICAgICAgIGlmIChNb25nb0Nvbm5lY3Rpb24uX2lzQ2Fubm90Q2hhbmdlSWRFcnJvcihlcnIpKSB7XG4gICAgICAgICAgICBkb1VwZGF0ZSgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjYWxsYmFjayhlcnIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWxsYmFjayhudWxsLCB7XG4gICAgICAgICAgICBudW1iZXJBZmZlY3RlZDogcmVzdWx0LnVwc2VydGVkQ291bnQsXG4gICAgICAgICAgICBpbnNlcnRlZElkOiByZXN1bHQudXBzZXJ0ZWRJZCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICApO1xuICB9O1xuXG4gIGRvVXBkYXRlKCk7XG59O1xuXG5fLmVhY2goW1wiaW5zZXJ0XCIsIFwidXBkYXRlXCIsIFwicmVtb3ZlXCIsIFwiZHJvcENvbGxlY3Rpb25cIiwgXCJkcm9wRGF0YWJhc2VcIl0sIGZ1bmN0aW9uIChtZXRob2QpIHtcbiAgTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZVttZXRob2RdID0gZnVuY3Rpb24gKC8qIGFyZ3VtZW50cyAqLykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gTWV0ZW9yLndyYXBBc3luYyhzZWxmW1wiX1wiICsgbWV0aG9kXSkuYXBwbHkoc2VsZiwgYXJndW1lbnRzKTtcbiAgfTtcbn0pO1xuXG4vLyBYWFggTW9uZ29Db25uZWN0aW9uLnVwc2VydCgpIGRvZXMgbm90IHJldHVybiB0aGUgaWQgb2YgdGhlIGluc2VydGVkIGRvY3VtZW50XG4vLyB1bmxlc3MgeW91IHNldCBpdCBleHBsaWNpdGx5IGluIHRoZSBzZWxlY3RvciBvciBtb2RpZmllciAoYXMgYSByZXBsYWNlbWVudFxuLy8gZG9jKS5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUudXBzZXJ0ID0gZnVuY3Rpb24gKGNvbGxlY3Rpb25OYW1lLCBzZWxlY3RvciwgbW9kLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucywgY2FsbGJhY2spIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG5cblxuICBpZiAodHlwZW9mIG9wdGlvbnMgPT09IFwiZnVuY3Rpb25cIiAmJiAhIGNhbGxiYWNrKSB7XG4gICAgY2FsbGJhY2sgPSBvcHRpb25zO1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuXG4gIHJldHVybiBzZWxmLnVwZGF0ZShjb2xsZWN0aW9uTmFtZSwgc2VsZWN0b3IsIG1vZCxcbiAgICAgICAgICAgICAgICAgICAgIF8uZXh0ZW5kKHt9LCBvcHRpb25zLCB7XG4gICAgICAgICAgICAgICAgICAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgX3JldHVybk9iamVjdDogdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgfSksIGNhbGxiYWNrKTtcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuZmluZCA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgc2VsZWN0b3IsIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAxKVxuICAgIHNlbGVjdG9yID0ge307XG5cbiAgcmV0dXJuIG5ldyBDdXJzb3IoXG4gICAgc2VsZiwgbmV3IEN1cnNvckRlc2NyaXB0aW9uKGNvbGxlY3Rpb25OYW1lLCBzZWxlY3Rvciwgb3B0aW9ucykpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5maW5kT25lQXN5bmMgPSBhc3luYyBmdW5jdGlvbiAoY29sbGVjdGlvbl9uYW1lLCBzZWxlY3RvcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAxKVxuICAgIHNlbGVjdG9yID0ge307XG5cbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gIG9wdGlvbnMubGltaXQgPSAxO1xuICByZXR1cm4gKGF3YWl0IHNlbGYuZmluZChjb2xsZWN0aW9uX25hbWUsIHNlbGVjdG9yLCBvcHRpb25zKS5mZXRjaEFzeW5jKCkpWzBdO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5maW5kT25lID0gZnVuY3Rpb24gKGNvbGxlY3Rpb25fbmFtZSwgc2VsZWN0b3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgcmV0dXJuIEZ1dHVyZS5mcm9tUHJvbWlzZShzZWxmLmZpbmRPbmVBc3luYyhjb2xsZWN0aW9uX25hbWUsIHNlbGVjdG9yLCBvcHRpb25zKSkud2FpdCgpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5jcmVhdGVJbmRleEFzeW5jID0gZnVuY3Rpb24gKGNvbGxlY3Rpb25OYW1lLCBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgLy8gV2UgZXhwZWN0IHRoaXMgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIGF0IHN0YXJ0dXAsIG5vdCBmcm9tIHdpdGhpbiBhIG1ldGhvZCxcbiAgLy8gc28gd2UgZG9uJ3QgaW50ZXJhY3Qgd2l0aCB0aGUgd3JpdGUgZmVuY2UuXG4gIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25OYW1lKTtcbiAgcmV0dXJuIGNvbGxlY3Rpb24uY3JlYXRlSW5kZXgoaW5kZXgsIG9wdGlvbnMpO1xufTtcblxuLy8gV2UnbGwgYWN0dWFsbHkgZGVzaWduIGFuIGluZGV4IEFQSSBsYXRlci4gRm9yIG5vdywgd2UganVzdCBwYXNzIHRocm91Z2ggdG9cbi8vIE1vbmdvJ3MsIGJ1dCBtYWtlIGl0IHN5bmNocm9ub3VzLlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5jcmVhdGVJbmRleCA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgaW5kZXgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuXG4gIHJldHVybiBGdXR1cmUuZnJvbVByb21pc2Uoc2VsZi5jcmVhdGVJbmRleEFzeW5jKGNvbGxlY3Rpb25OYW1lLCBpbmRleCwgb3B0aW9ucykpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5jb3VudERvY3VtZW50cyA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgLi4uYXJncykge1xuICBhcmdzID0gYXJncy5tYXAoYXJnID0+IHJlcGxhY2VUeXBlcyhhcmcsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSk7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSB0aGlzLnJhd0NvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUpO1xuICByZXR1cm4gY29sbGVjdGlvbi5jb3VudERvY3VtZW50cyguLi5hcmdzKTtcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuZXN0aW1hdGVkRG9jdW1lbnRDb3VudCA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgLi4uYXJncykge1xuICBhcmdzID0gYXJncy5tYXAoYXJnID0+IHJlcGxhY2VUeXBlcyhhcmcsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSk7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSB0aGlzLnJhd0NvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUpO1xuICByZXR1cm4gY29sbGVjdGlvbi5lc3RpbWF0ZWREb2N1bWVudENvdW50KC4uLmFyZ3MpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fZW5zdXJlSW5kZXggPSBNb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLmNyZWF0ZUluZGV4O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9kcm9wSW5kZXggPSBmdW5jdGlvbiAoY29sbGVjdGlvbk5hbWUsIGluZGV4KSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuXG4gIC8vIFRoaXMgZnVuY3Rpb24gaXMgb25seSB1c2VkIGJ5IHRlc3QgY29kZSwgbm90IHdpdGhpbiBhIG1ldGhvZCwgc28gd2UgZG9uJ3RcbiAgLy8gaW50ZXJhY3Qgd2l0aCB0aGUgd3JpdGUgZmVuY2UuXG4gIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25OYW1lKTtcbiAgdmFyIGZ1dHVyZSA9IG5ldyBGdXR1cmU7XG4gIHZhciBpbmRleE5hbWUgPSBjb2xsZWN0aW9uLmRyb3BJbmRleChpbmRleCwgZnV0dXJlLnJlc29sdmVyKCkpO1xuICBmdXR1cmUud2FpdCgpO1xufTtcblxuLy8gQ1VSU09SU1xuXG4vLyBUaGVyZSBhcmUgc2V2ZXJhbCBjbGFzc2VzIHdoaWNoIHJlbGF0ZSB0byBjdXJzb3JzOlxuLy9cbi8vIEN1cnNvckRlc2NyaXB0aW9uIHJlcHJlc2VudHMgdGhlIGFyZ3VtZW50cyB1c2VkIHRvIGNvbnN0cnVjdCBhIGN1cnNvcjpcbi8vIGNvbGxlY3Rpb25OYW1lLCBzZWxlY3RvciwgYW5kIChmaW5kKSBvcHRpb25zLiAgQmVjYXVzZSBpdCBpcyB1c2VkIGFzIGEga2V5XG4vLyBmb3IgY3Vyc29yIGRlLWR1cCwgZXZlcnl0aGluZyBpbiBpdCBzaG91bGQgZWl0aGVyIGJlIEpTT04tc3RyaW5naWZpYWJsZSBvclxuLy8gbm90IGFmZmVjdCBvYnNlcnZlQ2hhbmdlcyBvdXRwdXQgKGVnLCBvcHRpb25zLnRyYW5zZm9ybSBmdW5jdGlvbnMgYXJlIG5vdFxuLy8gc3RyaW5naWZpYWJsZSBidXQgZG8gbm90IGFmZmVjdCBvYnNlcnZlQ2hhbmdlcykuXG4vL1xuLy8gU3luY2hyb25vdXNDdXJzb3IgaXMgYSB3cmFwcGVyIGFyb3VuZCBhIE1vbmdvREIgY3Vyc29yXG4vLyB3aGljaCBpbmNsdWRlcyBmdWxseS1zeW5jaHJvbm91cyB2ZXJzaW9ucyBvZiBmb3JFYWNoLCBldGMuXG4vL1xuLy8gQ3Vyc29yIGlzIHRoZSBjdXJzb3Igb2JqZWN0IHJldHVybmVkIGZyb20gZmluZCgpLCB3aGljaCBpbXBsZW1lbnRzIHRoZVxuLy8gZG9jdW1lbnRlZCBNb25nby5Db2xsZWN0aW9uIGN1cnNvciBBUEkuICBJdCB3cmFwcyBhIEN1cnNvckRlc2NyaXB0aW9uIGFuZCBhXG4vLyBTeW5jaHJvbm91c0N1cnNvciAobGF6aWx5OiBpdCBkb2Vzbid0IGNvbnRhY3QgTW9uZ28gdW50aWwgeW91IGNhbGwgYSBtZXRob2Rcbi8vIGxpa2UgZmV0Y2ggb3IgZm9yRWFjaCBvbiBpdCkuXG4vL1xuLy8gT2JzZXJ2ZUhhbmRsZSBpcyB0aGUgXCJvYnNlcnZlIGhhbmRsZVwiIHJldHVybmVkIGZyb20gb2JzZXJ2ZUNoYW5nZXMuIEl0IGhhcyBhXG4vLyByZWZlcmVuY2UgdG8gYW4gT2JzZXJ2ZU11bHRpcGxleGVyLlxuLy9cbi8vIE9ic2VydmVNdWx0aXBsZXhlciBhbGxvd3MgbXVsdGlwbGUgaWRlbnRpY2FsIE9ic2VydmVIYW5kbGVzIHRvIGJlIGRyaXZlbiBieSBhXG4vLyBzaW5nbGUgb2JzZXJ2ZSBkcml2ZXIuXG4vL1xuLy8gVGhlcmUgYXJlIHR3byBcIm9ic2VydmUgZHJpdmVyc1wiIHdoaWNoIGRyaXZlIE9ic2VydmVNdWx0aXBsZXhlcnM6XG4vLyAgIC0gUG9sbGluZ09ic2VydmVEcml2ZXIgY2FjaGVzIHRoZSByZXN1bHRzIG9mIGEgcXVlcnkgYW5kIHJlcnVucyBpdCB3aGVuXG4vLyAgICAgbmVjZXNzYXJ5LlxuLy8gICAtIE9wbG9nT2JzZXJ2ZURyaXZlciBmb2xsb3dzIHRoZSBNb25nbyBvcGVyYXRpb24gbG9nIHRvIGRpcmVjdGx5IG9ic2VydmVcbi8vICAgICBkYXRhYmFzZSBjaGFuZ2VzLlxuLy8gQm90aCBpbXBsZW1lbnRhdGlvbnMgZm9sbG93IHRoZSBzYW1lIHNpbXBsZSBpbnRlcmZhY2U6IHdoZW4geW91IGNyZWF0ZSB0aGVtLFxuLy8gdGhleSBzdGFydCBzZW5kaW5nIG9ic2VydmVDaGFuZ2VzIGNhbGxiYWNrcyAoYW5kIGEgcmVhZHkoKSBpbnZvY2F0aW9uKSB0b1xuLy8gdGhlaXIgT2JzZXJ2ZU11bHRpcGxleGVyLCBhbmQgeW91IHN0b3AgdGhlbSBieSBjYWxsaW5nIHRoZWlyIHN0b3AoKSBtZXRob2QuXG5cbkN1cnNvckRlc2NyaXB0aW9uID0gZnVuY3Rpb24gKGNvbGxlY3Rpb25OYW1lLCBzZWxlY3Rvciwgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHNlbGYuY29sbGVjdGlvbk5hbWUgPSBjb2xsZWN0aW9uTmFtZTtcbiAgc2VsZi5zZWxlY3RvciA9IE1vbmdvLkNvbGxlY3Rpb24uX3Jld3JpdGVTZWxlY3RvcihzZWxlY3Rvcik7XG4gIHNlbGYub3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG59O1xuXG5DdXJzb3IgPSBmdW5jdGlvbiAobW9uZ28sIGN1cnNvckRlc2NyaXB0aW9uKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICBzZWxmLl9tb25nbyA9IG1vbmdvO1xuICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiA9IGN1cnNvckRlc2NyaXB0aW9uO1xuICBzZWxmLl9zeW5jaHJvbm91c0N1cnNvciA9IG51bGw7XG59O1xuXG5mdW5jdGlvbiBzZXR1cFN5bmNocm9ub3VzQ3Vyc29yKGN1cnNvciwgbWV0aG9kKSB7XG4gIC8vIFlvdSBjYW4gb25seSBvYnNlcnZlIGEgdGFpbGFibGUgY3Vyc29yLlxuICBpZiAoY3Vyc29yLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnRhaWxhYmxlKVxuICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGNhbGwgJyArIG1ldGhvZCArICcgb24gYSB0YWlsYWJsZSBjdXJzb3InKTtcblxuICBpZiAoIWN1cnNvci5fc3luY2hyb25vdXNDdXJzb3IpIHtcbiAgICBjdXJzb3IuX3N5bmNocm9ub3VzQ3Vyc29yID0gY3Vyc29yLl9tb25nby5fY3JlYXRlU3luY2hyb25vdXNDdXJzb3IoXG4gICAgICBjdXJzb3IuX2N1cnNvckRlc2NyaXB0aW9uLFxuICAgICAge1xuICAgICAgICAvLyBNYWtlIHN1cmUgdGhhdCB0aGUgXCJjdXJzb3JcIiBhcmd1bWVudCB0byBmb3JFYWNoL21hcCBjYWxsYmFja3MgaXMgdGhlXG4gICAgICAgIC8vIEN1cnNvciwgbm90IHRoZSBTeW5jaHJvbm91c0N1cnNvci5cbiAgICAgICAgc2VsZkZvckl0ZXJhdGlvbjogY3Vyc29yLFxuICAgICAgICB1c2VUcmFuc2Zvcm06IHRydWUsXG4gICAgICB9XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiBjdXJzb3IuX3N5bmNocm9ub3VzQ3Vyc29yO1xufVxuXG5cbkN1cnNvci5wcm90b3R5cGUuY291bnQgPSBmdW5jdGlvbiAoKSB7XG5cbiAgY29uc3QgY29sbGVjdGlvbiA9IHRoaXMuX21vbmdvLnJhd0NvbGxlY3Rpb24odGhpcy5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWUpO1xuICByZXR1cm4gUHJvbWlzZS5hd2FpdChjb2xsZWN0aW9uLmNvdW50RG9jdW1lbnRzKFxuICAgIHJlcGxhY2VUeXBlcyh0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3RvciwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLFxuICAgIHJlcGxhY2VUeXBlcyh0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyksXG4gICkpO1xufTtcblxuWy4uLkFTWU5DX0NVUlNPUl9NRVRIT0RTLCBTeW1ib2wuaXRlcmF0b3IsIFN5bWJvbC5hc3luY0l0ZXJhdG9yXS5mb3JFYWNoKG1ldGhvZE5hbWUgPT4ge1xuICAvLyBjb3VudCBpcyBoYW5kbGVkIHNwZWNpYWxseSBzaW5jZSB3ZSBkb24ndCB3YW50IHRvIGNyZWF0ZSBhIGN1cnNvci5cbiAgLy8gaXQgaXMgc3RpbGwgaW5jbHVkZWQgaW4gQVNZTkNfQ1VSU09SX01FVEhPRFMgYmVjYXVzZSB3ZSBzdGlsbCB3YW50IGFuIGFzeW5jIHZlcnNpb24gb2YgaXQgdG8gZXhpc3QuXG4gIGlmIChtZXRob2ROYW1lICE9PSAnY291bnQnKSB7XG4gICAgQ3Vyc29yLnByb3RvdHlwZVttZXRob2ROYW1lXSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICBjb25zdCBjdXJzb3IgPSBzZXR1cFN5bmNocm9ub3VzQ3Vyc29yKHRoaXMsIG1ldGhvZE5hbWUpO1xuICAgICAgcmV0dXJuIGN1cnNvclttZXRob2ROYW1lXSguLi5hcmdzKTtcbiAgICB9O1xuICB9XG5cbiAgLy8gVGhlc2UgbWV0aG9kcyBhcmUgaGFuZGxlZCBzZXBhcmF0ZWx5LlxuICBpZiAobWV0aG9kTmFtZSA9PT0gU3ltYm9sLml0ZXJhdG9yIHx8IG1ldGhvZE5hbWUgPT09IFN5bWJvbC5hc3luY0l0ZXJhdG9yKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgbWV0aG9kTmFtZUFzeW5jID0gZ2V0QXN5bmNNZXRob2ROYW1lKG1ldGhvZE5hbWUpO1xuICBDdXJzb3IucHJvdG90eXBlW21ldGhvZE5hbWVBc3luY10gPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgIHRyeSB7XG4gICAgICB0aGlzW21ldGhvZE5hbWVdLmlzQ2FsbGVkRnJvbUFzeW5jID0gdHJ1ZTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpc1ttZXRob2ROYW1lXSguLi5hcmdzKSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICB9O1xufSk7XG5cbkN1cnNvci5wcm90b3R5cGUuZ2V0VHJhbnNmb3JtID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy50cmFuc2Zvcm07XG59O1xuXG4vLyBXaGVuIHlvdSBjYWxsIE1ldGVvci5wdWJsaXNoKCkgd2l0aCBhIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIEN1cnNvciwgd2UgbmVlZFxuLy8gdG8gdHJhbnNtdXRlIGl0IGludG8gdGhlIGVxdWl2YWxlbnQgc3Vic2NyaXB0aW9uLiAgVGhpcyBpcyB0aGUgZnVuY3Rpb24gdGhhdFxuLy8gZG9lcyB0aGF0LlxuXG5DdXJzb3IucHJvdG90eXBlLl9wdWJsaXNoQ3Vyc29yID0gZnVuY3Rpb24gKHN1Yikge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciBjb2xsZWN0aW9uID0gc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWU7XG4gIHJldHVybiBNb25nby5Db2xsZWN0aW9uLl9wdWJsaXNoQ3Vyc29yKHNlbGYsIHN1YiwgY29sbGVjdGlvbik7XG59O1xuXG4vLyBVc2VkIHRvIGd1YXJhbnRlZSB0aGF0IHB1Ymxpc2ggZnVuY3Rpb25zIHJldHVybiBhdCBtb3N0IG9uZSBjdXJzb3IgcGVyXG4vLyBjb2xsZWN0aW9uLiBQcml2YXRlLCBiZWNhdXNlIHdlIG1pZ2h0IGxhdGVyIGhhdmUgY3Vyc29ycyB0aGF0IGluY2x1ZGVcbi8vIGRvY3VtZW50cyBmcm9tIG11bHRpcGxlIGNvbGxlY3Rpb25zIHNvbWVob3cuXG5DdXJzb3IucHJvdG90eXBlLl9nZXRDb2xsZWN0aW9uTmFtZSA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICByZXR1cm4gc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWU7XG59O1xuXG5DdXJzb3IucHJvdG90eXBlLm9ic2VydmUgPSBmdW5jdGlvbiAoY2FsbGJhY2tzKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgcmV0dXJuIExvY2FsQ29sbGVjdGlvbi5fb2JzZXJ2ZUZyb21PYnNlcnZlQ2hhbmdlcyhzZWxmLCBjYWxsYmFja3MpO1xufTtcblxuQ3Vyc29yLnByb3RvdHlwZS5vYnNlcnZlQ2hhbmdlcyA9IGZ1bmN0aW9uIChjYWxsYmFja3MsIG9wdGlvbnMgPSB7fSkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciBtZXRob2RzID0gW1xuICAgICdhZGRlZEF0JyxcbiAgICAnYWRkZWQnLFxuICAgICdjaGFuZ2VkQXQnLFxuICAgICdjaGFuZ2VkJyxcbiAgICAncmVtb3ZlZEF0JyxcbiAgICAncmVtb3ZlZCcsXG4gICAgJ21vdmVkVG8nXG4gIF07XG4gIHZhciBvcmRlcmVkID0gTG9jYWxDb2xsZWN0aW9uLl9vYnNlcnZlQ2hhbmdlc0NhbGxiYWNrc0FyZU9yZGVyZWQoY2FsbGJhY2tzKTtcblxuICBsZXQgZXhjZXB0aW9uTmFtZSA9IGNhbGxiYWNrcy5fZnJvbU9ic2VydmUgPyAnb2JzZXJ2ZScgOiAnb2JzZXJ2ZUNoYW5nZXMnO1xuICBleGNlcHRpb25OYW1lICs9ICcgY2FsbGJhY2snO1xuICBtZXRob2RzLmZvckVhY2goZnVuY3Rpb24gKG1ldGhvZCkge1xuICAgIGlmIChjYWxsYmFja3NbbWV0aG9kXSAmJiB0eXBlb2YgY2FsbGJhY2tzW21ldGhvZF0gPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICBjYWxsYmFja3NbbWV0aG9kXSA9IE1ldGVvci5iaW5kRW52aXJvbm1lbnQoY2FsbGJhY2tzW21ldGhvZF0sIG1ldGhvZCArIGV4Y2VwdGlvbk5hbWUpO1xuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIHNlbGYuX21vbmdvLl9vYnNlcnZlQ2hhbmdlcyhcbiAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzLCBvcHRpb25zLm5vbk11dGF0aW5nQ2FsbGJhY2tzKTtcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX2NyZWF0ZVN5bmNocm9ub3VzQ3Vyc29yID0gZnVuY3Rpb24oXG4gICAgY3Vyc29yRGVzY3JpcHRpb24sIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBvcHRpb25zID0gXy5waWNrKG9wdGlvbnMgfHwge30sICdzZWxmRm9ySXRlcmF0aW9uJywgJ3VzZVRyYW5zZm9ybScpO1xuXG4gIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGN1cnNvckRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lKTtcbiAgdmFyIGN1cnNvck9wdGlvbnMgPSBjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zO1xuICB2YXIgbW9uZ29PcHRpb25zID0ge1xuICAgIHNvcnQ6IGN1cnNvck9wdGlvbnMuc29ydCxcbiAgICBsaW1pdDogY3Vyc29yT3B0aW9ucy5saW1pdCxcbiAgICBza2lwOiBjdXJzb3JPcHRpb25zLnNraXAsXG4gICAgcHJvamVjdGlvbjogY3Vyc29yT3B0aW9ucy5maWVsZHMgfHwgY3Vyc29yT3B0aW9ucy5wcm9qZWN0aW9uLFxuICAgIHJlYWRQcmVmZXJlbmNlOiBjdXJzb3JPcHRpb25zLnJlYWRQcmVmZXJlbmNlLFxuICB9O1xuXG4gIC8vIERvIHdlIHdhbnQgYSB0YWlsYWJsZSBjdXJzb3IgKHdoaWNoIG9ubHkgd29ya3Mgb24gY2FwcGVkIGNvbGxlY3Rpb25zKT9cbiAgaWYgKGN1cnNvck9wdGlvbnMudGFpbGFibGUpIHtcbiAgICBtb25nb09wdGlvbnMubnVtYmVyT2ZSZXRyaWVzID0gLTE7XG4gIH1cblxuICB2YXIgZGJDdXJzb3IgPSBjb2xsZWN0aW9uLmZpbmQoXG4gICAgcmVwbGFjZVR5cGVzKGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyksXG4gICAgbW9uZ29PcHRpb25zKTtcblxuICAvLyBEbyB3ZSB3YW50IGEgdGFpbGFibGUgY3Vyc29yICh3aGljaCBvbmx5IHdvcmtzIG9uIGNhcHBlZCBjb2xsZWN0aW9ucyk/XG4gIGlmIChjdXJzb3JPcHRpb25zLnRhaWxhYmxlKSB7XG4gICAgLy8gV2Ugd2FudCBhIHRhaWxhYmxlIGN1cnNvci4uLlxuICAgIGRiQ3Vyc29yLmFkZEN1cnNvckZsYWcoXCJ0YWlsYWJsZVwiLCB0cnVlKVxuICAgIC8vIC4uLiBhbmQgZm9yIHRoZSBzZXJ2ZXIgdG8gd2FpdCBhIGJpdCBpZiBhbnkgZ2V0TW9yZSBoYXMgbm8gZGF0YSAocmF0aGVyXG4gICAgLy8gdGhhbiBtYWtpbmcgdXMgcHV0IHRoZSByZWxldmFudCBzbGVlcHMgaW4gdGhlIGNsaWVudCkuLi5cbiAgICBkYkN1cnNvci5hZGRDdXJzb3JGbGFnKFwiYXdhaXREYXRhXCIsIHRydWUpXG5cbiAgICAvLyBBbmQgaWYgdGhpcyBpcyBvbiB0aGUgb3Bsb2cgY29sbGVjdGlvbiBhbmQgdGhlIGN1cnNvciBzcGVjaWZpZXMgYSAndHMnLFxuICAgIC8vIHRoZW4gc2V0IHRoZSB1bmRvY3VtZW50ZWQgb3Bsb2cgcmVwbGF5IGZsYWcsIHdoaWNoIGRvZXMgYSBzcGVjaWFsIHNjYW4gdG9cbiAgICAvLyBmaW5kIHRoZSBmaXJzdCBkb2N1bWVudCAoaW5zdGVhZCBvZiBjcmVhdGluZyBhbiBpbmRleCBvbiB0cykuIFRoaXMgaXMgYVxuICAgIC8vIHZlcnkgaGFyZC1jb2RlZCBNb25nbyBmbGFnIHdoaWNoIG9ubHkgd29ya3Mgb24gdGhlIG9wbG9nIGNvbGxlY3Rpb24gYW5kXG4gICAgLy8gb25seSB3b3JrcyB3aXRoIHRoZSB0cyBmaWVsZC5cbiAgICBpZiAoY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWUgPT09IE9QTE9HX0NPTExFQ1RJT04gJiZcbiAgICAgICAgY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3IudHMpIHtcbiAgICAgIGRiQ3Vyc29yLmFkZEN1cnNvckZsYWcoXCJvcGxvZ1JlcGxheVwiLCB0cnVlKVxuICAgIH1cbiAgfVxuXG4gIGlmICh0eXBlb2YgY3Vyc29yT3B0aW9ucy5tYXhUaW1lTXMgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgZGJDdXJzb3IgPSBkYkN1cnNvci5tYXhUaW1lTVMoY3Vyc29yT3B0aW9ucy5tYXhUaW1lTXMpO1xuICB9XG4gIGlmICh0eXBlb2YgY3Vyc29yT3B0aW9ucy5oaW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgIGRiQ3Vyc29yID0gZGJDdXJzb3IuaGludChjdXJzb3JPcHRpb25zLmhpbnQpO1xuICB9XG5cbiAgcmV0dXJuIG5ldyBTeW5jaHJvbm91c0N1cnNvcihkYkN1cnNvciwgY3Vyc29yRGVzY3JpcHRpb24sIG9wdGlvbnMsIGNvbGxlY3Rpb24pO1xufTtcblxudmFyIFN5bmNocm9ub3VzQ3Vyc29yID0gZnVuY3Rpb24gKGRiQ3Vyc29yLCBjdXJzb3JEZXNjcmlwdGlvbiwgb3B0aW9ucywgY29sbGVjdGlvbikge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIG9wdGlvbnMgPSBfLnBpY2sob3B0aW9ucyB8fCB7fSwgJ3NlbGZGb3JJdGVyYXRpb24nLCAndXNlVHJhbnNmb3JtJyk7XG5cbiAgc2VsZi5fZGJDdXJzb3IgPSBkYkN1cnNvcjtcbiAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24gPSBjdXJzb3JEZXNjcmlwdGlvbjtcbiAgLy8gVGhlIFwic2VsZlwiIGFyZ3VtZW50IHBhc3NlZCB0byBmb3JFYWNoL21hcCBjYWxsYmFja3MuIElmIHdlJ3JlIHdyYXBwZWRcbiAgLy8gaW5zaWRlIGEgdXNlci12aXNpYmxlIEN1cnNvciwgd2Ugd2FudCB0byBwcm92aWRlIHRoZSBvdXRlciBjdXJzb3IhXG4gIHNlbGYuX3NlbGZGb3JJdGVyYXRpb24gPSBvcHRpb25zLnNlbGZGb3JJdGVyYXRpb24gfHwgc2VsZjtcbiAgaWYgKG9wdGlvbnMudXNlVHJhbnNmb3JtICYmIGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMudHJhbnNmb3JtKSB7XG4gICAgc2VsZi5fdHJhbnNmb3JtID0gTG9jYWxDb2xsZWN0aW9uLndyYXBUcmFuc2Zvcm0oXG4gICAgICBjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnRyYW5zZm9ybSk7XG4gIH0gZWxzZSB7XG4gICAgc2VsZi5fdHJhbnNmb3JtID0gbnVsbDtcbiAgfVxuXG4gIHNlbGYuX3N5bmNocm9ub3VzQ291bnQgPSBGdXR1cmUud3JhcChcbiAgICBjb2xsZWN0aW9uLmNvdW50RG9jdW1lbnRzLmJpbmQoXG4gICAgICBjb2xsZWN0aW9uLFxuICAgICAgcmVwbGFjZVR5cGVzKGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyksXG4gICAgICByZXBsYWNlVHlwZXMoY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucywgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLFxuICAgIClcbiAgKTtcbiAgc2VsZi5fdmlzaXRlZElkcyA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xufTtcblxuXy5leHRlbmQoU3luY2hyb25vdXNDdXJzb3IucHJvdG90eXBlLCB7XG4gIC8vIFJldHVybnMgYSBQcm9taXNlIGZvciB0aGUgbmV4dCBvYmplY3QgZnJvbSB0aGUgdW5kZXJseWluZyBjdXJzb3IgKGJlZm9yZVxuICAvLyB0aGUgTW9uZ28tPk1ldGVvciB0eXBlIHJlcGxhY2VtZW50KS5cbiAgX3Jhd05leHRPYmplY3RQcm9taXNlOiBmdW5jdGlvbiAoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHNlbGYuX2RiQ3Vyc29yLm5leHQoKGVyciwgZG9jKSA9PiB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXNvbHZlKGRvYyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9LFxuXG4gIC8vIFJldHVybnMgYSBQcm9taXNlIGZvciB0aGUgbmV4dCBvYmplY3QgZnJvbSB0aGUgY3Vyc29yLCBza2lwcGluZyB0aG9zZSB3aG9zZVxuICAvLyBJRHMgd2UndmUgYWxyZWFkeSBzZWVuIGFuZCByZXBsYWNpbmcgTW9uZ28gYXRvbXMgd2l0aCBNZXRlb3IgYXRvbXMuXG4gIF9uZXh0T2JqZWN0UHJvbWlzZTogYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICB2YXIgZG9jID0gYXdhaXQgc2VsZi5fcmF3TmV4dE9iamVjdFByb21pc2UoKTtcblxuICAgICAgaWYgKCFkb2MpIHJldHVybiBudWxsO1xuICAgICAgZG9jID0gcmVwbGFjZVR5cGVzKGRvYywgcmVwbGFjZU1vbmdvQXRvbVdpdGhNZXRlb3IpO1xuXG4gICAgICBpZiAoIXNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMudGFpbGFibGUgJiYgXy5oYXMoZG9jLCAnX2lkJykpIHtcbiAgICAgICAgLy8gRGlkIE1vbmdvIGdpdmUgdXMgZHVwbGljYXRlIGRvY3VtZW50cyBpbiB0aGUgc2FtZSBjdXJzb3I/IElmIHNvLFxuICAgICAgICAvLyBpZ25vcmUgdGhpcyBvbmUuIChEbyB0aGlzIGJlZm9yZSB0aGUgdHJhbnNmb3JtLCBzaW5jZSB0cmFuc2Zvcm0gbWlnaHRcbiAgICAgICAgLy8gcmV0dXJuIHNvbWUgdW5yZWxhdGVkIHZhbHVlLikgV2UgZG9uJ3QgZG8gdGhpcyBmb3IgdGFpbGFibGUgY3Vyc29ycyxcbiAgICAgICAgLy8gYmVjYXVzZSB3ZSB3YW50IHRvIG1haW50YWluIE8oMSkgbWVtb3J5IHVzYWdlLiBBbmQgaWYgdGhlcmUgaXNuJ3QgX2lkXG4gICAgICAgIC8vIGZvciBzb21lIHJlYXNvbiAobWF5YmUgaXQncyB0aGUgb3Bsb2cpLCB0aGVuIHdlIGRvbid0IGRvIHRoaXMgZWl0aGVyLlxuICAgICAgICAvLyAoQmUgY2FyZWZ1bCB0byBkbyB0aGlzIGZvciBmYWxzZXkgYnV0IGV4aXN0aW5nIF9pZCwgdGhvdWdoLilcbiAgICAgICAgaWYgKHNlbGYuX3Zpc2l0ZWRJZHMuaGFzKGRvYy5faWQpKSBjb250aW51ZTtcbiAgICAgICAgc2VsZi5fdmlzaXRlZElkcy5zZXQoZG9jLl9pZCwgdHJ1ZSk7XG4gICAgICB9XG5cbiAgICAgIGlmIChzZWxmLl90cmFuc2Zvcm0pXG4gICAgICAgIGRvYyA9IHNlbGYuX3RyYW5zZm9ybShkb2MpO1xuXG4gICAgICByZXR1cm4gZG9jO1xuICAgIH1cbiAgfSxcblxuICAvLyBSZXR1cm5zIGEgcHJvbWlzZSB3aGljaCBpcyByZXNvbHZlZCB3aXRoIHRoZSBuZXh0IG9iamVjdCAobGlrZSB3aXRoXG4gIC8vIF9uZXh0T2JqZWN0UHJvbWlzZSkgb3IgcmVqZWN0ZWQgaWYgdGhlIGN1cnNvciBkb2Vzbid0IHJldHVybiB3aXRoaW5cbiAgLy8gdGltZW91dE1TIG1zLlxuICBfbmV4dE9iamVjdFByb21pc2VXaXRoVGltZW91dDogZnVuY3Rpb24gKHRpbWVvdXRNUykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGlmICghdGltZW91dE1TKSB7XG4gICAgICByZXR1cm4gc2VsZi5fbmV4dE9iamVjdFByb21pc2UoKTtcbiAgICB9XG4gICAgY29uc3QgbmV4dE9iamVjdFByb21pc2UgPSBzZWxmLl9uZXh0T2JqZWN0UHJvbWlzZSgpO1xuICAgIGNvbnN0IHRpbWVvdXRFcnIgPSBuZXcgRXJyb3IoJ0NsaWVudC1zaWRlIHRpbWVvdXQgd2FpdGluZyBmb3IgbmV4dCBvYmplY3QnKTtcbiAgICBjb25zdCB0aW1lb3V0UHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHJlamVjdCh0aW1lb3V0RXJyKTtcbiAgICAgIH0sIHRpbWVvdXRNUyk7XG4gICAgfSk7XG4gICAgcmV0dXJuIFByb21pc2UucmFjZShbbmV4dE9iamVjdFByb21pc2UsIHRpbWVvdXRQcm9taXNlXSlcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGlmIChlcnIgPT09IHRpbWVvdXRFcnIpIHtcbiAgICAgICAgICBzZWxmLmNsb3NlKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfSk7XG4gIH0sXG5cbiAgX25leHRPYmplY3Q6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgcmV0dXJuIHNlbGYuX25leHRPYmplY3RQcm9taXNlKCkuYXdhaXQoKTtcbiAgfSxcblxuICBmb3JFYWNoOiBmdW5jdGlvbiAoY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgd3JhcHBlZEZuID0gTWV0ZW9yLndyYXBGbihjYWxsYmFjayk7XG5cbiAgICAvLyBHZXQgYmFjayB0byB0aGUgYmVnaW5uaW5nLlxuICAgIHNlbGYuX3Jld2luZCgpO1xuXG4gICAgLy8gV2UgaW1wbGVtZW50IHRoZSBsb29wIG91cnNlbGYgaW5zdGVhZCBvZiB1c2luZyBzZWxmLl9kYkN1cnNvci5lYWNoLFxuICAgIC8vIGJlY2F1c2UgXCJlYWNoXCIgd2lsbCBjYWxsIGl0cyBjYWxsYmFjayBvdXRzaWRlIG9mIGEgZmliZXIgd2hpY2ggbWFrZXMgaXRcbiAgICAvLyBtdWNoIG1vcmUgY29tcGxleCB0byBtYWtlIHRoaXMgZnVuY3Rpb24gc3luY2hyb25vdXMuXG4gICAgdmFyIGluZGV4ID0gMDtcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgdmFyIGRvYyA9IHNlbGYuX25leHRPYmplY3QoKTtcbiAgICAgIGlmICghZG9jKSByZXR1cm47XG4gICAgICB3cmFwcGVkRm4uY2FsbCh0aGlzQXJnLCBkb2MsIGluZGV4KyssIHNlbGYuX3NlbGZGb3JJdGVyYXRpb24pO1xuICAgIH1cbiAgfSxcblxuICAvLyBYWFggQWxsb3cgb3ZlcmxhcHBpbmcgY2FsbGJhY2sgZXhlY3V0aW9ucyBpZiBjYWxsYmFjayB5aWVsZHMuXG4gIG1hcDogZnVuY3Rpb24gKGNhbGxiYWNrLCB0aGlzQXJnKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGNvbnN0IHdyYXBwZWRGbiA9IE1ldGVvci53cmFwRm4oY2FsbGJhY2spO1xuICAgIHZhciByZXMgPSBbXTtcbiAgICBzZWxmLmZvckVhY2goZnVuY3Rpb24gKGRvYywgaW5kZXgpIHtcbiAgICAgIHJlcy5wdXNoKHdyYXBwZWRGbi5jYWxsKHRoaXNBcmcsIGRvYywgaW5kZXgsIHNlbGYuX3NlbGZGb3JJdGVyYXRpb24pKTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzO1xuICB9LFxuXG4gIF9yZXdpbmQ6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAvLyBrbm93biB0byBiZSBzeW5jaHJvbm91c1xuICAgIHNlbGYuX2RiQ3Vyc29yLnJld2luZCgpO1xuXG4gICAgc2VsZi5fdmlzaXRlZElkcyA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuICB9LFxuXG4gIC8vIE1vc3RseSB1c2FibGUgZm9yIHRhaWxhYmxlIGN1cnNvcnMuXG4gIGNsb3NlOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgc2VsZi5fZGJDdXJzb3IuY2xvc2UoKTtcbiAgfSxcblxuICBmZXRjaDogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gc2VsZi5tYXAoXy5pZGVudGl0eSk7XG4gIH0sXG5cbiAgY291bnQ6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgcmV0dXJuIHNlbGYuX3N5bmNocm9ub3VzQ291bnQoKS53YWl0KCk7XG4gIH0sXG5cbiAgLy8gVGhpcyBtZXRob2QgaXMgTk9UIHdyYXBwZWQgaW4gQ3Vyc29yLlxuICBnZXRSYXdPYmplY3RzOiBmdW5jdGlvbiAob3JkZXJlZCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAob3JkZXJlZCkge1xuICAgICAgcmV0dXJuIHNlbGYuZmV0Y2goKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHJlc3VsdHMgPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgICAgIHNlbGYuZm9yRWFjaChmdW5jdGlvbiAoZG9jKSB7XG4gICAgICAgIHJlc3VsdHMuc2V0KGRvYy5faWQsIGRvYyk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXN1bHRzO1xuICAgIH1cbiAgfVxufSk7XG5cblN5bmNocm9ub3VzQ3Vyc29yLnByb3RvdHlwZVtTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24gKCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgLy8gR2V0IGJhY2sgdG8gdGhlIGJlZ2lubmluZy5cbiAgc2VsZi5fcmV3aW5kKCk7XG5cbiAgcmV0dXJuIHtcbiAgICBuZXh0KCkge1xuICAgICAgY29uc3QgZG9jID0gc2VsZi5fbmV4dE9iamVjdCgpO1xuICAgICAgcmV0dXJuIGRvYyA/IHtcbiAgICAgICAgdmFsdWU6IGRvY1xuICAgICAgfSA6IHtcbiAgICAgICAgZG9uZTogdHJ1ZVxuICAgICAgfTtcbiAgICB9XG4gIH07XG59O1xuXG5TeW5jaHJvbm91c0N1cnNvci5wcm90b3R5cGVbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID0gZnVuY3Rpb24gKCkge1xuICBjb25zdCBzeW5jUmVzdWx0ID0gdGhpc1tTeW1ib2wuaXRlcmF0b3JdKCk7XG4gIHJldHVybiB7XG4gICAgYXN5bmMgbmV4dCgpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoc3luY1Jlc3VsdC5uZXh0KCkpO1xuICAgIH1cbiAgfTtcbn1cblxuLy8gVGFpbHMgdGhlIGN1cnNvciBkZXNjcmliZWQgYnkgY3Vyc29yRGVzY3JpcHRpb24sIG1vc3QgbGlrZWx5IG9uIHRoZVxuLy8gb3Bsb2cuIENhbGxzIGRvY0NhbGxiYWNrIHdpdGggZWFjaCBkb2N1bWVudCBmb3VuZC4gSWdub3JlcyBlcnJvcnMgYW5kIGp1c3Rcbi8vIHJlc3RhcnRzIHRoZSB0YWlsIG9uIGVycm9yLlxuLy9cbi8vIElmIHRpbWVvdXRNUyBpcyBzZXQsIHRoZW4gaWYgd2UgZG9uJ3QgZ2V0IGEgbmV3IGRvY3VtZW50IGV2ZXJ5IHRpbWVvdXRNUyxcbi8vIGtpbGwgYW5kIHJlc3RhcnQgdGhlIGN1cnNvci4gVGhpcyBpcyBwcmltYXJpbHkgYSB3b3JrYXJvdW5kIGZvciAjODU5OC5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUudGFpbCA9IGZ1bmN0aW9uIChjdXJzb3JEZXNjcmlwdGlvbiwgZG9jQ2FsbGJhY2ssIHRpbWVvdXRNUykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIGlmICghY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy50YWlsYWJsZSlcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW4gb25seSB0YWlsIGEgdGFpbGFibGUgY3Vyc29yXCIpO1xuXG4gIHZhciBjdXJzb3IgPSBzZWxmLl9jcmVhdGVTeW5jaHJvbm91c0N1cnNvcihjdXJzb3JEZXNjcmlwdGlvbik7XG5cbiAgdmFyIHN0b3BwZWQgPSBmYWxzZTtcbiAgdmFyIGxhc3RUUztcbiAgdmFyIGxvb3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGRvYyA9IG51bGw7XG4gICAgd2hpbGUgKHRydWUpIHtcbiAgICAgIGlmIChzdG9wcGVkKVxuICAgICAgICByZXR1cm47XG4gICAgICB0cnkge1xuICAgICAgICBkb2MgPSBjdXJzb3IuX25leHRPYmplY3RQcm9taXNlV2l0aFRpbWVvdXQodGltZW91dE1TKS5hd2FpdCgpO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIC8vIFRoZXJlJ3Mgbm8gZ29vZCB3YXkgdG8gZmlndXJlIG91dCBpZiB0aGlzIHdhcyBhY3R1YWxseSBhbiBlcnJvciBmcm9tXG4gICAgICAgIC8vIE1vbmdvLCBvciBqdXN0IGNsaWVudC1zaWRlIChpbmNsdWRpbmcgb3VyIG93biB0aW1lb3V0IGVycm9yKS4gQWhcbiAgICAgICAgLy8gd2VsbC4gQnV0IGVpdGhlciB3YXksIHdlIG5lZWQgdG8gcmV0cnkgdGhlIGN1cnNvciAodW5sZXNzIHRoZSBmYWlsdXJlXG4gICAgICAgIC8vIHdhcyBiZWNhdXNlIHRoZSBvYnNlcnZlIGdvdCBzdG9wcGVkKS5cbiAgICAgICAgZG9jID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIC8vIFNpbmNlIHdlIGF3YWl0ZWQgYSBwcm9taXNlIGFib3ZlLCB3ZSBuZWVkIHRvIGNoZWNrIGFnYWluIHRvIHNlZSBpZlxuICAgICAgLy8gd2UndmUgYmVlbiBzdG9wcGVkIGJlZm9yZSBjYWxsaW5nIHRoZSBjYWxsYmFjay5cbiAgICAgIGlmIChzdG9wcGVkKVxuICAgICAgICByZXR1cm47XG4gICAgICBpZiAoZG9jKSB7XG4gICAgICAgIC8vIElmIGEgdGFpbGFibGUgY3Vyc29yIGNvbnRhaW5zIGEgXCJ0c1wiIGZpZWxkLCB1c2UgaXQgdG8gcmVjcmVhdGUgdGhlXG4gICAgICAgIC8vIGN1cnNvciBvbiBlcnJvci4gKFwidHNcIiBpcyBhIHN0YW5kYXJkIHRoYXQgTW9uZ28gdXNlcyBpbnRlcm5hbGx5IGZvclxuICAgICAgICAvLyB0aGUgb3Bsb2csIGFuZCB0aGVyZSdzIGEgc3BlY2lhbCBmbGFnIHRoYXQgbGV0cyB5b3UgZG8gYmluYXJ5IHNlYXJjaFxuICAgICAgICAvLyBvbiBpdCBpbnN0ZWFkIG9mIG5lZWRpbmcgdG8gdXNlIGFuIGluZGV4LilcbiAgICAgICAgbGFzdFRTID0gZG9jLnRzO1xuICAgICAgICBkb2NDYWxsYmFjayhkb2MpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIG5ld1NlbGVjdG9yID0gXy5jbG9uZShjdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3Rvcik7XG4gICAgICAgIGlmIChsYXN0VFMpIHtcbiAgICAgICAgICBuZXdTZWxlY3Rvci50cyA9IHskZ3Q6IGxhc3RUU307XG4gICAgICAgIH1cbiAgICAgICAgY3Vyc29yID0gc2VsZi5fY3JlYXRlU3luY2hyb25vdXNDdXJzb3IobmV3IEN1cnNvckRlc2NyaXB0aW9uKFxuICAgICAgICAgIGN1cnNvckRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lLFxuICAgICAgICAgIG5ld1NlbGVjdG9yLFxuICAgICAgICAgIGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMpKTtcbiAgICAgICAgLy8gTW9uZ28gZmFpbG92ZXIgdGFrZXMgbWFueSBzZWNvbmRzLiAgUmV0cnkgaW4gYSBiaXQuICAoV2l0aG91dCB0aGlzXG4gICAgICAgIC8vIHNldFRpbWVvdXQsIHdlIHBlZyB0aGUgQ1BVIGF0IDEwMCUgYW5kIG5ldmVyIG5vdGljZSB0aGUgYWN0dWFsXG4gICAgICAgIC8vIGZhaWxvdmVyLlxuICAgICAgICBNZXRlb3Iuc2V0VGltZW91dChsb29wLCAxMDApO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgTWV0ZW9yLmRlZmVyKGxvb3ApO1xuXG4gIHJldHVybiB7XG4gICAgc3RvcDogZnVuY3Rpb24gKCkge1xuICAgICAgc3RvcHBlZCA9IHRydWU7XG4gICAgICBjdXJzb3IuY2xvc2UoKTtcbiAgICB9XG4gIH07XG59O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9vYnNlcnZlQ2hhbmdlcyA9IGZ1bmN0aW9uIChcbiAgICBjdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzLCBub25NdXRhdGluZ0NhbGxiYWNrcykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMudGFpbGFibGUpIHtcbiAgICByZXR1cm4gc2VsZi5fb2JzZXJ2ZUNoYW5nZXNUYWlsYWJsZShjdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzKTtcbiAgfVxuXG4gIC8vIFlvdSBtYXkgbm90IGZpbHRlciBvdXQgX2lkIHdoZW4gb2JzZXJ2aW5nIGNoYW5nZXMsIGJlY2F1c2UgdGhlIGlkIGlzIGEgY29yZVxuICAvLyBwYXJ0IG9mIHRoZSBvYnNlcnZlQ2hhbmdlcyBBUEkuXG4gIGNvbnN0IGZpZWxkc09wdGlvbnMgPSBjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnByb2plY3Rpb24gfHwgY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5maWVsZHM7XG4gIGlmIChmaWVsZHNPcHRpb25zICYmXG4gICAgICAoZmllbGRzT3B0aW9ucy5faWQgPT09IDAgfHxcbiAgICAgICBmaWVsZHNPcHRpb25zLl9pZCA9PT0gZmFsc2UpKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJZb3UgbWF5IG5vdCBvYnNlcnZlIGEgY3Vyc29yIHdpdGgge2ZpZWxkczoge19pZDogMH19XCIpO1xuICB9XG5cbiAgdmFyIG9ic2VydmVLZXkgPSBFSlNPTi5zdHJpbmdpZnkoXG4gICAgXy5leHRlbmQoe29yZGVyZWQ6IG9yZGVyZWR9LCBjdXJzb3JEZXNjcmlwdGlvbikpO1xuXG4gIHZhciBtdWx0aXBsZXhlciwgb2JzZXJ2ZURyaXZlcjtcbiAgdmFyIGZpcnN0SGFuZGxlID0gZmFsc2U7XG5cbiAgLy8gRmluZCBhIG1hdGNoaW5nIE9ic2VydmVNdWx0aXBsZXhlciwgb3IgY3JlYXRlIGEgbmV3IG9uZS4gVGhpcyBuZXh0IGJsb2NrIGlzXG4gIC8vIGd1YXJhbnRlZWQgdG8gbm90IHlpZWxkIChhbmQgaXQgZG9lc24ndCBjYWxsIGFueXRoaW5nIHRoYXQgY2FuIG9ic2VydmUgYVxuICAvLyBuZXcgcXVlcnkpLCBzbyBubyBvdGhlciBjYWxscyB0byB0aGlzIGZ1bmN0aW9uIGNhbiBpbnRlcmxlYXZlIHdpdGggaXQuXG4gIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoXy5oYXMoc2VsZi5fb2JzZXJ2ZU11bHRpcGxleGVycywgb2JzZXJ2ZUtleSkpIHtcbiAgICAgIG11bHRpcGxleGVyID0gc2VsZi5fb2JzZXJ2ZU11bHRpcGxleGVyc1tvYnNlcnZlS2V5XTtcbiAgICB9IGVsc2Uge1xuICAgICAgZmlyc3RIYW5kbGUgPSB0cnVlO1xuICAgICAgLy8gQ3JlYXRlIGEgbmV3IE9ic2VydmVNdWx0aXBsZXhlci5cbiAgICAgIG11bHRpcGxleGVyID0gbmV3IE9ic2VydmVNdWx0aXBsZXhlcih7XG4gICAgICAgIG9yZGVyZWQ6IG9yZGVyZWQsXG4gICAgICAgIG9uU3RvcDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGRlbGV0ZSBzZWxmLl9vYnNlcnZlTXVsdGlwbGV4ZXJzW29ic2VydmVLZXldO1xuICAgICAgICAgIG9ic2VydmVEcml2ZXIuc3RvcCgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHNlbGYuX29ic2VydmVNdWx0aXBsZXhlcnNbb2JzZXJ2ZUtleV0gPSBtdWx0aXBsZXhlcjtcbiAgICB9XG4gIH0pO1xuXG4gIHZhciBvYnNlcnZlSGFuZGxlID0gbmV3IE9ic2VydmVIYW5kbGUobXVsdGlwbGV4ZXIsXG4gICAgY2FsbGJhY2tzLFxuICAgIG5vbk11dGF0aW5nQ2FsbGJhY2tzLFxuICApO1xuXG4gIGlmIChmaXJzdEhhbmRsZSkge1xuICAgIHZhciBtYXRjaGVyLCBzb3J0ZXI7XG4gICAgdmFyIGNhblVzZU9wbG9nID0gXy5hbGwoW1xuICAgICAgZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBBdCBhIGJhcmUgbWluaW11bSwgdXNpbmcgdGhlIG9wbG9nIHJlcXVpcmVzIHVzIHRvIGhhdmUgYW4gb3Bsb2csIHRvXG4gICAgICAgIC8vIHdhbnQgdW5vcmRlcmVkIGNhbGxiYWNrcywgYW5kIHRvIG5vdCB3YW50IGEgY2FsbGJhY2sgb24gdGhlIHBvbGxzXG4gICAgICAgIC8vIHRoYXQgd29uJ3QgaGFwcGVuLlxuICAgICAgICByZXR1cm4gc2VsZi5fb3Bsb2dIYW5kbGUgJiYgIW9yZGVyZWQgJiZcbiAgICAgICAgICAhY2FsbGJhY2tzLl90ZXN0T25seVBvbGxDYWxsYmFjaztcbiAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy8gV2UgbmVlZCB0byBiZSBhYmxlIHRvIGNvbXBpbGUgdGhlIHNlbGVjdG9yLiBGYWxsIGJhY2sgdG8gcG9sbGluZyBmb3JcbiAgICAgICAgLy8gc29tZSBuZXdmYW5nbGVkICRzZWxlY3RvciB0aGF0IG1pbmltb25nbyBkb2Vzbid0IHN1cHBvcnQgeWV0LlxuICAgICAgICB0cnkge1xuICAgICAgICAgIG1hdGNoZXIgPSBuZXcgTWluaW1vbmdvLk1hdGNoZXIoY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3IpO1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gWFhYIG1ha2UgYWxsIGNvbXBpbGF0aW9uIGVycm9ycyBNaW5pbW9uZ29FcnJvciBvciBzb21ldGhpbmdcbiAgICAgICAgICAvLyAgICAgc28gdGhhdCB0aGlzIGRvZXNuJ3QgaWdub3JlIHVucmVsYXRlZCBleGNlcHRpb25zXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIC4uLiBhbmQgdGhlIHNlbGVjdG9yIGl0c2VsZiBuZWVkcyB0byBzdXBwb3J0IG9wbG9nLlxuICAgICAgICByZXR1cm4gT3Bsb2dPYnNlcnZlRHJpdmVyLmN1cnNvclN1cHBvcnRlZChjdXJzb3JEZXNjcmlwdGlvbiwgbWF0Y2hlcik7XG4gICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIEFuZCB3ZSBuZWVkIHRvIGJlIGFibGUgdG8gY29tcGlsZSB0aGUgc29ydCwgaWYgYW55LiAgZWcsIGNhbid0IGJlXG4gICAgICAgIC8vIHskbmF0dXJhbDogMX0uXG4gICAgICAgIGlmICghY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5zb3J0KVxuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHNvcnRlciA9IG5ldyBNaW5pbW9uZ28uU29ydGVyKGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMuc29ydCk7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBYWFggbWFrZSBhbGwgY29tcGlsYXRpb24gZXJyb3JzIE1pbmltb25nb0Vycm9yIG9yIHNvbWV0aGluZ1xuICAgICAgICAgIC8vICAgICBzbyB0aGF0IHRoaXMgZG9lc24ndCBpZ25vcmUgdW5yZWxhdGVkIGV4Y2VwdGlvbnNcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1dLCBmdW5jdGlvbiAoZikgeyByZXR1cm4gZigpOyB9KTsgIC8vIGludm9rZSBlYWNoIGZ1bmN0aW9uXG5cbiAgICB2YXIgZHJpdmVyQ2xhc3MgPSBjYW5Vc2VPcGxvZyA/IE9wbG9nT2JzZXJ2ZURyaXZlciA6IFBvbGxpbmdPYnNlcnZlRHJpdmVyO1xuICAgIG9ic2VydmVEcml2ZXIgPSBuZXcgZHJpdmVyQ2xhc3Moe1xuICAgICAgY3Vyc29yRGVzY3JpcHRpb246IGN1cnNvckRlc2NyaXB0aW9uLFxuICAgICAgbW9uZ29IYW5kbGU6IHNlbGYsXG4gICAgICBtdWx0aXBsZXhlcjogbXVsdGlwbGV4ZXIsXG4gICAgICBvcmRlcmVkOiBvcmRlcmVkLFxuICAgICAgbWF0Y2hlcjogbWF0Y2hlciwgIC8vIGlnbm9yZWQgYnkgcG9sbGluZ1xuICAgICAgc29ydGVyOiBzb3J0ZXIsICAvLyBpZ25vcmVkIGJ5IHBvbGxpbmdcbiAgICAgIF90ZXN0T25seVBvbGxDYWxsYmFjazogY2FsbGJhY2tzLl90ZXN0T25seVBvbGxDYWxsYmFja1xuICAgIH0pO1xuXG4gICAgLy8gVGhpcyBmaWVsZCBpcyBvbmx5IHNldCBmb3IgdXNlIGluIHRlc3RzLlxuICAgIG11bHRpcGxleGVyLl9vYnNlcnZlRHJpdmVyID0gb2JzZXJ2ZURyaXZlcjtcbiAgfVxuXG4gIC8vIEJsb2NrcyB1bnRpbCB0aGUgaW5pdGlhbCBhZGRzIGhhdmUgYmVlbiBzZW50LlxuICBtdWx0aXBsZXhlci5hZGRIYW5kbGVBbmRTZW5kSW5pdGlhbEFkZHMob2JzZXJ2ZUhhbmRsZSk7XG5cbiAgcmV0dXJuIG9ic2VydmVIYW5kbGU7XG59O1xuXG4vLyBMaXN0ZW4gZm9yIHRoZSBpbnZhbGlkYXRpb24gbWVzc2FnZXMgdGhhdCB3aWxsIHRyaWdnZXIgdXMgdG8gcG9sbCB0aGVcbi8vIGRhdGFiYXNlIGZvciBjaGFuZ2VzLiBJZiB0aGlzIHNlbGVjdG9yIHNwZWNpZmllcyBzcGVjaWZpYyBJRHMsIHNwZWNpZnkgdGhlbVxuLy8gaGVyZSwgc28gdGhhdCB1cGRhdGVzIHRvIGRpZmZlcmVudCBzcGVjaWZpYyBJRHMgZG9uJ3QgY2F1c2UgdXMgdG8gcG9sbC5cbi8vIGxpc3RlbkNhbGxiYWNrIGlzIHRoZSBzYW1lIGtpbmQgb2YgKG5vdGlmaWNhdGlvbiwgY29tcGxldGUpIGNhbGxiYWNrIHBhc3NlZFxuLy8gdG8gSW52YWxpZGF0aW9uQ3Jvc3NiYXIubGlzdGVuLlxuXG5saXN0ZW5BbGwgPSBmdW5jdGlvbiAoY3Vyc29yRGVzY3JpcHRpb24sIGxpc3RlbkNhbGxiYWNrKSB7XG4gIHZhciBsaXN0ZW5lcnMgPSBbXTtcbiAgZm9yRWFjaFRyaWdnZXIoY3Vyc29yRGVzY3JpcHRpb24sIGZ1bmN0aW9uICh0cmlnZ2VyKSB7XG4gICAgbGlzdGVuZXJzLnB1c2goRERQU2VydmVyLl9JbnZhbGlkYXRpb25Dcm9zc2Jhci5saXN0ZW4oXG4gICAgICB0cmlnZ2VyLCBsaXN0ZW5DYWxsYmFjaykpO1xuICB9KTtcblxuICByZXR1cm4ge1xuICAgIHN0b3A6IGZ1bmN0aW9uICgpIHtcbiAgICAgIF8uZWFjaChsaXN0ZW5lcnMsIGZ1bmN0aW9uIChsaXN0ZW5lcikge1xuICAgICAgICBsaXN0ZW5lci5zdG9wKCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG59O1xuXG5mb3JFYWNoVHJpZ2dlciA9IGZ1bmN0aW9uIChjdXJzb3JEZXNjcmlwdGlvbiwgdHJpZ2dlckNhbGxiYWNrKSB7XG4gIHZhciBrZXkgPSB7Y29sbGVjdGlvbjogY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWV9O1xuICB2YXIgc3BlY2lmaWNJZHMgPSBMb2NhbENvbGxlY3Rpb24uX2lkc01hdGNoZWRCeVNlbGVjdG9yKFxuICAgIGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yKTtcbiAgaWYgKHNwZWNpZmljSWRzKSB7XG4gICAgXy5lYWNoKHNwZWNpZmljSWRzLCBmdW5jdGlvbiAoaWQpIHtcbiAgICAgIHRyaWdnZXJDYWxsYmFjayhfLmV4dGVuZCh7aWQ6IGlkfSwga2V5KSk7XG4gICAgfSk7XG4gICAgdHJpZ2dlckNhbGxiYWNrKF8uZXh0ZW5kKHtkcm9wQ29sbGVjdGlvbjogdHJ1ZSwgaWQ6IG51bGx9LCBrZXkpKTtcbiAgfSBlbHNlIHtcbiAgICB0cmlnZ2VyQ2FsbGJhY2soa2V5KTtcbiAgfVxuICAvLyBFdmVyeW9uZSBjYXJlcyBhYm91dCB0aGUgZGF0YWJhc2UgYmVpbmcgZHJvcHBlZC5cbiAgdHJpZ2dlckNhbGxiYWNrKHsgZHJvcERhdGFiYXNlOiB0cnVlIH0pO1xufTtcblxuLy8gb2JzZXJ2ZUNoYW5nZXMgZm9yIHRhaWxhYmxlIGN1cnNvcnMgb24gY2FwcGVkIGNvbGxlY3Rpb25zLlxuLy9cbi8vIFNvbWUgZGlmZmVyZW5jZXMgZnJvbSBub3JtYWwgY3Vyc29yczpcbi8vICAgLSBXaWxsIG5ldmVyIHByb2R1Y2UgYW55dGhpbmcgb3RoZXIgdGhhbiAnYWRkZWQnIG9yICdhZGRlZEJlZm9yZScuIElmIHlvdVxuLy8gICAgIGRvIHVwZGF0ZSBhIGRvY3VtZW50IHRoYXQgaGFzIGFscmVhZHkgYmVlbiBwcm9kdWNlZCwgdGhpcyB3aWxsIG5vdCBub3RpY2Vcbi8vICAgICBpdC5cbi8vICAgLSBJZiB5b3UgZGlzY29ubmVjdCBhbmQgcmVjb25uZWN0IGZyb20gTW9uZ28sIGl0IHdpbGwgZXNzZW50aWFsbHkgcmVzdGFydFxuLy8gICAgIHRoZSBxdWVyeSwgd2hpY2ggd2lsbCBsZWFkIHRvIGR1cGxpY2F0ZSByZXN1bHRzLiBUaGlzIGlzIHByZXR0eSBiYWQsXG4vLyAgICAgYnV0IGlmIHlvdSBpbmNsdWRlIGEgZmllbGQgY2FsbGVkICd0cycgd2hpY2ggaXMgaW5zZXJ0ZWQgYXNcbi8vICAgICBuZXcgTW9uZ29JbnRlcm5hbHMuTW9uZ29UaW1lc3RhbXAoMCwgMCkgKHdoaWNoIGlzIGluaXRpYWxpemVkIHRvIHRoZVxuLy8gICAgIGN1cnJlbnQgTW9uZ28tc3R5bGUgdGltZXN0YW1wKSwgd2UnbGwgYmUgYWJsZSB0byBmaW5kIHRoZSBwbGFjZSB0b1xuLy8gICAgIHJlc3RhcnQgcHJvcGVybHkuIChUaGlzIGZpZWxkIGlzIHNwZWNpZmljYWxseSB1bmRlcnN0b29kIGJ5IE1vbmdvIHdpdGggYW5cbi8vICAgICBvcHRpbWl6YXRpb24gd2hpY2ggYWxsb3dzIGl0IHRvIGZpbmQgdGhlIHJpZ2h0IHBsYWNlIHRvIHN0YXJ0IHdpdGhvdXRcbi8vICAgICBhbiBpbmRleCBvbiB0cy4gSXQncyBob3cgdGhlIG9wbG9nIHdvcmtzLilcbi8vICAgLSBObyBjYWxsYmFja3MgYXJlIHRyaWdnZXJlZCBzeW5jaHJvbm91c2x5IHdpdGggdGhlIGNhbGwgKHRoZXJlJ3Mgbm9cbi8vICAgICBkaWZmZXJlbnRpYXRpb24gYmV0d2VlbiBcImluaXRpYWwgZGF0YVwiIGFuZCBcImxhdGVyIGNoYW5nZXNcIjsgZXZlcnl0aGluZ1xuLy8gICAgIHRoYXQgbWF0Y2hlcyB0aGUgcXVlcnkgZ2V0cyBzZW50IGFzeW5jaHJvbm91c2x5KS5cbi8vICAgLSBEZS1kdXBsaWNhdGlvbiBpcyBub3QgaW1wbGVtZW50ZWQuXG4vLyAgIC0gRG9lcyBub3QgeWV0IGludGVyYWN0IHdpdGggdGhlIHdyaXRlIGZlbmNlLiBQcm9iYWJseSwgdGhpcyBzaG91bGQgd29yayBieVxuLy8gICAgIGlnbm9yaW5nIHJlbW92ZXMgKHdoaWNoIGRvbid0IHdvcmsgb24gY2FwcGVkIGNvbGxlY3Rpb25zKSBhbmQgdXBkYXRlc1xuLy8gICAgICh3aGljaCBkb24ndCBhZmZlY3QgdGFpbGFibGUgY3Vyc29ycyksIGFuZCBqdXN0IGtlZXBpbmcgdHJhY2sgb2YgdGhlIElEXG4vLyAgICAgb2YgdGhlIGluc2VydGVkIG9iamVjdCwgYW5kIGNsb3NpbmcgdGhlIHdyaXRlIGZlbmNlIG9uY2UgeW91IGdldCB0byB0aGF0XG4vLyAgICAgSUQgKG9yIHRpbWVzdGFtcD8pLiAgVGhpcyBkb2Vzbid0IHdvcmsgd2VsbCBpZiB0aGUgZG9jdW1lbnQgZG9lc24ndCBtYXRjaFxuLy8gICAgIHRoZSBxdWVyeSwgdGhvdWdoLiAgT24gdGhlIG90aGVyIGhhbmQsIHRoZSB3cml0ZSBmZW5jZSBjYW4gY2xvc2Vcbi8vICAgICBpbW1lZGlhdGVseSBpZiBpdCBkb2VzIG5vdCBtYXRjaCB0aGUgcXVlcnkuIFNvIGlmIHdlIHRydXN0IG1pbmltb25nb1xuLy8gICAgIGVub3VnaCB0byBhY2N1cmF0ZWx5IGV2YWx1YXRlIHRoZSBxdWVyeSBhZ2FpbnN0IHRoZSB3cml0ZSBmZW5jZSwgd2Vcbi8vICAgICBzaG91bGQgYmUgYWJsZSB0byBkbyB0aGlzLi4uICBPZiBjb3Vyc2UsIG1pbmltb25nbyBkb2Vzbid0IGV2ZW4gc3VwcG9ydFxuLy8gICAgIE1vbmdvIFRpbWVzdGFtcHMgeWV0LlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fb2JzZXJ2ZUNoYW5nZXNUYWlsYWJsZSA9IGZ1bmN0aW9uIChcbiAgICBjdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICAvLyBUYWlsYWJsZSBjdXJzb3JzIG9ubHkgZXZlciBjYWxsIGFkZGVkL2FkZGVkQmVmb3JlIGNhbGxiYWNrcywgc28gaXQncyBhblxuICAvLyBlcnJvciBpZiB5b3UgZGlkbid0IHByb3ZpZGUgdGhlbS5cbiAgaWYgKChvcmRlcmVkICYmICFjYWxsYmFja3MuYWRkZWRCZWZvcmUpIHx8XG4gICAgICAoIW9yZGVyZWQgJiYgIWNhbGxiYWNrcy5hZGRlZCkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW4ndCBvYnNlcnZlIGFuIFwiICsgKG9yZGVyZWQgPyBcIm9yZGVyZWRcIiA6IFwidW5vcmRlcmVkXCIpXG4gICAgICAgICAgICAgICAgICAgICsgXCIgdGFpbGFibGUgY3Vyc29yIHdpdGhvdXQgYSBcIlxuICAgICAgICAgICAgICAgICAgICArIChvcmRlcmVkID8gXCJhZGRlZEJlZm9yZVwiIDogXCJhZGRlZFwiKSArIFwiIGNhbGxiYWNrXCIpO1xuICB9XG5cbiAgcmV0dXJuIHNlbGYudGFpbChjdXJzb3JEZXNjcmlwdGlvbiwgZnVuY3Rpb24gKGRvYykge1xuICAgIHZhciBpZCA9IGRvYy5faWQ7XG4gICAgZGVsZXRlIGRvYy5faWQ7XG4gICAgLy8gVGhlIHRzIGlzIGFuIGltcGxlbWVudGF0aW9uIGRldGFpbC4gSGlkZSBpdC5cbiAgICBkZWxldGUgZG9jLnRzO1xuICAgIGlmIChvcmRlcmVkKSB7XG4gICAgICBjYWxsYmFja3MuYWRkZWRCZWZvcmUoaWQsIGRvYywgbnVsbCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhbGxiYWNrcy5hZGRlZChpZCwgZG9jKTtcbiAgICB9XG4gIH0pO1xufTtcblxuLy8gWFhYIFdlIHByb2JhYmx5IG5lZWQgdG8gZmluZCBhIGJldHRlciB3YXkgdG8gZXhwb3NlIHRoaXMuIFJpZ2h0IG5vd1xuLy8gaXQncyBvbmx5IHVzZWQgYnkgdGVzdHMsIGJ1dCBpbiBmYWN0IHlvdSBuZWVkIGl0IGluIG5vcm1hbFxuLy8gb3BlcmF0aW9uIHRvIGludGVyYWN0IHdpdGggY2FwcGVkIGNvbGxlY3Rpb25zLlxuTW9uZ29JbnRlcm5hbHMuTW9uZ29UaW1lc3RhbXAgPSBNb25nb0RCLlRpbWVzdGFtcDtcblxuTW9uZ29JbnRlcm5hbHMuQ29ubmVjdGlvbiA9IE1vbmdvQ29ubmVjdGlvbjtcbiIsInZhciBGdXR1cmUgPSBOcG0ucmVxdWlyZSgnZmliZXJzL2Z1dHVyZScpO1xuXG5pbXBvcnQgeyBOcG1Nb2R1bGVNb25nb2RiIH0gZnJvbSBcIm1ldGVvci9ucG0tbW9uZ29cIjtcbmNvbnN0IHsgTG9uZyB9ID0gTnBtTW9kdWxlTW9uZ29kYjtcblxuT1BMT0dfQ09MTEVDVElPTiA9ICdvcGxvZy5ycyc7XG5cbnZhciBUT09fRkFSX0JFSElORCA9IHByb2Nlc3MuZW52Lk1FVEVPUl9PUExPR19UT09fRkFSX0JFSElORCB8fCAyMDAwO1xudmFyIFRBSUxfVElNRU9VVCA9ICtwcm9jZXNzLmVudi5NRVRFT1JfT1BMT0dfVEFJTF9USU1FT1VUIHx8IDMwMDAwO1xuXG52YXIgc2hvd1RTID0gZnVuY3Rpb24gKHRzKSB7XG4gIHJldHVybiBcIlRpbWVzdGFtcChcIiArIHRzLmdldEhpZ2hCaXRzKCkgKyBcIiwgXCIgKyB0cy5nZXRMb3dCaXRzKCkgKyBcIilcIjtcbn07XG5cbmlkRm9yT3AgPSBmdW5jdGlvbiAob3ApIHtcbiAgaWYgKG9wLm9wID09PSAnZCcpXG4gICAgcmV0dXJuIG9wLm8uX2lkO1xuICBlbHNlIGlmIChvcC5vcCA9PT0gJ2knKVxuICAgIHJldHVybiBvcC5vLl9pZDtcbiAgZWxzZSBpZiAob3Aub3AgPT09ICd1JylcbiAgICByZXR1cm4gb3AubzIuX2lkO1xuICBlbHNlIGlmIChvcC5vcCA9PT0gJ2MnKVxuICAgIHRocm93IEVycm9yKFwiT3BlcmF0b3IgJ2MnIGRvZXNuJ3Qgc3VwcGx5IGFuIG9iamVjdCB3aXRoIGlkOiBcIiArXG4gICAgICAgICAgICAgICAgRUpTT04uc3RyaW5naWZ5KG9wKSk7XG4gIGVsc2VcbiAgICB0aHJvdyBFcnJvcihcIlVua25vd24gb3A6IFwiICsgRUpTT04uc3RyaW5naWZ5KG9wKSk7XG59O1xuXG5PcGxvZ0hhbmRsZSA9IGZ1bmN0aW9uIChvcGxvZ1VybCwgZGJOYW1lKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgc2VsZi5fb3Bsb2dVcmwgPSBvcGxvZ1VybDtcbiAgc2VsZi5fZGJOYW1lID0gZGJOYW1lO1xuXG4gIHNlbGYuX29wbG9nTGFzdEVudHJ5Q29ubmVjdGlvbiA9IG51bGw7XG4gIHNlbGYuX29wbG9nVGFpbENvbm5lY3Rpb24gPSBudWxsO1xuICBzZWxmLl9zdG9wcGVkID0gZmFsc2U7XG4gIHNlbGYuX3RhaWxIYW5kbGUgPSBudWxsO1xuICBzZWxmLl9yZWFkeUZ1dHVyZSA9IG5ldyBGdXR1cmUoKTtcbiAgc2VsZi5fY3Jvc3NiYXIgPSBuZXcgRERQU2VydmVyLl9Dcm9zc2Jhcih7XG4gICAgZmFjdFBhY2thZ2U6IFwibW9uZ28tbGl2ZWRhdGFcIiwgZmFjdE5hbWU6IFwib3Bsb2ctd2F0Y2hlcnNcIlxuICB9KTtcbiAgc2VsZi5fYmFzZU9wbG9nU2VsZWN0b3IgPSB7XG4gICAgbnM6IG5ldyBSZWdFeHAoXCJeKD86XCIgKyBbXG4gICAgICBNZXRlb3IuX2VzY2FwZVJlZ0V4cChzZWxmLl9kYk5hbWUgKyBcIi5cIiksXG4gICAgICBNZXRlb3IuX2VzY2FwZVJlZ0V4cChcImFkbWluLiRjbWRcIiksXG4gICAgXS5qb2luKFwifFwiKSArIFwiKVwiKSxcblxuICAgICRvcjogW1xuICAgICAgeyBvcDogeyAkaW46IFsnaScsICd1JywgJ2QnXSB9IH0sXG4gICAgICAvLyBkcm9wIGNvbGxlY3Rpb25cbiAgICAgIHsgb3A6ICdjJywgJ28uZHJvcCc6IHsgJGV4aXN0czogdHJ1ZSB9IH0sXG4gICAgICB7IG9wOiAnYycsICdvLmRyb3BEYXRhYmFzZSc6IDEgfSxcbiAgICAgIHsgb3A6ICdjJywgJ28uYXBwbHlPcHMnOiB7ICRleGlzdHM6IHRydWUgfSB9LFxuICAgIF1cbiAgfTtcblxuICAvLyBEYXRhIHN0cnVjdHVyZXMgdG8gc3VwcG9ydCB3YWl0VW50aWxDYXVnaHRVcCgpLiBFYWNoIG9wbG9nIGVudHJ5IGhhcyBhXG4gIC8vIE1vbmdvVGltZXN0YW1wIG9iamVjdCBvbiBpdCAod2hpY2ggaXMgbm90IHRoZSBzYW1lIGFzIGEgRGF0ZSAtLS0gaXQncyBhXG4gIC8vIGNvbWJpbmF0aW9uIG9mIHRpbWUgYW5kIGFuIGluY3JlbWVudGluZyBjb3VudGVyOyBzZWVcbiAgLy8gaHR0cDovL2RvY3MubW9uZ29kYi5vcmcvbWFudWFsL3JlZmVyZW5jZS9ic29uLXR5cGVzLyN0aW1lc3RhbXBzKS5cbiAgLy9cbiAgLy8gX2NhdGNoaW5nVXBGdXR1cmVzIGlzIGFuIGFycmF5IG9mIHt0czogTW9uZ29UaW1lc3RhbXAsIGZ1dHVyZTogRnV0dXJlfVxuICAvLyBvYmplY3RzLCBzb3J0ZWQgYnkgYXNjZW5kaW5nIHRpbWVzdGFtcC4gX2xhc3RQcm9jZXNzZWRUUyBpcyB0aGVcbiAgLy8gTW9uZ29UaW1lc3RhbXAgb2YgdGhlIGxhc3Qgb3Bsb2cgZW50cnkgd2UndmUgcHJvY2Vzc2VkLlxuICAvL1xuICAvLyBFYWNoIHRpbWUgd2UgY2FsbCB3YWl0VW50aWxDYXVnaHRVcCwgd2UgdGFrZSBhIHBlZWsgYXQgdGhlIGZpbmFsIG9wbG9nXG4gIC8vIGVudHJ5IGluIHRoZSBkYi4gIElmIHdlJ3ZlIGFscmVhZHkgcHJvY2Vzc2VkIGl0IChpZSwgaXQgaXMgbm90IGdyZWF0ZXIgdGhhblxuICAvLyBfbGFzdFByb2Nlc3NlZFRTKSwgd2FpdFVudGlsQ2F1Z2h0VXAgaW1tZWRpYXRlbHkgcmV0dXJucy4gT3RoZXJ3aXNlLFxuICAvLyB3YWl0VW50aWxDYXVnaHRVcCBtYWtlcyBhIG5ldyBGdXR1cmUgYW5kIGluc2VydHMgaXQgYWxvbmcgd2l0aCB0aGUgZmluYWxcbiAgLy8gdGltZXN0YW1wIGVudHJ5IHRoYXQgaXQgcmVhZCwgaW50byBfY2F0Y2hpbmdVcEZ1dHVyZXMuIHdhaXRVbnRpbENhdWdodFVwXG4gIC8vIHRoZW4gd2FpdHMgb24gdGhhdCBmdXR1cmUsIHdoaWNoIGlzIHJlc29sdmVkIG9uY2UgX2xhc3RQcm9jZXNzZWRUUyBpc1xuICAvLyBpbmNyZW1lbnRlZCB0byBiZSBwYXN0IGl0cyB0aW1lc3RhbXAgYnkgdGhlIHdvcmtlciBmaWJlci5cbiAgLy9cbiAgLy8gWFhYIHVzZSBhIHByaW9yaXR5IHF1ZXVlIG9yIHNvbWV0aGluZyBlbHNlIHRoYXQncyBmYXN0ZXIgdGhhbiBhbiBhcnJheVxuICBzZWxmLl9jYXRjaGluZ1VwRnV0dXJlcyA9IFtdO1xuICBzZWxmLl9sYXN0UHJvY2Vzc2VkVFMgPSBudWxsO1xuXG4gIHNlbGYuX29uU2tpcHBlZEVudHJpZXNIb29rID0gbmV3IEhvb2soe1xuICAgIGRlYnVnUHJpbnRFeGNlcHRpb25zOiBcIm9uU2tpcHBlZEVudHJpZXMgY2FsbGJhY2tcIlxuICB9KTtcblxuICBzZWxmLl9lbnRyeVF1ZXVlID0gbmV3IE1ldGVvci5fRG91YmxlRW5kZWRRdWV1ZSgpO1xuICBzZWxmLl93b3JrZXJBY3RpdmUgPSBmYWxzZTtcblxuICBzZWxmLl9zdGFydFRhaWxpbmcoKTtcbn07XG5cbk9iamVjdC5hc3NpZ24oT3Bsb2dIYW5kbGUucHJvdG90eXBlLCB7XG4gIHN0b3A6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICByZXR1cm47XG4gICAgc2VsZi5fc3RvcHBlZCA9IHRydWU7XG4gICAgaWYgKHNlbGYuX3RhaWxIYW5kbGUpXG4gICAgICBzZWxmLl90YWlsSGFuZGxlLnN0b3AoKTtcbiAgICAvLyBYWFggc2hvdWxkIGNsb3NlIGNvbm5lY3Rpb25zIHRvb1xuICB9LFxuICBvbk9wbG9nRW50cnk6IGZ1bmN0aW9uICh0cmlnZ2VyLCBjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNhbGxlZCBvbk9wbG9nRW50cnkgb24gc3RvcHBlZCBoYW5kbGUhXCIpO1xuXG4gICAgLy8gQ2FsbGluZyBvbk9wbG9nRW50cnkgcmVxdWlyZXMgdXMgdG8gd2FpdCBmb3IgdGhlIHRhaWxpbmcgdG8gYmUgcmVhZHkuXG4gICAgc2VsZi5fcmVhZHlGdXR1cmUud2FpdCgpO1xuXG4gICAgdmFyIG9yaWdpbmFsQ2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICBjYWxsYmFjayA9IE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24gKG5vdGlmaWNhdGlvbikge1xuICAgICAgb3JpZ2luYWxDYWxsYmFjayhub3RpZmljYXRpb24pO1xuICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIE1ldGVvci5fZGVidWcoXCJFcnJvciBpbiBvcGxvZyBjYWxsYmFja1wiLCBlcnIpO1xuICAgIH0pO1xuICAgIHZhciBsaXN0ZW5IYW5kbGUgPSBzZWxmLl9jcm9zc2Jhci5saXN0ZW4odHJpZ2dlciwgY2FsbGJhY2spO1xuICAgIHJldHVybiB7XG4gICAgICBzdG9wOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGxpc3RlbkhhbmRsZS5zdG9wKCk7XG4gICAgICB9XG4gICAgfTtcbiAgfSxcbiAgLy8gUmVnaXN0ZXIgYSBjYWxsYmFjayB0byBiZSBpbnZva2VkIGFueSB0aW1lIHdlIHNraXAgb3Bsb2cgZW50cmllcyAoZWcsXG4gIC8vIGJlY2F1c2Ugd2UgYXJlIHRvbyBmYXIgYmVoaW5kKS5cbiAgb25Ta2lwcGVkRW50cmllczogZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ2FsbGVkIG9uU2tpcHBlZEVudHJpZXMgb24gc3RvcHBlZCBoYW5kbGUhXCIpO1xuICAgIHJldHVybiBzZWxmLl9vblNraXBwZWRFbnRyaWVzSG9vay5yZWdpc3RlcihjYWxsYmFjayk7XG4gIH0sXG4gIC8vIENhbGxzIGBjYWxsYmFja2Agb25jZSB0aGUgb3Bsb2cgaGFzIGJlZW4gcHJvY2Vzc2VkIHVwIHRvIGEgcG9pbnQgdGhhdCBpc1xuICAvLyByb3VnaGx5IFwibm93XCI6IHNwZWNpZmljYWxseSwgb25jZSB3ZSd2ZSBwcm9jZXNzZWQgYWxsIG9wcyB0aGF0IGFyZVxuICAvLyBjdXJyZW50bHkgdmlzaWJsZS5cbiAgLy8gWFhYIGJlY29tZSBjb252aW5jZWQgdGhhdCB0aGlzIGlzIGFjdHVhbGx5IHNhZmUgZXZlbiBpZiBvcGxvZ0Nvbm5lY3Rpb25cbiAgLy8gaXMgc29tZSBraW5kIG9mIHBvb2xcbiAgd2FpdFVudGlsQ2F1Z2h0VXA6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYWxsZWQgd2FpdFVudGlsQ2F1Z2h0VXAgb24gc3RvcHBlZCBoYW5kbGUhXCIpO1xuXG4gICAgLy8gQ2FsbGluZyB3YWl0VW50aWxDYXVnaHRVcCByZXF1cmllcyB1cyB0byB3YWl0IGZvciB0aGUgb3Bsb2cgY29ubmVjdGlvbiB0b1xuICAgIC8vIGJlIHJlYWR5LlxuICAgIHNlbGYuX3JlYWR5RnV0dXJlLndhaXQoKTtcbiAgICB2YXIgbGFzdEVudHJ5O1xuXG4gICAgd2hpbGUgKCFzZWxmLl9zdG9wcGVkKSB7XG4gICAgICAvLyBXZSBuZWVkIHRvIG1ha2UgdGhlIHNlbGVjdG9yIGF0IGxlYXN0IGFzIHJlc3RyaWN0aXZlIGFzIHRoZSBhY3R1YWxcbiAgICAgIC8vIHRhaWxpbmcgc2VsZWN0b3IgKGllLCB3ZSBuZWVkIHRvIHNwZWNpZnkgdGhlIERCIG5hbWUpIG9yIGVsc2Ugd2UgbWlnaHRcbiAgICAgIC8vIGZpbmQgYSBUUyB0aGF0IHdvbid0IHNob3cgdXAgaW4gdGhlIGFjdHVhbCB0YWlsIHN0cmVhbS5cbiAgICAgIHRyeSB7XG4gICAgICAgIGxhc3RFbnRyeSA9IHNlbGYuX29wbG9nTGFzdEVudHJ5Q29ubmVjdGlvbi5maW5kT25lKFxuICAgICAgICAgIE9QTE9HX0NPTExFQ1RJT04sIHNlbGYuX2Jhc2VPcGxvZ1NlbGVjdG9yLFxuICAgICAgICAgIHtwcm9qZWN0aW9uOiB7dHM6IDF9LCBzb3J0OiB7JG5hdHVyYWw6IC0xfX0pO1xuICAgICAgICBicmVhaztcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gRHVyaW5nIGZhaWxvdmVyIChlZykgaWYgd2UgZ2V0IGFuIGV4Y2VwdGlvbiB3ZSBzaG91bGQgbG9nIGFuZCByZXRyeVxuICAgICAgICAvLyBpbnN0ZWFkIG9mIGNyYXNoaW5nLlxuICAgICAgICBNZXRlb3IuX2RlYnVnKFwiR290IGV4Y2VwdGlvbiB3aGlsZSByZWFkaW5nIGxhc3QgZW50cnlcIiwgZSk7XG4gICAgICAgIE1ldGVvci5fc2xlZXBGb3JNcygxMDApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuO1xuXG4gICAgaWYgKCFsYXN0RW50cnkpIHtcbiAgICAgIC8vIFJlYWxseSwgbm90aGluZyBpbiB0aGUgb3Bsb2c/IFdlbGwsIHdlJ3ZlIHByb2Nlc3NlZCBldmVyeXRoaW5nLlxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciB0cyA9IGxhc3RFbnRyeS50cztcbiAgICBpZiAoIXRzKVxuICAgICAgdGhyb3cgRXJyb3IoXCJvcGxvZyBlbnRyeSB3aXRob3V0IHRzOiBcIiArIEVKU09OLnN0cmluZ2lmeShsYXN0RW50cnkpKTtcblxuICAgIGlmIChzZWxmLl9sYXN0UHJvY2Vzc2VkVFMgJiYgdHMubGVzc1RoYW5PckVxdWFsKHNlbGYuX2xhc3RQcm9jZXNzZWRUUykpIHtcbiAgICAgIC8vIFdlJ3ZlIGFscmVhZHkgY2F1Z2h0IHVwIHRvIGhlcmUuXG4gICAgICByZXR1cm47XG4gICAgfVxuXG5cbiAgICAvLyBJbnNlcnQgdGhlIGZ1dHVyZSBpbnRvIG91ciBsaXN0LiBBbG1vc3QgYWx3YXlzLCB0aGlzIHdpbGwgYmUgYXQgdGhlIGVuZCxcbiAgICAvLyBidXQgaXQncyBjb25jZWl2YWJsZSB0aGF0IGlmIHdlIGZhaWwgb3ZlciBmcm9tIG9uZSBwcmltYXJ5IHRvIGFub3RoZXIsXG4gICAgLy8gdGhlIG9wbG9nIGVudHJpZXMgd2Ugc2VlIHdpbGwgZ28gYmFja3dhcmRzLlxuICAgIHZhciBpbnNlcnRBZnRlciA9IHNlbGYuX2NhdGNoaW5nVXBGdXR1cmVzLmxlbmd0aDtcbiAgICB3aGlsZSAoaW5zZXJ0QWZ0ZXIgLSAxID4gMCAmJiBzZWxmLl9jYXRjaGluZ1VwRnV0dXJlc1tpbnNlcnRBZnRlciAtIDFdLnRzLmdyZWF0ZXJUaGFuKHRzKSkge1xuICAgICAgaW5zZXJ0QWZ0ZXItLTtcbiAgICB9XG4gICAgdmFyIGYgPSBuZXcgRnV0dXJlO1xuICAgIHNlbGYuX2NhdGNoaW5nVXBGdXR1cmVzLnNwbGljZShpbnNlcnRBZnRlciwgMCwge3RzOiB0cywgZnV0dXJlOiBmfSk7XG4gICAgZi53YWl0KCk7XG4gIH0sXG4gIF9zdGFydFRhaWxpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgLy8gRmlyc3QsIG1ha2Ugc3VyZSB0aGF0IHdlJ3JlIHRhbGtpbmcgdG8gdGhlIGxvY2FsIGRhdGFiYXNlLlxuICAgIHZhciBtb25nb2RiVXJpID0gTnBtLnJlcXVpcmUoJ21vbmdvZGItdXJpJyk7XG4gICAgaWYgKG1vbmdvZGJVcmkucGFyc2Uoc2VsZi5fb3Bsb2dVcmwpLmRhdGFiYXNlICE9PSAnbG9jYWwnKSB7XG4gICAgICB0aHJvdyBFcnJvcihcIiRNT05HT19PUExPR19VUkwgbXVzdCBiZSBzZXQgdG8gdGhlICdsb2NhbCcgZGF0YWJhc2Ugb2YgXCIgK1xuICAgICAgICAgICAgICAgICAgXCJhIE1vbmdvIHJlcGxpY2Egc2V0XCIpO1xuICAgIH1cblxuICAgIC8vIFdlIG1ha2UgdHdvIHNlcGFyYXRlIGNvbm5lY3Rpb25zIHRvIE1vbmdvLiBUaGUgTm9kZSBNb25nbyBkcml2ZXJcbiAgICAvLyBpbXBsZW1lbnRzIGEgbmFpdmUgcm91bmQtcm9iaW4gY29ubmVjdGlvbiBwb29sOiBlYWNoIFwiY29ubmVjdGlvblwiIGlzIGFcbiAgICAvLyBwb29sIG9mIHNldmVyYWwgKDUgYnkgZGVmYXVsdCkgVENQIGNvbm5lY3Rpb25zLCBhbmQgZWFjaCByZXF1ZXN0IGlzXG4gICAgLy8gcm90YXRlZCB0aHJvdWdoIHRoZSBwb29scy4gVGFpbGFibGUgY3Vyc29yIHF1ZXJpZXMgYmxvY2sgb24gdGhlIHNlcnZlclxuICAgIC8vIHVudGlsIHRoZXJlIGlzIHNvbWUgZGF0YSB0byByZXR1cm4gKG9yIHVudGlsIGEgZmV3IHNlY29uZHMgaGF2ZVxuICAgIC8vIHBhc3NlZCkuIFNvIGlmIHRoZSBjb25uZWN0aW9uIHBvb2wgdXNlZCBmb3IgdGFpbGluZyBjdXJzb3JzIGlzIHRoZSBzYW1lXG4gICAgLy8gcG9vbCB1c2VkIGZvciBvdGhlciBxdWVyaWVzLCB0aGUgb3RoZXIgcXVlcmllcyB3aWxsIGJlIGRlbGF5ZWQgYnkgc2Vjb25kc1xuICAgIC8vIDEvNSBvZiB0aGUgdGltZS5cbiAgICAvL1xuICAgIC8vIFRoZSB0YWlsIGNvbm5lY3Rpb24gd2lsbCBvbmx5IGV2ZXIgYmUgcnVubmluZyBhIHNpbmdsZSB0YWlsIGNvbW1hbmQsIHNvXG4gICAgLy8gaXQgb25seSBuZWVkcyB0byBtYWtlIG9uZSB1bmRlcmx5aW5nIFRDUCBjb25uZWN0aW9uLlxuICAgIHNlbGYuX29wbG9nVGFpbENvbm5lY3Rpb24gPSBuZXcgTW9uZ29Db25uZWN0aW9uKFxuICAgICAgc2VsZi5fb3Bsb2dVcmwsIHttYXhQb29sU2l6ZTogMSwgbWluUG9vbFNpemU6IDF9KTtcbiAgICAvLyBYWFggYmV0dGVyIGRvY3MsIGJ1dDogaXQncyB0byBnZXQgbW9ub3RvbmljIHJlc3VsdHNcbiAgICAvLyBYWFggaXMgaXQgc2FmZSB0byBzYXkgXCJpZiB0aGVyZSdzIGFuIGluIGZsaWdodCBxdWVyeSwganVzdCB1c2UgaXRzXG4gICAgLy8gICAgIHJlc3VsdHNcIj8gSSBkb24ndCB0aGluayBzbyBidXQgc2hvdWxkIGNvbnNpZGVyIHRoYXRcbiAgICBzZWxmLl9vcGxvZ0xhc3RFbnRyeUNvbm5lY3Rpb24gPSBuZXcgTW9uZ29Db25uZWN0aW9uKFxuICAgICAgc2VsZi5fb3Bsb2dVcmwsIHttYXhQb29sU2l6ZTogMSwgbWluUG9vbFNpemU6IDF9KTtcblxuICAgIC8vIE5vdywgbWFrZSBzdXJlIHRoYXQgdGhlcmUgYWN0dWFsbHkgaXMgYSByZXBsIHNldCBoZXJlLiBJZiBub3QsIG9wbG9nXG4gICAgLy8gdGFpbGluZyB3b24ndCBldmVyIGZpbmQgYW55dGhpbmchXG4gICAgLy8gTW9yZSBvbiB0aGUgaXNNYXN0ZXJEb2NcbiAgICAvLyBodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL3JlZmVyZW5jZS9jb21tYW5kL2lzTWFzdGVyL1xuICAgIHZhciBmID0gbmV3IEZ1dHVyZTtcbiAgICBzZWxmLl9vcGxvZ0xhc3RFbnRyeUNvbm5lY3Rpb24uZGIuYWRtaW4oKS5jb21tYW5kKFxuICAgICAgeyBpc21hc3RlcjogMSB9LCBmLnJlc29sdmVyKCkpO1xuICAgIHZhciBpc01hc3RlckRvYyA9IGYud2FpdCgpO1xuXG4gICAgaWYgKCEoaXNNYXN0ZXJEb2MgJiYgaXNNYXN0ZXJEb2Muc2V0TmFtZSkpIHtcbiAgICAgIHRocm93IEVycm9yKFwiJE1PTkdPX09QTE9HX1VSTCBtdXN0IGJlIHNldCB0byB0aGUgJ2xvY2FsJyBkYXRhYmFzZSBvZiBcIiArXG4gICAgICAgICAgICAgICAgICBcImEgTW9uZ28gcmVwbGljYSBzZXRcIik7XG4gICAgfVxuXG4gICAgLy8gRmluZCB0aGUgbGFzdCBvcGxvZyBlbnRyeS5cbiAgICB2YXIgbGFzdE9wbG9nRW50cnkgPSBzZWxmLl9vcGxvZ0xhc3RFbnRyeUNvbm5lY3Rpb24uZmluZE9uZShcbiAgICAgIE9QTE9HX0NPTExFQ1RJT04sIHt9LCB7c29ydDogeyRuYXR1cmFsOiAtMX0sIHByb2plY3Rpb246IHt0czogMX19KTtcblxuICAgIHZhciBvcGxvZ1NlbGVjdG9yID0gXy5jbG9uZShzZWxmLl9iYXNlT3Bsb2dTZWxlY3Rvcik7XG4gICAgaWYgKGxhc3RPcGxvZ0VudHJ5KSB7XG4gICAgICAvLyBTdGFydCBhZnRlciB0aGUgbGFzdCBlbnRyeSB0aGF0IGN1cnJlbnRseSBleGlzdHMuXG4gICAgICBvcGxvZ1NlbGVjdG9yLnRzID0geyRndDogbGFzdE9wbG9nRW50cnkudHN9O1xuICAgICAgLy8gSWYgdGhlcmUgYXJlIGFueSBjYWxscyB0byBjYWxsV2hlblByb2Nlc3NlZExhdGVzdCBiZWZvcmUgYW55IG90aGVyXG4gICAgICAvLyBvcGxvZyBlbnRyaWVzIHNob3cgdXAsIGFsbG93IGNhbGxXaGVuUHJvY2Vzc2VkTGF0ZXN0IHRvIGNhbGwgaXRzXG4gICAgICAvLyBjYWxsYmFjayBpbW1lZGlhdGVseS5cbiAgICAgIHNlbGYuX2xhc3RQcm9jZXNzZWRUUyA9IGxhc3RPcGxvZ0VudHJ5LnRzO1xuICAgIH1cblxuICAgIHZhciBjdXJzb3JEZXNjcmlwdGlvbiA9IG5ldyBDdXJzb3JEZXNjcmlwdGlvbihcbiAgICAgIE9QTE9HX0NPTExFQ1RJT04sIG9wbG9nU2VsZWN0b3IsIHt0YWlsYWJsZTogdHJ1ZX0pO1xuXG4gICAgLy8gU3RhcnQgdGFpbGluZyB0aGUgb3Bsb2cuXG4gICAgLy9cbiAgICAvLyBXZSByZXN0YXJ0IHRoZSBsb3ctbGV2ZWwgb3Bsb2cgcXVlcnkgZXZlcnkgMzAgc2Vjb25kcyBpZiB3ZSBkaWRuJ3QgZ2V0IGFcbiAgICAvLyBkb2MuIFRoaXMgaXMgYSB3b3JrYXJvdW5kIGZvciAjODU5ODogdGhlIE5vZGUgTW9uZ28gZHJpdmVyIGhhcyBhdCBsZWFzdFxuICAgIC8vIG9uZSBidWcgdGhhdCBjYW4gbGVhZCB0byBxdWVyeSBjYWxsYmFja3MgbmV2ZXIgZ2V0dGluZyBjYWxsZWQgKGV2ZW4gd2l0aFxuICAgIC8vIGFuIGVycm9yKSB3aGVuIGxlYWRlcnNoaXAgZmFpbG92ZXIgb2NjdXIuXG4gICAgc2VsZi5fdGFpbEhhbmRsZSA9IHNlbGYuX29wbG9nVGFpbENvbm5lY3Rpb24udGFpbChcbiAgICAgIGN1cnNvckRlc2NyaXB0aW9uLFxuICAgICAgZnVuY3Rpb24gKGRvYykge1xuICAgICAgICBzZWxmLl9lbnRyeVF1ZXVlLnB1c2goZG9jKTtcbiAgICAgICAgc2VsZi5fbWF5YmVTdGFydFdvcmtlcigpO1xuICAgICAgfSxcbiAgICAgIFRBSUxfVElNRU9VVFxuICAgICk7XG4gICAgc2VsZi5fcmVhZHlGdXR1cmUucmV0dXJuKCk7XG4gIH0sXG5cbiAgX21heWJlU3RhcnRXb3JrZXI6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3dvcmtlckFjdGl2ZSkgcmV0dXJuO1xuICAgIHNlbGYuX3dvcmtlckFjdGl2ZSA9IHRydWU7XG5cbiAgICBNZXRlb3IuZGVmZXIoZnVuY3Rpb24gKCkge1xuICAgICAgLy8gTWF5IGJlIGNhbGxlZCByZWN1cnNpdmVseSBpbiBjYXNlIG9mIHRyYW5zYWN0aW9ucy5cbiAgICAgIGZ1bmN0aW9uIGhhbmRsZURvYyhkb2MpIHtcbiAgICAgICAgaWYgKGRvYy5ucyA9PT0gXCJhZG1pbi4kY21kXCIpIHtcbiAgICAgICAgICBpZiAoZG9jLm8uYXBwbHlPcHMpIHtcbiAgICAgICAgICAgIC8vIFRoaXMgd2FzIGEgc3VjY2Vzc2Z1bCB0cmFuc2FjdGlvbiwgc28gd2UgbmVlZCB0byBhcHBseSB0aGVcbiAgICAgICAgICAgIC8vIG9wZXJhdGlvbnMgdGhhdCB3ZXJlIGludm9sdmVkLlxuICAgICAgICAgICAgbGV0IG5leHRUaW1lc3RhbXAgPSBkb2MudHM7XG4gICAgICAgICAgICBkb2Muby5hcHBseU9wcy5mb3JFYWNoKG9wID0+IHtcbiAgICAgICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tZXRlb3IvbWV0ZW9yL2lzc3Vlcy8xMDQyMC5cbiAgICAgICAgICAgICAgaWYgKCFvcC50cykge1xuICAgICAgICAgICAgICAgIG9wLnRzID0gbmV4dFRpbWVzdGFtcDtcbiAgICAgICAgICAgICAgICBuZXh0VGltZXN0YW1wID0gbmV4dFRpbWVzdGFtcC5hZGQoTG9uZy5PTkUpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGhhbmRsZURvYyhvcCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5rbm93biBjb21tYW5kIFwiICsgRUpTT04uc3RyaW5naWZ5KGRvYykpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdHJpZ2dlciA9IHtcbiAgICAgICAgICBkcm9wQ29sbGVjdGlvbjogZmFsc2UsXG4gICAgICAgICAgZHJvcERhdGFiYXNlOiBmYWxzZSxcbiAgICAgICAgICBvcDogZG9jLFxuICAgICAgICB9O1xuXG4gICAgICAgIGlmICh0eXBlb2YgZG9jLm5zID09PSBcInN0cmluZ1wiICYmXG4gICAgICAgICAgICBkb2MubnMuc3RhcnRzV2l0aChzZWxmLl9kYk5hbWUgKyBcIi5cIikpIHtcbiAgICAgICAgICB0cmlnZ2VyLmNvbGxlY3Rpb24gPSBkb2MubnMuc2xpY2Uoc2VsZi5fZGJOYW1lLmxlbmd0aCArIDEpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gSXMgaXQgYSBzcGVjaWFsIGNvbW1hbmQgYW5kIHRoZSBjb2xsZWN0aW9uIG5hbWUgaXMgaGlkZGVuXG4gICAgICAgIC8vIHNvbWV3aGVyZSBpbiBvcGVyYXRvcj9cbiAgICAgICAgaWYgKHRyaWdnZXIuY29sbGVjdGlvbiA9PT0gXCIkY21kXCIpIHtcbiAgICAgICAgICBpZiAoZG9jLm8uZHJvcERhdGFiYXNlKSB7XG4gICAgICAgICAgICBkZWxldGUgdHJpZ2dlci5jb2xsZWN0aW9uO1xuICAgICAgICAgICAgdHJpZ2dlci5kcm9wRGF0YWJhc2UgPSB0cnVlO1xuICAgICAgICAgIH0gZWxzZSBpZiAoXy5oYXMoZG9jLm8sIFwiZHJvcFwiKSkge1xuICAgICAgICAgICAgdHJpZ2dlci5jb2xsZWN0aW9uID0gZG9jLm8uZHJvcDtcbiAgICAgICAgICAgIHRyaWdnZXIuZHJvcENvbGxlY3Rpb24gPSB0cnVlO1xuICAgICAgICAgICAgdHJpZ2dlci5pZCA9IG51bGw7XG4gICAgICAgICAgfSBlbHNlIGlmIChcImNyZWF0ZVwiIGluIGRvYy5vICYmIFwiaWRJbmRleFwiIGluIGRvYy5vKSB7XG4gICAgICAgICAgICAvLyBBIGNvbGxlY3Rpb24gZ290IGltcGxpY2l0bHkgY3JlYXRlZCB3aXRoaW4gYSB0cmFuc2FjdGlvbi4gVGhlcmUnc1xuICAgICAgICAgICAgLy8gbm8gbmVlZCB0byBkbyBhbnl0aGluZyBhYm91dCBpdC5cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgRXJyb3IoXCJVbmtub3duIGNvbW1hbmQgXCIgKyBFSlNPTi5zdHJpbmdpZnkoZG9jKSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gQWxsIG90aGVyIG9wcyBoYXZlIGFuIGlkLlxuICAgICAgICAgIHRyaWdnZXIuaWQgPSBpZEZvck9wKGRvYyk7XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLl9jcm9zc2Jhci5maXJlKHRyaWdnZXIpO1xuICAgICAgfVxuXG4gICAgICB0cnkge1xuICAgICAgICB3aGlsZSAoISBzZWxmLl9zdG9wcGVkICYmXG4gICAgICAgICAgICAgICAhIHNlbGYuX2VudHJ5UXVldWUuaXNFbXB0eSgpKSB7XG4gICAgICAgICAgLy8gQXJlIHdlIHRvbyBmYXIgYmVoaW5kPyBKdXN0IHRlbGwgb3VyIG9ic2VydmVycyB0aGF0IHRoZXkgbmVlZCB0b1xuICAgICAgICAgIC8vIHJlcG9sbCwgYW5kIGRyb3Agb3VyIHF1ZXVlLlxuICAgICAgICAgIGlmIChzZWxmLl9lbnRyeVF1ZXVlLmxlbmd0aCA+IFRPT19GQVJfQkVISU5EKSB7XG4gICAgICAgICAgICB2YXIgbGFzdEVudHJ5ID0gc2VsZi5fZW50cnlRdWV1ZS5wb3AoKTtcbiAgICAgICAgICAgIHNlbGYuX2VudHJ5UXVldWUuY2xlYXIoKTtcblxuICAgICAgICAgICAgc2VsZi5fb25Ta2lwcGVkRW50cmllc0hvb2suZWFjaChmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgLy8gRnJlZSBhbnkgd2FpdFVudGlsQ2F1Z2h0VXAoKSBjYWxscyB0aGF0IHdlcmUgd2FpdGluZyBmb3IgdXMgdG9cbiAgICAgICAgICAgIC8vIHBhc3Mgc29tZXRoaW5nIHRoYXQgd2UganVzdCBza2lwcGVkLlxuICAgICAgICAgICAgc2VsZi5fc2V0TGFzdFByb2Nlc3NlZFRTKGxhc3RFbnRyeS50cyk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBkb2MgPSBzZWxmLl9lbnRyeVF1ZXVlLnNoaWZ0KCk7XG5cbiAgICAgICAgICAvLyBGaXJlIHRyaWdnZXIocykgZm9yIHRoaXMgZG9jLlxuICAgICAgICAgIGhhbmRsZURvYyhkb2MpO1xuXG4gICAgICAgICAgLy8gTm93IHRoYXQgd2UndmUgcHJvY2Vzc2VkIHRoaXMgb3BlcmF0aW9uLCBwcm9jZXNzIHBlbmRpbmdcbiAgICAgICAgICAvLyBzZXF1ZW5jZXJzLlxuICAgICAgICAgIGlmIChkb2MudHMpIHtcbiAgICAgICAgICAgIHNlbGYuX3NldExhc3RQcm9jZXNzZWRUUyhkb2MudHMpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBFcnJvcihcIm9wbG9nIGVudHJ5IHdpdGhvdXQgdHM6IFwiICsgRUpTT04uc3RyaW5naWZ5KGRvYykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2VsZi5fd29ya2VyQWN0aXZlID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG5cbiAgX3NldExhc3RQcm9jZXNzZWRUUzogZnVuY3Rpb24gKHRzKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHNlbGYuX2xhc3RQcm9jZXNzZWRUUyA9IHRzO1xuICAgIHdoaWxlICghXy5pc0VtcHR5KHNlbGYuX2NhdGNoaW5nVXBGdXR1cmVzKSAmJiBzZWxmLl9jYXRjaGluZ1VwRnV0dXJlc1swXS50cy5sZXNzVGhhbk9yRXF1YWwoc2VsZi5fbGFzdFByb2Nlc3NlZFRTKSkge1xuICAgICAgdmFyIHNlcXVlbmNlciA9IHNlbGYuX2NhdGNoaW5nVXBGdXR1cmVzLnNoaWZ0KCk7XG4gICAgICBzZXF1ZW5jZXIuZnV0dXJlLnJldHVybigpO1xuICAgIH1cbiAgfSxcblxuICAvL01ldGhvZHMgdXNlZCBvbiB0ZXN0cyB0byBkaW5hbWljYWxseSBjaGFuZ2UgVE9PX0ZBUl9CRUhJTkRcbiAgX2RlZmluZVRvb0ZhckJlaGluZDogZnVuY3Rpb24odmFsdWUpIHtcbiAgICBUT09fRkFSX0JFSElORCA9IHZhbHVlO1xuICB9LFxuICBfcmVzZXRUb29GYXJCZWhpbmQ6IGZ1bmN0aW9uKCkge1xuICAgIFRPT19GQVJfQkVISU5EID0gcHJvY2Vzcy5lbnYuTUVURU9SX09QTE9HX1RPT19GQVJfQkVISU5EIHx8IDIwMDA7XG4gIH1cbn0pO1xuIiwidmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKCdmaWJlcnMvZnV0dXJlJyk7XG5cbk9ic2VydmVNdWx0aXBsZXhlciA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICBpZiAoIW9wdGlvbnMgfHwgIV8uaGFzKG9wdGlvbnMsICdvcmRlcmVkJykpXG4gICAgdGhyb3cgRXJyb3IoXCJtdXN0IHNwZWNpZmllZCBvcmRlcmVkXCIpO1xuXG4gIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICBcIm1vbmdvLWxpdmVkYXRhXCIsIFwib2JzZXJ2ZS1tdWx0aXBsZXhlcnNcIiwgMSk7XG5cbiAgc2VsZi5fb3JkZXJlZCA9IG9wdGlvbnMub3JkZXJlZDtcbiAgc2VsZi5fb25TdG9wID0gb3B0aW9ucy5vblN0b3AgfHwgZnVuY3Rpb24gKCkge307XG4gIHNlbGYuX3F1ZXVlID0gbmV3IE1ldGVvci5fU3luY2hyb25vdXNRdWV1ZSgpO1xuICBzZWxmLl9oYW5kbGVzID0ge307XG4gIHNlbGYuX3JlYWR5RnV0dXJlID0gbmV3IEZ1dHVyZTtcbiAgc2VsZi5fY2FjaGUgPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9DYWNoaW5nQ2hhbmdlT2JzZXJ2ZXIoe1xuICAgIG9yZGVyZWQ6IG9wdGlvbnMub3JkZXJlZH0pO1xuICAvLyBOdW1iZXIgb2YgYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIHRhc2tzIHNjaGVkdWxlZCBidXQgbm90IHlldFxuICAvLyBydW5uaW5nLiByZW1vdmVIYW5kbGUgdXNlcyB0aGlzIHRvIGtub3cgaWYgaXQncyB0aW1lIHRvIGNhbGwgdGhlIG9uU3RvcFxuICAvLyBjYWxsYmFjay5cbiAgc2VsZi5fYWRkSGFuZGxlVGFza3NTY2hlZHVsZWRCdXROb3RQZXJmb3JtZWQgPSAwO1xuXG4gIF8uZWFjaChzZWxmLmNhbGxiYWNrTmFtZXMoKSwgZnVuY3Rpb24gKGNhbGxiYWNrTmFtZSkge1xuICAgIHNlbGZbY2FsbGJhY2tOYW1lXSA9IGZ1bmN0aW9uICgvKiAuLi4gKi8pIHtcbiAgICAgIHNlbGYuX2FwcGx5Q2FsbGJhY2soY2FsbGJhY2tOYW1lLCBfLnRvQXJyYXkoYXJndW1lbnRzKSk7XG4gICAgfTtcbiAgfSk7XG59O1xuXG5fLmV4dGVuZChPYnNlcnZlTXVsdGlwbGV4ZXIucHJvdG90eXBlLCB7XG4gIGFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkczogZnVuY3Rpb24gKGhhbmRsZSkge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIC8vIENoZWNrIHRoaXMgYmVmb3JlIGNhbGxpbmcgcnVuVGFzayAoZXZlbiB0aG91Z2ggcnVuVGFzayBkb2VzIHRoZSBzYW1lXG4gICAgLy8gY2hlY2spIHNvIHRoYXQgd2UgZG9uJ3QgbGVhayBhbiBPYnNlcnZlTXVsdGlwbGV4ZXIgb24gZXJyb3IgYnlcbiAgICAvLyBpbmNyZW1lbnRpbmcgX2FkZEhhbmRsZVRhc2tzU2NoZWR1bGVkQnV0Tm90UGVyZm9ybWVkIGFuZCBuZXZlclxuICAgIC8vIGRlY3JlbWVudGluZyBpdC5cbiAgICBpZiAoIXNlbGYuX3F1ZXVlLnNhZmVUb1J1blRhc2soKSlcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNhbid0IGNhbGwgb2JzZXJ2ZUNoYW5nZXMgZnJvbSBhbiBvYnNlcnZlIGNhbGxiYWNrIG9uIHRoZSBzYW1lIHF1ZXJ5XCIpO1xuICAgICsrc2VsZi5fYWRkSGFuZGxlVGFza3NTY2hlZHVsZWRCdXROb3RQZXJmb3JtZWQ7XG5cbiAgICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgICBcIm1vbmdvLWxpdmVkYXRhXCIsIFwib2JzZXJ2ZS1oYW5kbGVzXCIsIDEpO1xuXG4gICAgc2VsZi5fcXVldWUucnVuVGFzayhmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9oYW5kbGVzW2hhbmRsZS5faWRdID0gaGFuZGxlO1xuICAgICAgLy8gU2VuZCBvdXQgd2hhdGV2ZXIgYWRkcyB3ZSBoYXZlIHNvIGZhciAod2hldGhlciBvciBub3Qgd2UgdGhlXG4gICAgICAvLyBtdWx0aXBsZXhlciBpcyByZWFkeSkuXG4gICAgICBzZWxmLl9zZW5kQWRkcyhoYW5kbGUpO1xuICAgICAgLS1zZWxmLl9hZGRIYW5kbGVUYXNrc1NjaGVkdWxlZEJ1dE5vdFBlcmZvcm1lZDtcbiAgICB9KTtcbiAgICAvLyAqb3V0c2lkZSogdGhlIHRhc2ssIHNpbmNlIG90aGVyd2lzZSB3ZSdkIGRlYWRsb2NrXG4gICAgc2VsZi5fcmVhZHlGdXR1cmUud2FpdCgpO1xuICB9LFxuXG4gIC8vIFJlbW92ZSBhbiBvYnNlcnZlIGhhbmRsZS4gSWYgaXQgd2FzIHRoZSBsYXN0IG9ic2VydmUgaGFuZGxlLCBjYWxsIHRoZVxuICAvLyBvblN0b3AgY2FsbGJhY2s7IHlvdSBjYW5ub3QgYWRkIGFueSBtb3JlIG9ic2VydmUgaGFuZGxlcyBhZnRlciB0aGlzLlxuICAvL1xuICAvLyBUaGlzIGlzIG5vdCBzeW5jaHJvbml6ZWQgd2l0aCBwb2xscyBhbmQgaGFuZGxlIGFkZGl0aW9uczogdGhpcyBtZWFucyB0aGF0XG4gIC8vIHlvdSBjYW4gc2FmZWx5IGNhbGwgaXQgZnJvbSB3aXRoaW4gYW4gb2JzZXJ2ZSBjYWxsYmFjaywgYnV0IGl0IGFsc28gbWVhbnNcbiAgLy8gdGhhdCB3ZSBoYXZlIHRvIGJlIGNhcmVmdWwgd2hlbiB3ZSBpdGVyYXRlIG92ZXIgX2hhbmRsZXMuXG4gIHJlbW92ZUhhbmRsZTogZnVuY3Rpb24gKGlkKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgLy8gVGhpcyBzaG91bGQgbm90IGJlIHBvc3NpYmxlOiB5b3UgY2FuIG9ubHkgY2FsbCByZW1vdmVIYW5kbGUgYnkgaGF2aW5nXG4gICAgLy8gYWNjZXNzIHRvIHRoZSBPYnNlcnZlSGFuZGxlLCB3aGljaCBpc24ndCByZXR1cm5lZCB0byB1c2VyIGNvZGUgdW50aWwgdGhlXG4gICAgLy8gbXVsdGlwbGV4IGlzIHJlYWR5LlxuICAgIGlmICghc2VsZi5fcmVhZHkoKSlcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNhbid0IHJlbW92ZSBoYW5kbGVzIHVudGlsIHRoZSBtdWx0aXBsZXggaXMgcmVhZHlcIik7XG5cbiAgICBkZWxldGUgc2VsZi5faGFuZGxlc1tpZF07XG5cbiAgICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgICBcIm1vbmdvLWxpdmVkYXRhXCIsIFwib2JzZXJ2ZS1oYW5kbGVzXCIsIC0xKTtcblxuICAgIGlmIChfLmlzRW1wdHkoc2VsZi5faGFuZGxlcykgJiZcbiAgICAgICAgc2VsZi5fYWRkSGFuZGxlVGFza3NTY2hlZHVsZWRCdXROb3RQZXJmb3JtZWQgPT09IDApIHtcbiAgICAgIHNlbGYuX3N0b3AoKTtcbiAgICB9XG4gIH0sXG4gIF9zdG9wOiBmdW5jdGlvbiAob3B0aW9ucykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcblxuICAgIC8vIEl0IHNob3VsZG4ndCBiZSBwb3NzaWJsZSBmb3IgdXMgdG8gc3RvcCB3aGVuIGFsbCBvdXIgaGFuZGxlcyBzdGlsbFxuICAgIC8vIGhhdmVuJ3QgYmVlbiByZXR1cm5lZCBmcm9tIG9ic2VydmVDaGFuZ2VzIVxuICAgIGlmICghIHNlbGYuX3JlYWR5KCkgJiYgISBvcHRpb25zLmZyb21RdWVyeUVycm9yKVxuICAgICAgdGhyb3cgRXJyb3IoXCJzdXJwcmlzaW5nIF9zdG9wOiBub3QgcmVhZHlcIik7XG5cbiAgICAvLyBDYWxsIHN0b3AgY2FsbGJhY2sgKHdoaWNoIGtpbGxzIHRoZSB1bmRlcmx5aW5nIHByb2Nlc3Mgd2hpY2ggc2VuZHMgdXNcbiAgICAvLyBjYWxsYmFja3MgYW5kIHJlbW92ZXMgdXMgZnJvbSB0aGUgY29ubmVjdGlvbidzIGRpY3Rpb25hcnkpLlxuICAgIHNlbGYuX29uU3RvcCgpO1xuICAgIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLW11bHRpcGxleGVyc1wiLCAtMSk7XG5cbiAgICAvLyBDYXVzZSBmdXR1cmUgYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIGNhbGxzIHRvIHRocm93IChidXQgdGhlIG9uU3RvcFxuICAgIC8vIGNhbGxiYWNrIHNob3VsZCBtYWtlIG91ciBjb25uZWN0aW9uIGZvcmdldCBhYm91dCB1cykuXG4gICAgc2VsZi5faGFuZGxlcyA9IG51bGw7XG4gIH0sXG5cbiAgLy8gQWxsb3dzIGFsbCBhZGRIYW5kbGVBbmRTZW5kSW5pdGlhbEFkZHMgY2FsbHMgdG8gcmV0dXJuLCBvbmNlIGFsbCBwcmVjZWRpbmdcbiAgLy8gYWRkcyBoYXZlIGJlZW4gcHJvY2Vzc2VkLiBEb2VzIG5vdCBibG9jay5cbiAgcmVhZHk6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgc2VsZi5fcXVldWUucXVldWVUYXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLl9yZWFkeSgpKVxuICAgICAgICB0aHJvdyBFcnJvcihcImNhbid0IG1ha2UgT2JzZXJ2ZU11bHRpcGxleCByZWFkeSB0d2ljZSFcIik7XG4gICAgICBzZWxmLl9yZWFkeUZ1dHVyZS5yZXR1cm4oKTtcbiAgICB9KTtcbiAgfSxcblxuICAvLyBJZiB0cnlpbmcgdG8gZXhlY3V0ZSB0aGUgcXVlcnkgcmVzdWx0cyBpbiBhbiBlcnJvciwgY2FsbCB0aGlzLiBUaGlzIGlzXG4gIC8vIGludGVuZGVkIGZvciBwZXJtYW5lbnQgZXJyb3JzLCBub3QgdHJhbnNpZW50IG5ldHdvcmsgZXJyb3JzIHRoYXQgY291bGQgYmVcbiAgLy8gZml4ZWQuIEl0IHNob3VsZCBvbmx5IGJlIGNhbGxlZCBiZWZvcmUgcmVhZHkoKSwgYmVjYXVzZSBpZiB5b3UgY2FsbGVkIHJlYWR5XG4gIC8vIHRoYXQgbWVhbnQgdGhhdCB5b3UgbWFuYWdlZCB0byBydW4gdGhlIHF1ZXJ5IG9uY2UuIEl0IHdpbGwgc3RvcCB0aGlzXG4gIC8vIE9ic2VydmVNdWx0aXBsZXggYW5kIGNhdXNlIGFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkcyBjYWxscyAoYW5kIHRodXNcbiAgLy8gb2JzZXJ2ZUNoYW5nZXMgY2FsbHMpIHRvIHRocm93IHRoZSBlcnJvci5cbiAgcXVlcnlFcnJvcjogZnVuY3Rpb24gKGVycikge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBzZWxmLl9xdWV1ZS5ydW5UYXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLl9yZWFkeSgpKVxuICAgICAgICB0aHJvdyBFcnJvcihcImNhbid0IGNsYWltIHF1ZXJ5IGhhcyBhbiBlcnJvciBhZnRlciBpdCB3b3JrZWQhXCIpO1xuICAgICAgc2VsZi5fc3RvcCh7ZnJvbVF1ZXJ5RXJyb3I6IHRydWV9KTtcbiAgICAgIHNlbGYuX3JlYWR5RnV0dXJlLnRocm93KGVycik7XG4gICAgfSk7XG4gIH0sXG5cbiAgLy8gQ2FsbHMgXCJjYlwiIG9uY2UgdGhlIGVmZmVjdHMgb2YgYWxsIFwicmVhZHlcIiwgXCJhZGRIYW5kbGVBbmRTZW5kSW5pdGlhbEFkZHNcIlxuICAvLyBhbmQgb2JzZXJ2ZSBjYWxsYmFja3Mgd2hpY2ggY2FtZSBiZWZvcmUgdGhpcyBjYWxsIGhhdmUgYmVlbiBwcm9wYWdhdGVkIHRvXG4gIC8vIGFsbCBoYW5kbGVzLiBcInJlYWR5XCIgbXVzdCBoYXZlIGFscmVhZHkgYmVlbiBjYWxsZWQgb24gdGhpcyBtdWx0aXBsZXhlci5cbiAgb25GbHVzaDogZnVuY3Rpb24gKGNiKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHNlbGYuX3F1ZXVlLnF1ZXVlVGFzayhmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoIXNlbGYuX3JlYWR5KCkpXG4gICAgICAgIHRocm93IEVycm9yKFwib25seSBjYWxsIG9uRmx1c2ggb24gYSBtdWx0aXBsZXhlciB0aGF0IHdpbGwgYmUgcmVhZHlcIik7XG4gICAgICBjYigpO1xuICAgIH0pO1xuICB9LFxuICBjYWxsYmFja05hbWVzOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmIChzZWxmLl9vcmRlcmVkKVxuICAgICAgcmV0dXJuIFtcImFkZGVkQmVmb3JlXCIsIFwiY2hhbmdlZFwiLCBcIm1vdmVkQmVmb3JlXCIsIFwicmVtb3ZlZFwiXTtcbiAgICBlbHNlXG4gICAgICByZXR1cm4gW1wiYWRkZWRcIiwgXCJjaGFuZ2VkXCIsIFwicmVtb3ZlZFwiXTtcbiAgfSxcbiAgX3JlYWR5OiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlYWR5RnV0dXJlLmlzUmVzb2x2ZWQoKTtcbiAgfSxcbiAgX2FwcGx5Q2FsbGJhY2s6IGZ1bmN0aW9uIChjYWxsYmFja05hbWUsIGFyZ3MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgc2VsZi5fcXVldWUucXVldWVUYXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgIC8vIElmIHdlIHN0b3BwZWQgaW4gdGhlIG1lYW50aW1lLCBkbyBub3RoaW5nLlxuICAgICAgaWYgKCFzZWxmLl9oYW5kbGVzKVxuICAgICAgICByZXR1cm47XG5cbiAgICAgIC8vIEZpcnN0LCBhcHBseSB0aGUgY2hhbmdlIHRvIHRoZSBjYWNoZS5cbiAgICAgIHNlbGYuX2NhY2hlLmFwcGx5Q2hhbmdlW2NhbGxiYWNrTmFtZV0uYXBwbHkobnVsbCwgYXJncyk7XG5cbiAgICAgIC8vIElmIHdlIGhhdmVuJ3QgZmluaXNoZWQgdGhlIGluaXRpYWwgYWRkcywgdGhlbiB3ZSBzaG91bGQgb25seSBiZSBnZXR0aW5nXG4gICAgICAvLyBhZGRzLlxuICAgICAgaWYgKCFzZWxmLl9yZWFkeSgpICYmXG4gICAgICAgICAgKGNhbGxiYWNrTmFtZSAhPT0gJ2FkZGVkJyAmJiBjYWxsYmFja05hbWUgIT09ICdhZGRlZEJlZm9yZScpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkdvdCBcIiArIGNhbGxiYWNrTmFtZSArIFwiIGR1cmluZyBpbml0aWFsIGFkZHNcIik7XG4gICAgICB9XG5cbiAgICAgIC8vIE5vdyBtdWx0aXBsZXggdGhlIGNhbGxiYWNrcyBvdXQgdG8gYWxsIG9ic2VydmUgaGFuZGxlcy4gSXQncyBPSyBpZlxuICAgICAgLy8gdGhlc2UgY2FsbHMgeWllbGQ7IHNpbmNlIHdlJ3JlIGluc2lkZSBhIHRhc2ssIG5vIG90aGVyIHVzZSBvZiBvdXIgcXVldWVcbiAgICAgIC8vIGNhbiBjb250aW51ZSB1bnRpbCB0aGVzZSBhcmUgZG9uZS4gKEJ1dCB3ZSBkbyBoYXZlIHRvIGJlIGNhcmVmdWwgdG8gbm90XG4gICAgICAvLyB1c2UgYSBoYW5kbGUgdGhhdCBnb3QgcmVtb3ZlZCwgYmVjYXVzZSByZW1vdmVIYW5kbGUgZG9lcyBub3QgdXNlIHRoZVxuICAgICAgLy8gcXVldWU7IHRodXMsIHdlIGl0ZXJhdGUgb3ZlciBhbiBhcnJheSBvZiBrZXlzIHRoYXQgd2UgY29udHJvbC4pXG4gICAgICBfLmVhY2goXy5rZXlzKHNlbGYuX2hhbmRsZXMpLCBmdW5jdGlvbiAoaGFuZGxlSWQpIHtcbiAgICAgICAgdmFyIGhhbmRsZSA9IHNlbGYuX2hhbmRsZXMgJiYgc2VsZi5faGFuZGxlc1toYW5kbGVJZF07XG4gICAgICAgIGlmICghaGFuZGxlKVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgdmFyIGNhbGxiYWNrID0gaGFuZGxlWydfJyArIGNhbGxiYWNrTmFtZV07XG4gICAgICAgIC8vIGNsb25lIGFyZ3VtZW50cyBzbyB0aGF0IGNhbGxiYWNrcyBjYW4gbXV0YXRlIHRoZWlyIGFyZ3VtZW50c1xuICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjay5hcHBseShudWxsLFxuICAgICAgICAgIGhhbmRsZS5ub25NdXRhdGluZ0NhbGxiYWNrcyA/IGFyZ3MgOiBFSlNPTi5jbG9uZShhcmdzKSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSxcblxuICAvLyBTZW5kcyBpbml0aWFsIGFkZHMgdG8gYSBoYW5kbGUuIEl0IHNob3VsZCBvbmx5IGJlIGNhbGxlZCBmcm9tIHdpdGhpbiBhIHRhc2tcbiAgLy8gKHRoZSB0YXNrIHRoYXQgaXMgcHJvY2Vzc2luZyB0aGUgYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIGNhbGwpLiBJdFxuICAvLyBzeW5jaHJvbm91c2x5IGludm9rZXMgdGhlIGhhbmRsZSdzIGFkZGVkIG9yIGFkZGVkQmVmb3JlOyB0aGVyZSdzIG5vIG5lZWQgdG9cbiAgLy8gZmx1c2ggdGhlIHF1ZXVlIGFmdGVyd2FyZHMgdG8gZW5zdXJlIHRoYXQgdGhlIGNhbGxiYWNrcyBnZXQgb3V0LlxuICBfc2VuZEFkZHM6IGZ1bmN0aW9uIChoYW5kbGUpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3F1ZXVlLnNhZmVUb1J1blRhc2soKSlcbiAgICAgIHRocm93IEVycm9yKFwiX3NlbmRBZGRzIG1heSBvbmx5IGJlIGNhbGxlZCBmcm9tIHdpdGhpbiBhIHRhc2shXCIpO1xuICAgIHZhciBhZGQgPSBzZWxmLl9vcmRlcmVkID8gaGFuZGxlLl9hZGRlZEJlZm9yZSA6IGhhbmRsZS5fYWRkZWQ7XG4gICAgaWYgKCFhZGQpXG4gICAgICByZXR1cm47XG4gICAgLy8gbm90ZTogZG9jcyBtYXkgYmUgYW4gX0lkTWFwIG9yIGFuIE9yZGVyZWREaWN0XG4gICAgc2VsZi5fY2FjaGUuZG9jcy5mb3JFYWNoKGZ1bmN0aW9uIChkb2MsIGlkKSB7XG4gICAgICBpZiAoIV8uaGFzKHNlbGYuX2hhbmRsZXMsIGhhbmRsZS5faWQpKVxuICAgICAgICB0aHJvdyBFcnJvcihcImhhbmRsZSBnb3QgcmVtb3ZlZCBiZWZvcmUgc2VuZGluZyBpbml0aWFsIGFkZHMhXCIpO1xuICAgICAgY29uc3QgeyBfaWQsIC4uLmZpZWxkcyB9ID0gaGFuZGxlLm5vbk11dGF0aW5nQ2FsbGJhY2tzID8gZG9jXG4gICAgICAgIDogRUpTT04uY2xvbmUoZG9jKTtcbiAgICAgIGlmIChzZWxmLl9vcmRlcmVkKVxuICAgICAgICBhZGQoaWQsIGZpZWxkcywgbnVsbCk7IC8vIHdlJ3JlIGdvaW5nIGluIG9yZGVyLCBzbyBhZGQgYXQgZW5kXG4gICAgICBlbHNlXG4gICAgICAgIGFkZChpZCwgZmllbGRzKTtcbiAgICB9KTtcbiAgfVxufSk7XG5cblxudmFyIG5leHRPYnNlcnZlSGFuZGxlSWQgPSAxO1xuXG4vLyBXaGVuIHRoZSBjYWxsYmFja3MgZG8gbm90IG11dGF0ZSB0aGUgYXJndW1lbnRzLCB3ZSBjYW4gc2tpcCBhIGxvdCBvZiBkYXRhIGNsb25lc1xuT2JzZXJ2ZUhhbmRsZSA9IGZ1bmN0aW9uIChtdWx0aXBsZXhlciwgY2FsbGJhY2tzLCBub25NdXRhdGluZ0NhbGxiYWNrcyA9IGZhbHNlKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgLy8gVGhlIGVuZCB1c2VyIGlzIG9ubHkgc3VwcG9zZWQgdG8gY2FsbCBzdG9wKCkuICBUaGUgb3RoZXIgZmllbGRzIGFyZVxuICAvLyBhY2Nlc3NpYmxlIHRvIHRoZSBtdWx0aXBsZXhlciwgdGhvdWdoLlxuICBzZWxmLl9tdWx0aXBsZXhlciA9IG11bHRpcGxleGVyO1xuICBfLmVhY2gobXVsdGlwbGV4ZXIuY2FsbGJhY2tOYW1lcygpLCBmdW5jdGlvbiAobmFtZSkge1xuICAgIGlmIChjYWxsYmFja3NbbmFtZV0pIHtcbiAgICAgIHNlbGZbJ18nICsgbmFtZV0gPSBjYWxsYmFja3NbbmFtZV07XG4gICAgfSBlbHNlIGlmIChuYW1lID09PSBcImFkZGVkQmVmb3JlXCIgJiYgY2FsbGJhY2tzLmFkZGVkKSB7XG4gICAgICAvLyBTcGVjaWFsIGNhc2U6IGlmIHlvdSBzcGVjaWZ5IFwiYWRkZWRcIiBhbmQgXCJtb3ZlZEJlZm9yZVwiLCB5b3UgZ2V0IGFuXG4gICAgICAvLyBvcmRlcmVkIG9ic2VydmUgd2hlcmUgZm9yIHNvbWUgcmVhc29uIHlvdSBkb24ndCBnZXQgb3JkZXJpbmcgZGF0YSBvblxuICAgICAgLy8gdGhlIGFkZHMuICBJIGR1bm5vLCB3ZSB3cm90ZSB0ZXN0cyBmb3IgaXQsIHRoZXJlIG11c3QgaGF2ZSBiZWVuIGFcbiAgICAgIC8vIHJlYXNvbi5cbiAgICAgIHNlbGYuX2FkZGVkQmVmb3JlID0gZnVuY3Rpb24gKGlkLCBmaWVsZHMsIGJlZm9yZSkge1xuICAgICAgICBjYWxsYmFja3MuYWRkZWQoaWQsIGZpZWxkcyk7XG4gICAgICB9O1xuICAgIH1cbiAgfSk7XG4gIHNlbGYuX3N0b3BwZWQgPSBmYWxzZTtcbiAgc2VsZi5faWQgPSBuZXh0T2JzZXJ2ZUhhbmRsZUlkKys7XG4gIHNlbGYubm9uTXV0YXRpbmdDYWxsYmFja3MgPSBub25NdXRhdGluZ0NhbGxiYWNrcztcbn07XG5PYnNlcnZlSGFuZGxlLnByb3RvdHlwZS5zdG9wID0gZnVuY3Rpb24gKCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgIHJldHVybjtcbiAgc2VsZi5fc3RvcHBlZCA9IHRydWU7XG4gIHNlbGYuX211bHRpcGxleGVyLnJlbW92ZUhhbmRsZShzZWxmLl9pZCk7XG59O1xuIiwidmFyIEZpYmVyID0gTnBtLnJlcXVpcmUoJ2ZpYmVycycpO1xuXG5leHBvcnQgY2xhc3MgRG9jRmV0Y2hlciB7XG4gIGNvbnN0cnVjdG9yKG1vbmdvQ29ubmVjdGlvbikge1xuICAgIHRoaXMuX21vbmdvQ29ubmVjdGlvbiA9IG1vbmdvQ29ubmVjdGlvbjtcbiAgICAvLyBNYXAgZnJvbSBvcCAtPiBbY2FsbGJhY2tdXG4gICAgdGhpcy5fY2FsbGJhY2tzRm9yT3AgPSBuZXcgTWFwO1xuICB9XG5cbiAgLy8gRmV0Y2hlcyBkb2N1bWVudCBcImlkXCIgZnJvbSBjb2xsZWN0aW9uTmFtZSwgcmV0dXJuaW5nIGl0IG9yIG51bGwgaWYgbm90XG4gIC8vIGZvdW5kLlxuICAvL1xuICAvLyBJZiB5b3UgbWFrZSBtdWx0aXBsZSBjYWxscyB0byBmZXRjaCgpIHdpdGggdGhlIHNhbWUgb3AgcmVmZXJlbmNlLFxuICAvLyBEb2NGZXRjaGVyIG1heSBhc3N1bWUgdGhhdCB0aGV5IGFsbCByZXR1cm4gdGhlIHNhbWUgZG9jdW1lbnQuIChJdCBkb2VzXG4gIC8vIG5vdCBjaGVjayB0byBzZWUgaWYgY29sbGVjdGlvbk5hbWUvaWQgbWF0Y2guKVxuICAvL1xuICAvLyBZb3UgbWF5IGFzc3VtZSB0aGF0IGNhbGxiYWNrIGlzIG5ldmVyIGNhbGxlZCBzeW5jaHJvbm91c2x5IChhbmQgaW4gZmFjdFxuICAvLyBPcGxvZ09ic2VydmVEcml2ZXIgZG9lcyBzbykuXG4gIGZldGNoKGNvbGxlY3Rpb25OYW1lLCBpZCwgb3AsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBcbiAgICBjaGVjayhjb2xsZWN0aW9uTmFtZSwgU3RyaW5nKTtcbiAgICBjaGVjayhvcCwgT2JqZWN0KTtcblxuXG4gICAgLy8gSWYgdGhlcmUncyBhbHJlYWR5IGFuIGluLXByb2dyZXNzIGZldGNoIGZvciB0aGlzIGNhY2hlIGtleSwgeWllbGQgdW50aWxcbiAgICAvLyBpdCdzIGRvbmUgYW5kIHJldHVybiB3aGF0ZXZlciBpdCByZXR1cm5zLlxuICAgIGlmIChzZWxmLl9jYWxsYmFja3NGb3JPcC5oYXMob3ApKSB7XG4gICAgICBzZWxmLl9jYWxsYmFja3NGb3JPcC5nZXQob3ApLnB1c2goY2FsbGJhY2spO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGNhbGxiYWNrcyA9IFtjYWxsYmFja107XG4gICAgc2VsZi5fY2FsbGJhY2tzRm9yT3Auc2V0KG9wLCBjYWxsYmFja3MpO1xuXG4gICAgRmliZXIoZnVuY3Rpb24gKCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIGRvYyA9IHNlbGYuX21vbmdvQ29ubmVjdGlvbi5maW5kT25lKFxuICAgICAgICAgIGNvbGxlY3Rpb25OYW1lLCB7X2lkOiBpZH0pIHx8IG51bGw7XG4gICAgICAgIC8vIFJldHVybiBkb2MgdG8gYWxsIHJlbGV2YW50IGNhbGxiYWNrcy4gTm90ZSB0aGF0IHRoaXMgYXJyYXkgY2FuXG4gICAgICAgIC8vIGNvbnRpbnVlIHRvIGdyb3cgZHVyaW5nIGNhbGxiYWNrIGV4Y2VjdXRpb24uXG4gICAgICAgIHdoaWxlIChjYWxsYmFja3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgIC8vIENsb25lIHRoZSBkb2N1bWVudCBzbyB0aGF0IHRoZSB2YXJpb3VzIGNhbGxzIHRvIGZldGNoIGRvbid0IHJldHVyblxuICAgICAgICAgIC8vIG9iamVjdHMgdGhhdCBhcmUgaW50ZXJ0d2luZ2xlZCB3aXRoIGVhY2ggb3RoZXIuIENsb25lIGJlZm9yZVxuICAgICAgICAgIC8vIHBvcHBpbmcgdGhlIGZ1dHVyZSwgc28gdGhhdCBpZiBjbG9uZSB0aHJvd3MsIHRoZSBlcnJvciBnZXRzIHBhc3NlZFxuICAgICAgICAgIC8vIHRvIHRoZSBuZXh0IGNhbGxiYWNrLlxuICAgICAgICAgIGNhbGxiYWNrcy5wb3AoKShudWxsLCBFSlNPTi5jbG9uZShkb2MpKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB3aGlsZSAoY2FsbGJhY2tzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBjYWxsYmFja3MucG9wKCkoZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIC8vIFhYWCBjb25zaWRlciBrZWVwaW5nIHRoZSBkb2MgYXJvdW5kIGZvciBhIHBlcmlvZCBvZiB0aW1lIGJlZm9yZVxuICAgICAgICAvLyByZW1vdmluZyBmcm9tIHRoZSBjYWNoZVxuICAgICAgICBzZWxmLl9jYWxsYmFja3NGb3JPcC5kZWxldGUob3ApO1xuICAgICAgfVxuICAgIH0pLnJ1bigpO1xuICB9XG59XG4iLCJ2YXIgUE9MTElOR19USFJPVFRMRV9NUyA9ICtwcm9jZXNzLmVudi5NRVRFT1JfUE9MTElOR19USFJPVFRMRV9NUyB8fCA1MDtcbnZhciBQT0xMSU5HX0lOVEVSVkFMX01TID0gK3Byb2Nlc3MuZW52Lk1FVEVPUl9QT0xMSU5HX0lOVEVSVkFMX01TIHx8IDEwICogMTAwMDtcblxuUG9sbGluZ09ic2VydmVEcml2ZXIgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24gPSBvcHRpb25zLmN1cnNvckRlc2NyaXB0aW9uO1xuICBzZWxmLl9tb25nb0hhbmRsZSA9IG9wdGlvbnMubW9uZ29IYW5kbGU7XG4gIHNlbGYuX29yZGVyZWQgPSBvcHRpb25zLm9yZGVyZWQ7XG4gIHNlbGYuX211bHRpcGxleGVyID0gb3B0aW9ucy5tdWx0aXBsZXhlcjtcbiAgc2VsZi5fc3RvcENhbGxiYWNrcyA9IFtdO1xuICBzZWxmLl9zdG9wcGVkID0gZmFsc2U7XG5cbiAgc2VsZi5fc3luY2hyb25vdXNDdXJzb3IgPSBzZWxmLl9tb25nb0hhbmRsZS5fY3JlYXRlU3luY2hyb25vdXNDdXJzb3IoXG4gICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24pO1xuXG4gIC8vIHByZXZpb3VzIHJlc3VsdHMgc25hcHNob3QuICBvbiBlYWNoIHBvbGwgY3ljbGUsIGRpZmZzIGFnYWluc3RcbiAgLy8gcmVzdWx0cyBkcml2ZXMgdGhlIGNhbGxiYWNrcy5cbiAgc2VsZi5fcmVzdWx0cyA9IG51bGw7XG5cbiAgLy8gVGhlIG51bWJlciBvZiBfcG9sbE1vbmdvIGNhbGxzIHRoYXQgaGF2ZSBiZWVuIGFkZGVkIHRvIHNlbGYuX3Rhc2tRdWV1ZSBidXRcbiAgLy8gaGF2ZSBub3Qgc3RhcnRlZCBydW5uaW5nLiBVc2VkIHRvIG1ha2Ugc3VyZSB3ZSBuZXZlciBzY2hlZHVsZSBtb3JlIHRoYW4gb25lXG4gIC8vIF9wb2xsTW9uZ28gKG90aGVyIHRoYW4gcG9zc2libHkgdGhlIG9uZSB0aGF0IGlzIGN1cnJlbnRseSBydW5uaW5nKS4gSXQnc1xuICAvLyBhbHNvIHVzZWQgYnkgX3N1c3BlbmRQb2xsaW5nIHRvIHByZXRlbmQgdGhlcmUncyBhIHBvbGwgc2NoZWR1bGVkLiBVc3VhbGx5LFxuICAvLyBpdCdzIGVpdGhlciAwIChmb3IgXCJubyBwb2xscyBzY2hlZHVsZWQgb3RoZXIgdGhhbiBtYXliZSBvbmUgY3VycmVudGx5XG4gIC8vIHJ1bm5pbmdcIikgb3IgMSAoZm9yIFwiYSBwb2xsIHNjaGVkdWxlZCB0aGF0IGlzbid0IHJ1bm5pbmcgeWV0XCIpLCBidXQgaXQgY2FuXG4gIC8vIGFsc28gYmUgMiBpZiBpbmNyZW1lbnRlZCBieSBfc3VzcGVuZFBvbGxpbmcuXG4gIHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCA9IDA7XG4gIHNlbGYuX3BlbmRpbmdXcml0ZXMgPSBbXTsgLy8gcGVvcGxlIHRvIG5vdGlmeSB3aGVuIHBvbGxpbmcgY29tcGxldGVzXG5cbiAgLy8gTWFrZSBzdXJlIHRvIGNyZWF0ZSBhIHNlcGFyYXRlbHkgdGhyb3R0bGVkIGZ1bmN0aW9uIGZvciBlYWNoXG4gIC8vIFBvbGxpbmdPYnNlcnZlRHJpdmVyIG9iamVjdC5cbiAgc2VsZi5fZW5zdXJlUG9sbElzU2NoZWR1bGVkID0gXy50aHJvdHRsZShcbiAgICBzZWxmLl91bnRocm90dGxlZEVuc3VyZVBvbGxJc1NjaGVkdWxlZCxcbiAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnBvbGxpbmdUaHJvdHRsZU1zIHx8IFBPTExJTkdfVEhST1RUTEVfTVMgLyogbXMgKi8pO1xuXG4gIC8vIFhYWCBmaWd1cmUgb3V0IGlmIHdlIHN0aWxsIG5lZWQgYSBxdWV1ZVxuICBzZWxmLl90YXNrUXVldWUgPSBuZXcgTWV0ZW9yLl9TeW5jaHJvbm91c1F1ZXVlKCk7XG5cbiAgdmFyIGxpc3RlbmVyc0hhbmRsZSA9IGxpc3RlbkFsbChcbiAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiwgZnVuY3Rpb24gKG5vdGlmaWNhdGlvbikge1xuICAgICAgLy8gV2hlbiBzb21lb25lIGRvZXMgYSB0cmFuc2FjdGlvbiB0aGF0IG1pZ2h0IGFmZmVjdCB1cywgc2NoZWR1bGUgYSBwb2xsXG4gICAgICAvLyBvZiB0aGUgZGF0YWJhc2UuIElmIHRoYXQgdHJhbnNhY3Rpb24gaGFwcGVucyBpbnNpZGUgb2YgYSB3cml0ZSBmZW5jZSxcbiAgICAgIC8vIGJsb2NrIHRoZSBmZW5jZSB1bnRpbCB3ZSd2ZSBwb2xsZWQgYW5kIG5vdGlmaWVkIG9ic2VydmVycy5cbiAgICAgIHZhciBmZW5jZSA9IEREUFNlcnZlci5fQ3VycmVudFdyaXRlRmVuY2UuZ2V0KCk7XG4gICAgICBpZiAoZmVuY2UpXG4gICAgICAgIHNlbGYuX3BlbmRpbmdXcml0ZXMucHVzaChmZW5jZS5iZWdpbldyaXRlKCkpO1xuICAgICAgLy8gRW5zdXJlIGEgcG9sbCBpcyBzY2hlZHVsZWQuLi4gYnV0IGlmIHdlIGFscmVhZHkga25vdyB0aGF0IG9uZSBpcyxcbiAgICAgIC8vIGRvbid0IGhpdCB0aGUgdGhyb3R0bGVkIF9lbnN1cmVQb2xsSXNTY2hlZHVsZWQgZnVuY3Rpb24gKHdoaWNoIG1pZ2h0XG4gICAgICAvLyBsZWFkIHRvIHVzIGNhbGxpbmcgaXQgdW5uZWNlc3NhcmlseSBpbiA8cG9sbGluZ1Rocm90dGxlTXM+IG1zKS5cbiAgICAgIGlmIChzZWxmLl9wb2xsc1NjaGVkdWxlZEJ1dE5vdFN0YXJ0ZWQgPT09IDApXG4gICAgICAgIHNlbGYuX2Vuc3VyZVBvbGxJc1NjaGVkdWxlZCgpO1xuICAgIH1cbiAgKTtcbiAgc2VsZi5fc3RvcENhbGxiYWNrcy5wdXNoKGZ1bmN0aW9uICgpIHsgbGlzdGVuZXJzSGFuZGxlLnN0b3AoKTsgfSk7XG5cbiAgLy8gZXZlcnkgb25jZSBhbmQgYSB3aGlsZSwgcG9sbCBldmVuIGlmIHdlIGRvbid0IHRoaW5rIHdlJ3JlIGRpcnR5LCBmb3JcbiAgLy8gZXZlbnR1YWwgY29uc2lzdGVuY3kgd2l0aCBkYXRhYmFzZSB3cml0ZXMgZnJvbSBvdXRzaWRlIHRoZSBNZXRlb3JcbiAgLy8gdW5pdmVyc2UuXG4gIC8vXG4gIC8vIEZvciB0ZXN0aW5nLCB0aGVyZSdzIGFuIHVuZG9jdW1lbnRlZCBjYWxsYmFjayBhcmd1bWVudCB0byBvYnNlcnZlQ2hhbmdlc1xuICAvLyB3aGljaCBkaXNhYmxlcyB0aW1lLWJhc2VkIHBvbGxpbmcgYW5kIGdldHMgY2FsbGVkIGF0IHRoZSBiZWdpbm5pbmcgb2YgZWFjaFxuICAvLyBwb2xsLlxuICBpZiAob3B0aW9ucy5fdGVzdE9ubHlQb2xsQ2FsbGJhY2spIHtcbiAgICBzZWxmLl90ZXN0T25seVBvbGxDYWxsYmFjayA9IG9wdGlvbnMuX3Rlc3RPbmx5UG9sbENhbGxiYWNrO1xuICB9IGVsc2Uge1xuICAgIHZhciBwb2xsaW5nSW50ZXJ2YWwgPVxuICAgICAgICAgIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMucG9sbGluZ0ludGVydmFsTXMgfHxcbiAgICAgICAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLl9wb2xsaW5nSW50ZXJ2YWwgfHwgLy8gQ09NUEFUIHdpdGggMS4yXG4gICAgICAgICAgUE9MTElOR19JTlRFUlZBTF9NUztcbiAgICB2YXIgaW50ZXJ2YWxIYW5kbGUgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoXG4gICAgICBfLmJpbmQoc2VsZi5fZW5zdXJlUG9sbElzU2NoZWR1bGVkLCBzZWxmKSwgcG9sbGluZ0ludGVydmFsKTtcbiAgICBzZWxmLl9zdG9wQ2FsbGJhY2tzLnB1c2goZnVuY3Rpb24gKCkge1xuICAgICAgTWV0ZW9yLmNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxIYW5kbGUpO1xuICAgIH0pO1xuICB9XG5cbiAgLy8gTWFrZSBzdXJlIHdlIGFjdHVhbGx5IHBvbGwgc29vbiFcbiAgc2VsZi5fdW50aHJvdHRsZWRFbnN1cmVQb2xsSXNTY2hlZHVsZWQoKTtcblxuICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgXCJtb25nby1saXZlZGF0YVwiLCBcIm9ic2VydmUtZHJpdmVycy1wb2xsaW5nXCIsIDEpO1xufTtcblxuXy5leHRlbmQoUG9sbGluZ09ic2VydmVEcml2ZXIucHJvdG90eXBlLCB7XG4gIC8vIFRoaXMgaXMgYWx3YXlzIGNhbGxlZCB0aHJvdWdoIF8udGhyb3R0bGUgKGV4Y2VwdCBvbmNlIGF0IHN0YXJ0dXApLlxuICBfdW50aHJvdHRsZWRFbnN1cmVQb2xsSXNTY2hlZHVsZWQ6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCA+IDApXG4gICAgICByZXR1cm47XG4gICAgKytzZWxmLl9wb2xsc1NjaGVkdWxlZEJ1dE5vdFN0YXJ0ZWQ7XG4gICAgc2VsZi5fdGFza1F1ZXVlLnF1ZXVlVGFzayhmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9wb2xsTW9uZ28oKTtcbiAgICB9KTtcbiAgfSxcblxuICAvLyB0ZXN0LW9ubHkgaW50ZXJmYWNlIGZvciBjb250cm9sbGluZyBwb2xsaW5nLlxuICAvL1xuICAvLyBfc3VzcGVuZFBvbGxpbmcgYmxvY2tzIHVudGlsIGFueSBjdXJyZW50bHkgcnVubmluZyBhbmQgc2NoZWR1bGVkIHBvbGxzIGFyZVxuICAvLyBkb25lLCBhbmQgcHJldmVudHMgYW55IGZ1cnRoZXIgcG9sbHMgZnJvbSBiZWluZyBzY2hlZHVsZWQuIChuZXdcbiAgLy8gT2JzZXJ2ZUhhbmRsZXMgY2FuIGJlIGFkZGVkIGFuZCByZWNlaXZlIHRoZWlyIGluaXRpYWwgYWRkZWQgY2FsbGJhY2tzLFxuICAvLyB0aG91Z2guKVxuICAvL1xuICAvLyBfcmVzdW1lUG9sbGluZyBpbW1lZGlhdGVseSBwb2xscywgYW5kIGFsbG93cyBmdXJ0aGVyIHBvbGxzIHRvIG9jY3VyLlxuICBfc3VzcGVuZFBvbGxpbmc6IGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAvLyBQcmV0ZW5kIHRoYXQgdGhlcmUncyBhbm90aGVyIHBvbGwgc2NoZWR1bGVkICh3aGljaCB3aWxsIHByZXZlbnRcbiAgICAvLyBfZW5zdXJlUG9sbElzU2NoZWR1bGVkIGZyb20gcXVldWVpbmcgYW55IG1vcmUgcG9sbHMpLlxuICAgICsrc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkO1xuICAgIC8vIE5vdyBibG9jayB1bnRpbCBhbGwgY3VycmVudGx5IHJ1bm5pbmcgb3Igc2NoZWR1bGVkIHBvbGxzIGFyZSBkb25lLlxuICAgIHNlbGYuX3Rhc2tRdWV1ZS5ydW5UYXNrKGZ1bmN0aW9uKCkge30pO1xuXG4gICAgLy8gQ29uZmlybSB0aGF0IHRoZXJlIGlzIG9ubHkgb25lIFwicG9sbFwiICh0aGUgZmFrZSBvbmUgd2UncmUgcHJldGVuZGluZyB0b1xuICAgIC8vIGhhdmUpIHNjaGVkdWxlZC5cbiAgICBpZiAoc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkICE9PSAxKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCBpcyBcIiArXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkKTtcbiAgfSxcbiAgX3Jlc3VtZVBvbGxpbmc6IGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAvLyBXZSBzaG91bGQgYmUgaW4gdGhlIHNhbWUgc3RhdGUgYXMgaW4gdGhlIGVuZCBvZiBfc3VzcGVuZFBvbGxpbmcuXG4gICAgaWYgKHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCAhPT0gMSlcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIl9wb2xsc1NjaGVkdWxlZEJ1dE5vdFN0YXJ0ZWQgaXMgXCIgK1xuICAgICAgICAgICAgICAgICAgICAgIHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCk7XG4gICAgLy8gUnVuIGEgcG9sbCBzeW5jaHJvbm91c2x5ICh3aGljaCB3aWxsIGNvdW50ZXJhY3QgdGhlXG4gICAgLy8gKytfcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkIGZyb20gX3N1c3BlbmRQb2xsaW5nKS5cbiAgICBzZWxmLl90YXNrUXVldWUucnVuVGFzayhmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9wb2xsTW9uZ28oKTtcbiAgICB9KTtcbiAgfSxcblxuICBfcG9sbE1vbmdvOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIC0tc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkO1xuXG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICByZXR1cm47XG5cbiAgICB2YXIgZmlyc3QgPSBmYWxzZTtcbiAgICB2YXIgbmV3UmVzdWx0cztcbiAgICB2YXIgb2xkUmVzdWx0cyA9IHNlbGYuX3Jlc3VsdHM7XG4gICAgaWYgKCFvbGRSZXN1bHRzKSB7XG4gICAgICBmaXJzdCA9IHRydWU7XG4gICAgICAvLyBYWFggbWF5YmUgdXNlIE9yZGVyZWREaWN0IGluc3RlYWQ/XG4gICAgICBvbGRSZXN1bHRzID0gc2VsZi5fb3JkZXJlZCA/IFtdIDogbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG4gICAgfVxuXG4gICAgc2VsZi5fdGVzdE9ubHlQb2xsQ2FsbGJhY2sgJiYgc2VsZi5fdGVzdE9ubHlQb2xsQ2FsbGJhY2soKTtcblxuICAgIC8vIFNhdmUgdGhlIGxpc3Qgb2YgcGVuZGluZyB3cml0ZXMgd2hpY2ggdGhpcyByb3VuZCB3aWxsIGNvbW1pdC5cbiAgICB2YXIgd3JpdGVzRm9yQ3ljbGUgPSBzZWxmLl9wZW5kaW5nV3JpdGVzO1xuICAgIHNlbGYuX3BlbmRpbmdXcml0ZXMgPSBbXTtcblxuICAgIC8vIEdldCB0aGUgbmV3IHF1ZXJ5IHJlc3VsdHMuIChUaGlzIHlpZWxkcy4pXG4gICAgdHJ5IHtcbiAgICAgIG5ld1Jlc3VsdHMgPSBzZWxmLl9zeW5jaHJvbm91c0N1cnNvci5nZXRSYXdPYmplY3RzKHNlbGYuX29yZGVyZWQpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChmaXJzdCAmJiB0eXBlb2YoZS5jb2RlKSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgLy8gVGhpcyBpcyBhbiBlcnJvciBkb2N1bWVudCBzZW50IHRvIHVzIGJ5IG1vbmdvZCwgbm90IGEgY29ubmVjdGlvblxuICAgICAgICAvLyBlcnJvciBnZW5lcmF0ZWQgYnkgdGhlIGNsaWVudC4gQW5kIHdlJ3ZlIG5ldmVyIHNlZW4gdGhpcyBxdWVyeSB3b3JrXG4gICAgICAgIC8vIHN1Y2Nlc3NmdWxseS4gUHJvYmFibHkgaXQncyBhIGJhZCBzZWxlY3RvciBvciBzb21ldGhpbmcsIHNvIHdlIHNob3VsZFxuICAgICAgICAvLyBOT1QgcmV0cnkuIEluc3RlYWQsIHdlIHNob3VsZCBoYWx0IHRoZSBvYnNlcnZlICh3aGljaCBlbmRzIHVwIGNhbGxpbmdcbiAgICAgICAgLy8gYHN0b3BgIG9uIHVzKS5cbiAgICAgICAgc2VsZi5fbXVsdGlwbGV4ZXIucXVlcnlFcnJvcihcbiAgICAgICAgICBuZXcgRXJyb3IoXG4gICAgICAgICAgICBcIkV4Y2VwdGlvbiB3aGlsZSBwb2xsaW5nIHF1ZXJ5IFwiICtcbiAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24pICsgXCI6IFwiICsgZS5tZXNzYWdlKSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gZ2V0UmF3T2JqZWN0cyBjYW4gdGhyb3cgaWYgd2UncmUgaGF2aW5nIHRyb3VibGUgdGFsa2luZyB0byB0aGVcbiAgICAgIC8vIGRhdGFiYXNlLiAgVGhhdCdzIGZpbmUgLS0tIHdlIHdpbGwgcmVwb2xsIGxhdGVyIGFueXdheS4gQnV0IHdlIHNob3VsZFxuICAgICAgLy8gbWFrZSBzdXJlIG5vdCB0byBsb3NlIHRyYWNrIG9mIHRoaXMgY3ljbGUncyB3cml0ZXMuXG4gICAgICAvLyAoSXQgYWxzbyBjYW4gdGhyb3cgaWYgdGhlcmUncyBqdXN0IHNvbWV0aGluZyBpbnZhbGlkIGFib3V0IHRoaXMgcXVlcnk7XG4gICAgICAvLyB1bmZvcnR1bmF0ZWx5IHRoZSBPYnNlcnZlRHJpdmVyIEFQSSBkb2Vzbid0IHByb3ZpZGUgYSBnb29kIHdheSB0b1xuICAgICAgLy8gXCJjYW5jZWxcIiB0aGUgb2JzZXJ2ZSBmcm9tIHRoZSBpbnNpZGUgaW4gdGhpcyBjYXNlLlxuICAgICAgQXJyYXkucHJvdG90eXBlLnB1c2guYXBwbHkoc2VsZi5fcGVuZGluZ1dyaXRlcywgd3JpdGVzRm9yQ3ljbGUpO1xuICAgICAgTWV0ZW9yLl9kZWJ1ZyhcIkV4Y2VwdGlvbiB3aGlsZSBwb2xsaW5nIHF1ZXJ5IFwiICtcbiAgICAgICAgICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24pLCBlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSdW4gZGlmZnMuXG4gICAgaWYgKCFzZWxmLl9zdG9wcGVkKSB7XG4gICAgICBMb2NhbENvbGxlY3Rpb24uX2RpZmZRdWVyeUNoYW5nZXMoXG4gICAgICAgIHNlbGYuX29yZGVyZWQsIG9sZFJlc3VsdHMsIG5ld1Jlc3VsdHMsIHNlbGYuX211bHRpcGxleGVyKTtcbiAgICB9XG5cbiAgICAvLyBTaWduYWxzIHRoZSBtdWx0aXBsZXhlciB0byBhbGxvdyBhbGwgb2JzZXJ2ZUNoYW5nZXMgY2FsbHMgdGhhdCBzaGFyZSB0aGlzXG4gICAgLy8gbXVsdGlwbGV4ZXIgdG8gcmV0dXJuLiAoVGhpcyBoYXBwZW5zIGFzeW5jaHJvbm91c2x5LCB2aWEgdGhlXG4gICAgLy8gbXVsdGlwbGV4ZXIncyBxdWV1ZS4pXG4gICAgaWYgKGZpcnN0KVxuICAgICAgc2VsZi5fbXVsdGlwbGV4ZXIucmVhZHkoKTtcblxuICAgIC8vIFJlcGxhY2Ugc2VsZi5fcmVzdWx0cyBhdG9taWNhbGx5LiAgKFRoaXMgYXNzaWdubWVudCBpcyB3aGF0IG1ha2VzIGBmaXJzdGBcbiAgICAvLyBzdGF5IHRocm91Z2ggb24gdGhlIG5leHQgY3ljbGUsIHNvIHdlJ3ZlIHdhaXRlZCB1bnRpbCBhZnRlciB3ZSd2ZVxuICAgIC8vIGNvbW1pdHRlZCB0byByZWFkeS1pbmcgdGhlIG11bHRpcGxleGVyLilcbiAgICBzZWxmLl9yZXN1bHRzID0gbmV3UmVzdWx0cztcblxuICAgIC8vIE9uY2UgdGhlIE9ic2VydmVNdWx0aXBsZXhlciBoYXMgcHJvY2Vzc2VkIGV2ZXJ5dGhpbmcgd2UndmUgZG9uZSBpbiB0aGlzXG4gICAgLy8gcm91bmQsIG1hcmsgYWxsIHRoZSB3cml0ZXMgd2hpY2ggZXhpc3RlZCBiZWZvcmUgdGhpcyBjYWxsIGFzXG4gICAgLy8gY29tbW1pdHRlZC4gKElmIG5ldyB3cml0ZXMgaGF2ZSBzaG93biB1cCBpbiB0aGUgbWVhbnRpbWUsIHRoZXJlJ2xsXG4gICAgLy8gYWxyZWFkeSBiZSBhbm90aGVyIF9wb2xsTW9uZ28gdGFzayBzY2hlZHVsZWQuKVxuICAgIHNlbGYuX211bHRpcGxleGVyLm9uRmx1c2goZnVuY3Rpb24gKCkge1xuICAgICAgXy5lYWNoKHdyaXRlc0ZvckN5Y2xlLCBmdW5jdGlvbiAodykge1xuICAgICAgICB3LmNvbW1pdHRlZCgpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sXG5cbiAgc3RvcDogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBzZWxmLl9zdG9wcGVkID0gdHJ1ZTtcbiAgICBfLmVhY2goc2VsZi5fc3RvcENhbGxiYWNrcywgZnVuY3Rpb24gKGMpIHsgYygpOyB9KTtcbiAgICAvLyBSZWxlYXNlIGFueSB3cml0ZSBmZW5jZXMgdGhhdCBhcmUgd2FpdGluZyBvbiB1cy5cbiAgICBfLmVhY2goc2VsZi5fcGVuZGluZ1dyaXRlcywgZnVuY3Rpb24gKHcpIHtcbiAgICAgIHcuY29tbWl0dGVkKCk7XG4gICAgfSk7XG4gICAgUGFja2FnZVsnZmFjdHMtYmFzZSddICYmIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXS5GYWN0cy5pbmNyZW1lbnRTZXJ2ZXJGYWN0KFxuICAgICAgXCJtb25nby1saXZlZGF0YVwiLCBcIm9ic2VydmUtZHJpdmVycy1wb2xsaW5nXCIsIC0xKTtcbiAgfVxufSk7XG4iLCJpbXBvcnQgeyBvcGxvZ1YyVjFDb252ZXJ0ZXIgfSBmcm9tIFwiLi9vcGxvZ192Ml9jb252ZXJ0ZXJcIjtcblxudmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKCdmaWJlcnMvZnV0dXJlJyk7XG5cbnZhciBQSEFTRSA9IHtcbiAgUVVFUllJTkc6IFwiUVVFUllJTkdcIixcbiAgRkVUQ0hJTkc6IFwiRkVUQ0hJTkdcIixcbiAgU1RFQURZOiBcIlNURUFEWVwiXG59O1xuXG4vLyBFeGNlcHRpb24gdGhyb3duIGJ5IF9uZWVkVG9Qb2xsUXVlcnkgd2hpY2ggdW5yb2xscyB0aGUgc3RhY2sgdXAgdG8gdGhlXG4vLyBlbmNsb3NpbmcgY2FsbCB0byBmaW5pc2hJZk5lZWRUb1BvbGxRdWVyeS5cbnZhciBTd2l0Y2hlZFRvUXVlcnkgPSBmdW5jdGlvbiAoKSB7fTtcbnZhciBmaW5pc2hJZk5lZWRUb1BvbGxRdWVyeSA9IGZ1bmN0aW9uIChmKSB7XG4gIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgdHJ5IHtcbiAgICAgIGYuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoIShlIGluc3RhbmNlb2YgU3dpdGNoZWRUb1F1ZXJ5KSlcbiAgICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH07XG59O1xuXG52YXIgY3VycmVudElkID0gMDtcblxuLy8gT3Bsb2dPYnNlcnZlRHJpdmVyIGlzIGFuIGFsdGVybmF0aXZlIHRvIFBvbGxpbmdPYnNlcnZlRHJpdmVyIHdoaWNoIGZvbGxvd3Ncbi8vIHRoZSBNb25nbyBvcGVyYXRpb24gbG9nIGluc3RlYWQgb2YganVzdCByZS1wb2xsaW5nIHRoZSBxdWVyeS4gSXQgb2JleXMgdGhlXG4vLyBzYW1lIHNpbXBsZSBpbnRlcmZhY2U6IGNvbnN0cnVjdGluZyBpdCBzdGFydHMgc2VuZGluZyBvYnNlcnZlQ2hhbmdlc1xuLy8gY2FsbGJhY2tzIChhbmQgYSByZWFkeSgpIGludm9jYXRpb24pIHRvIHRoZSBPYnNlcnZlTXVsdGlwbGV4ZXIsIGFuZCB5b3Ugc3RvcFxuLy8gaXQgYnkgY2FsbGluZyB0aGUgc3RvcCgpIG1ldGhvZC5cbk9wbG9nT2JzZXJ2ZURyaXZlciA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgc2VsZi5fdXNlc09wbG9nID0gdHJ1ZTsgIC8vIHRlc3RzIGxvb2sgYXQgdGhpc1xuXG4gIHNlbGYuX2lkID0gY3VycmVudElkO1xuICBjdXJyZW50SWQrKztcblxuICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiA9IG9wdGlvbnMuY3Vyc29yRGVzY3JpcHRpb247XG4gIHNlbGYuX21vbmdvSGFuZGxlID0gb3B0aW9ucy5tb25nb0hhbmRsZTtcbiAgc2VsZi5fbXVsdGlwbGV4ZXIgPSBvcHRpb25zLm11bHRpcGxleGVyO1xuXG4gIGlmIChvcHRpb25zLm9yZGVyZWQpIHtcbiAgICB0aHJvdyBFcnJvcihcIk9wbG9nT2JzZXJ2ZURyaXZlciBvbmx5IHN1cHBvcnRzIHVub3JkZXJlZCBvYnNlcnZlQ2hhbmdlc1wiKTtcbiAgfVxuXG4gIHZhciBzb3J0ZXIgPSBvcHRpb25zLnNvcnRlcjtcbiAgLy8gV2UgZG9uJ3Qgc3VwcG9ydCAkbmVhciBhbmQgb3RoZXIgZ2VvLXF1ZXJpZXMgc28gaXQncyBPSyB0byBpbml0aWFsaXplIHRoZVxuICAvLyBjb21wYXJhdG9yIG9ubHkgb25jZSBpbiB0aGUgY29uc3RydWN0b3IuXG4gIHZhciBjb21wYXJhdG9yID0gc29ydGVyICYmIHNvcnRlci5nZXRDb21wYXJhdG9yKCk7XG5cbiAgaWYgKG9wdGlvbnMuY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5saW1pdCkge1xuICAgIC8vIFRoZXJlIGFyZSBzZXZlcmFsIHByb3BlcnRpZXMgb3JkZXJlZCBkcml2ZXIgaW1wbGVtZW50czpcbiAgICAvLyAtIF9saW1pdCBpcyBhIHBvc2l0aXZlIG51bWJlclxuICAgIC8vIC0gX2NvbXBhcmF0b3IgaXMgYSBmdW5jdGlvbi1jb21wYXJhdG9yIGJ5IHdoaWNoIHRoZSBxdWVyeSBpcyBvcmRlcmVkXG4gICAgLy8gLSBfdW5wdWJsaXNoZWRCdWZmZXIgaXMgbm9uLW51bGwgTWluL01heCBIZWFwLFxuICAgIC8vICAgICAgICAgICAgICAgICAgICAgIHRoZSBlbXB0eSBidWZmZXIgaW4gU1RFQURZIHBoYXNlIGltcGxpZXMgdGhhdCB0aGVcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICBldmVyeXRoaW5nIHRoYXQgbWF0Y2hlcyB0aGUgcXVlcmllcyBzZWxlY3RvciBmaXRzXG4gICAgLy8gICAgICAgICAgICAgICAgICAgICAgaW50byBwdWJsaXNoZWQgc2V0LlxuICAgIC8vIC0gX3B1Ymxpc2hlZCAtIE1heCBIZWFwIChhbHNvIGltcGxlbWVudHMgSWRNYXAgbWV0aG9kcylcblxuICAgIHZhciBoZWFwT3B0aW9ucyA9IHsgSWRNYXA6IExvY2FsQ29sbGVjdGlvbi5fSWRNYXAgfTtcbiAgICBzZWxmLl9saW1pdCA9IHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMubGltaXQ7XG4gICAgc2VsZi5fY29tcGFyYXRvciA9IGNvbXBhcmF0b3I7XG4gICAgc2VsZi5fc29ydGVyID0gc29ydGVyO1xuICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyID0gbmV3IE1pbk1heEhlYXAoY29tcGFyYXRvciwgaGVhcE9wdGlvbnMpO1xuICAgIC8vIFdlIG5lZWQgc29tZXRoaW5nIHRoYXQgY2FuIGZpbmQgTWF4IHZhbHVlIGluIGFkZGl0aW9uIHRvIElkTWFwIGludGVyZmFjZVxuICAgIHNlbGYuX3B1Ymxpc2hlZCA9IG5ldyBNYXhIZWFwKGNvbXBhcmF0b3IsIGhlYXBPcHRpb25zKTtcbiAgfSBlbHNlIHtcbiAgICBzZWxmLl9saW1pdCA9IDA7XG4gICAgc2VsZi5fY29tcGFyYXRvciA9IG51bGw7XG4gICAgc2VsZi5fc29ydGVyID0gbnVsbDtcbiAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlciA9IG51bGw7XG4gICAgc2VsZi5fcHVibGlzaGVkID0gbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG4gIH1cblxuICAvLyBJbmRpY2F0ZXMgaWYgaXQgaXMgc2FmZSB0byBpbnNlcnQgYSBuZXcgZG9jdW1lbnQgYXQgdGhlIGVuZCBvZiB0aGUgYnVmZmVyXG4gIC8vIGZvciB0aGlzIHF1ZXJ5LiBpLmUuIGl0IGlzIGtub3duIHRoYXQgdGhlcmUgYXJlIG5vIGRvY3VtZW50cyBtYXRjaGluZyB0aGVcbiAgLy8gc2VsZWN0b3IgdGhvc2UgYXJlIG5vdCBpbiBwdWJsaXNoZWQgb3IgYnVmZmVyLlxuICBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgPSBmYWxzZTtcblxuICBzZWxmLl9zdG9wcGVkID0gZmFsc2U7XG4gIHNlbGYuX3N0b3BIYW5kbGVzID0gW107XG5cbiAgUGFja2FnZVsnZmFjdHMtYmFzZSddICYmIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXS5GYWN0cy5pbmNyZW1lbnRTZXJ2ZXJGYWN0KFxuICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWRyaXZlcnMtb3Bsb2dcIiwgMSk7XG5cbiAgc2VsZi5fcmVnaXN0ZXJQaGFzZUNoYW5nZShQSEFTRS5RVUVSWUlORyk7XG5cbiAgc2VsZi5fbWF0Y2hlciA9IG9wdGlvbnMubWF0Y2hlcjtcbiAgLy8gd2UgYXJlIG5vdyB1c2luZyBwcm9qZWN0aW9uLCBub3QgZmllbGRzIGluIHRoZSBjdXJzb3IgZGVzY3JpcHRpb24gZXZlbiBpZiB5b3UgcGFzcyB7ZmllbGRzfVxuICAvLyBpbiB0aGUgY3Vyc29yIGNvbnN0cnVjdGlvblxuICB2YXIgcHJvamVjdGlvbiA9IHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMuZmllbGRzIHx8IHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMucHJvamVjdGlvbiB8fCB7fTtcbiAgc2VsZi5fcHJvamVjdGlvbkZuID0gTG9jYWxDb2xsZWN0aW9uLl9jb21waWxlUHJvamVjdGlvbihwcm9qZWN0aW9uKTtcbiAgLy8gUHJvamVjdGlvbiBmdW5jdGlvbiwgcmVzdWx0IG9mIGNvbWJpbmluZyBpbXBvcnRhbnQgZmllbGRzIGZvciBzZWxlY3RvciBhbmRcbiAgLy8gZXhpc3RpbmcgZmllbGRzIHByb2plY3Rpb25cbiAgc2VsZi5fc2hhcmVkUHJvamVjdGlvbiA9IHNlbGYuX21hdGNoZXIuY29tYmluZUludG9Qcm9qZWN0aW9uKHByb2plY3Rpb24pO1xuICBpZiAoc29ydGVyKVxuICAgIHNlbGYuX3NoYXJlZFByb2plY3Rpb24gPSBzb3J0ZXIuY29tYmluZUludG9Qcm9qZWN0aW9uKHNlbGYuX3NoYXJlZFByb2plY3Rpb24pO1xuICBzZWxmLl9zaGFyZWRQcm9qZWN0aW9uRm4gPSBMb2NhbENvbGxlY3Rpb24uX2NvbXBpbGVQcm9qZWN0aW9uKFxuICAgIHNlbGYuX3NoYXJlZFByb2plY3Rpb24pO1xuXG4gIHNlbGYuX25lZWRUb0ZldGNoID0gbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG4gIHNlbGYuX2N1cnJlbnRseUZldGNoaW5nID0gbnVsbDtcbiAgc2VsZi5fZmV0Y2hHZW5lcmF0aW9uID0gMDtcblxuICBzZWxmLl9yZXF1ZXJ5V2hlbkRvbmVUaGlzUXVlcnkgPSBmYWxzZTtcbiAgc2VsZi5fd3JpdGVzVG9Db21taXRXaGVuV2VSZWFjaFN0ZWFkeSA9IFtdO1xuXG4gIC8vIElmIHRoZSBvcGxvZyBoYW5kbGUgdGVsbHMgdXMgdGhhdCBpdCBza2lwcGVkIHNvbWUgZW50cmllcyAoYmVjYXVzZSBpdCBnb3RcbiAgLy8gYmVoaW5kLCBzYXkpLCByZS1wb2xsLlxuICBzZWxmLl9zdG9wSGFuZGxlcy5wdXNoKHNlbGYuX21vbmdvSGFuZGxlLl9vcGxvZ0hhbmRsZS5vblNraXBwZWRFbnRyaWVzKFxuICAgIGZpbmlzaElmTmVlZFRvUG9sbFF1ZXJ5KGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYuX25lZWRUb1BvbGxRdWVyeSgpO1xuICAgIH0pXG4gICkpO1xuXG4gIGZvckVhY2hUcmlnZ2VyKHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLCBmdW5jdGlvbiAodHJpZ2dlcikge1xuICAgIHNlbGYuX3N0b3BIYW5kbGVzLnB1c2goc2VsZi5fbW9uZ29IYW5kbGUuX29wbG9nSGFuZGxlLm9uT3Bsb2dFbnRyeShcbiAgICAgIHRyaWdnZXIsIGZ1bmN0aW9uIChub3RpZmljYXRpb24pIHtcbiAgICAgICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBvcCA9IG5vdGlmaWNhdGlvbi5vcDtcbiAgICAgICAgICBpZiAobm90aWZpY2F0aW9uLmRyb3BDb2xsZWN0aW9uIHx8IG5vdGlmaWNhdGlvbi5kcm9wRGF0YWJhc2UpIHtcbiAgICAgICAgICAgIC8vIE5vdGU6IHRoaXMgY2FsbCBpcyBub3QgYWxsb3dlZCB0byBibG9jayBvbiBhbnl0aGluZyAoZXNwZWNpYWxseVxuICAgICAgICAgICAgLy8gb24gd2FpdGluZyBmb3Igb3Bsb2cgZW50cmllcyB0byBjYXRjaCB1cCkgYmVjYXVzZSB0aGF0IHdpbGwgYmxvY2tcbiAgICAgICAgICAgIC8vIG9uT3Bsb2dFbnRyeSFcbiAgICAgICAgICAgIHNlbGYuX25lZWRUb1BvbGxRdWVyeSgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBBbGwgb3RoZXIgb3BlcmF0b3JzIHNob3VsZCBiZSBoYW5kbGVkIGRlcGVuZGluZyBvbiBwaGFzZVxuICAgICAgICAgICAgaWYgKHNlbGYuX3BoYXNlID09PSBQSEFTRS5RVUVSWUlORykge1xuICAgICAgICAgICAgICBzZWxmLl9oYW5kbGVPcGxvZ0VudHJ5UXVlcnlpbmcob3ApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgc2VsZi5faGFuZGxlT3Bsb2dFbnRyeVN0ZWFkeU9yRmV0Y2hpbmcob3ApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSkpO1xuICAgICAgfVxuICAgICkpO1xuICB9KTtcblxuICAvLyBYWFggb3JkZXJpbmcgdy5yLnQuIGV2ZXJ5dGhpbmcgZWxzZT9cbiAgc2VsZi5fc3RvcEhhbmRsZXMucHVzaChsaXN0ZW5BbGwoXG4gICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24sIGZ1bmN0aW9uIChub3RpZmljYXRpb24pIHtcbiAgICAgIC8vIElmIHdlJ3JlIG5vdCBpbiBhIHByZS1maXJlIHdyaXRlIGZlbmNlLCB3ZSBkb24ndCBoYXZlIHRvIGRvIGFueXRoaW5nLlxuICAgICAgdmFyIGZlbmNlID0gRERQU2VydmVyLl9DdXJyZW50V3JpdGVGZW5jZS5nZXQoKTtcbiAgICAgIGlmICghZmVuY2UgfHwgZmVuY2UuZmlyZWQpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgaWYgKGZlbmNlLl9vcGxvZ09ic2VydmVEcml2ZXJzKSB7XG4gICAgICAgIGZlbmNlLl9vcGxvZ09ic2VydmVEcml2ZXJzW3NlbGYuX2lkXSA9IHNlbGY7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgZmVuY2UuX29wbG9nT2JzZXJ2ZURyaXZlcnMgPSB7fTtcbiAgICAgIGZlbmNlLl9vcGxvZ09ic2VydmVEcml2ZXJzW3NlbGYuX2lkXSA9IHNlbGY7XG5cbiAgICAgIGZlbmNlLm9uQmVmb3JlRmlyZShmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBkcml2ZXJzID0gZmVuY2UuX29wbG9nT2JzZXJ2ZURyaXZlcnM7XG4gICAgICAgIGRlbGV0ZSBmZW5jZS5fb3Bsb2dPYnNlcnZlRHJpdmVycztcblxuICAgICAgICAvLyBUaGlzIGZlbmNlIGNhbm5vdCBmaXJlIHVudGlsIHdlJ3ZlIGNhdWdodCB1cCB0byBcInRoaXMgcG9pbnRcIiBpbiB0aGVcbiAgICAgICAgLy8gb3Bsb2csIGFuZCBhbGwgb2JzZXJ2ZXJzIG1hZGUgaXQgYmFjayB0byB0aGUgc3RlYWR5IHN0YXRlLlxuICAgICAgICBzZWxmLl9tb25nb0hhbmRsZS5fb3Bsb2dIYW5kbGUud2FpdFVudGlsQ2F1Z2h0VXAoKTtcblxuICAgICAgICBfLmVhY2goZHJpdmVycywgZnVuY3Rpb24gKGRyaXZlcikge1xuICAgICAgICAgIGlmIChkcml2ZXIuX3N0b3BwZWQpXG4gICAgICAgICAgICByZXR1cm47XG5cbiAgICAgICAgICB2YXIgd3JpdGUgPSBmZW5jZS5iZWdpbldyaXRlKCk7XG4gICAgICAgICAgaWYgKGRyaXZlci5fcGhhc2UgPT09IFBIQVNFLlNURUFEWSkge1xuICAgICAgICAgICAgLy8gTWFrZSBzdXJlIHRoYXQgYWxsIG9mIHRoZSBjYWxsYmFja3MgaGF2ZSBtYWRlIGl0IHRocm91Z2ggdGhlXG4gICAgICAgICAgICAvLyBtdWx0aXBsZXhlciBhbmQgYmVlbiBkZWxpdmVyZWQgdG8gT2JzZXJ2ZUhhbmRsZXMgYmVmb3JlIGNvbW1pdHRpbmdcbiAgICAgICAgICAgIC8vIHdyaXRlcy5cbiAgICAgICAgICAgIGRyaXZlci5fbXVsdGlwbGV4ZXIub25GbHVzaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGRyaXZlci5fd3JpdGVzVG9Db21taXRXaGVuV2VSZWFjaFN0ZWFkeS5wdXNoKHdyaXRlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICApKTtcblxuICAvLyBXaGVuIE1vbmdvIGZhaWxzIG92ZXIsIHdlIG5lZWQgdG8gcmVwb2xsIHRoZSBxdWVyeSwgaW4gY2FzZSB3ZSBwcm9jZXNzZWQgYW5cbiAgLy8gb3Bsb2cgZW50cnkgdGhhdCBnb3Qgcm9sbGVkIGJhY2suXG4gIHNlbGYuX3N0b3BIYW5kbGVzLnB1c2goc2VsZi5fbW9uZ29IYW5kbGUuX29uRmFpbG92ZXIoZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkoXG4gICAgZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5fbmVlZFRvUG9sbFF1ZXJ5KCk7XG4gICAgfSkpKTtcblxuICAvLyBHaXZlIF9vYnNlcnZlQ2hhbmdlcyBhIGNoYW5jZSB0byBhZGQgdGhlIG5ldyBPYnNlcnZlSGFuZGxlIHRvIG91clxuICAvLyBtdWx0aXBsZXhlciwgc28gdGhhdCB0aGUgYWRkZWQgY2FsbHMgZ2V0IHN0cmVhbWVkLlxuICBNZXRlb3IuZGVmZXIoZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkoZnVuY3Rpb24gKCkge1xuICAgIHNlbGYuX3J1bkluaXRpYWxRdWVyeSgpO1xuICB9KSk7XG59O1xuXG5fLmV4dGVuZChPcGxvZ09ic2VydmVEcml2ZXIucHJvdG90eXBlLCB7XG4gIF9hZGRQdWJsaXNoZWQ6IGZ1bmN0aW9uIChpZCwgZG9jKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHZhciBmaWVsZHMgPSBfLmNsb25lKGRvYyk7XG4gICAgICBkZWxldGUgZmllbGRzLl9pZDtcbiAgICAgIHNlbGYuX3B1Ymxpc2hlZC5zZXQoaWQsIHNlbGYuX3NoYXJlZFByb2plY3Rpb25Gbihkb2MpKTtcbiAgICAgIHNlbGYuX211bHRpcGxleGVyLmFkZGVkKGlkLCBzZWxmLl9wcm9qZWN0aW9uRm4oZmllbGRzKSk7XG5cbiAgICAgIC8vIEFmdGVyIGFkZGluZyB0aGlzIGRvY3VtZW50LCB0aGUgcHVibGlzaGVkIHNldCBtaWdodCBiZSBvdmVyZmxvd2VkXG4gICAgICAvLyAoZXhjZWVkaW5nIGNhcGFjaXR5IHNwZWNpZmllZCBieSBsaW1pdCkuIElmIHNvLCBwdXNoIHRoZSBtYXhpbXVtXG4gICAgICAvLyBlbGVtZW50IHRvIHRoZSBidWZmZXIsIHdlIG1pZ2h0IHdhbnQgdG8gc2F2ZSBpdCBpbiBtZW1vcnkgdG8gcmVkdWNlIHRoZVxuICAgICAgLy8gYW1vdW50IG9mIE1vbmdvIGxvb2t1cHMgaW4gdGhlIGZ1dHVyZS5cbiAgICAgIGlmIChzZWxmLl9saW1pdCAmJiBzZWxmLl9wdWJsaXNoZWQuc2l6ZSgpID4gc2VsZi5fbGltaXQpIHtcbiAgICAgICAgLy8gWFhYIGluIHRoZW9yeSB0aGUgc2l6ZSBvZiBwdWJsaXNoZWQgaXMgbm8gbW9yZSB0aGFuIGxpbWl0KzFcbiAgICAgICAgaWYgKHNlbGYuX3B1Ymxpc2hlZC5zaXplKCkgIT09IHNlbGYuX2xpbWl0ICsgMSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkFmdGVyIGFkZGluZyB0byBwdWJsaXNoZWQsIFwiICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHNlbGYuX3B1Ymxpc2hlZC5zaXplKCkgLSBzZWxmLl9saW1pdCkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICBcIiBkb2N1bWVudHMgYXJlIG92ZXJmbG93aW5nIHRoZSBzZXRcIik7XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgb3ZlcmZsb3dpbmdEb2NJZCA9IHNlbGYuX3B1Ymxpc2hlZC5tYXhFbGVtZW50SWQoKTtcbiAgICAgICAgdmFyIG92ZXJmbG93aW5nRG9jID0gc2VsZi5fcHVibGlzaGVkLmdldChvdmVyZmxvd2luZ0RvY0lkKTtcblxuICAgICAgICBpZiAoRUpTT04uZXF1YWxzKG92ZXJmbG93aW5nRG9jSWQsIGlkKSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSBkb2N1bWVudCBqdXN0IGFkZGVkIGlzIG92ZXJmbG93aW5nIHRoZSBwdWJsaXNoZWQgc2V0XCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgc2VsZi5fcHVibGlzaGVkLnJlbW92ZShvdmVyZmxvd2luZ0RvY0lkKTtcbiAgICAgICAgc2VsZi5fbXVsdGlwbGV4ZXIucmVtb3ZlZChvdmVyZmxvd2luZ0RvY0lkKTtcbiAgICAgICAgc2VsZi5fYWRkQnVmZmVyZWQob3ZlcmZsb3dpbmdEb2NJZCwgb3ZlcmZsb3dpbmdEb2MpO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICBfcmVtb3ZlUHVibGlzaGVkOiBmdW5jdGlvbiAoaWQpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5fcHVibGlzaGVkLnJlbW92ZShpZCk7XG4gICAgICBzZWxmLl9tdWx0aXBsZXhlci5yZW1vdmVkKGlkKTtcbiAgICAgIGlmICghIHNlbGYuX2xpbWl0IHx8IHNlbGYuX3B1Ymxpc2hlZC5zaXplKCkgPT09IHNlbGYuX2xpbWl0KVxuICAgICAgICByZXR1cm47XG5cbiAgICAgIGlmIChzZWxmLl9wdWJsaXNoZWQuc2l6ZSgpID4gc2VsZi5fbGltaXQpXG4gICAgICAgIHRocm93IEVycm9yKFwic2VsZi5fcHVibGlzaGVkIGdvdCB0b28gYmlnXCIpO1xuXG4gICAgICAvLyBPSywgd2UgYXJlIHB1Ymxpc2hpbmcgbGVzcyB0aGFuIHRoZSBsaW1pdC4gTWF5YmUgd2Ugc2hvdWxkIGxvb2sgaW4gdGhlXG4gICAgICAvLyBidWZmZXIgdG8gZmluZCB0aGUgbmV4dCBlbGVtZW50IHBhc3Qgd2hhdCB3ZSB3ZXJlIHB1Ymxpc2hpbmcgYmVmb3JlLlxuXG4gICAgICBpZiAoIXNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmVtcHR5KCkpIHtcbiAgICAgICAgLy8gVGhlcmUncyBzb21ldGhpbmcgaW4gdGhlIGJ1ZmZlcjsgbW92ZSB0aGUgZmlyc3QgdGhpbmcgaW4gaXQgdG9cbiAgICAgICAgLy8gX3B1Ymxpc2hlZC5cbiAgICAgICAgdmFyIG5ld0RvY0lkID0gc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIubWluRWxlbWVudElkKCk7XG4gICAgICAgIHZhciBuZXdEb2MgPSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5nZXQobmV3RG9jSWQpO1xuICAgICAgICBzZWxmLl9yZW1vdmVCdWZmZXJlZChuZXdEb2NJZCk7XG4gICAgICAgIHNlbGYuX2FkZFB1Ymxpc2hlZChuZXdEb2NJZCwgbmV3RG9jKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBUaGVyZSdzIG5vdGhpbmcgaW4gdGhlIGJ1ZmZlci4gIFRoaXMgY291bGQgbWVhbiBvbmUgb2YgYSBmZXcgdGhpbmdzLlxuXG4gICAgICAvLyAoYSkgV2UgY291bGQgYmUgaW4gdGhlIG1pZGRsZSBvZiByZS1ydW5uaW5nIHRoZSBxdWVyeSAoc3BlY2lmaWNhbGx5LCB3ZVxuICAgICAgLy8gY291bGQgYmUgaW4gX3B1Ymxpc2hOZXdSZXN1bHRzKS4gSW4gdGhhdCBjYXNlLCBfdW5wdWJsaXNoZWRCdWZmZXIgaXNcbiAgICAgIC8vIGVtcHR5IGJlY2F1c2Ugd2UgY2xlYXIgaXQgYXQgdGhlIGJlZ2lubmluZyBvZiBfcHVibGlzaE5ld1Jlc3VsdHMuIEluXG4gICAgICAvLyB0aGlzIGNhc2UsIG91ciBjYWxsZXIgYWxyZWFkeSBrbm93cyB0aGUgZW50aXJlIGFuc3dlciB0byB0aGUgcXVlcnkgYW5kXG4gICAgICAvLyB3ZSBkb24ndCBuZWVkIHRvIGRvIGFueXRoaW5nIGZhbmN5IGhlcmUuICBKdXN0IHJldHVybi5cbiAgICAgIGlmIChzZWxmLl9waGFzZSA9PT0gUEhBU0UuUVVFUllJTkcpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgLy8gKGIpIFdlJ3JlIHByZXR0eSBjb25maWRlbnQgdGhhdCB0aGUgdW5pb24gb2YgX3B1Ymxpc2hlZCBhbmRcbiAgICAgIC8vIF91bnB1Ymxpc2hlZEJ1ZmZlciBjb250YWluIGFsbCBkb2N1bWVudHMgdGhhdCBtYXRjaCBzZWxlY3Rvci4gQmVjYXVzZVxuICAgICAgLy8gX3VucHVibGlzaGVkQnVmZmVyIGlzIGVtcHR5LCB0aGF0IG1lYW5zIHdlJ3JlIGNvbmZpZGVudCB0aGF0IF9wdWJsaXNoZWRcbiAgICAgIC8vIGNvbnRhaW5zIGFsbCBkb2N1bWVudHMgdGhhdCBtYXRjaCBzZWxlY3Rvci4gU28gd2UgaGF2ZSBub3RoaW5nIHRvIGRvLlxuICAgICAgaWYgKHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlcilcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgICAvLyAoYykgTWF5YmUgdGhlcmUgYXJlIG90aGVyIGRvY3VtZW50cyBvdXQgdGhlcmUgdGhhdCBzaG91bGQgYmUgaW4gb3VyXG4gICAgICAvLyBidWZmZXIuIEJ1dCBpbiB0aGF0IGNhc2UsIHdoZW4gd2UgZW1wdGllZCBfdW5wdWJsaXNoZWRCdWZmZXIgaW5cbiAgICAgIC8vIF9yZW1vdmVCdWZmZXJlZCwgd2Ugc2hvdWxkIGhhdmUgY2FsbGVkIF9uZWVkVG9Qb2xsUXVlcnksIHdoaWNoIHdpbGxcbiAgICAgIC8vIGVpdGhlciBwdXQgc29tZXRoaW5nIGluIF91bnB1Ymxpc2hlZEJ1ZmZlciBvciBzZXQgX3NhZmVBcHBlbmRUb0J1ZmZlclxuICAgICAgLy8gKG9yIGJvdGgpLCBhbmQgaXQgd2lsbCBwdXQgdXMgaW4gUVVFUllJTkcgZm9yIHRoYXQgd2hvbGUgdGltZS4gU28gaW5cbiAgICAgIC8vIGZhY3QsIHdlIHNob3VsZG4ndCBiZSBhYmxlIHRvIGdldCBoZXJlLlxuXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJCdWZmZXIgaW5leHBsaWNhYmx5IGVtcHR5XCIpO1xuICAgIH0pO1xuICB9LFxuICBfY2hhbmdlUHVibGlzaGVkOiBmdW5jdGlvbiAoaWQsIG9sZERvYywgbmV3RG9jKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYuX3B1Ymxpc2hlZC5zZXQoaWQsIHNlbGYuX3NoYXJlZFByb2plY3Rpb25GbihuZXdEb2MpKTtcbiAgICAgIHZhciBwcm9qZWN0ZWROZXcgPSBzZWxmLl9wcm9qZWN0aW9uRm4obmV3RG9jKTtcbiAgICAgIHZhciBwcm9qZWN0ZWRPbGQgPSBzZWxmLl9wcm9qZWN0aW9uRm4ob2xkRG9jKTtcbiAgICAgIHZhciBjaGFuZ2VkID0gRGlmZlNlcXVlbmNlLm1ha2VDaGFuZ2VkRmllbGRzKFxuICAgICAgICBwcm9qZWN0ZWROZXcsIHByb2plY3RlZE9sZCk7XG4gICAgICBpZiAoIV8uaXNFbXB0eShjaGFuZ2VkKSlcbiAgICAgICAgc2VsZi5fbXVsdGlwbGV4ZXIuY2hhbmdlZChpZCwgY2hhbmdlZCk7XG4gICAgfSk7XG4gIH0sXG4gIF9hZGRCdWZmZXJlZDogZnVuY3Rpb24gKGlkLCBkb2MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuc2V0KGlkLCBzZWxmLl9zaGFyZWRQcm9qZWN0aW9uRm4oZG9jKSk7XG5cbiAgICAgIC8vIElmIHNvbWV0aGluZyBpcyBvdmVyZmxvd2luZyB0aGUgYnVmZmVyLCB3ZSBqdXN0IHJlbW92ZSBpdCBmcm9tIGNhY2hlXG4gICAgICBpZiAoc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuc2l6ZSgpID4gc2VsZi5fbGltaXQpIHtcbiAgICAgICAgdmFyIG1heEJ1ZmZlcmVkSWQgPSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5tYXhFbGVtZW50SWQoKTtcblxuICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5yZW1vdmUobWF4QnVmZmVyZWRJZCk7XG5cbiAgICAgICAgLy8gU2luY2Ugc29tZXRoaW5nIG1hdGNoaW5nIGlzIHJlbW92ZWQgZnJvbSBjYWNoZSAoYm90aCBwdWJsaXNoZWQgc2V0IGFuZFxuICAgICAgICAvLyBidWZmZXIpLCBzZXQgZmxhZyB0byBmYWxzZVxuICAgICAgICBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcbiAgLy8gSXMgY2FsbGVkIGVpdGhlciB0byByZW1vdmUgdGhlIGRvYyBjb21wbGV0ZWx5IGZyb20gbWF0Y2hpbmcgc2V0IG9yIHRvIG1vdmVcbiAgLy8gaXQgdG8gdGhlIHB1Ymxpc2hlZCBzZXQgbGF0ZXIuXG4gIF9yZW1vdmVCdWZmZXJlZDogZnVuY3Rpb24gKGlkKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnJlbW92ZShpZCk7XG4gICAgICAvLyBUbyBrZWVwIHRoZSBjb250cmFjdCBcImJ1ZmZlciBpcyBuZXZlciBlbXB0eSBpbiBTVEVBRFkgcGhhc2UgdW5sZXNzIHRoZVxuICAgICAgLy8gZXZlcnl0aGluZyBtYXRjaGluZyBmaXRzIGludG8gcHVibGlzaGVkXCIgdHJ1ZSwgd2UgcG9sbCBldmVyeXRoaW5nIGFzXG4gICAgICAvLyBzb29uIGFzIHdlIHNlZSB0aGUgYnVmZmVyIGJlY29taW5nIGVtcHR5LlxuICAgICAgaWYgKCEgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuc2l6ZSgpICYmICEgc2VsZi5fc2FmZUFwcGVuZFRvQnVmZmVyKVxuICAgICAgICBzZWxmLl9uZWVkVG9Qb2xsUXVlcnkoKTtcbiAgICB9KTtcbiAgfSxcbiAgLy8gQ2FsbGVkIHdoZW4gYSBkb2N1bWVudCBoYXMgam9pbmVkIHRoZSBcIk1hdGNoaW5nXCIgcmVzdWx0cyBzZXQuXG4gIC8vIFRha2VzIHJlc3BvbnNpYmlsaXR5IG9mIGtlZXBpbmcgX3VucHVibGlzaGVkQnVmZmVyIGluIHN5bmMgd2l0aCBfcHVibGlzaGVkXG4gIC8vIGFuZCB0aGUgZWZmZWN0IG9mIGxpbWl0IGVuZm9yY2VkLlxuICBfYWRkTWF0Y2hpbmc6IGZ1bmN0aW9uIChkb2MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGlkID0gZG9jLl9pZDtcbiAgICAgIGlmIChzZWxmLl9wdWJsaXNoZWQuaGFzKGlkKSlcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJ0cmllZCB0byBhZGQgc29tZXRoaW5nIGFscmVhZHkgcHVibGlzaGVkIFwiICsgaWQpO1xuICAgICAgaWYgKHNlbGYuX2xpbWl0ICYmIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmhhcyhpZCkpXG4gICAgICAgIHRocm93IEVycm9yKFwidHJpZWQgdG8gYWRkIHNvbWV0aGluZyBhbHJlYWR5IGV4aXN0ZWQgaW4gYnVmZmVyIFwiICsgaWQpO1xuXG4gICAgICB2YXIgbGltaXQgPSBzZWxmLl9saW1pdDtcbiAgICAgIHZhciBjb21wYXJhdG9yID0gc2VsZi5fY29tcGFyYXRvcjtcbiAgICAgIHZhciBtYXhQdWJsaXNoZWQgPSAobGltaXQgJiYgc2VsZi5fcHVibGlzaGVkLnNpemUoKSA+IDApID9cbiAgICAgICAgc2VsZi5fcHVibGlzaGVkLmdldChzZWxmLl9wdWJsaXNoZWQubWF4RWxlbWVudElkKCkpIDogbnVsbDtcbiAgICAgIHZhciBtYXhCdWZmZXJlZCA9IChsaW1pdCAmJiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgPiAwKVxuICAgICAgICA/IHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmdldChzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5tYXhFbGVtZW50SWQoKSlcbiAgICAgICAgOiBudWxsO1xuICAgICAgLy8gVGhlIHF1ZXJ5IGlzIHVubGltaXRlZCBvciBkaWRuJ3QgcHVibGlzaCBlbm91Z2ggZG9jdW1lbnRzIHlldCBvciB0aGVcbiAgICAgIC8vIG5ldyBkb2N1bWVudCB3b3VsZCBmaXQgaW50byBwdWJsaXNoZWQgc2V0IHB1c2hpbmcgdGhlIG1heGltdW0gZWxlbWVudFxuICAgICAgLy8gb3V0LCB0aGVuIHdlIG5lZWQgdG8gcHVibGlzaCB0aGUgZG9jLlxuICAgICAgdmFyIHRvUHVibGlzaCA9ICEgbGltaXQgfHwgc2VsZi5fcHVibGlzaGVkLnNpemUoKSA8IGxpbWl0IHx8XG4gICAgICAgIGNvbXBhcmF0b3IoZG9jLCBtYXhQdWJsaXNoZWQpIDwgMDtcblxuICAgICAgLy8gT3RoZXJ3aXNlIHdlIG1pZ2h0IG5lZWQgdG8gYnVmZmVyIGl0IChvbmx5IGluIGNhc2Ugb2YgbGltaXRlZCBxdWVyeSkuXG4gICAgICAvLyBCdWZmZXJpbmcgaXMgYWxsb3dlZCBpZiB0aGUgYnVmZmVyIGlzIG5vdCBmaWxsZWQgdXAgeWV0IGFuZCBhbGxcbiAgICAgIC8vIG1hdGNoaW5nIGRvY3MgYXJlIGVpdGhlciBpbiB0aGUgcHVibGlzaGVkIHNldCBvciBpbiB0aGUgYnVmZmVyLlxuICAgICAgdmFyIGNhbkFwcGVuZFRvQnVmZmVyID0gIXRvUHVibGlzaCAmJiBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgJiZcbiAgICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuc2l6ZSgpIDwgbGltaXQ7XG5cbiAgICAgIC8vIE9yIGlmIGl0IGlzIHNtYWxsIGVub3VnaCB0byBiZSBzYWZlbHkgaW5zZXJ0ZWQgdG8gdGhlIG1pZGRsZSBvciB0aGVcbiAgICAgIC8vIGJlZ2lubmluZyBvZiB0aGUgYnVmZmVyLlxuICAgICAgdmFyIGNhbkluc2VydEludG9CdWZmZXIgPSAhdG9QdWJsaXNoICYmIG1heEJ1ZmZlcmVkICYmXG4gICAgICAgIGNvbXBhcmF0b3IoZG9jLCBtYXhCdWZmZXJlZCkgPD0gMDtcblxuICAgICAgdmFyIHRvQnVmZmVyID0gY2FuQXBwZW5kVG9CdWZmZXIgfHwgY2FuSW5zZXJ0SW50b0J1ZmZlcjtcblxuICAgICAgaWYgKHRvUHVibGlzaCkge1xuICAgICAgICBzZWxmLl9hZGRQdWJsaXNoZWQoaWQsIGRvYyk7XG4gICAgICB9IGVsc2UgaWYgKHRvQnVmZmVyKSB7XG4gICAgICAgIHNlbGYuX2FkZEJ1ZmZlcmVkKGlkLCBkb2MpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gZHJvcHBpbmcgaXQgYW5kIG5vdCBzYXZpbmcgdG8gdGhlIGNhY2hlXG4gICAgICAgIHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlciA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICAvLyBDYWxsZWQgd2hlbiBhIGRvY3VtZW50IGxlYXZlcyB0aGUgXCJNYXRjaGluZ1wiIHJlc3VsdHMgc2V0LlxuICAvLyBUYWtlcyByZXNwb25zaWJpbGl0eSBvZiBrZWVwaW5nIF91bnB1Ymxpc2hlZEJ1ZmZlciBpbiBzeW5jIHdpdGggX3B1Ymxpc2hlZFxuICAvLyBhbmQgdGhlIGVmZmVjdCBvZiBsaW1pdCBlbmZvcmNlZC5cbiAgX3JlbW92ZU1hdGNoaW5nOiBmdW5jdGlvbiAoaWQpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKCEgc2VsZi5fcHVibGlzaGVkLmhhcyhpZCkgJiYgISBzZWxmLl9saW1pdClcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJ0cmllZCB0byByZW1vdmUgc29tZXRoaW5nIG1hdGNoaW5nIGJ1dCBub3QgY2FjaGVkIFwiICsgaWQpO1xuXG4gICAgICBpZiAoc2VsZi5fcHVibGlzaGVkLmhhcyhpZCkpIHtcbiAgICAgICAgc2VsZi5fcmVtb3ZlUHVibGlzaGVkKGlkKTtcbiAgICAgIH0gZWxzZSBpZiAoc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuaGFzKGlkKSkge1xuICAgICAgICBzZWxmLl9yZW1vdmVCdWZmZXJlZChpZCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG4gIF9oYW5kbGVEb2M6IGZ1bmN0aW9uIChpZCwgbmV3RG9jKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIHZhciBtYXRjaGVzTm93ID0gbmV3RG9jICYmIHNlbGYuX21hdGNoZXIuZG9jdW1lbnRNYXRjaGVzKG5ld0RvYykucmVzdWx0O1xuXG4gICAgICB2YXIgcHVibGlzaGVkQmVmb3JlID0gc2VsZi5fcHVibGlzaGVkLmhhcyhpZCk7XG4gICAgICB2YXIgYnVmZmVyZWRCZWZvcmUgPSBzZWxmLl9saW1pdCAmJiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5oYXMoaWQpO1xuICAgICAgdmFyIGNhY2hlZEJlZm9yZSA9IHB1Ymxpc2hlZEJlZm9yZSB8fCBidWZmZXJlZEJlZm9yZTtcblxuICAgICAgaWYgKG1hdGNoZXNOb3cgJiYgIWNhY2hlZEJlZm9yZSkge1xuICAgICAgICBzZWxmLl9hZGRNYXRjaGluZyhuZXdEb2MpO1xuICAgICAgfSBlbHNlIGlmIChjYWNoZWRCZWZvcmUgJiYgIW1hdGNoZXNOb3cpIHtcbiAgICAgICAgc2VsZi5fcmVtb3ZlTWF0Y2hpbmcoaWQpO1xuICAgICAgfSBlbHNlIGlmIChjYWNoZWRCZWZvcmUgJiYgbWF0Y2hlc05vdykge1xuICAgICAgICB2YXIgb2xkRG9jID0gc2VsZi5fcHVibGlzaGVkLmdldChpZCk7XG4gICAgICAgIHZhciBjb21wYXJhdG9yID0gc2VsZi5fY29tcGFyYXRvcjtcbiAgICAgICAgdmFyIG1pbkJ1ZmZlcmVkID0gc2VsZi5fbGltaXQgJiYgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuc2l6ZSgpICYmXG4gICAgICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuZ2V0KHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLm1pbkVsZW1lbnRJZCgpKTtcbiAgICAgICAgdmFyIG1heEJ1ZmZlcmVkO1xuXG4gICAgICAgIGlmIChwdWJsaXNoZWRCZWZvcmUpIHtcbiAgICAgICAgICAvLyBVbmxpbWl0ZWQgY2FzZSB3aGVyZSB0aGUgZG9jdW1lbnQgc3RheXMgaW4gcHVibGlzaGVkIG9uY2UgaXRcbiAgICAgICAgICAvLyBtYXRjaGVzIG9yIHRoZSBjYXNlIHdoZW4gd2UgZG9uJ3QgaGF2ZSBlbm91Z2ggbWF0Y2hpbmcgZG9jcyB0b1xuICAgICAgICAgIC8vIHB1Ymxpc2ggb3IgdGhlIGNoYW5nZWQgYnV0IG1hdGNoaW5nIGRvYyB3aWxsIHN0YXkgaW4gcHVibGlzaGVkXG4gICAgICAgICAgLy8gYW55d2F5cy5cbiAgICAgICAgICAvL1xuICAgICAgICAgIC8vIFhYWDogV2UgcmVseSBvbiB0aGUgZW1wdGluZXNzIG9mIGJ1ZmZlci4gQmUgc3VyZSB0byBtYWludGFpbiB0aGVcbiAgICAgICAgICAvLyBmYWN0IHRoYXQgYnVmZmVyIGNhbid0IGJlIGVtcHR5IGlmIHRoZXJlIGFyZSBtYXRjaGluZyBkb2N1bWVudHMgbm90XG4gICAgICAgICAgLy8gcHVibGlzaGVkLiBOb3RhYmx5LCB3ZSBkb24ndCB3YW50IHRvIHNjaGVkdWxlIHJlcG9sbCBhbmQgY29udGludWVcbiAgICAgICAgICAvLyByZWx5aW5nIG9uIHRoaXMgcHJvcGVydHkuXG4gICAgICAgICAgdmFyIHN0YXlzSW5QdWJsaXNoZWQgPSAhIHNlbGYuX2xpbWl0IHx8XG4gICAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgPT09IDAgfHxcbiAgICAgICAgICAgIGNvbXBhcmF0b3IobmV3RG9jLCBtaW5CdWZmZXJlZCkgPD0gMDtcblxuICAgICAgICAgIGlmIChzdGF5c0luUHVibGlzaGVkKSB7XG4gICAgICAgICAgICBzZWxmLl9jaGFuZ2VQdWJsaXNoZWQoaWQsIG9sZERvYywgbmV3RG9jKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gYWZ0ZXIgdGhlIGNoYW5nZSBkb2MgZG9lc24ndCBzdGF5IGluIHRoZSBwdWJsaXNoZWQsIHJlbW92ZSBpdFxuICAgICAgICAgICAgc2VsZi5fcmVtb3ZlUHVibGlzaGVkKGlkKTtcbiAgICAgICAgICAgIC8vIGJ1dCBpdCBjYW4gbW92ZSBpbnRvIGJ1ZmZlcmVkIG5vdywgY2hlY2sgaXRcbiAgICAgICAgICAgIG1heEJ1ZmZlcmVkID0gc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuZ2V0KFxuICAgICAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5tYXhFbGVtZW50SWQoKSk7XG5cbiAgICAgICAgICAgIHZhciB0b0J1ZmZlciA9IHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlciB8fFxuICAgICAgICAgICAgICAgICAgKG1heEJ1ZmZlcmVkICYmIGNvbXBhcmF0b3IobmV3RG9jLCBtYXhCdWZmZXJlZCkgPD0gMCk7XG5cbiAgICAgICAgICAgIGlmICh0b0J1ZmZlcikge1xuICAgICAgICAgICAgICBzZWxmLl9hZGRCdWZmZXJlZChpZCwgbmV3RG9jKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIFRocm93IGF3YXkgZnJvbSBib3RoIHB1Ymxpc2hlZCBzZXQgYW5kIGJ1ZmZlclxuICAgICAgICAgICAgICBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoYnVmZmVyZWRCZWZvcmUpIHtcbiAgICAgICAgICBvbGREb2MgPSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5nZXQoaWQpO1xuICAgICAgICAgIC8vIHJlbW92ZSB0aGUgb2xkIHZlcnNpb24gbWFudWFsbHkgaW5zdGVhZCBvZiB1c2luZyBfcmVtb3ZlQnVmZmVyZWQgc29cbiAgICAgICAgICAvLyB3ZSBkb24ndCB0cmlnZ2VyIHRoZSBxdWVyeWluZyBpbW1lZGlhdGVseS4gIGlmIHdlIGVuZCB0aGlzIGJsb2NrXG4gICAgICAgICAgLy8gd2l0aCB0aGUgYnVmZmVyIGVtcHR5LCB3ZSB3aWxsIG5lZWQgdG8gdHJpZ2dlciB0aGUgcXVlcnkgcG9sbFxuICAgICAgICAgIC8vIG1hbnVhbGx5IHRvby5cbiAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5yZW1vdmUoaWQpO1xuXG4gICAgICAgICAgdmFyIG1heFB1Ymxpc2hlZCA9IHNlbGYuX3B1Ymxpc2hlZC5nZXQoXG4gICAgICAgICAgICBzZWxmLl9wdWJsaXNoZWQubWF4RWxlbWVudElkKCkpO1xuICAgICAgICAgIG1heEJ1ZmZlcmVkID0gc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuc2l6ZSgpICYmXG4gICAgICAgICAgICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuZ2V0KFxuICAgICAgICAgICAgICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIubWF4RWxlbWVudElkKCkpO1xuXG4gICAgICAgICAgLy8gdGhlIGJ1ZmZlcmVkIGRvYyB3YXMgdXBkYXRlZCwgaXQgY291bGQgbW92ZSB0byBwdWJsaXNoZWRcbiAgICAgICAgICB2YXIgdG9QdWJsaXNoID0gY29tcGFyYXRvcihuZXdEb2MsIG1heFB1Ymxpc2hlZCkgPCAwO1xuXG4gICAgICAgICAgLy8gb3Igc3RheXMgaW4gYnVmZmVyIGV2ZW4gYWZ0ZXIgdGhlIGNoYW5nZVxuICAgICAgICAgIHZhciBzdGF5c0luQnVmZmVyID0gKCEgdG9QdWJsaXNoICYmIHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlcikgfHxcbiAgICAgICAgICAgICAgICAoIXRvUHVibGlzaCAmJiBtYXhCdWZmZXJlZCAmJlxuICAgICAgICAgICAgICAgICBjb21wYXJhdG9yKG5ld0RvYywgbWF4QnVmZmVyZWQpIDw9IDApO1xuXG4gICAgICAgICAgaWYgKHRvUHVibGlzaCkge1xuICAgICAgICAgICAgc2VsZi5fYWRkUHVibGlzaGVkKGlkLCBuZXdEb2MpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoc3RheXNJbkJ1ZmZlcikge1xuICAgICAgICAgICAgLy8gc3RheXMgaW4gYnVmZmVyIGJ1dCBjaGFuZ2VzXG4gICAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zZXQoaWQsIG5ld0RvYyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFRocm93IGF3YXkgZnJvbSBib3RoIHB1Ymxpc2hlZCBzZXQgYW5kIGJ1ZmZlclxuICAgICAgICAgICAgc2VsZi5fc2FmZUFwcGVuZFRvQnVmZmVyID0gZmFsc2U7XG4gICAgICAgICAgICAvLyBOb3JtYWxseSB0aGlzIGNoZWNrIHdvdWxkIGhhdmUgYmVlbiBkb25lIGluIF9yZW1vdmVCdWZmZXJlZCBidXRcbiAgICAgICAgICAgIC8vIHdlIGRpZG4ndCB1c2UgaXQsIHNvIHdlIG5lZWQgdG8gZG8gaXQgb3Vyc2VsZiBub3cuXG4gICAgICAgICAgICBpZiAoISBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkpIHtcbiAgICAgICAgICAgICAgc2VsZi5fbmVlZFRvUG9sbFF1ZXJ5KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImNhY2hlZEJlZm9yZSBpbXBsaWVzIGVpdGhlciBvZiBwdWJsaXNoZWRCZWZvcmUgb3IgYnVmZmVyZWRCZWZvcmUgaXMgdHJ1ZS5cIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcbiAgX2ZldGNoTW9kaWZpZWREb2N1bWVudHM6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5fcmVnaXN0ZXJQaGFzZUNoYW5nZShQSEFTRS5GRVRDSElORyk7XG4gICAgICAvLyBEZWZlciwgYmVjYXVzZSBub3RoaW5nIGNhbGxlZCBmcm9tIHRoZSBvcGxvZyBlbnRyeSBoYW5kbGVyIG1heSB5aWVsZCxcbiAgICAgIC8vIGJ1dCBmZXRjaCgpIHlpZWxkcy5cbiAgICAgIE1ldGVvci5kZWZlcihmaW5pc2hJZk5lZWRUb1BvbGxRdWVyeShmdW5jdGlvbiAoKSB7XG4gICAgICAgIHdoaWxlICghc2VsZi5fc3RvcHBlZCAmJiAhc2VsZi5fbmVlZFRvRmV0Y2guZW1wdHkoKSkge1xuICAgICAgICAgIGlmIChzZWxmLl9waGFzZSA9PT0gUEhBU0UuUVVFUllJTkcpIHtcbiAgICAgICAgICAgIC8vIFdoaWxlIGZldGNoaW5nLCB3ZSBkZWNpZGVkIHRvIGdvIGludG8gUVVFUllJTkcgbW9kZSwgYW5kIHRoZW4gd2VcbiAgICAgICAgICAgIC8vIHNhdyBhbm90aGVyIG9wbG9nIGVudHJ5LCBzbyBfbmVlZFRvRmV0Y2ggaXMgbm90IGVtcHR5LiBCdXQgd2VcbiAgICAgICAgICAgIC8vIHNob3VsZG4ndCBmZXRjaCB0aGVzZSBkb2N1bWVudHMgdW50aWwgQUZURVIgdGhlIHF1ZXJ5IGlzIGRvbmUuXG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBCZWluZyBpbiBzdGVhZHkgcGhhc2UgaGVyZSB3b3VsZCBiZSBzdXJwcmlzaW5nLlxuICAgICAgICAgIGlmIChzZWxmLl9waGFzZSAhPT0gUEhBU0UuRkVUQ0hJTkcpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJwaGFzZSBpbiBmZXRjaE1vZGlmaWVkRG9jdW1lbnRzOiBcIiArIHNlbGYuX3BoYXNlKTtcblxuICAgICAgICAgIHNlbGYuX2N1cnJlbnRseUZldGNoaW5nID0gc2VsZi5fbmVlZFRvRmV0Y2g7XG4gICAgICAgICAgdmFyIHRoaXNHZW5lcmF0aW9uID0gKytzZWxmLl9mZXRjaEdlbmVyYXRpb247XG4gICAgICAgICAgc2VsZi5fbmVlZFRvRmV0Y2ggPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgICAgICAgICB2YXIgd2FpdGluZyA9IDA7XG4gICAgICAgICAgdmFyIGZ1dCA9IG5ldyBGdXR1cmU7XG4gICAgICAgICAgLy8gVGhpcyBsb29wIGlzIHNhZmUsIGJlY2F1c2UgX2N1cnJlbnRseUZldGNoaW5nIHdpbGwgbm90IGJlIHVwZGF0ZWRcbiAgICAgICAgICAvLyBkdXJpbmcgdGhpcyBsb29wIChpbiBmYWN0LCBpdCBpcyBuZXZlciBtdXRhdGVkKS5cbiAgICAgICAgICBzZWxmLl9jdXJyZW50bHlGZXRjaGluZy5mb3JFYWNoKGZ1bmN0aW9uIChvcCwgaWQpIHtcbiAgICAgICAgICAgIHdhaXRpbmcrKztcbiAgICAgICAgICAgIHNlbGYuX21vbmdvSGFuZGxlLl9kb2NGZXRjaGVyLmZldGNoKFxuICAgICAgICAgICAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZSwgaWQsIG9wLFxuICAgICAgICAgICAgICBmaW5pc2hJZk5lZWRUb1BvbGxRdWVyeShmdW5jdGlvbiAoZXJyLCBkb2MpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgICAgICBNZXRlb3IuX2RlYnVnKFwiR290IGV4Y2VwdGlvbiB3aGlsZSBmZXRjaGluZyBkb2N1bWVudHNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnIpO1xuICAgICAgICAgICAgICAgICAgICAvLyBJZiB3ZSBnZXQgYW4gZXJyb3IgZnJvbSB0aGUgZmV0Y2hlciAoZWcsIHRyb3VibGVcbiAgICAgICAgICAgICAgICAgICAgLy8gY29ubmVjdGluZyB0byBNb25nbyksIGxldCdzIGp1c3QgYWJhbmRvbiB0aGUgZmV0Y2ggcGhhc2VcbiAgICAgICAgICAgICAgICAgICAgLy8gYWx0b2dldGhlciBhbmQgZmFsbCBiYWNrIHRvIHBvbGxpbmcuIEl0J3Mgbm90IGxpa2Ugd2UncmVcbiAgICAgICAgICAgICAgICAgICAgLy8gZ2V0dGluZyBsaXZlIHVwZGF0ZXMgYW55d2F5LlxuICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZi5fcGhhc2UgIT09IFBIQVNFLlFVRVJZSU5HKSB7XG4gICAgICAgICAgICAgICAgICAgICAgc2VsZi5fbmVlZFRvUG9sbFF1ZXJ5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIXNlbGYuX3N0b3BwZWQgJiYgc2VsZi5fcGhhc2UgPT09IFBIQVNFLkZFVENISU5HXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICYmIHNlbGYuX2ZldGNoR2VuZXJhdGlvbiA9PT0gdGhpc0dlbmVyYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gV2UgcmUtY2hlY2sgdGhlIGdlbmVyYXRpb24gaW4gY2FzZSB3ZSd2ZSBoYWQgYW4gZXhwbGljaXRcbiAgICAgICAgICAgICAgICAgICAgLy8gX3BvbGxRdWVyeSBjYWxsIChlZywgaW4gYW5vdGhlciBmaWJlcikgd2hpY2ggc2hvdWxkXG4gICAgICAgICAgICAgICAgICAgIC8vIGVmZmVjdGl2ZWx5IGNhbmNlbCB0aGlzIHJvdW5kIG9mIGZldGNoZXMuICAoX3BvbGxRdWVyeVxuICAgICAgICAgICAgICAgICAgICAvLyBpbmNyZW1lbnRzIHRoZSBnZW5lcmF0aW9uLilcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5faGFuZGxlRG9jKGlkLCBkb2MpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICB3YWl0aW5nLS07XG4gICAgICAgICAgICAgICAgICAvLyBCZWNhdXNlIGZldGNoKCkgbmV2ZXIgY2FsbHMgaXRzIGNhbGxiYWNrIHN5bmNocm9ub3VzbHksXG4gICAgICAgICAgICAgICAgICAvLyB0aGlzIGlzIHNhZmUgKGllLCB3ZSB3b24ndCBjYWxsIGZ1dC5yZXR1cm4oKSBiZWZvcmUgdGhlXG4gICAgICAgICAgICAgICAgICAvLyBmb3JFYWNoIGlzIGRvbmUpLlxuICAgICAgICAgICAgICAgICAgaWYgKHdhaXRpbmcgPT09IDApXG4gICAgICAgICAgICAgICAgICAgIGZ1dC5yZXR1cm4oKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBmdXQud2FpdCgpO1xuICAgICAgICAgIC8vIEV4aXQgbm93IGlmIHdlJ3ZlIGhhZCBhIF9wb2xsUXVlcnkgY2FsbCAoaGVyZSBvciBpbiBhbm90aGVyIGZpYmVyKS5cbiAgICAgICAgICBpZiAoc2VsZi5fcGhhc2UgPT09IFBIQVNFLlFVRVJZSU5HKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIHNlbGYuX2N1cnJlbnRseUZldGNoaW5nID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICAvLyBXZSdyZSBkb25lIGZldGNoaW5nLCBzbyB3ZSBjYW4gYmUgc3RlYWR5LCB1bmxlc3Mgd2UndmUgaGFkIGFcbiAgICAgICAgLy8gX3BvbGxRdWVyeSBjYWxsIChoZXJlIG9yIGluIGFub3RoZXIgZmliZXIpLlxuICAgICAgICBpZiAoc2VsZi5fcGhhc2UgIT09IFBIQVNFLlFVRVJZSU5HKVxuICAgICAgICAgIHNlbGYuX2JlU3RlYWR5KCk7XG4gICAgICB9KSk7XG4gICAgfSk7XG4gIH0sXG4gIF9iZVN0ZWFkeTogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9yZWdpc3RlclBoYXNlQ2hhbmdlKFBIQVNFLlNURUFEWSk7XG4gICAgICB2YXIgd3JpdGVzID0gc2VsZi5fd3JpdGVzVG9Db21taXRXaGVuV2VSZWFjaFN0ZWFkeTtcbiAgICAgIHNlbGYuX3dyaXRlc1RvQ29tbWl0V2hlbldlUmVhY2hTdGVhZHkgPSBbXTtcbiAgICAgIHNlbGYuX211bHRpcGxleGVyLm9uRmx1c2goZnVuY3Rpb24gKCkge1xuICAgICAgICBfLmVhY2god3JpdGVzLCBmdW5jdGlvbiAodykge1xuICAgICAgICAgIHcuY29tbWl0dGVkKCk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sXG4gIF9oYW5kbGVPcGxvZ0VudHJ5UXVlcnlpbmc6IGZ1bmN0aW9uIChvcCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9uZWVkVG9GZXRjaC5zZXQoaWRGb3JPcChvcCksIG9wKTtcbiAgICB9KTtcbiAgfSxcbiAgX2hhbmRsZU9wbG9nRW50cnlTdGVhZHlPckZldGNoaW5nOiBmdW5jdGlvbiAob3ApIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGlkID0gaWRGb3JPcChvcCk7XG4gICAgICAvLyBJZiB3ZSdyZSBhbHJlYWR5IGZldGNoaW5nIHRoaXMgb25lLCBvciBhYm91dCB0bywgd2UgY2FuJ3Qgb3B0aW1pemU7XG4gICAgICAvLyBtYWtlIHN1cmUgdGhhdCB3ZSBmZXRjaCBpdCBhZ2FpbiBpZiBuZWNlc3NhcnkuXG4gICAgICBpZiAoc2VsZi5fcGhhc2UgPT09IFBIQVNFLkZFVENISU5HICYmXG4gICAgICAgICAgKChzZWxmLl9jdXJyZW50bHlGZXRjaGluZyAmJiBzZWxmLl9jdXJyZW50bHlGZXRjaGluZy5oYXMoaWQpKSB8fFxuICAgICAgICAgICBzZWxmLl9uZWVkVG9GZXRjaC5oYXMoaWQpKSkge1xuICAgICAgICBzZWxmLl9uZWVkVG9GZXRjaC5zZXQoaWQsIG9wKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZiAob3Aub3AgPT09ICdkJykge1xuICAgICAgICBpZiAoc2VsZi5fcHVibGlzaGVkLmhhcyhpZCkgfHxcbiAgICAgICAgICAgIChzZWxmLl9saW1pdCAmJiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5oYXMoaWQpKSlcbiAgICAgICAgICBzZWxmLl9yZW1vdmVNYXRjaGluZyhpZCk7XG4gICAgICB9IGVsc2UgaWYgKG9wLm9wID09PSAnaScpIHtcbiAgICAgICAgaWYgKHNlbGYuX3B1Ymxpc2hlZC5oYXMoaWQpKVxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImluc2VydCBmb3VuZCBmb3IgYWxyZWFkeS1leGlzdGluZyBJRCBpbiBwdWJsaXNoZWRcIik7XG4gICAgICAgIGlmIChzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlciAmJiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5oYXMoaWQpKVxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImluc2VydCBmb3VuZCBmb3IgYWxyZWFkeS1leGlzdGluZyBJRCBpbiBidWZmZXJcIik7XG5cbiAgICAgICAgLy8gWFhYIHdoYXQgaWYgc2VsZWN0b3IgeWllbGRzPyAgZm9yIG5vdyBpdCBjYW4ndCBidXQgbGF0ZXIgaXQgY291bGRcbiAgICAgICAgLy8gaGF2ZSAkd2hlcmVcbiAgICAgICAgaWYgKHNlbGYuX21hdGNoZXIuZG9jdW1lbnRNYXRjaGVzKG9wLm8pLnJlc3VsdClcbiAgICAgICAgICBzZWxmLl9hZGRNYXRjaGluZyhvcC5vKTtcbiAgICAgIH0gZWxzZSBpZiAob3Aub3AgPT09ICd1Jykge1xuICAgICAgICAvLyB3ZSBhcmUgbWFwcGluZyB0aGUgbmV3IG9wbG9nIGZvcm1hdCBvbiBtb25nbyA1XG4gICAgICAgIC8vIHRvIHdoYXQgd2Uga25vdyBiZXR0ZXIsICRzZXRcbiAgICAgICAgb3AubyA9IG9wbG9nVjJWMUNvbnZlcnRlcihvcC5vKVxuICAgICAgICAvLyBJcyB0aGlzIGEgbW9kaWZpZXIgKCRzZXQvJHVuc2V0LCB3aGljaCBtYXkgcmVxdWlyZSB1cyB0byBwb2xsIHRoZVxuICAgICAgICAvLyBkYXRhYmFzZSB0byBmaWd1cmUgb3V0IGlmIHRoZSB3aG9sZSBkb2N1bWVudCBtYXRjaGVzIHRoZSBzZWxlY3Rvcikgb3JcbiAgICAgICAgLy8gYSByZXBsYWNlbWVudCAoaW4gd2hpY2ggY2FzZSB3ZSBjYW4ganVzdCBkaXJlY3RseSByZS1ldmFsdWF0ZSB0aGVcbiAgICAgICAgLy8gc2VsZWN0b3IpP1xuICAgICAgICAvLyBvcGxvZyBmb3JtYXQgaGFzIGNoYW5nZWQgb24gbW9uZ29kYiA1LCB3ZSBoYXZlIHRvIHN1cHBvcnQgYm90aCBub3dcbiAgICAgICAgLy8gZGlmZiBpcyB0aGUgZm9ybWF0IGluIE1vbmdvIDUrIChvcGxvZyB2MilcbiAgICAgICAgdmFyIGlzUmVwbGFjZSA9ICFfLmhhcyhvcC5vLCAnJHNldCcpICYmICFfLmhhcyhvcC5vLCAnZGlmZicpICYmICFfLmhhcyhvcC5vLCAnJHVuc2V0Jyk7XG4gICAgICAgIC8vIElmIHRoaXMgbW9kaWZpZXIgbW9kaWZpZXMgc29tZXRoaW5nIGluc2lkZSBhbiBFSlNPTiBjdXN0b20gdHlwZSAoaWUsXG4gICAgICAgIC8vIGFueXRoaW5nIHdpdGggRUpTT04kKSwgdGhlbiB3ZSBjYW4ndCB0cnkgdG8gdXNlXG4gICAgICAgIC8vIExvY2FsQ29sbGVjdGlvbi5fbW9kaWZ5LCBzaW5jZSB0aGF0IGp1c3QgbXV0YXRlcyB0aGUgRUpTT04gZW5jb2RpbmcsXG4gICAgICAgIC8vIG5vdCB0aGUgYWN0dWFsIG9iamVjdC5cbiAgICAgICAgdmFyIGNhbkRpcmVjdGx5TW9kaWZ5RG9jID1cbiAgICAgICAgICAhaXNSZXBsYWNlICYmIG1vZGlmaWVyQ2FuQmVEaXJlY3RseUFwcGxpZWQob3Aubyk7XG5cbiAgICAgICAgdmFyIHB1Ymxpc2hlZEJlZm9yZSA9IHNlbGYuX3B1Ymxpc2hlZC5oYXMoaWQpO1xuICAgICAgICB2YXIgYnVmZmVyZWRCZWZvcmUgPSBzZWxmLl9saW1pdCAmJiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5oYXMoaWQpO1xuXG4gICAgICAgIGlmIChpc1JlcGxhY2UpIHtcbiAgICAgICAgICBzZWxmLl9oYW5kbGVEb2MoaWQsIF8uZXh0ZW5kKHtfaWQ6IGlkfSwgb3AubykpO1xuICAgICAgICB9IGVsc2UgaWYgKChwdWJsaXNoZWRCZWZvcmUgfHwgYnVmZmVyZWRCZWZvcmUpICYmXG4gICAgICAgICAgICAgICAgICAgY2FuRGlyZWN0bHlNb2RpZnlEb2MpIHtcbiAgICAgICAgICAvLyBPaCBncmVhdCwgd2UgYWN0dWFsbHkga25vdyB3aGF0IHRoZSBkb2N1bWVudCBpcywgc28gd2UgY2FuIGFwcGx5XG4gICAgICAgICAgLy8gdGhpcyBkaXJlY3RseS5cbiAgICAgICAgICB2YXIgbmV3RG9jID0gc2VsZi5fcHVibGlzaGVkLmhhcyhpZClcbiAgICAgICAgICAgID8gc2VsZi5fcHVibGlzaGVkLmdldChpZCkgOiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5nZXQoaWQpO1xuICAgICAgICAgIG5ld0RvYyA9IEVKU09OLmNsb25lKG5ld0RvYyk7XG5cbiAgICAgICAgICBuZXdEb2MuX2lkID0gaWQ7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIExvY2FsQ29sbGVjdGlvbi5fbW9kaWZ5KG5ld0RvYywgb3Aubyk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgaWYgKGUubmFtZSAhPT0gXCJNaW5pbW9uZ29FcnJvclwiKVxuICAgICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgICAgLy8gV2UgZGlkbid0IHVuZGVyc3RhbmQgdGhlIG1vZGlmaWVyLiAgUmUtZmV0Y2guXG4gICAgICAgICAgICBzZWxmLl9uZWVkVG9GZXRjaC5zZXQoaWQsIG9wKTtcbiAgICAgICAgICAgIGlmIChzZWxmLl9waGFzZSA9PT0gUEhBU0UuU1RFQURZKSB7XG4gICAgICAgICAgICAgIHNlbGYuX2ZldGNoTW9kaWZpZWREb2N1bWVudHMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgc2VsZi5faGFuZGxlRG9jKGlkLCBzZWxmLl9zaGFyZWRQcm9qZWN0aW9uRm4obmV3RG9jKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIWNhbkRpcmVjdGx5TW9kaWZ5RG9jIHx8XG4gICAgICAgICAgICAgICAgICAgc2VsZi5fbWF0Y2hlci5jYW5CZWNvbWVUcnVlQnlNb2RpZmllcihvcC5vKSB8fFxuICAgICAgICAgICAgICAgICAgIChzZWxmLl9zb3J0ZXIgJiYgc2VsZi5fc29ydGVyLmFmZmVjdGVkQnlNb2RpZmllcihvcC5vKSkpIHtcbiAgICAgICAgICBzZWxmLl9uZWVkVG9GZXRjaC5zZXQoaWQsIG9wKTtcbiAgICAgICAgICBpZiAoc2VsZi5fcGhhc2UgPT09IFBIQVNFLlNURUFEWSlcbiAgICAgICAgICAgIHNlbGYuX2ZldGNoTW9kaWZpZWREb2N1bWVudHMoKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJYWFggU1VSUFJJU0lORyBPUEVSQVRJT046IFwiICsgb3ApO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICAvLyBZaWVsZHMhXG4gIF9ydW5Jbml0aWFsUXVlcnk6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJvcGxvZyBzdG9wcGVkIHN1cnByaXNpbmdseSBlYXJseVwiKTtcblxuICAgIHNlbGYuX3J1blF1ZXJ5KHtpbml0aWFsOiB0cnVlfSk7ICAvLyB5aWVsZHNcblxuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuOyAgLy8gY2FuIGhhcHBlbiBvbiBxdWVyeUVycm9yXG5cbiAgICAvLyBBbGxvdyBvYnNlcnZlQ2hhbmdlcyBjYWxscyB0byByZXR1cm4uIChBZnRlciB0aGlzLCBpdCdzIHBvc3NpYmxlIGZvclxuICAgIC8vIHN0b3AoKSB0byBiZSBjYWxsZWQuKVxuICAgIHNlbGYuX211bHRpcGxleGVyLnJlYWR5KCk7XG5cbiAgICBzZWxmLl9kb25lUXVlcnlpbmcoKTsgIC8vIHlpZWxkc1xuICB9LFxuXG4gIC8vIEluIHZhcmlvdXMgY2lyY3Vtc3RhbmNlcywgd2UgbWF5IGp1c3Qgd2FudCB0byBzdG9wIHByb2Nlc3NpbmcgdGhlIG9wbG9nIGFuZFxuICAvLyByZS1ydW4gdGhlIGluaXRpYWwgcXVlcnksIGp1c3QgYXMgaWYgd2Ugd2VyZSBhIFBvbGxpbmdPYnNlcnZlRHJpdmVyLlxuICAvL1xuICAvLyBUaGlzIGZ1bmN0aW9uIG1heSBub3QgYmxvY2ssIGJlY2F1c2UgaXQgaXMgY2FsbGVkIGZyb20gYW4gb3Bsb2cgZW50cnlcbiAgLy8gaGFuZGxlci5cbiAgLy9cbiAgLy8gWFhYIFdlIHNob3VsZCBjYWxsIHRoaXMgd2hlbiB3ZSBkZXRlY3QgdGhhdCB3ZSd2ZSBiZWVuIGluIEZFVENISU5HIGZvciBcInRvb1xuICAvLyBsb25nXCIuXG4gIC8vXG4gIC8vIFhYWCBXZSBzaG91bGQgY2FsbCB0aGlzIHdoZW4gd2UgZGV0ZWN0IE1vbmdvIGZhaWxvdmVyIChzaW5jZSB0aGF0IG1pZ2h0XG4gIC8vIG1lYW4gdGhhdCBzb21lIG9mIHRoZSBvcGxvZyBlbnRyaWVzIHdlIGhhdmUgcHJvY2Vzc2VkIGhhdmUgYmVlbiByb2xsZWRcbiAgLy8gYmFjaykuIFRoZSBOb2RlIE1vbmdvIGRyaXZlciBpcyBpbiB0aGUgbWlkZGxlIG9mIGEgYnVuY2ggb2YgaHVnZVxuICAvLyByZWZhY3RvcmluZ3MsIGluY2x1ZGluZyB0aGUgd2F5IHRoYXQgaXQgbm90aWZpZXMgeW91IHdoZW4gcHJpbWFyeVxuICAvLyBjaGFuZ2VzLiBXaWxsIHB1dCBvZmYgaW1wbGVtZW50aW5nIHRoaXMgdW50aWwgZHJpdmVyIDEuNCBpcyBvdXQuXG4gIF9wb2xsUXVlcnk6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgLy8gWWF5LCB3ZSBnZXQgdG8gZm9yZ2V0IGFib3V0IGFsbCB0aGUgdGhpbmdzIHdlIHRob3VnaHQgd2UgaGFkIHRvIGZldGNoLlxuICAgICAgc2VsZi5fbmVlZFRvRmV0Y2ggPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgICAgIHNlbGYuX2N1cnJlbnRseUZldGNoaW5nID0gbnVsbDtcbiAgICAgICsrc2VsZi5fZmV0Y2hHZW5lcmF0aW9uOyAgLy8gaWdub3JlIGFueSBpbi1mbGlnaHQgZmV0Y2hlc1xuICAgICAgc2VsZi5fcmVnaXN0ZXJQaGFzZUNoYW5nZShQSEFTRS5RVUVSWUlORyk7XG5cbiAgICAgIC8vIERlZmVyIHNvIHRoYXQgd2UgZG9uJ3QgeWllbGQuICBXZSBkb24ndCBuZWVkIGZpbmlzaElmTmVlZFRvUG9sbFF1ZXJ5XG4gICAgICAvLyBoZXJlIGJlY2F1c2UgU3dpdGNoZWRUb1F1ZXJ5IGlzIG5vdCB0aHJvd24gaW4gUVVFUllJTkcgbW9kZS5cbiAgICAgIE1ldGVvci5kZWZlcihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHNlbGYuX3J1blF1ZXJ5KCk7XG4gICAgICAgIHNlbGYuX2RvbmVRdWVyeWluZygpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sXG5cbiAgLy8gWWllbGRzIVxuICBfcnVuUXVlcnk6IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICAgIHZhciBuZXdSZXN1bHRzLCBuZXdCdWZmZXI7XG5cbiAgICAvLyBUaGlzIHdoaWxlIGxvb3AgaXMganVzdCB0byByZXRyeSBmYWlsdXJlcy5cbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgLy8gSWYgd2UndmUgYmVlbiBzdG9wcGVkLCB3ZSBkb24ndCBoYXZlIHRvIHJ1biBhbnl0aGluZyBhbnkgbW9yZS5cbiAgICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgICByZXR1cm47XG5cbiAgICAgIG5ld1Jlc3VsdHMgPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgICAgIG5ld0J1ZmZlciA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuXG4gICAgICAvLyBRdWVyeSAyeCBkb2N1bWVudHMgYXMgdGhlIGhhbGYgZXhjbHVkZWQgZnJvbSB0aGUgb3JpZ2luYWwgcXVlcnkgd2lsbCBnb1xuICAgICAgLy8gaW50byB1bnB1Ymxpc2hlZCBidWZmZXIgdG8gcmVkdWNlIGFkZGl0aW9uYWwgTW9uZ28gbG9va3VwcyBpbiBjYXNlc1xuICAgICAgLy8gd2hlbiBkb2N1bWVudHMgYXJlIHJlbW92ZWQgZnJvbSB0aGUgcHVibGlzaGVkIHNldCBhbmQgbmVlZCBhXG4gICAgICAvLyByZXBsYWNlbWVudC5cbiAgICAgIC8vIFhYWCBuZWVkcyBtb3JlIHRob3VnaHQgb24gbm9uLXplcm8gc2tpcFxuICAgICAgLy8gWFhYIDIgaXMgYSBcIm1hZ2ljIG51bWJlclwiIG1lYW5pbmcgdGhlcmUgaXMgYW4gZXh0cmEgY2h1bmsgb2YgZG9jcyBmb3JcbiAgICAgIC8vIGJ1ZmZlciBpZiBzdWNoIGlzIG5lZWRlZC5cbiAgICAgIHZhciBjdXJzb3IgPSBzZWxmLl9jdXJzb3JGb3JRdWVyeSh7IGxpbWl0OiBzZWxmLl9saW1pdCAqIDIgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjdXJzb3IuZm9yRWFjaChmdW5jdGlvbiAoZG9jLCBpKSB7ICAvLyB5aWVsZHNcbiAgICAgICAgICBpZiAoIXNlbGYuX2xpbWl0IHx8IGkgPCBzZWxmLl9saW1pdCkge1xuICAgICAgICAgICAgbmV3UmVzdWx0cy5zZXQoZG9jLl9pZCwgZG9jKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbmV3QnVmZmVyLnNldChkb2MuX2lkLCBkb2MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBpZiAob3B0aW9ucy5pbml0aWFsICYmIHR5cGVvZihlLmNvZGUpID09PSAnbnVtYmVyJykge1xuICAgICAgICAgIC8vIFRoaXMgaXMgYW4gZXJyb3IgZG9jdW1lbnQgc2VudCB0byB1cyBieSBtb25nb2QsIG5vdCBhIGNvbm5lY3Rpb25cbiAgICAgICAgICAvLyBlcnJvciBnZW5lcmF0ZWQgYnkgdGhlIGNsaWVudC4gQW5kIHdlJ3ZlIG5ldmVyIHNlZW4gdGhpcyBxdWVyeSB3b3JrXG4gICAgICAgICAgLy8gc3VjY2Vzc2Z1bGx5LiBQcm9iYWJseSBpdCdzIGEgYmFkIHNlbGVjdG9yIG9yIHNvbWV0aGluZywgc28gd2VcbiAgICAgICAgICAvLyBzaG91bGQgTk9UIHJldHJ5LiBJbnN0ZWFkLCB3ZSBzaG91bGQgaGFsdCB0aGUgb2JzZXJ2ZSAod2hpY2ggZW5kc1xuICAgICAgICAgIC8vIHVwIGNhbGxpbmcgYHN0b3BgIG9uIHVzKS5cbiAgICAgICAgICBzZWxmLl9tdWx0aXBsZXhlci5xdWVyeUVycm9yKGUpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIER1cmluZyBmYWlsb3ZlciAoZWcpIGlmIHdlIGdldCBhbiBleGNlcHRpb24gd2Ugc2hvdWxkIGxvZyBhbmQgcmV0cnlcbiAgICAgICAgLy8gaW5zdGVhZCBvZiBjcmFzaGluZy5cbiAgICAgICAgTWV0ZW9yLl9kZWJ1ZyhcIkdvdCBleGNlcHRpb24gd2hpbGUgcG9sbGluZyBxdWVyeVwiLCBlKTtcbiAgICAgICAgTWV0ZW9yLl9zbGVlcEZvck1zKDEwMCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICByZXR1cm47XG5cbiAgICBzZWxmLl9wdWJsaXNoTmV3UmVzdWx0cyhuZXdSZXN1bHRzLCBuZXdCdWZmZXIpO1xuICB9LFxuXG4gIC8vIFRyYW5zaXRpb25zIHRvIFFVRVJZSU5HIGFuZCBydW5zIGFub3RoZXIgcXVlcnksIG9yIChpZiBhbHJlYWR5IGluIFFVRVJZSU5HKVxuICAvLyBlbnN1cmVzIHRoYXQgd2Ugd2lsbCBxdWVyeSBhZ2FpbiBsYXRlci5cbiAgLy9cbiAgLy8gVGhpcyBmdW5jdGlvbiBtYXkgbm90IGJsb2NrLCBiZWNhdXNlIGl0IGlzIGNhbGxlZCBmcm9tIGFuIG9wbG9nIGVudHJ5XG4gIC8vIGhhbmRsZXIuIEhvd2V2ZXIsIGlmIHdlIHdlcmUgbm90IGFscmVhZHkgaW4gdGhlIFFVRVJZSU5HIHBoYXNlLCBpdCB0aHJvd3NcbiAgLy8gYW4gZXhjZXB0aW9uIHRoYXQgaXMgY2F1Z2h0IGJ5IHRoZSBjbG9zZXN0IHN1cnJvdW5kaW5nXG4gIC8vIGZpbmlzaElmTmVlZFRvUG9sbFF1ZXJ5IGNhbGw7IHRoaXMgZW5zdXJlcyB0aGF0IHdlIGRvbid0IGNvbnRpbnVlIHJ1bm5pbmdcbiAgLy8gY2xvc2UgdGhhdCB3YXMgZGVzaWduZWQgZm9yIGFub3RoZXIgcGhhc2UgaW5zaWRlIFBIQVNFLlFVRVJZSU5HLlxuICAvL1xuICAvLyAoSXQncyBhbHNvIG5lY2Vzc2FyeSB3aGVuZXZlciBsb2dpYyBpbiB0aGlzIGZpbGUgeWllbGRzIHRvIGNoZWNrIHRoYXQgb3RoZXJcbiAgLy8gcGhhc2VzIGhhdmVuJ3QgcHV0IHVzIGludG8gUVVFUllJTkcgbW9kZSwgdGhvdWdoOyBlZyxcbiAgLy8gX2ZldGNoTW9kaWZpZWREb2N1bWVudHMgZG9lcyB0aGlzLilcbiAgX25lZWRUb1BvbGxRdWVyeTogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgICAvLyBJZiB3ZSdyZSBub3QgYWxyZWFkeSBpbiB0aGUgbWlkZGxlIG9mIGEgcXVlcnksIHdlIGNhbiBxdWVyeSBub3dcbiAgICAgIC8vIChwb3NzaWJseSBwYXVzaW5nIEZFVENISU5HKS5cbiAgICAgIGlmIChzZWxmLl9waGFzZSAhPT0gUEhBU0UuUVVFUllJTkcpIHtcbiAgICAgICAgc2VsZi5fcG9sbFF1ZXJ5KCk7XG4gICAgICAgIHRocm93IG5ldyBTd2l0Y2hlZFRvUXVlcnk7XG4gICAgICB9XG5cbiAgICAgIC8vIFdlJ3JlIGN1cnJlbnRseSBpbiBRVUVSWUlORy4gU2V0IGEgZmxhZyB0byBlbnN1cmUgdGhhdCB3ZSBydW4gYW5vdGhlclxuICAgICAgLy8gcXVlcnkgd2hlbiB3ZSdyZSBkb25lLlxuICAgICAgc2VsZi5fcmVxdWVyeVdoZW5Eb25lVGhpc1F1ZXJ5ID0gdHJ1ZTtcbiAgICB9KTtcbiAgfSxcblxuICAvLyBZaWVsZHMhXG4gIF9kb25lUXVlcnlpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHJldHVybjtcbiAgICBzZWxmLl9tb25nb0hhbmRsZS5fb3Bsb2dIYW5kbGUud2FpdFVudGlsQ2F1Z2h0VXAoKTsgIC8vIHlpZWxkc1xuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuO1xuICAgIGlmIChzZWxmLl9waGFzZSAhPT0gUEhBU0UuUVVFUllJTkcpXG4gICAgICB0aHJvdyBFcnJvcihcIlBoYXNlIHVuZXhwZWN0ZWRseSBcIiArIHNlbGYuX3BoYXNlKTtcblxuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLl9yZXF1ZXJ5V2hlbkRvbmVUaGlzUXVlcnkpIHtcbiAgICAgICAgc2VsZi5fcmVxdWVyeVdoZW5Eb25lVGhpc1F1ZXJ5ID0gZmFsc2U7XG4gICAgICAgIHNlbGYuX3BvbGxRdWVyeSgpO1xuICAgICAgfSBlbHNlIGlmIChzZWxmLl9uZWVkVG9GZXRjaC5lbXB0eSgpKSB7XG4gICAgICAgIHNlbGYuX2JlU3RlYWR5KCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZWxmLl9mZXRjaE1vZGlmaWVkRG9jdW1lbnRzKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG5cbiAgX2N1cnNvckZvclF1ZXJ5OiBmdW5jdGlvbiAob3B0aW9uc092ZXJ3cml0ZSkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgLy8gVGhlIHF1ZXJ5IHdlIHJ1biBpcyBhbG1vc3QgdGhlIHNhbWUgYXMgdGhlIGN1cnNvciB3ZSBhcmUgb2JzZXJ2aW5nLFxuICAgICAgLy8gd2l0aCBhIGZldyBjaGFuZ2VzLiBXZSBuZWVkIHRvIHJlYWQgYWxsIHRoZSBmaWVsZHMgdGhhdCBhcmUgcmVsZXZhbnQgdG9cbiAgICAgIC8vIHRoZSBzZWxlY3Rvciwgbm90IGp1c3QgdGhlIGZpZWxkcyB3ZSBhcmUgZ29pbmcgdG8gcHVibGlzaCAodGhhdCdzIHRoZVxuICAgICAgLy8gXCJzaGFyZWRcIiBwcm9qZWN0aW9uKS4gQW5kIHdlIGRvbid0IHdhbnQgdG8gYXBwbHkgYW55IHRyYW5zZm9ybSBpbiB0aGVcbiAgICAgIC8vIGN1cnNvciwgYmVjYXVzZSBvYnNlcnZlQ2hhbmdlcyBzaG91bGRuJ3QgdXNlIHRoZSB0cmFuc2Zvcm0uXG4gICAgICB2YXIgb3B0aW9ucyA9IF8uY2xvbmUoc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucyk7XG5cbiAgICAgIC8vIEFsbG93IHRoZSBjYWxsZXIgdG8gbW9kaWZ5IHRoZSBvcHRpb25zLiBVc2VmdWwgdG8gc3BlY2lmeSBkaWZmZXJlbnRcbiAgICAgIC8vIHNraXAgYW5kIGxpbWl0IHZhbHVlcy5cbiAgICAgIF8uZXh0ZW5kKG9wdGlvbnMsIG9wdGlvbnNPdmVyd3JpdGUpO1xuXG4gICAgICBvcHRpb25zLmZpZWxkcyA9IHNlbGYuX3NoYXJlZFByb2plY3Rpb247XG4gICAgICBkZWxldGUgb3B0aW9ucy50cmFuc2Zvcm07XG4gICAgICAvLyBXZSBhcmUgTk9UIGRlZXAgY2xvbmluZyBmaWVsZHMgb3Igc2VsZWN0b3IgaGVyZSwgd2hpY2ggc2hvdWxkIGJlIE9LLlxuICAgICAgdmFyIGRlc2NyaXB0aW9uID0gbmV3IEN1cnNvckRlc2NyaXB0aW9uKFxuICAgICAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZSxcbiAgICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3IsXG4gICAgICAgIG9wdGlvbnMpO1xuICAgICAgcmV0dXJuIG5ldyBDdXJzb3Ioc2VsZi5fbW9uZ29IYW5kbGUsIGRlc2NyaXB0aW9uKTtcbiAgICB9KTtcbiAgfSxcblxuXG4gIC8vIFJlcGxhY2Ugc2VsZi5fcHVibGlzaGVkIHdpdGggbmV3UmVzdWx0cyAoYm90aCBhcmUgSWRNYXBzKSwgaW52b2tpbmcgb2JzZXJ2ZVxuICAvLyBjYWxsYmFja3Mgb24gdGhlIG11bHRpcGxleGVyLlxuICAvLyBSZXBsYWNlIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyIHdpdGggbmV3QnVmZmVyLlxuICAvL1xuICAvLyBYWFggVGhpcyBpcyB2ZXJ5IHNpbWlsYXIgdG8gTG9jYWxDb2xsZWN0aW9uLl9kaWZmUXVlcnlVbm9yZGVyZWRDaGFuZ2VzLiBXZVxuICAvLyBzaG91bGQgcmVhbGx5OiAoYSkgVW5pZnkgSWRNYXAgYW5kIE9yZGVyZWREaWN0IGludG8gVW5vcmRlcmVkL09yZGVyZWREaWN0XG4gIC8vIChiKSBSZXdyaXRlIGRpZmYuanMgdG8gdXNlIHRoZXNlIGNsYXNzZXMgaW5zdGVhZCBvZiBhcnJheXMgYW5kIG9iamVjdHMuXG4gIF9wdWJsaXNoTmV3UmVzdWx0czogZnVuY3Rpb24gKG5ld1Jlc3VsdHMsIG5ld0J1ZmZlcikge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG5cbiAgICAgIC8vIElmIHRoZSBxdWVyeSBpcyBsaW1pdGVkIGFuZCB0aGVyZSBpcyBhIGJ1ZmZlciwgc2h1dCBkb3duIHNvIGl0IGRvZXNuJ3RcbiAgICAgIC8vIHN0YXkgaW4gYSB3YXkuXG4gICAgICBpZiAoc2VsZi5fbGltaXQpIHtcbiAgICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuY2xlYXIoKTtcbiAgICAgIH1cblxuICAgICAgLy8gRmlyc3QgcmVtb3ZlIGFueXRoaW5nIHRoYXQncyBnb25lLiBCZSBjYXJlZnVsIG5vdCB0byBtb2RpZnlcbiAgICAgIC8vIHNlbGYuX3B1Ymxpc2hlZCB3aGlsZSBpdGVyYXRpbmcgb3ZlciBpdC5cbiAgICAgIHZhciBpZHNUb1JlbW92ZSA9IFtdO1xuICAgICAgc2VsZi5fcHVibGlzaGVkLmZvckVhY2goZnVuY3Rpb24gKGRvYywgaWQpIHtcbiAgICAgICAgaWYgKCFuZXdSZXN1bHRzLmhhcyhpZCkpXG4gICAgICAgICAgaWRzVG9SZW1vdmUucHVzaChpZCk7XG4gICAgICB9KTtcbiAgICAgIF8uZWFjaChpZHNUb1JlbW92ZSwgZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgIHNlbGYuX3JlbW92ZVB1Ymxpc2hlZChpZCk7XG4gICAgICB9KTtcblxuICAgICAgLy8gTm93IGRvIGFkZHMgYW5kIGNoYW5nZXMuXG4gICAgICAvLyBJZiBzZWxmIGhhcyBhIGJ1ZmZlciBhbmQgbGltaXQsIHRoZSBuZXcgZmV0Y2hlZCByZXN1bHQgd2lsbCBiZVxuICAgICAgLy8gbGltaXRlZCBjb3JyZWN0bHkgYXMgdGhlIHF1ZXJ5IGhhcyBzb3J0IHNwZWNpZmllci5cbiAgICAgIG5ld1Jlc3VsdHMuZm9yRWFjaChmdW5jdGlvbiAoZG9jLCBpZCkge1xuICAgICAgICBzZWxmLl9oYW5kbGVEb2MoaWQsIGRvYyk7XG4gICAgICB9KTtcblxuICAgICAgLy8gU2FuaXR5LWNoZWNrIHRoYXQgZXZlcnl0aGluZyB3ZSB0cmllZCB0byBwdXQgaW50byBfcHVibGlzaGVkIGVuZGVkIHVwXG4gICAgICAvLyB0aGVyZS5cbiAgICAgIC8vIFhYWCBpZiB0aGlzIGlzIHNsb3csIHJlbW92ZSBpdCBsYXRlclxuICAgICAgaWYgKHNlbGYuX3B1Ymxpc2hlZC5zaXplKCkgIT09IG5ld1Jlc3VsdHMuc2l6ZSgpKSB7XG4gICAgICAgIE1ldGVvci5fZGVidWcoJ1RoZSBNb25nbyBzZXJ2ZXIgYW5kIHRoZSBNZXRlb3IgcXVlcnkgZGlzYWdyZWUgb24gaG93ICcgK1xuICAgICAgICAgICdtYW55IGRvY3VtZW50cyBtYXRjaCB5b3VyIHF1ZXJ5LiBDdXJzb3IgZGVzY3JpcHRpb246ICcsXG4gICAgICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24pO1xuICAgICAgfVxuICAgICAgXG4gICAgICBzZWxmLl9wdWJsaXNoZWQuZm9yRWFjaChmdW5jdGlvbiAoZG9jLCBpZCkge1xuICAgICAgICBpZiAoIW5ld1Jlc3VsdHMuaGFzKGlkKSlcbiAgICAgICAgICB0aHJvdyBFcnJvcihcIl9wdWJsaXNoZWQgaGFzIGEgZG9jIHRoYXQgbmV3UmVzdWx0cyBkb2Vzbid0OyBcIiArIGlkKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBGaW5hbGx5LCByZXBsYWNlIHRoZSBidWZmZXJcbiAgICAgIG5ld0J1ZmZlci5mb3JFYWNoKGZ1bmN0aW9uIChkb2MsIGlkKSB7XG4gICAgICAgIHNlbGYuX2FkZEJ1ZmZlcmVkKGlkLCBkb2MpO1xuICAgICAgfSk7XG5cbiAgICAgIHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlciA9IG5ld0J1ZmZlci5zaXplKCkgPCBzZWxmLl9saW1pdDtcbiAgICB9KTtcbiAgfSxcblxuICAvLyBUaGlzIHN0b3AgZnVuY3Rpb24gaXMgaW52b2tlZCBmcm9tIHRoZSBvblN0b3Agb2YgdGhlIE9ic2VydmVNdWx0aXBsZXhlciwgc29cbiAgLy8gaXQgc2hvdWxkbid0IGFjdHVhbGx5IGJlIHBvc3NpYmxlIHRvIGNhbGwgaXQgdW50aWwgdGhlIG11bHRpcGxleGVyIGlzXG4gIC8vIHJlYWR5LlxuICAvL1xuICAvLyBJdCdzIGltcG9ydGFudCB0byBjaGVjayBzZWxmLl9zdG9wcGVkIGFmdGVyIGV2ZXJ5IGNhbGwgaW4gdGhpcyBmaWxlIHRoYXRcbiAgLy8gY2FuIHlpZWxkIVxuICBzdG9wOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuO1xuICAgIHNlbGYuX3N0b3BwZWQgPSB0cnVlO1xuICAgIF8uZWFjaChzZWxmLl9zdG9wSGFuZGxlcywgZnVuY3Rpb24gKGhhbmRsZSkge1xuICAgICAgaGFuZGxlLnN0b3AoKTtcbiAgICB9KTtcblxuICAgIC8vIE5vdGU6IHdlICpkb24ndCogdXNlIG11bHRpcGxleGVyLm9uRmx1c2ggaGVyZSBiZWNhdXNlIHRoaXMgc3RvcFxuICAgIC8vIGNhbGxiYWNrIGlzIGFjdHVhbGx5IGludm9rZWQgYnkgdGhlIG11bHRpcGxleGVyIGl0c2VsZiB3aGVuIGl0IGhhc1xuICAgIC8vIGRldGVybWluZWQgdGhhdCB0aGVyZSBhcmUgbm8gaGFuZGxlcyBsZWZ0LiBTbyBub3RoaW5nIGlzIGFjdHVhbGx5IGdvaW5nXG4gICAgLy8gdG8gZ2V0IGZsdXNoZWQgKGFuZCBpdCdzIHByb2JhYmx5IG5vdCB2YWxpZCB0byBjYWxsIG1ldGhvZHMgb24gdGhlXG4gICAgLy8gZHlpbmcgbXVsdGlwbGV4ZXIpLlxuICAgIF8uZWFjaChzZWxmLl93cml0ZXNUb0NvbW1pdFdoZW5XZVJlYWNoU3RlYWR5LCBmdW5jdGlvbiAodykge1xuICAgICAgdy5jb21taXR0ZWQoKTsgIC8vIG1heWJlIHlpZWxkcz9cbiAgICB9KTtcbiAgICBzZWxmLl93cml0ZXNUb0NvbW1pdFdoZW5XZVJlYWNoU3RlYWR5ID0gbnVsbDtcblxuICAgIC8vIFByb2FjdGl2ZWx5IGRyb3AgcmVmZXJlbmNlcyB0byBwb3RlbnRpYWxseSBiaWcgdGhpbmdzLlxuICAgIHNlbGYuX3B1Ymxpc2hlZCA9IG51bGw7XG4gICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIgPSBudWxsO1xuICAgIHNlbGYuX25lZWRUb0ZldGNoID0gbnVsbDtcbiAgICBzZWxmLl9jdXJyZW50bHlGZXRjaGluZyA9IG51bGw7XG4gICAgc2VsZi5fb3Bsb2dFbnRyeUhhbmRsZSA9IG51bGw7XG4gICAgc2VsZi5fbGlzdGVuZXJzSGFuZGxlID0gbnVsbDtcblxuICAgIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWRyaXZlcnMtb3Bsb2dcIiwgLTEpO1xuICB9LFxuXG4gIF9yZWdpc3RlclBoYXNlQ2hhbmdlOiBmdW5jdGlvbiAocGhhc2UpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIG5vdyA9IG5ldyBEYXRlO1xuXG4gICAgICBpZiAoc2VsZi5fcGhhc2UpIHtcbiAgICAgICAgdmFyIHRpbWVEaWZmID0gbm93IC0gc2VsZi5fcGhhc2VTdGFydFRpbWU7XG4gICAgICAgIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICAgICAgICBcIm1vbmdvLWxpdmVkYXRhXCIsIFwidGltZS1zcGVudC1pbi1cIiArIHNlbGYuX3BoYXNlICsgXCItcGhhc2VcIiwgdGltZURpZmYpO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9waGFzZSA9IHBoYXNlO1xuICAgICAgc2VsZi5fcGhhc2VTdGFydFRpbWUgPSBub3c7XG4gICAgfSk7XG4gIH1cbn0pO1xuXG4vLyBEb2VzIG91ciBvcGxvZyB0YWlsaW5nIGNvZGUgc3VwcG9ydCB0aGlzIGN1cnNvcj8gRm9yIG5vdywgd2UgYXJlIGJlaW5nIHZlcnlcbi8vIGNvbnNlcnZhdGl2ZSBhbmQgYWxsb3dpbmcgb25seSBzaW1wbGUgcXVlcmllcyB3aXRoIHNpbXBsZSBvcHRpb25zLlxuLy8gKFRoaXMgaXMgYSBcInN0YXRpYyBtZXRob2RcIi4pXG5PcGxvZ09ic2VydmVEcml2ZXIuY3Vyc29yU3VwcG9ydGVkID0gZnVuY3Rpb24gKGN1cnNvckRlc2NyaXB0aW9uLCBtYXRjaGVyKSB7XG4gIC8vIEZpcnN0LCBjaGVjayB0aGUgb3B0aW9ucy5cbiAgdmFyIG9wdGlvbnMgPSBjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zO1xuXG4gIC8vIERpZCB0aGUgdXNlciBzYXkgbm8gZXhwbGljaXRseT9cbiAgLy8gdW5kZXJzY29yZWQgdmVyc2lvbiBvZiB0aGUgb3B0aW9uIGlzIENPTVBBVCB3aXRoIDEuMlxuICBpZiAob3B0aW9ucy5kaXNhYmxlT3Bsb2cgfHwgb3B0aW9ucy5fZGlzYWJsZU9wbG9nKVxuICAgIHJldHVybiBmYWxzZTtcblxuICAvLyBza2lwIGlzIG5vdCBzdXBwb3J0ZWQ6IHRvIHN1cHBvcnQgaXQgd2Ugd291bGQgbmVlZCB0byBrZWVwIHRyYWNrIG9mIGFsbFxuICAvLyBcInNraXBwZWRcIiBkb2N1bWVudHMgb3IgYXQgbGVhc3QgdGhlaXIgaWRzLlxuICAvLyBsaW1pdCB3L28gYSBzb3J0IHNwZWNpZmllciBpcyBub3Qgc3VwcG9ydGVkOiBjdXJyZW50IGltcGxlbWVudGF0aW9uIG5lZWRzIGFcbiAgLy8gZGV0ZXJtaW5pc3RpYyB3YXkgdG8gb3JkZXIgZG9jdW1lbnRzLlxuICBpZiAob3B0aW9ucy5za2lwIHx8IChvcHRpb25zLmxpbWl0ICYmICFvcHRpb25zLnNvcnQpKSByZXR1cm4gZmFsc2U7XG5cbiAgLy8gSWYgYSBmaWVsZHMgcHJvamVjdGlvbiBvcHRpb24gaXMgZ2l2ZW4gY2hlY2sgaWYgaXQgaXMgc3VwcG9ydGVkIGJ5XG4gIC8vIG1pbmltb25nbyAoc29tZSBvcGVyYXRvcnMgYXJlIG5vdCBzdXBwb3J0ZWQpLlxuICBjb25zdCBmaWVsZHMgPSBvcHRpb25zLmZpZWxkcyB8fCBvcHRpb25zLnByb2plY3Rpb247XG4gIGlmIChmaWVsZHMpIHtcbiAgICB0cnkge1xuICAgICAgTG9jYWxDb2xsZWN0aW9uLl9jaGVja1N1cHBvcnRlZFByb2plY3Rpb24oZmllbGRzKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoZS5uYW1lID09PSBcIk1pbmltb25nb0Vycm9yXCIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBXZSBkb24ndCBhbGxvdyB0aGUgZm9sbG93aW5nIHNlbGVjdG9yczpcbiAgLy8gICAtICR3aGVyZSAobm90IGNvbmZpZGVudCB0aGF0IHdlIHByb3ZpZGUgdGhlIHNhbWUgSlMgZW52aXJvbm1lbnRcbiAgLy8gICAgICAgICAgICAgYXMgTW9uZ28sIGFuZCBjYW4geWllbGQhKVxuICAvLyAgIC0gJG5lYXIgKGhhcyBcImludGVyZXN0aW5nXCIgcHJvcGVydGllcyBpbiBNb25nb0RCLCBsaWtlIHRoZSBwb3NzaWJpbGl0eVxuICAvLyAgICAgICAgICAgIG9mIHJldHVybmluZyBhbiBJRCBtdWx0aXBsZSB0aW1lcywgdGhvdWdoIGV2ZW4gcG9sbGluZyBtYXliZVxuICAvLyAgICAgICAgICAgIGhhdmUgYSBidWcgdGhlcmUpXG4gIC8vICAgICAgICAgICBYWFg6IG9uY2Ugd2Ugc3VwcG9ydCBpdCwgd2Ugd291bGQgbmVlZCB0byB0aGluayBtb3JlIG9uIGhvdyB3ZVxuICAvLyAgICAgICAgICAgaW5pdGlhbGl6ZSB0aGUgY29tcGFyYXRvcnMgd2hlbiB3ZSBjcmVhdGUgdGhlIGRyaXZlci5cbiAgcmV0dXJuICFtYXRjaGVyLmhhc1doZXJlKCkgJiYgIW1hdGNoZXIuaGFzR2VvUXVlcnkoKTtcbn07XG5cbnZhciBtb2RpZmllckNhbkJlRGlyZWN0bHlBcHBsaWVkID0gZnVuY3Rpb24gKG1vZGlmaWVyKSB7XG4gIHJldHVybiBfLmFsbChtb2RpZmllciwgZnVuY3Rpb24gKGZpZWxkcywgb3BlcmF0aW9uKSB7XG4gICAgcmV0dXJuIF8uYWxsKGZpZWxkcywgZnVuY3Rpb24gKHZhbHVlLCBmaWVsZCkge1xuICAgICAgcmV0dXJuICEvRUpTT05cXCQvLnRlc3QoZmllbGQpO1xuICAgIH0pO1xuICB9KTtcbn07XG5cbk1vbmdvSW50ZXJuYWxzLk9wbG9nT2JzZXJ2ZURyaXZlciA9IE9wbG9nT2JzZXJ2ZURyaXZlcjtcbiIsIi8vIENvbnZlcnRlciBvZiB0aGUgbmV3IE1vbmdvREIgT3Bsb2cgZm9ybWF0ICg+PTUuMCkgdG8gdGhlIG9uZSB0aGF0IE1ldGVvclxuLy8gaGFuZGxlcyB3ZWxsLCBpLmUuLCBgJHNldGAgYW5kIGAkdW5zZXRgLiBUaGUgbmV3IGZvcm1hdCBpcyBjb21wbGV0ZWx5IG5ldyxcbi8vIGFuZCBsb29rcyBhcyBmb2xsb3dzOlxuLy9cbi8vICAgeyAkdjogMiwgZGlmZjogRGlmZiB9XG4vL1xuLy8gd2hlcmUgYERpZmZgIGlzIGEgcmVjdXJzaXZlIHN0cnVjdHVyZTpcbi8vXG4vLyAgIHtcbi8vICAgICAvLyBOZXN0ZWQgdXBkYXRlcyAoc29tZXRpbWVzIGFsc28gcmVwcmVzZW50ZWQgd2l0aCBhbiBzLWZpZWxkKS5cbi8vICAgICAvLyBFeGFtcGxlOiBgeyAkc2V0OiB7ICdmb28uYmFyJzogMSB9IH1gLlxuLy8gICAgIGk6IHsgPGtleT46IDx2YWx1ZT4sIC4uLiB9LFxuLy9cbi8vICAgICAvLyBUb3AtbGV2ZWwgdXBkYXRlcy5cbi8vICAgICAvLyBFeGFtcGxlOiBgeyAkc2V0OiB7IGZvbzogeyBiYXI6IDEgfSB9IH1gLlxuLy8gICAgIHU6IHsgPGtleT46IDx2YWx1ZT4sIC4uLiB9LFxuLy9cbi8vICAgICAvLyBVbnNldHMuXG4vLyAgICAgLy8gRXhhbXBsZTogYHsgJHVuc2V0OiB7IGZvbzogJycgfSB9YC5cbi8vICAgICBkOiB7IDxrZXk+OiBmYWxzZSwgLi4uIH0sXG4vL1xuLy8gICAgIC8vIEFycmF5IG9wZXJhdGlvbnMuXG4vLyAgICAgLy8gRXhhbXBsZTogYHsgJHB1c2g6IHsgZm9vOiAnYmFyJyB9IH1gLlxuLy8gICAgIHM8a2V5PjogeyBhOiB0cnVlLCB1PGluZGV4PjogPHZhbHVlPiwgLi4uIH0sXG4vLyAgICAgLi4uXG4vL1xuLy8gICAgIC8vIE5lc3RlZCBvcGVyYXRpb25zIChzb21ldGltZXMgYWxzbyByZXByZXNlbnRlZCBpbiB0aGUgYGlgIGZpZWxkKS5cbi8vICAgICAvLyBFeGFtcGxlOiBgeyAkc2V0OiB7ICdmb28uYmFyJzogMSB9IH1gLlxuLy8gICAgIHM8a2V5PjogRGlmZixcbi8vICAgICAuLi5cbi8vICAgfVxuLy9cbi8vIChhbGwgZmllbGRzIGFyZSBvcHRpb25hbCkuXG5cbmZ1bmN0aW9uIGpvaW4ocHJlZml4LCBrZXkpIHtcbiAgcmV0dXJuIHByZWZpeCA/IGAke3ByZWZpeH0uJHtrZXl9YCA6IGtleTtcbn1cblxuY29uc3QgYXJyYXlPcGVyYXRvcktleVJlZ2V4ID0gL14oYXxbc3VdXFxkKykkLztcblxuZnVuY3Rpb24gaXNBcnJheU9wZXJhdG9yS2V5KGZpZWxkKSB7XG4gIHJldHVybiBhcnJheU9wZXJhdG9yS2V5UmVnZXgudGVzdChmaWVsZCk7XG59XG5cbmZ1bmN0aW9uIGlzQXJyYXlPcGVyYXRvcihvcGVyYXRvcikge1xuICByZXR1cm4gb3BlcmF0b3IuYSA9PT0gdHJ1ZSAmJiBPYmplY3Qua2V5cyhvcGVyYXRvcikuZXZlcnkoaXNBcnJheU9wZXJhdG9yS2V5KTtcbn1cblxuZnVuY3Rpb24gZmxhdHRlbk9iamVjdEludG8odGFyZ2V0LCBzb3VyY2UsIHByZWZpeCkge1xuICBpZiAoQXJyYXkuaXNBcnJheShzb3VyY2UpIHx8IHR5cGVvZiBzb3VyY2UgIT09ICdvYmplY3QnIHx8IHNvdXJjZSA9PT0gbnVsbCB8fFxuICAgICAgc291cmNlIGluc3RhbmNlb2YgTW9uZ28uT2JqZWN0SUQpIHtcbiAgICB0YXJnZXRbcHJlZml4XSA9IHNvdXJjZTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXMoc291cmNlKTtcbiAgICBpZiAoZW50cmllcy5sZW5ndGgpIHtcbiAgICAgIGVudHJpZXMuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICAgIGZsYXR0ZW5PYmplY3RJbnRvKHRhcmdldCwgdmFsdWUsIGpvaW4ocHJlZml4LCBrZXkpKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0YXJnZXRbcHJlZml4XSA9IHNvdXJjZTtcbiAgICB9XG4gIH1cbn1cblxuY29uc3QgbG9nRGVidWdNZXNzYWdlcyA9ICEhcHJvY2Vzcy5lbnYuT1BMT0dfQ09OVkVSVEVSX0RFQlVHO1xuXG5mdW5jdGlvbiBjb252ZXJ0T3Bsb2dEaWZmKG9wbG9nRW50cnksIGRpZmYsIHByZWZpeCkge1xuICBpZiAobG9nRGVidWdNZXNzYWdlcykge1xuICAgIGNvbnNvbGUubG9nKGBjb252ZXJ0T3Bsb2dEaWZmKCR7SlNPTi5zdHJpbmdpZnkob3Bsb2dFbnRyeSl9LCAke0pTT04uc3RyaW5naWZ5KGRpZmYpfSwgJHtKU09OLnN0cmluZ2lmeShwcmVmaXgpfSlgKTtcbiAgfVxuXG4gIE9iamVjdC5lbnRyaWVzKGRpZmYpLmZvckVhY2goKFtkaWZmS2V5LCB2YWx1ZV0pID0+IHtcbiAgICBpZiAoZGlmZktleSA9PT0gJ2QnKSB7XG4gICAgICAvLyBIYW5kbGUgYCR1bnNldGBzLlxuICAgICAgb3Bsb2dFbnRyeS4kdW5zZXQgPz89IHt9O1xuICAgICAgT2JqZWN0LmtleXModmFsdWUpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgb3Bsb2dFbnRyeS4kdW5zZXRbam9pbihwcmVmaXgsIGtleSldID0gdHJ1ZTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZGlmZktleSA9PT0gJ2knKSB7XG4gICAgICAvLyBIYW5kbGUgKHBvdGVudGlhbGx5KSBuZXN0ZWQgYCRzZXRgcy5cbiAgICAgIG9wbG9nRW50cnkuJHNldCA/Pz0ge307XG4gICAgICBmbGF0dGVuT2JqZWN0SW50byhvcGxvZ0VudHJ5LiRzZXQsIHZhbHVlLCBwcmVmaXgpO1xuICAgIH0gZWxzZSBpZiAoZGlmZktleSA9PT0gJ3UnKSB7XG4gICAgICAvLyBIYW5kbGUgZmxhdCBgJHNldGBzLlxuICAgICAgb3Bsb2dFbnRyeS4kc2V0ID8/PSB7fTtcbiAgICAgIE9iamVjdC5lbnRyaWVzKHZhbHVlKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgb3Bsb2dFbnRyeS4kc2V0W2pvaW4ocHJlZml4LCBrZXkpXSA9IHZhbHVlO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEhhbmRsZSBzLWZpZWxkcy5cbiAgICAgIGNvbnN0IGtleSA9IGRpZmZLZXkuc2xpY2UoMSk7XG4gICAgICBpZiAoaXNBcnJheU9wZXJhdG9yKHZhbHVlKSkge1xuICAgICAgICAvLyBBcnJheSBvcGVyYXRvci5cbiAgICAgICAgT2JqZWN0LmVudHJpZXModmFsdWUpLmZvckVhY2goKFtwb3NpdGlvbiwgdmFsdWVdKSA9PiB7XG4gICAgICAgICAgaWYgKHBvc2l0aW9uID09PSAnYScpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBwb3NpdGlvbktleSA9IGpvaW4oam9pbihwcmVmaXgsIGtleSksIHBvc2l0aW9uLnNsaWNlKDEpKTtcbiAgICAgICAgICBpZiAocG9zaXRpb25bMF0gPT09ICdzJykge1xuICAgICAgICAgICAgY29udmVydE9wbG9nRGlmZihvcGxvZ0VudHJ5LCB2YWx1ZSwgcG9zaXRpb25LZXkpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICAgIG9wbG9nRW50cnkuJHVuc2V0ID8/PSB7fTtcbiAgICAgICAgICAgIG9wbG9nRW50cnkuJHVuc2V0W3Bvc2l0aW9uS2V5XSA9IHRydWU7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG9wbG9nRW50cnkuJHNldCA/Pz0ge307XG4gICAgICAgICAgICBvcGxvZ0VudHJ5LiRzZXRbcG9zaXRpb25LZXldID0gdmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAoa2V5KSB7XG4gICAgICAgIC8vIE5lc3RlZCBvYmplY3QuXG4gICAgICAgIGNvbnZlcnRPcGxvZ0RpZmYob3Bsb2dFbnRyeSwgdmFsdWUsIGpvaW4ocHJlZml4LCBrZXkpKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gb3Bsb2dWMlYxQ29udmVydGVyKG9wbG9nRW50cnkpIHtcbiAgLy8gUGFzcy10aHJvdWdoIHYxIGFuZCAocHJvYmFibHkpIGludmFsaWQgZW50cmllcy5cbiAgaWYgKG9wbG9nRW50cnkuJHYgIT09IDIgfHwgIW9wbG9nRW50cnkuZGlmZikge1xuICAgIHJldHVybiBvcGxvZ0VudHJ5O1xuICB9XG5cbiAgY29uc3QgY29udmVydGVkT3Bsb2dFbnRyeSA9IHsgJHY6IDIgfTtcbiAgY29udmVydE9wbG9nRGlmZihjb252ZXJ0ZWRPcGxvZ0VudHJ5LCBvcGxvZ0VudHJ5LmRpZmYsICcnKTtcbiAgcmV0dXJuIGNvbnZlcnRlZE9wbG9nRW50cnk7XG59XG4iLCIvLyBzaW5nbGV0b25cbmV4cG9ydCBjb25zdCBMb2NhbENvbGxlY3Rpb25Ecml2ZXIgPSBuZXcgKGNsYXNzIExvY2FsQ29sbGVjdGlvbkRyaXZlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMubm9Db25uQ29sbGVjdGlvbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB9XG5cbiAgb3BlbihuYW1lLCBjb25uKSB7XG4gICAgaWYgKCEgbmFtZSkge1xuICAgICAgcmV0dXJuIG5ldyBMb2NhbENvbGxlY3Rpb247XG4gICAgfVxuXG4gICAgaWYgKCEgY29ubikge1xuICAgICAgcmV0dXJuIGVuc3VyZUNvbGxlY3Rpb24obmFtZSwgdGhpcy5ub0Nvbm5Db2xsZWN0aW9ucyk7XG4gICAgfVxuXG4gICAgaWYgKCEgY29ubi5fbW9uZ29fbGl2ZWRhdGFfY29sbGVjdGlvbnMpIHtcbiAgICAgIGNvbm4uX21vbmdvX2xpdmVkYXRhX2NvbGxlY3Rpb25zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB9XG5cbiAgICAvLyBYWFggaXMgdGhlcmUgYSB3YXkgdG8ga2VlcCB0cmFjayBvZiBhIGNvbm5lY3Rpb24ncyBjb2xsZWN0aW9ucyB3aXRob3V0XG4gICAgLy8gZGFuZ2xpbmcgaXQgb2ZmIHRoZSBjb25uZWN0aW9uIG9iamVjdD9cbiAgICByZXR1cm4gZW5zdXJlQ29sbGVjdGlvbihuYW1lLCBjb25uLl9tb25nb19saXZlZGF0YV9jb2xsZWN0aW9ucyk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBlbnN1cmVDb2xsZWN0aW9uKG5hbWUsIGNvbGxlY3Rpb25zKSB7XG4gIHJldHVybiAobmFtZSBpbiBjb2xsZWN0aW9ucylcbiAgICA/IGNvbGxlY3Rpb25zW25hbWVdXG4gICAgOiBjb2xsZWN0aW9uc1tuYW1lXSA9IG5ldyBMb2NhbENvbGxlY3Rpb24obmFtZSk7XG59XG4iLCJpbXBvcnQge1xuICBBU1lOQ19DT0xMRUNUSU9OX01FVEhPRFMsXG4gIGdldEFzeW5jTWV0aG9kTmFtZVxufSBmcm9tIFwibWV0ZW9yL21pbmltb25nby9jb25zdGFudHNcIjtcblxuTW9uZ29JbnRlcm5hbHMuUmVtb3RlQ29sbGVjdGlvbkRyaXZlciA9IGZ1bmN0aW9uIChcbiAgbW9uZ29fdXJsLCBvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgc2VsZi5tb25nbyA9IG5ldyBNb25nb0Nvbm5lY3Rpb24obW9uZ29fdXJsLCBvcHRpb25zKTtcbn07XG5cbmNvbnN0IFJFTU9URV9DT0xMRUNUSU9OX01FVEhPRFMgPSBbXG4gICdfY3JlYXRlQ2FwcGVkQ29sbGVjdGlvbicsXG4gICdfZHJvcEluZGV4JyxcbiAgJ19lbnN1cmVJbmRleCcsXG4gICdjcmVhdGVJbmRleCcsXG4gICdjb3VudERvY3VtZW50cycsXG4gICdkcm9wQ29sbGVjdGlvbicsXG4gICdlc3RpbWF0ZWREb2N1bWVudENvdW50JyxcbiAgJ2ZpbmQnLFxuICAnZmluZE9uZScsXG4gICdpbnNlcnQnLFxuICAncmF3Q29sbGVjdGlvbicsXG4gICdyZW1vdmUnLFxuICAndXBkYXRlJyxcbiAgJ3Vwc2VydCcsXG5dO1xuXG5PYmplY3QuYXNzaWduKE1vbmdvSW50ZXJuYWxzLlJlbW90ZUNvbGxlY3Rpb25Ecml2ZXIucHJvdG90eXBlLCB7XG4gIG9wZW46IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHZhciByZXQgPSB7fTtcbiAgICBSRU1PVEVfQ09MTEVDVElPTl9NRVRIT0RTLmZvckVhY2goXG4gICAgICBmdW5jdGlvbiAobSkge1xuICAgICAgICByZXRbbV0gPSBfLmJpbmQoc2VsZi5tb25nb1ttXSwgc2VsZi5tb25nbywgbmFtZSk7XG5cbiAgICAgICAgaWYgKCFBU1lOQ19DT0xMRUNUSU9OX01FVEhPRFMuaW5jbHVkZXMobSkpIHJldHVybjtcbiAgICAgICAgY29uc3QgYXN5bmNNZXRob2ROYW1lID0gZ2V0QXN5bmNNZXRob2ROYW1lKG0pO1xuICAgICAgICByZXRbYXN5bmNNZXRob2ROYW1lXSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUocmV0W21dKC4uLmFyZ3MpKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIHJldHVybiByZXQ7XG4gIH1cbn0pO1xuXG4vLyBDcmVhdGUgdGhlIHNpbmdsZXRvbiBSZW1vdGVDb2xsZWN0aW9uRHJpdmVyIG9ubHkgb24gZGVtYW5kLCBzbyB3ZVxuLy8gb25seSByZXF1aXJlIE1vbmdvIGNvbmZpZ3VyYXRpb24gaWYgaXQncyBhY3R1YWxseSB1c2VkIChlZywgbm90IGlmXG4vLyB5b3UncmUgb25seSB0cnlpbmcgdG8gcmVjZWl2ZSBkYXRhIGZyb20gYSByZW1vdGUgRERQIHNlcnZlci4pXG5Nb25nb0ludGVybmFscy5kZWZhdWx0UmVtb3RlQ29sbGVjdGlvbkRyaXZlciA9IF8ub25jZShmdW5jdGlvbiAoKSB7XG4gIHZhciBjb25uZWN0aW9uT3B0aW9ucyA9IHt9O1xuXG4gIHZhciBtb25nb1VybCA9IHByb2Nlc3MuZW52Lk1PTkdPX1VSTDtcblxuICBpZiAocHJvY2Vzcy5lbnYuTU9OR09fT1BMT0dfVVJMKSB7XG4gICAgY29ubmVjdGlvbk9wdGlvbnMub3Bsb2dVcmwgPSBwcm9jZXNzLmVudi5NT05HT19PUExPR19VUkw7XG4gIH1cblxuICBpZiAoISBtb25nb1VybClcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJNT05HT19VUkwgbXVzdCBiZSBzZXQgaW4gZW52aXJvbm1lbnRcIik7XG5cbiAgY29uc3QgZHJpdmVyID0gbmV3IE1vbmdvSW50ZXJuYWxzLlJlbW90ZUNvbGxlY3Rpb25Ecml2ZXIobW9uZ29VcmwsIGNvbm5lY3Rpb25PcHRpb25zKTtcblxuICAvLyBBcyBtYW55IGRlcGxveW1lbnQgdG9vbHMsIGluY2x1ZGluZyBNZXRlb3IgVXAsIHNlbmQgcmVxdWVzdHMgdG8gdGhlIGFwcCBpblxuICAvLyBvcmRlciB0byBjb25maXJtIHRoYXQgdGhlIGRlcGxveW1lbnQgZmluaXNoZWQgc3VjY2Vzc2Z1bGx5LCBpdCdzIHJlcXVpcmVkXG4gIC8vIHRvIGtub3cgYWJvdXQgYSBkYXRhYmFzZSBjb25uZWN0aW9uIHByb2JsZW0gYmVmb3JlIHRoZSBhcHAgc3RhcnRzLiBEb2luZyBzb1xuICAvLyBpbiBhIGBNZXRlb3Iuc3RhcnR1cGAgaXMgZmluZSwgYXMgdGhlIGBXZWJBcHBgIGhhbmRsZXMgcmVxdWVzdHMgb25seSBhZnRlclxuICAvLyBhbGwgYXJlIGZpbmlzaGVkLlxuICBNZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gICAgUHJvbWlzZS5hd2FpdChkcml2ZXIubW9uZ28uY2xpZW50LmNvbm5lY3QoKSk7XG4gIH0pO1xuXG4gIHJldHVybiBkcml2ZXI7XG59KTtcbiIsIi8vIG9wdGlvbnMuY29ubmVjdGlvbiwgaWYgZ2l2ZW4sIGlzIGEgTGl2ZWRhdGFDbGllbnQgb3IgTGl2ZWRhdGFTZXJ2ZXJcbi8vIFhYWCBwcmVzZW50bHkgdGhlcmUgaXMgbm8gd2F5IHRvIGRlc3Ryb3kvY2xlYW4gdXAgYSBDb2xsZWN0aW9uXG5pbXBvcnQge1xuICBBU1lOQ19DT0xMRUNUSU9OX01FVEhPRFMsXG4gIGdldEFzeW5jTWV0aG9kTmFtZSxcbn0gZnJvbSAnbWV0ZW9yL21pbmltb25nby9jb25zdGFudHMnO1xuXG5pbXBvcnQgeyBub3JtYWxpemVQcm9qZWN0aW9uIH0gZnJvbSAnLi9tb25nb191dGlscyc7XG5leHBvcnQgZnVuY3Rpb24gd2FyblVzaW5nT2xkQXBpKG1ldGhvZE5hbWUsIGNvbGxlY3Rpb25OYW1lLCBpc0NhbGxlZEZyb21Bc3luYykge1xuICBpZiAoXG4gICAgcHJvY2Vzcy5lbnYuV0FSTl9XSEVOX1VTSU5HX09MRF9BUEkgJiYgLy8gYWxzbyBlbnN1cmVzIGl0IGlzIG9uIHRoZSBzZXJ2ZXJcbiAgICAhaXNDYWxsZWRGcm9tQXN5bmMgLy8gbXVzdCBiZSB0cnVlIG90aGVyd2lzZSB3ZSBzaG91bGQgbG9nXG4gICkge1xuICAgIGlmIChjb2xsZWN0aW9uTmFtZSA9PT0gdW5kZWZpbmVkIHx8IGNvbGxlY3Rpb25OYW1lLmluY2x1ZGVzKCdvcGxvZycpKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnNvbGUud2FybihgXG4gICBcbiAgIENhbGxpbmcgbWV0aG9kICR7Y29sbGVjdGlvbk5hbWV9LiR7bWV0aG9kTmFtZX0gZnJvbSBvbGQgQVBJIG9uIHNlcnZlci5cbiAgIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCwgZnJvbSB0aGUgc2VydmVyLCBpbiB2ZXJzaW9uIDMuXG4gICBUcmFjZSBpcyBiZWxvdzpgKTtcbiAgICBjb25zb2xlLnRyYWNlKCk7XG4gIH1cbn1cbi8qKlxuICogQHN1bW1hcnkgTmFtZXNwYWNlIGZvciBNb25nb0RCLXJlbGF0ZWQgaXRlbXNcbiAqIEBuYW1lc3BhY2VcbiAqL1xuTW9uZ28gPSB7fTtcblxuLyoqXG4gKiBAc3VtbWFyeSBDb25zdHJ1Y3RvciBmb3IgYSBDb2xsZWN0aW9uXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBpbnN0YW5jZW5hbWUgY29sbGVjdGlvblxuICogQGNsYXNzXG4gKiBAcGFyYW0ge1N0cmluZ30gbmFtZSBUaGUgbmFtZSBvZiB0aGUgY29sbGVjdGlvbi4gIElmIG51bGwsIGNyZWF0ZXMgYW4gdW5tYW5hZ2VkICh1bnN5bmNocm9uaXplZCkgbG9jYWwgY29sbGVjdGlvbi5cbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zLmNvbm5lY3Rpb24gVGhlIHNlcnZlciBjb25uZWN0aW9uIHRoYXQgd2lsbCBtYW5hZ2UgdGhpcyBjb2xsZWN0aW9uLiBVc2VzIHRoZSBkZWZhdWx0IGNvbm5lY3Rpb24gaWYgbm90IHNwZWNpZmllZC4gIFBhc3MgdGhlIHJldHVybiB2YWx1ZSBvZiBjYWxsaW5nIFtgRERQLmNvbm5lY3RgXSgjZGRwX2Nvbm5lY3QpIHRvIHNwZWNpZnkgYSBkaWZmZXJlbnQgc2VydmVyLiBQYXNzIGBudWxsYCB0byBzcGVjaWZ5IG5vIGNvbm5lY3Rpb24uIFVubWFuYWdlZCAoYG5hbWVgIGlzIG51bGwpIGNvbGxlY3Rpb25zIGNhbm5vdCBzcGVjaWZ5IGEgY29ubmVjdGlvbi5cbiAqIEBwYXJhbSB7U3RyaW5nfSBvcHRpb25zLmlkR2VuZXJhdGlvbiBUaGUgbWV0aG9kIG9mIGdlbmVyYXRpbmcgdGhlIGBfaWRgIGZpZWxkcyBvZiBuZXcgZG9jdW1lbnRzIGluIHRoaXMgY29sbGVjdGlvbi4gIFBvc3NpYmxlIHZhbHVlczpcblxuIC0gKipgJ1NUUklORydgKio6IHJhbmRvbSBzdHJpbmdzXG4gLSAqKmAnTU9OR08nYCoqOiAgcmFuZG9tIFtgTW9uZ28uT2JqZWN0SURgXSgjbW9uZ29fb2JqZWN0X2lkKSB2YWx1ZXNcblxuVGhlIGRlZmF1bHQgaWQgZ2VuZXJhdGlvbiB0ZWNobmlxdWUgaXMgYCdTVFJJTkcnYC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9wdGlvbnMudHJhbnNmb3JtIEFuIG9wdGlvbmFsIHRyYW5zZm9ybWF0aW9uIGZ1bmN0aW9uLiBEb2N1bWVudHMgd2lsbCBiZSBwYXNzZWQgdGhyb3VnaCB0aGlzIGZ1bmN0aW9uIGJlZm9yZSBiZWluZyByZXR1cm5lZCBmcm9tIGBmZXRjaGAgb3IgYGZpbmRPbmVgLCBhbmQgYmVmb3JlIGJlaW5nIHBhc3NlZCB0byBjYWxsYmFja3Mgb2YgYG9ic2VydmVgLCBgbWFwYCwgYGZvckVhY2hgLCBgYWxsb3dgLCBhbmQgYGRlbnlgLiBUcmFuc2Zvcm1zIGFyZSAqbm90KiBhcHBsaWVkIGZvciB0aGUgY2FsbGJhY2tzIG9mIGBvYnNlcnZlQ2hhbmdlc2Agb3IgdG8gY3Vyc29ycyByZXR1cm5lZCBmcm9tIHB1Ymxpc2ggZnVuY3Rpb25zLlxuICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLmRlZmluZU11dGF0aW9uTWV0aG9kcyBTZXQgdG8gYGZhbHNlYCB0byBza2lwIHNldHRpbmcgdXAgdGhlIG11dGF0aW9uIG1ldGhvZHMgdGhhdCBlbmFibGUgaW5zZXJ0L3VwZGF0ZS9yZW1vdmUgZnJvbSBjbGllbnQgY29kZS4gRGVmYXVsdCBgdHJ1ZWAuXG4gKi9cbk1vbmdvLkNvbGxlY3Rpb24gPSBmdW5jdGlvbiBDb2xsZWN0aW9uKG5hbWUsIG9wdGlvbnMpIHtcbiAgaWYgKCFuYW1lICYmIG5hbWUgIT09IG51bGwpIHtcbiAgICBNZXRlb3IuX2RlYnVnKFxuICAgICAgJ1dhcm5pbmc6IGNyZWF0aW5nIGFub255bW91cyBjb2xsZWN0aW9uLiBJdCB3aWxsIG5vdCBiZSAnICtcbiAgICAgICAgJ3NhdmVkIG9yIHN5bmNocm9uaXplZCBvdmVyIHRoZSBuZXR3b3JrLiAoUGFzcyBudWxsIGZvciAnICtcbiAgICAgICAgJ3RoZSBjb2xsZWN0aW9uIG5hbWUgdG8gdHVybiBvZmYgdGhpcyB3YXJuaW5nLiknXG4gICAgKTtcbiAgICBuYW1lID0gbnVsbDtcbiAgfVxuXG4gIGlmIChuYW1lICE9PSBudWxsICYmIHR5cGVvZiBuYW1lICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdGaXJzdCBhcmd1bWVudCB0byBuZXcgTW9uZ28uQ29sbGVjdGlvbiBtdXN0IGJlIGEgc3RyaW5nIG9yIG51bGwnXG4gICAgKTtcbiAgfVxuXG4gIGlmIChvcHRpb25zICYmIG9wdGlvbnMubWV0aG9kcykge1xuICAgIC8vIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5IGhhY2sgd2l0aCBvcmlnaW5hbCBzaWduYXR1cmUgKHdoaWNoIHBhc3NlZFxuICAgIC8vIFwiY29ubmVjdGlvblwiIGRpcmVjdGx5IGluc3RlYWQgb2YgaW4gb3B0aW9ucy4gKENvbm5lY3Rpb25zIG11c3QgaGF2ZSBhIFwibWV0aG9kc1wiXG4gICAgLy8gbWV0aG9kLilcbiAgICAvLyBYWFggcmVtb3ZlIGJlZm9yZSAxLjBcbiAgICBvcHRpb25zID0geyBjb25uZWN0aW9uOiBvcHRpb25zIH07XG4gIH1cbiAgLy8gQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IFwiY29ubmVjdGlvblwiIHVzZWQgdG8gYmUgY2FsbGVkIFwibWFuYWdlclwiLlxuICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLm1hbmFnZXIgJiYgIW9wdGlvbnMuY29ubmVjdGlvbikge1xuICAgIG9wdGlvbnMuY29ubmVjdGlvbiA9IG9wdGlvbnMubWFuYWdlcjtcbiAgfVxuXG4gIG9wdGlvbnMgPSB7XG4gICAgY29ubmVjdGlvbjogdW5kZWZpbmVkLFxuICAgIGlkR2VuZXJhdGlvbjogJ1NUUklORycsXG4gICAgdHJhbnNmb3JtOiBudWxsLFxuICAgIF9kcml2ZXI6IHVuZGVmaW5lZCxcbiAgICBfcHJldmVudEF1dG9wdWJsaXNoOiBmYWxzZSxcbiAgICAuLi5vcHRpb25zLFxuICB9O1xuXG4gIHN3aXRjaCAob3B0aW9ucy5pZEdlbmVyYXRpb24pIHtcbiAgICBjYXNlICdNT05HTyc6XG4gICAgICB0aGlzLl9tYWtlTmV3SUQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHNyYyA9IG5hbWVcbiAgICAgICAgICA/IEREUC5yYW5kb21TdHJlYW0oJy9jb2xsZWN0aW9uLycgKyBuYW1lKVxuICAgICAgICAgIDogUmFuZG9tLmluc2VjdXJlO1xuICAgICAgICByZXR1cm4gbmV3IE1vbmdvLk9iamVjdElEKHNyYy5oZXhTdHJpbmcoMjQpKTtcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdTVFJJTkcnOlxuICAgIGRlZmF1bHQ6XG4gICAgICB0aGlzLl9tYWtlTmV3SUQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHNyYyA9IG5hbWVcbiAgICAgICAgICA/IEREUC5yYW5kb21TdHJlYW0oJy9jb2xsZWN0aW9uLycgKyBuYW1lKVxuICAgICAgICAgIDogUmFuZG9tLmluc2VjdXJlO1xuICAgICAgICByZXR1cm4gc3JjLmlkKCk7XG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gIH1cblxuICB0aGlzLl90cmFuc2Zvcm0gPSBMb2NhbENvbGxlY3Rpb24ud3JhcFRyYW5zZm9ybShvcHRpb25zLnRyYW5zZm9ybSk7XG5cbiAgaWYgKCFuYW1lIHx8IG9wdGlvbnMuY29ubmVjdGlvbiA9PT0gbnVsbClcbiAgICAvLyBub3RlOiBuYW1lbGVzcyBjb2xsZWN0aW9ucyBuZXZlciBoYXZlIGEgY29ubmVjdGlvblxuICAgIHRoaXMuX2Nvbm5lY3Rpb24gPSBudWxsO1xuICBlbHNlIGlmIChvcHRpb25zLmNvbm5lY3Rpb24pIHRoaXMuX2Nvbm5lY3Rpb24gPSBvcHRpb25zLmNvbm5lY3Rpb247XG4gIGVsc2UgaWYgKE1ldGVvci5pc0NsaWVudCkgdGhpcy5fY29ubmVjdGlvbiA9IE1ldGVvci5jb25uZWN0aW9uO1xuICBlbHNlIHRoaXMuX2Nvbm5lY3Rpb24gPSBNZXRlb3Iuc2VydmVyO1xuXG4gIGlmICghb3B0aW9ucy5fZHJpdmVyKSB7XG4gICAgLy8gWFhYIFRoaXMgY2hlY2sgYXNzdW1lcyB0aGF0IHdlYmFwcCBpcyBsb2FkZWQgc28gdGhhdCBNZXRlb3Iuc2VydmVyICE9PVxuICAgIC8vIG51bGwuIFdlIHNob3VsZCBmdWxseSBzdXBwb3J0IHRoZSBjYXNlIG9mIFwid2FudCB0byB1c2UgYSBNb25nby1iYWNrZWRcbiAgICAvLyBjb2xsZWN0aW9uIGZyb20gTm9kZSBjb2RlIHdpdGhvdXQgd2ViYXBwXCIsIGJ1dCB3ZSBkb24ndCB5ZXQuXG4gICAgLy8gI01ldGVvclNlcnZlck51bGxcbiAgICBpZiAoXG4gICAgICBuYW1lICYmXG4gICAgICB0aGlzLl9jb25uZWN0aW9uID09PSBNZXRlb3Iuc2VydmVyICYmXG4gICAgICB0eXBlb2YgTW9uZ29JbnRlcm5hbHMgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICBNb25nb0ludGVybmFscy5kZWZhdWx0UmVtb3RlQ29sbGVjdGlvbkRyaXZlclxuICAgICkge1xuICAgICAgb3B0aW9ucy5fZHJpdmVyID0gTW9uZ29JbnRlcm5hbHMuZGVmYXVsdFJlbW90ZUNvbGxlY3Rpb25Ecml2ZXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgeyBMb2NhbENvbGxlY3Rpb25Ecml2ZXIgfSA9IHJlcXVpcmUoJy4vbG9jYWxfY29sbGVjdGlvbl9kcml2ZXIuanMnKTtcbiAgICAgIG9wdGlvbnMuX2RyaXZlciA9IExvY2FsQ29sbGVjdGlvbkRyaXZlcjtcbiAgICB9XG4gIH1cblxuICB0aGlzLl9jb2xsZWN0aW9uID0gb3B0aW9ucy5fZHJpdmVyLm9wZW4obmFtZSwgdGhpcy5fY29ubmVjdGlvbik7XG4gIHRoaXMuX25hbWUgPSBuYW1lO1xuICB0aGlzLl9kcml2ZXIgPSBvcHRpb25zLl9kcml2ZXI7XG5cbiAgdGhpcy5fbWF5YmVTZXRVcFJlcGxpY2F0aW9uKG5hbWUsIG9wdGlvbnMpO1xuXG4gIC8vIFhYWCBkb24ndCBkZWZpbmUgdGhlc2UgdW50aWwgYWxsb3cgb3IgZGVueSBpcyBhY3R1YWxseSB1c2VkIGZvciB0aGlzXG4gIC8vIGNvbGxlY3Rpb24uIENvdWxkIGJlIGhhcmQgaWYgdGhlIHNlY3VyaXR5IHJ1bGVzIGFyZSBvbmx5IGRlZmluZWQgb24gdGhlXG4gIC8vIHNlcnZlci5cbiAgaWYgKG9wdGlvbnMuZGVmaW5lTXV0YXRpb25NZXRob2RzICE9PSBmYWxzZSkge1xuICAgIHRyeSB7XG4gICAgICB0aGlzLl9kZWZpbmVNdXRhdGlvbk1ldGhvZHMoe1xuICAgICAgICB1c2VFeGlzdGluZzogb3B0aW9ucy5fc3VwcHJlc3NTYW1lTmFtZUVycm9yID09PSB0cnVlLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIFRocm93IGEgbW9yZSB1bmRlcnN0YW5kYWJsZSBlcnJvciBvbiB0aGUgc2VydmVyIGZvciBzYW1lIGNvbGxlY3Rpb24gbmFtZVxuICAgICAgaWYgKFxuICAgICAgICBlcnJvci5tZXNzYWdlID09PSBgQSBtZXRob2QgbmFtZWQgJy8ke25hbWV9L2luc2VydCcgaXMgYWxyZWFkeSBkZWZpbmVkYFxuICAgICAgKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFRoZXJlIGlzIGFscmVhZHkgYSBjb2xsZWN0aW9uIG5hbWVkIFwiJHtuYW1lfVwiYCk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cblxuICAvLyBhdXRvcHVibGlzaFxuICBpZiAoXG4gICAgUGFja2FnZS5hdXRvcHVibGlzaCAmJlxuICAgICFvcHRpb25zLl9wcmV2ZW50QXV0b3B1Ymxpc2ggJiZcbiAgICB0aGlzLl9jb25uZWN0aW9uICYmXG4gICAgdGhpcy5fY29ubmVjdGlvbi5wdWJsaXNoXG4gICkge1xuICAgIHRoaXMuX2Nvbm5lY3Rpb24ucHVibGlzaChudWxsLCAoKSA9PiB0aGlzLmZpbmQoKSwge1xuICAgICAgaXNfYXV0bzogdHJ1ZSxcbiAgICB9KTtcbiAgfVxufTtcblxuT2JqZWN0LmFzc2lnbihNb25nby5Db2xsZWN0aW9uLnByb3RvdHlwZSwge1xuICBfbWF5YmVTZXRVcFJlcGxpY2F0aW9uKG5hbWUsIHsgX3N1cHByZXNzU2FtZU5hbWVFcnJvciA9IGZhbHNlIH0pIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBpZiAoIShzZWxmLl9jb25uZWN0aW9uICYmIHNlbGYuX2Nvbm5lY3Rpb24ucmVnaXN0ZXJTdG9yZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBPSywgd2UncmUgZ29pbmcgdG8gYmUgYSBzbGF2ZSwgcmVwbGljYXRpbmcgc29tZSByZW1vdGVcbiAgICAvLyBkYXRhYmFzZSwgZXhjZXB0IHBvc3NpYmx5IHdpdGggc29tZSB0ZW1wb3JhcnkgZGl2ZXJnZW5jZSB3aGlsZVxuICAgIC8vIHdlIGhhdmUgdW5hY2tub3dsZWRnZWQgUlBDJ3MuXG4gICAgY29uc3Qgb2sgPSBzZWxmLl9jb25uZWN0aW9uLnJlZ2lzdGVyU3RvcmUobmFtZSwge1xuICAgICAgLy8gQ2FsbGVkIGF0IHRoZSBiZWdpbm5pbmcgb2YgYSBiYXRjaCBvZiB1cGRhdGVzLiBiYXRjaFNpemUgaXMgdGhlIG51bWJlclxuICAgICAgLy8gb2YgdXBkYXRlIGNhbGxzIHRvIGV4cGVjdC5cbiAgICAgIC8vXG4gICAgICAvLyBYWFggVGhpcyBpbnRlcmZhY2UgaXMgcHJldHR5IGphbmt5LiByZXNldCBwcm9iYWJseSBvdWdodCB0byBnbyBiYWNrIHRvXG4gICAgICAvLyBiZWluZyBpdHMgb3duIGZ1bmN0aW9uLCBhbmQgY2FsbGVycyBzaG91bGRuJ3QgaGF2ZSB0byBjYWxjdWxhdGVcbiAgICAgIC8vIGJhdGNoU2l6ZS4gVGhlIG9wdGltaXphdGlvbiBvZiBub3QgY2FsbGluZyBwYXVzZS9yZW1vdmUgc2hvdWxkIGJlXG4gICAgICAvLyBkZWxheWVkIHVudGlsIGxhdGVyOiB0aGUgZmlyc3QgY2FsbCB0byB1cGRhdGUoKSBzaG91bGQgYnVmZmVyIGl0c1xuICAgICAgLy8gbWVzc2FnZSwgYW5kIHRoZW4gd2UgY2FuIGVpdGhlciBkaXJlY3RseSBhcHBseSBpdCBhdCBlbmRVcGRhdGUgdGltZSBpZlxuICAgICAgLy8gaXQgd2FzIHRoZSBvbmx5IHVwZGF0ZSwgb3IgZG8gcGF1c2VPYnNlcnZlcnMvYXBwbHkvYXBwbHkgYXQgdGhlIG5leHRcbiAgICAgIC8vIHVwZGF0ZSgpIGlmIHRoZXJlJ3MgYW5vdGhlciBvbmUuXG4gICAgICBiZWdpblVwZGF0ZShiYXRjaFNpemUsIHJlc2V0KSB7XG4gICAgICAgIC8vIHBhdXNlIG9ic2VydmVycyBzbyB1c2VycyBkb24ndCBzZWUgZmxpY2tlciB3aGVuIHVwZGF0aW5nIHNldmVyYWxcbiAgICAgICAgLy8gb2JqZWN0cyBhdCBvbmNlIChpbmNsdWRpbmcgdGhlIHBvc3QtcmVjb25uZWN0IHJlc2V0LWFuZC1yZWFwcGx5XG4gICAgICAgIC8vIHN0YWdlKSwgYW5kIHNvIHRoYXQgYSByZS1zb3J0aW5nIG9mIGEgcXVlcnkgY2FuIHRha2UgYWR2YW50YWdlIG9mIHRoZVxuICAgICAgICAvLyBmdWxsIF9kaWZmUXVlcnkgbW92ZWQgY2FsY3VsYXRpb24gaW5zdGVhZCBvZiBhcHBseWluZyBjaGFuZ2Ugb25lIGF0IGFcbiAgICAgICAgLy8gdGltZS5cbiAgICAgICAgaWYgKGJhdGNoU2l6ZSA+IDEgfHwgcmVzZXQpIHNlbGYuX2NvbGxlY3Rpb24ucGF1c2VPYnNlcnZlcnMoKTtcblxuICAgICAgICBpZiAocmVzZXQpIHNlbGYuX2NvbGxlY3Rpb24ucmVtb3ZlKHt9KTtcbiAgICAgIH0sXG5cbiAgICAgIC8vIEFwcGx5IGFuIHVwZGF0ZS5cbiAgICAgIC8vIFhYWCBiZXR0ZXIgc3BlY2lmeSB0aGlzIGludGVyZmFjZSAobm90IGluIHRlcm1zIG9mIGEgd2lyZSBtZXNzYWdlKT9cbiAgICAgIHVwZGF0ZShtc2cpIHtcbiAgICAgICAgdmFyIG1vbmdvSWQgPSBNb25nb0lELmlkUGFyc2UobXNnLmlkKTtcbiAgICAgICAgdmFyIGRvYyA9IHNlbGYuX2NvbGxlY3Rpb24uX2RvY3MuZ2V0KG1vbmdvSWQpO1xuXG4gICAgICAgIC8vV2hlbiB0aGUgc2VydmVyJ3MgbWVyZ2Vib3ggaXMgZGlzYWJsZWQgZm9yIGEgY29sbGVjdGlvbiwgdGhlIGNsaWVudCBtdXN0IGdyYWNlZnVsbHkgaGFuZGxlIGl0IHdoZW46XG4gICAgICAgIC8vICpXZSByZWNlaXZlIGFuIGFkZGVkIG1lc3NhZ2UgZm9yIGEgZG9jdW1lbnQgdGhhdCBpcyBhbHJlYWR5IHRoZXJlLiBJbnN0ZWFkLCBpdCB3aWxsIGJlIGNoYW5nZWRcbiAgICAgICAgLy8gKldlIHJlZWl2ZSBhIGNoYW5nZSBtZXNzYWdlIGZvciBhIGRvY3VtZW50IHRoYXQgaXMgbm90IHRoZXJlLiBJbnN0ZWFkLCBpdCB3aWxsIGJlIGFkZGVkXG4gICAgICAgIC8vICpXZSByZWNlaXZlIGEgcmVtb3ZlZCBtZXNzc2FnZSBmb3IgYSBkb2N1bWVudCB0aGF0IGlzIG5vdCB0aGVyZS4gSW5zdGVhZCwgbm90aW5nIHdpbCBoYXBwZW4uXG5cbiAgICAgICAgLy9Db2RlIGlzIGRlcml2ZWQgZnJvbSBjbGllbnQtc2lkZSBjb2RlIG9yaWdpbmFsbHkgaW4gcGVlcmxpYnJhcnk6Y29udHJvbC1tZXJnZWJveFxuICAgICAgICAvL2h0dHBzOi8vZ2l0aHViLmNvbS9wZWVybGlicmFyeS9tZXRlb3ItY29udHJvbC1tZXJnZWJveC9ibG9iL21hc3Rlci9jbGllbnQuY29mZmVlXG5cbiAgICAgICAgLy9Gb3IgbW9yZSBpbmZvcm1hdGlvbiwgcmVmZXIgdG8gZGlzY3Vzc2lvbiBcIkluaXRpYWwgc3VwcG9ydCBmb3IgcHVibGljYXRpb24gc3RyYXRlZ2llcyBpbiBsaXZlZGF0YSBzZXJ2ZXJcIjpcbiAgICAgICAgLy9odHRwczovL2dpdGh1Yi5jb20vbWV0ZW9yL21ldGVvci9wdWxsLzExMTUxXG4gICAgICAgIGlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICAgICAgICBpZiAobXNnLm1zZyA9PT0gJ2FkZGVkJyAmJiBkb2MpIHtcbiAgICAgICAgICAgIG1zZy5tc2cgPSAnY2hhbmdlZCc7XG4gICAgICAgICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAncmVtb3ZlZCcgJiYgIWRvYykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH0gZWxzZSBpZiAobXNnLm1zZyA9PT0gJ2NoYW5nZWQnICYmICFkb2MpIHtcbiAgICAgICAgICAgIG1zZy5tc2cgPSAnYWRkZWQnO1xuICAgICAgICAgICAgX3JlZiA9IG1zZy5maWVsZHM7XG4gICAgICAgICAgICBmb3IgKGZpZWxkIGluIF9yZWYpIHtcbiAgICAgICAgICAgICAgdmFsdWUgPSBfcmVmW2ZpZWxkXTtcbiAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgICAgICBkZWxldGUgbXNnLmZpZWxkc1tmaWVsZF07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJcyB0aGlzIGEgXCJyZXBsYWNlIHRoZSB3aG9sZSBkb2NcIiBtZXNzYWdlIGNvbWluZyBmcm9tIHRoZSBxdWllc2NlbmNlXG4gICAgICAgIC8vIG9mIG1ldGhvZCB3cml0ZXMgdG8gYW4gb2JqZWN0PyAoTm90ZSB0aGF0ICd1bmRlZmluZWQnIGlzIGEgdmFsaWRcbiAgICAgICAgLy8gdmFsdWUgbWVhbmluZyBcInJlbW92ZSBpdFwiLilcbiAgICAgICAgaWYgKG1zZy5tc2cgPT09ICdyZXBsYWNlJykge1xuICAgICAgICAgIHZhciByZXBsYWNlID0gbXNnLnJlcGxhY2U7XG4gICAgICAgICAgaWYgKCFyZXBsYWNlKSB7XG4gICAgICAgICAgICBpZiAoZG9jKSBzZWxmLl9jb2xsZWN0aW9uLnJlbW92ZShtb25nb0lkKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCFkb2MpIHtcbiAgICAgICAgICAgIHNlbGYuX2NvbGxlY3Rpb24uaW5zZXJ0KHJlcGxhY2UpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBYWFggY2hlY2sgdGhhdCByZXBsYWNlIGhhcyBubyAkIG9wc1xuICAgICAgICAgICAgc2VsZi5fY29sbGVjdGlvbi51cGRhdGUobW9uZ29JZCwgcmVwbGFjZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAnYWRkZWQnKSB7XG4gICAgICAgICAgaWYgKGRvYykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAnRXhwZWN0ZWQgbm90IHRvIGZpbmQgYSBkb2N1bWVudCBhbHJlYWR5IHByZXNlbnQgZm9yIGFuIGFkZCdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlbGYuX2NvbGxlY3Rpb24uaW5zZXJ0KHsgX2lkOiBtb25nb0lkLCAuLi5tc2cuZmllbGRzIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKG1zZy5tc2cgPT09ICdyZW1vdmVkJykge1xuICAgICAgICAgIGlmICghZG9jKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAnRXhwZWN0ZWQgdG8gZmluZCBhIGRvY3VtZW50IGFscmVhZHkgcHJlc2VudCBmb3IgcmVtb3ZlZCdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgc2VsZi5fY29sbGVjdGlvbi5yZW1vdmUobW9uZ29JZCk7XG4gICAgICAgIH0gZWxzZSBpZiAobXNnLm1zZyA9PT0gJ2NoYW5nZWQnKSB7XG4gICAgICAgICAgaWYgKCFkb2MpIHRocm93IG5ldyBFcnJvcignRXhwZWN0ZWQgdG8gZmluZCBhIGRvY3VtZW50IHRvIGNoYW5nZScpO1xuICAgICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhtc2cuZmllbGRzKTtcbiAgICAgICAgICBpZiAoa2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB2YXIgbW9kaWZpZXIgPSB7fTtcbiAgICAgICAgICAgIGtleXMuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IG1zZy5maWVsZHNba2V5XTtcbiAgICAgICAgICAgICAgaWYgKEVKU09OLmVxdWFscyhkb2Nba2V5XSwgdmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFtb2RpZmllci4kdW5zZXQpIHtcbiAgICAgICAgICAgICAgICAgIG1vZGlmaWVyLiR1bnNldCA9IHt9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBtb2RpZmllci4kdW5zZXRba2V5XSA9IDE7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKCFtb2RpZmllci4kc2V0KSB7XG4gICAgICAgICAgICAgICAgICBtb2RpZmllci4kc2V0ID0ge307XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG1vZGlmaWVyLiRzZXRba2V5XSA9IHZhbHVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyhtb2RpZmllcikubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICBzZWxmLl9jb2xsZWN0aW9uLnVwZGF0ZShtb25nb0lkLCBtb2RpZmllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkkgZG9uJ3Qga25vdyBob3cgdG8gZGVhbCB3aXRoIHRoaXMgbWVzc2FnZVwiKTtcbiAgICAgICAgfVxuICAgICAgfSxcblxuICAgICAgLy8gQ2FsbGVkIGF0IHRoZSBlbmQgb2YgYSBiYXRjaCBvZiB1cGRhdGVzLlxuICAgICAgZW5kVXBkYXRlKCkge1xuICAgICAgICBzZWxmLl9jb2xsZWN0aW9uLnJlc3VtZU9ic2VydmVycygpO1xuICAgICAgfSxcblxuICAgICAgLy8gQ2FsbGVkIGFyb3VuZCBtZXRob2Qgc3R1YiBpbnZvY2F0aW9ucyB0byBjYXB0dXJlIHRoZSBvcmlnaW5hbCB2ZXJzaW9uc1xuICAgICAgLy8gb2YgbW9kaWZpZWQgZG9jdW1lbnRzLlxuICAgICAgc2F2ZU9yaWdpbmFscygpIHtcbiAgICAgICAgc2VsZi5fY29sbGVjdGlvbi5zYXZlT3JpZ2luYWxzKCk7XG4gICAgICB9LFxuICAgICAgcmV0cmlldmVPcmlnaW5hbHMoKSB7XG4gICAgICAgIHJldHVybiBzZWxmLl9jb2xsZWN0aW9uLnJldHJpZXZlT3JpZ2luYWxzKCk7XG4gICAgICB9LFxuXG4gICAgICAvLyBVc2VkIHRvIHByZXNlcnZlIGN1cnJlbnQgdmVyc2lvbnMgb2YgZG9jdW1lbnRzIGFjcm9zcyBhIHN0b3JlIHJlc2V0LlxuICAgICAgZ2V0RG9jKGlkKSB7XG4gICAgICAgIHJldHVybiBzZWxmLmZpbmRPbmUoaWQpO1xuICAgICAgfSxcblxuICAgICAgLy8gVG8gYmUgYWJsZSB0byBnZXQgYmFjayB0byB0aGUgY29sbGVjdGlvbiBmcm9tIHRoZSBzdG9yZS5cbiAgICAgIF9nZXRDb2xsZWN0aW9uKCkge1xuICAgICAgICByZXR1cm4gc2VsZjtcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBpZiAoIW9rKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0gYFRoZXJlIGlzIGFscmVhZHkgYSBjb2xsZWN0aW9uIG5hbWVkIFwiJHtuYW1lfVwiYDtcbiAgICAgIGlmIChfc3VwcHJlc3NTYW1lTmFtZUVycm9yID09PSB0cnVlKSB7XG4gICAgICAgIC8vIFhYWCBJbiB0aGVvcnkgd2UgZG8gbm90IGhhdmUgdG8gdGhyb3cgd2hlbiBgb2tgIGlzIGZhbHN5LiBUaGVcbiAgICAgICAgLy8gc3RvcmUgaXMgYWxyZWFkeSBkZWZpbmVkIGZvciB0aGlzIGNvbGxlY3Rpb24gbmFtZSwgYnV0IHRoaXNcbiAgICAgICAgLy8gd2lsbCBzaW1wbHkgYmUgYW5vdGhlciByZWZlcmVuY2UgdG8gaXQgYW5kIGV2ZXJ5dGhpbmcgc2hvdWxkXG4gICAgICAgIC8vIHdvcmsuIEhvd2V2ZXIsIHdlIGhhdmUgaGlzdG9yaWNhbGx5IHRocm93biBhbiBlcnJvciBoZXJlLCBzb1xuICAgICAgICAvLyBmb3Igbm93IHdlIHdpbGwgc2tpcCB0aGUgZXJyb3Igb25seSB3aGVuIF9zdXBwcmVzc1NhbWVOYW1lRXJyb3JcbiAgICAgICAgLy8gaXMgYHRydWVgLCBhbGxvd2luZyBwZW9wbGUgdG8gb3B0IGluIGFuZCBnaXZlIHRoaXMgc29tZSByZWFsXG4gICAgICAgIC8vIHdvcmxkIHRlc3RpbmcuXG4gICAgICAgIGNvbnNvbGUud2FybiA/IGNvbnNvbGUud2FybihtZXNzYWdlKSA6IGNvbnNvbGUubG9nKG1lc3NhZ2UpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICAgICAgfVxuICAgIH1cbiAgfSxcblxuICAvLy9cbiAgLy8vIE1haW4gY29sbGVjdGlvbiBBUElcbiAgLy8vXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBHZXRzIHRoZSBudW1iZXIgb2YgZG9jdW1lbnRzIG1hdGNoaW5nIHRoZSBmaWx0ZXIuIEZvciBhIGZhc3QgY291bnQgb2YgdGhlIHRvdGFsIGRvY3VtZW50cyBpbiBhIGNvbGxlY3Rpb24gc2VlIGBlc3RpbWF0ZWREb2N1bWVudENvdW50YC5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgY291bnREb2N1bWVudHNcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gW3NlbGVjdG9yXSBBIHF1ZXJ5IGRlc2NyaWJpbmcgdGhlIGRvY3VtZW50cyB0byBjb3VudFxuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdIEFsbCBvcHRpb25zIGFyZSBsaXN0ZWQgaW4gW01vbmdvREIgZG9jdW1lbnRhdGlvbl0oaHR0cHM6Ly9tb25nb2RiLmdpdGh1Yi5pby9ub2RlLW1vbmdvZGItbmF0aXZlLzQuMTEvaW50ZXJmYWNlcy9Db3VudERvY3VtZW50c09wdGlvbnMuaHRtbCkuIFBsZWFzZSBub3RlIHRoYXQgbm90IGFsbCBvZiB0aGVtIGFyZSBhdmFpbGFibGUgb24gdGhlIGNsaWVudC5cbiAgICogQHJldHVybnMge1Byb21pc2U8bnVtYmVyPn1cbiAgICovXG4gIGNvdW50RG9jdW1lbnRzKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5jb3VudERvY3VtZW50cyguLi5hcmdzKTtcbiAgfSxcblxuICAvKipcbiAgICogQHN1bW1hcnkgR2V0cyBhbiBlc3RpbWF0ZSBvZiB0aGUgY291bnQgb2YgZG9jdW1lbnRzIGluIGEgY29sbGVjdGlvbiB1c2luZyBjb2xsZWN0aW9uIG1ldGFkYXRhLiBGb3IgYW4gZXhhY3QgY291bnQgb2YgdGhlIGRvY3VtZW50cyBpbiBhIGNvbGxlY3Rpb24gc2VlIGBjb3VudERvY3VtZW50c2AuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWV0aG9kIGVzdGltYXRlZERvY3VtZW50Q291bnRcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gQWxsIG9wdGlvbnMgYXJlIGxpc3RlZCBpbiBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL21vbmdvZGIuZ2l0aHViLmlvL25vZGUtbW9uZ29kYi1uYXRpdmUvNC4xMS9pbnRlcmZhY2VzL0VzdGltYXRlZERvY3VtZW50Q291bnRPcHRpb25zLmh0bWwpLiBQbGVhc2Ugbm90ZSB0aGF0IG5vdCBhbGwgb2YgdGhlbSBhcmUgYXZhaWxhYmxlIG9uIHRoZSBjbGllbnQuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPG51bWJlcj59XG4gICAqL1xuICBlc3RpbWF0ZWREb2N1bWVudENvdW50KC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5lc3RpbWF0ZWREb2N1bWVudENvdW50KC4uLmFyZ3MpO1xuICB9LFxuXG4gIF9nZXRGaW5kU2VsZWN0b3IoYXJncykge1xuICAgIGlmIChhcmdzLmxlbmd0aCA9PSAwKSByZXR1cm4ge307XG4gICAgZWxzZSByZXR1cm4gYXJnc1swXTtcbiAgfSxcblxuICBfZ2V0RmluZE9wdGlvbnMoYXJncykge1xuICAgIGNvbnN0IFssIG9wdGlvbnNdID0gYXJncyB8fCBbXTtcbiAgICBjb25zdCBuZXdPcHRpb25zID0gbm9ybWFsaXplUHJvamVjdGlvbihvcHRpb25zKTtcblxuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoYXJncy5sZW5ndGggPCAyKSB7XG4gICAgICByZXR1cm4geyB0cmFuc2Zvcm06IHNlbGYuX3RyYW5zZm9ybSB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBjaGVjayhcbiAgICAgICAgbmV3T3B0aW9ucyxcbiAgICAgICAgTWF0Y2guT3B0aW9uYWwoXG4gICAgICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHtcbiAgICAgICAgICAgIHByb2plY3Rpb246IE1hdGNoLk9wdGlvbmFsKE1hdGNoLk9uZU9mKE9iamVjdCwgdW5kZWZpbmVkKSksXG4gICAgICAgICAgICBzb3J0OiBNYXRjaC5PcHRpb25hbChcbiAgICAgICAgICAgICAgTWF0Y2guT25lT2YoT2JqZWN0LCBBcnJheSwgRnVuY3Rpb24sIHVuZGVmaW5lZClcbiAgICAgICAgICAgICksXG4gICAgICAgICAgICBsaW1pdDogTWF0Y2guT3B0aW9uYWwoTWF0Y2guT25lT2YoTnVtYmVyLCB1bmRlZmluZWQpKSxcbiAgICAgICAgICAgIHNraXA6IE1hdGNoLk9wdGlvbmFsKE1hdGNoLk9uZU9mKE51bWJlciwgdW5kZWZpbmVkKSksXG4gICAgICAgICAgfSlcbiAgICAgICAgKVxuICAgICAgKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdHJhbnNmb3JtOiBzZWxmLl90cmFuc2Zvcm0sXG4gICAgICAgIC4uLm5ld09wdGlvbnMsXG4gICAgICB9O1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogQHN1bW1hcnkgRmluZCB0aGUgZG9jdW1lbnRzIGluIGEgY29sbGVjdGlvbiB0aGF0IG1hdGNoIHRoZSBzZWxlY3Rvci5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgZmluZFxuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtNb25nb1NlbGVjdG9yfSBbc2VsZWN0b3JdIEEgcXVlcnkgZGVzY3JpYmluZyB0aGUgZG9jdW1lbnRzIHRvIGZpbmRcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgKiBAcGFyYW0ge01vbmdvU29ydFNwZWNpZmllcn0gb3B0aW9ucy5zb3J0IFNvcnQgb3JkZXIgKGRlZmF1bHQ6IG5hdHVyYWwgb3JkZXIpXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLnNraXAgTnVtYmVyIG9mIHJlc3VsdHMgdG8gc2tpcCBhdCB0aGUgYmVnaW5uaW5nXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLmxpbWl0IE1heGltdW0gbnVtYmVyIG9mIHJlc3VsdHMgdG8gcmV0dXJuXG4gICAqIEBwYXJhbSB7TW9uZ29GaWVsZFNwZWNpZmllcn0gb3B0aW9ucy5maWVsZHMgRGljdGlvbmFyeSBvZiBmaWVsZHMgdG8gcmV0dXJuIG9yIGV4Y2x1ZGUuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5yZWFjdGl2ZSAoQ2xpZW50IG9ubHkpIERlZmF1bHQgYHRydWVgOyBwYXNzIGBmYWxzZWAgdG8gZGlzYWJsZSByZWFjdGl2aXR5XG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IG9wdGlvbnMudHJhbnNmb3JtIE92ZXJyaWRlcyBgdHJhbnNmb3JtYCBvbiB0aGUgIFtgQ29sbGVjdGlvbmBdKCNjb2xsZWN0aW9ucykgZm9yIHRoaXMgY3Vyc29yLiAgUGFzcyBgbnVsbGAgdG8gZGlzYWJsZSB0cmFuc2Zvcm1hdGlvbi5cbiAgICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLmRpc2FibGVPcGxvZyAoU2VydmVyIG9ubHkpIFBhc3MgdHJ1ZSB0byBkaXNhYmxlIG9wbG9nLXRhaWxpbmcgb24gdGhpcyBxdWVyeS4gVGhpcyBhZmZlY3RzIHRoZSB3YXkgc2VydmVyIHByb2Nlc3NlcyBjYWxscyB0byBgb2JzZXJ2ZWAgb24gdGhpcyBxdWVyeS4gRGlzYWJsaW5nIHRoZSBvcGxvZyBjYW4gYmUgdXNlZnVsIHdoZW4gd29ya2luZyB3aXRoIGRhdGEgdGhhdCB1cGRhdGVzIGluIGxhcmdlIGJhdGNoZXMuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLnBvbGxpbmdJbnRlcnZhbE1zIChTZXJ2ZXIgb25seSkgV2hlbiBvcGxvZyBpcyBkaXNhYmxlZCAodGhyb3VnaCB0aGUgdXNlIG9mIGBkaXNhYmxlT3Bsb2dgIG9yIHdoZW4gb3RoZXJ3aXNlIG5vdCBhdmFpbGFibGUpLCB0aGUgZnJlcXVlbmN5IChpbiBtaWxsaXNlY29uZHMpIG9mIGhvdyBvZnRlbiB0byBwb2xsIHRoaXMgcXVlcnkgd2hlbiBvYnNlcnZpbmcgb24gdGhlIHNlcnZlci4gRGVmYXVsdHMgdG8gMTAwMDBtcyAoMTAgc2Vjb25kcykuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLnBvbGxpbmdUaHJvdHRsZU1zIChTZXJ2ZXIgb25seSkgV2hlbiBvcGxvZyBpcyBkaXNhYmxlZCAodGhyb3VnaCB0aGUgdXNlIG9mIGBkaXNhYmxlT3Bsb2dgIG9yIHdoZW4gb3RoZXJ3aXNlIG5vdCBhdmFpbGFibGUpLCB0aGUgbWluaW11bSB0aW1lIChpbiBtaWxsaXNlY29uZHMpIHRvIGFsbG93IGJldHdlZW4gcmUtcG9sbGluZyB3aGVuIG9ic2VydmluZyBvbiB0aGUgc2VydmVyLiBJbmNyZWFzaW5nIHRoaXMgd2lsbCBzYXZlIENQVSBhbmQgbW9uZ28gbG9hZCBhdCB0aGUgZXhwZW5zZSBvZiBzbG93ZXIgdXBkYXRlcyB0byB1c2Vycy4gRGVjcmVhc2luZyB0aGlzIGlzIG5vdCByZWNvbW1lbmRlZC4gRGVmYXVsdHMgdG8gNTBtcy5cbiAgICogQHBhcmFtIHtOdW1iZXJ9IG9wdGlvbnMubWF4VGltZU1zIChTZXJ2ZXIgb25seSkgSWYgc2V0LCBpbnN0cnVjdHMgTW9uZ29EQiB0byBzZXQgYSB0aW1lIGxpbWl0IGZvciB0aGlzIGN1cnNvcidzIG9wZXJhdGlvbnMuIElmIHRoZSBvcGVyYXRpb24gcmVhY2hlcyB0aGUgc3BlY2lmaWVkIHRpbWUgbGltaXQgKGluIG1pbGxpc2Vjb25kcykgd2l0aG91dCB0aGUgaGF2aW5nIGJlZW4gY29tcGxldGVkLCBhbiBleGNlcHRpb24gd2lsbCBiZSB0aHJvd24uIFVzZWZ1bCB0byBwcmV2ZW50IGFuIChhY2NpZGVudGFsIG9yIG1hbGljaW91cykgdW5vcHRpbWl6ZWQgcXVlcnkgZnJvbSBjYXVzaW5nIGEgZnVsbCBjb2xsZWN0aW9uIHNjYW4gdGhhdCB3b3VsZCBkaXNydXB0IG90aGVyIGRhdGFiYXNlIHVzZXJzLCBhdCB0aGUgZXhwZW5zZSBvZiBuZWVkaW5nIHRvIGhhbmRsZSB0aGUgcmVzdWx0aW5nIGVycm9yLlxuICAgKiBAcGFyYW0ge1N0cmluZ3xPYmplY3R9IG9wdGlvbnMuaGludCAoU2VydmVyIG9ubHkpIE92ZXJyaWRlcyBNb25nb0RCJ3MgZGVmYXVsdCBpbmRleCBzZWxlY3Rpb24gYW5kIHF1ZXJ5IG9wdGltaXphdGlvbiBwcm9jZXNzLiBTcGVjaWZ5IGFuIGluZGV4IHRvIGZvcmNlIGl0cyB1c2UsIGVpdGhlciBieSBpdHMgbmFtZSBvciBpbmRleCBzcGVjaWZpY2F0aW9uLiBZb3UgY2FuIGFsc28gc3BlY2lmeSBgeyAkbmF0dXJhbCA6IDEgfWAgdG8gZm9yY2UgYSBmb3J3YXJkcyBjb2xsZWN0aW9uIHNjYW4sIG9yIGB7ICRuYXR1cmFsIDogLTEgfWAgZm9yIGEgcmV2ZXJzZSBjb2xsZWN0aW9uIHNjYW4uIFNldHRpbmcgdGhpcyBpcyBvbmx5IHJlY29tbWVuZGVkIGZvciBhZHZhbmNlZCB1c2Vycy5cbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdGlvbnMucmVhZFByZWZlcmVuY2UgKFNlcnZlciBvbmx5KSBTcGVjaWZpZXMgYSBjdXN0b20gTW9uZ29EQiBbYHJlYWRQcmVmZXJlbmNlYF0oaHR0cHM6Ly9kb2NzLm1vbmdvZGIuY29tL21hbnVhbC9jb3JlL3JlYWQtcHJlZmVyZW5jZSkgZm9yIHRoaXMgcGFydGljdWxhciBjdXJzb3IuIFBvc3NpYmxlIHZhbHVlcyBhcmUgYHByaW1hcnlgLCBgcHJpbWFyeVByZWZlcnJlZGAsIGBzZWNvbmRhcnlgLCBgc2Vjb25kYXJ5UHJlZmVycmVkYCBhbmQgYG5lYXJlc3RgLlxuICAgKiBAcmV0dXJucyB7TW9uZ28uQ3Vyc29yfVxuICAgKi9cbiAgZmluZCguLi5hcmdzKSB7XG4gICAgLy8gQ29sbGVjdGlvbi5maW5kKCkgKHJldHVybiBhbGwgZG9jcykgYmVoYXZlcyBkaWZmZXJlbnRseVxuICAgIC8vIGZyb20gQ29sbGVjdGlvbi5maW5kKHVuZGVmaW5lZCkgKHJldHVybiAwIGRvY3MpLiAgc28gYmVcbiAgICAvLyBjYXJlZnVsIGFib3V0IHRoZSBsZW5ndGggb2YgYXJndW1lbnRzLlxuICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLmZpbmQoXG4gICAgICB0aGlzLl9nZXRGaW5kU2VsZWN0b3IoYXJncyksXG4gICAgICB0aGlzLl9nZXRGaW5kT3B0aW9ucyhhcmdzKVxuICAgICk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEZpbmRzIHRoZSBmaXJzdCBkb2N1bWVudCB0aGF0IG1hdGNoZXMgdGhlIHNlbGVjdG9yLCBhcyBvcmRlcmVkIGJ5IHNvcnQgYW5kIHNraXAgb3B0aW9ucy4gUmV0dXJucyBgdW5kZWZpbmVkYCBpZiBubyBtYXRjaGluZyBkb2N1bWVudCBpcyBmb3VuZC5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgZmluZE9uZVxuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtNb25nb1NlbGVjdG9yfSBbc2VsZWN0b3JdIEEgcXVlcnkgZGVzY3JpYmluZyB0aGUgZG9jdW1lbnRzIHRvIGZpbmRcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgKiBAcGFyYW0ge01vbmdvU29ydFNwZWNpZmllcn0gb3B0aW9ucy5zb3J0IFNvcnQgb3JkZXIgKGRlZmF1bHQ6IG5hdHVyYWwgb3JkZXIpXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLnNraXAgTnVtYmVyIG9mIHJlc3VsdHMgdG8gc2tpcCBhdCB0aGUgYmVnaW5uaW5nXG4gICAqIEBwYXJhbSB7TW9uZ29GaWVsZFNwZWNpZmllcn0gb3B0aW9ucy5maWVsZHMgRGljdGlvbmFyeSBvZiBmaWVsZHMgdG8gcmV0dXJuIG9yIGV4Y2x1ZGUuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5yZWFjdGl2ZSAoQ2xpZW50IG9ubHkpIERlZmF1bHQgdHJ1ZTsgcGFzcyBmYWxzZSB0byBkaXNhYmxlIHJlYWN0aXZpdHlcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gb3B0aW9ucy50cmFuc2Zvcm0gT3ZlcnJpZGVzIGB0cmFuc2Zvcm1gIG9uIHRoZSBbYENvbGxlY3Rpb25gXSgjY29sbGVjdGlvbnMpIGZvciB0aGlzIGN1cnNvci4gIFBhc3MgYG51bGxgIHRvIGRpc2FibGUgdHJhbnNmb3JtYXRpb24uXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBvcHRpb25zLnJlYWRQcmVmZXJlbmNlIChTZXJ2ZXIgb25seSkgU3BlY2lmaWVzIGEgY3VzdG9tIE1vbmdvREIgW2ByZWFkUHJlZmVyZW5jZWBdKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvY29yZS9yZWFkLXByZWZlcmVuY2UpIGZvciBmZXRjaGluZyB0aGUgZG9jdW1lbnQuIFBvc3NpYmxlIHZhbHVlcyBhcmUgYHByaW1hcnlgLCBgcHJpbWFyeVByZWZlcnJlZGAsIGBzZWNvbmRhcnlgLCBgc2Vjb25kYXJ5UHJlZmVycmVkYCBhbmQgYG5lYXJlc3RgLlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgZmluZE9uZSguLi5hcmdzKSB7XG4gICAgLy8gW0ZJQkVSU11cbiAgICAvLyBUT0RPOiBSZW1vdmUgdGhpcyB3aGVuIDMuMCBpcyByZWxlYXNlZC5cbiAgICB3YXJuVXNpbmdPbGRBcGkoJ2ZpbmRPbmUnLCB0aGlzLl9uYW1lLCB0aGlzLmZpbmRPbmUuaXNDYWxsZWRGcm9tQXN5bmMpO1xuICAgIHRoaXMuZmluZE9uZS5pc0NhbGxlZEZyb21Bc3luYyA9IGZhbHNlO1xuXG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZmluZE9uZShcbiAgICAgIHRoaXMuX2dldEZpbmRTZWxlY3RvcihhcmdzKSxcbiAgICAgIHRoaXMuX2dldEZpbmRPcHRpb25zKGFyZ3MpXG4gICAgKTtcbiAgfSxcbn0pO1xuXG5PYmplY3QuYXNzaWduKE1vbmdvLkNvbGxlY3Rpb24sIHtcbiAgX3B1Ymxpc2hDdXJzb3IoY3Vyc29yLCBzdWIsIGNvbGxlY3Rpb24pIHtcbiAgICB2YXIgb2JzZXJ2ZUhhbmRsZSA9IGN1cnNvci5vYnNlcnZlQ2hhbmdlcyhcbiAgICAgIHtcbiAgICAgICAgYWRkZWQ6IGZ1bmN0aW9uKGlkLCBmaWVsZHMpIHtcbiAgICAgICAgICBzdWIuYWRkZWQoY29sbGVjdGlvbiwgaWQsIGZpZWxkcyk7XG4gICAgICAgIH0sXG4gICAgICAgIGNoYW5nZWQ6IGZ1bmN0aW9uKGlkLCBmaWVsZHMpIHtcbiAgICAgICAgICBzdWIuY2hhbmdlZChjb2xsZWN0aW9uLCBpZCwgZmllbGRzKTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVtb3ZlZDogZnVuY3Rpb24oaWQpIHtcbiAgICAgICAgICBzdWIucmVtb3ZlZChjb2xsZWN0aW9uLCBpZCk7XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgLy8gUHVibGljYXRpb25zIGRvbid0IG11dGF0ZSB0aGUgZG9jdW1lbnRzXG4gICAgICAvLyBUaGlzIGlzIHRlc3RlZCBieSB0aGUgYGxpdmVkYXRhIC0gcHVibGlzaCBjYWxsYmFja3MgY2xvbmVgIHRlc3RcbiAgICAgIHsgbm9uTXV0YXRpbmdDYWxsYmFja3M6IHRydWUgfVxuICAgICk7XG5cbiAgICAvLyBXZSBkb24ndCBjYWxsIHN1Yi5yZWFkeSgpIGhlcmU6IGl0IGdldHMgY2FsbGVkIGluIGxpdmVkYXRhX3NlcnZlciwgYWZ0ZXJcbiAgICAvLyBwb3NzaWJseSBjYWxsaW5nIF9wdWJsaXNoQ3Vyc29yIG9uIG11bHRpcGxlIHJldHVybmVkIGN1cnNvcnMuXG5cbiAgICAvLyByZWdpc3RlciBzdG9wIGNhbGxiYWNrIChleHBlY3RzIGxhbWJkYSB3LyBubyBhcmdzKS5cbiAgICBzdWIub25TdG9wKGZ1bmN0aW9uKCkge1xuICAgICAgb2JzZXJ2ZUhhbmRsZS5zdG9wKCk7XG4gICAgfSk7XG5cbiAgICAvLyByZXR1cm4gdGhlIG9ic2VydmVIYW5kbGUgaW4gY2FzZSBpdCBuZWVkcyB0byBiZSBzdG9wcGVkIGVhcmx5XG4gICAgcmV0dXJuIG9ic2VydmVIYW5kbGU7XG4gIH0sXG5cbiAgLy8gcHJvdGVjdCBhZ2FpbnN0IGRhbmdlcm91cyBzZWxlY3RvcnMuICBmYWxzZXkgYW5kIHtfaWQ6IGZhbHNleX0gYXJlIGJvdGhcbiAgLy8gbGlrZWx5IHByb2dyYW1tZXIgZXJyb3IsIGFuZCBub3Qgd2hhdCB5b3Ugd2FudCwgcGFydGljdWxhcmx5IGZvciBkZXN0cnVjdGl2ZVxuICAvLyBvcGVyYXRpb25zLiBJZiBhIGZhbHNleSBfaWQgaXMgc2VudCBpbiwgYSBuZXcgc3RyaW5nIF9pZCB3aWxsIGJlXG4gIC8vIGdlbmVyYXRlZCBhbmQgcmV0dXJuZWQ7IGlmIGEgZmFsbGJhY2tJZCBpcyBwcm92aWRlZCwgaXQgd2lsbCBiZSByZXR1cm5lZFxuICAvLyBpbnN0ZWFkLlxuICBfcmV3cml0ZVNlbGVjdG9yKHNlbGVjdG9yLCB7IGZhbGxiYWNrSWQgfSA9IHt9KSB7XG4gICAgLy8gc2hvcnRoYW5kIC0tIHNjYWxhcnMgbWF0Y2ggX2lkXG4gICAgaWYgKExvY2FsQ29sbGVjdGlvbi5fc2VsZWN0b3JJc0lkKHNlbGVjdG9yKSkgc2VsZWN0b3IgPSB7IF9pZDogc2VsZWN0b3IgfTtcblxuICAgIGlmIChBcnJheS5pc0FycmF5KHNlbGVjdG9yKSkge1xuICAgICAgLy8gVGhpcyBpcyBjb25zaXN0ZW50IHdpdGggdGhlIE1vbmdvIGNvbnNvbGUgaXRzZWxmOyBpZiB3ZSBkb24ndCBkbyB0aGlzXG4gICAgICAvLyBjaGVjayBwYXNzaW5nIGFuIGVtcHR5IGFycmF5IGVuZHMgdXAgc2VsZWN0aW5nIGFsbCBpdGVtc1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTW9uZ28gc2VsZWN0b3IgY2FuJ3QgYmUgYW4gYXJyYXkuXCIpO1xuICAgIH1cblxuICAgIGlmICghc2VsZWN0b3IgfHwgKCdfaWQnIGluIHNlbGVjdG9yICYmICFzZWxlY3Rvci5faWQpKSB7XG4gICAgICAvLyBjYW4ndCBtYXRjaCBhbnl0aGluZ1xuICAgICAgcmV0dXJuIHsgX2lkOiBmYWxsYmFja0lkIHx8IFJhbmRvbS5pZCgpIH07XG4gICAgfVxuXG4gICAgcmV0dXJuIHNlbGVjdG9yO1xuICB9LFxufSk7XG5cbk9iamVjdC5hc3NpZ24oTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGUsIHtcbiAgLy8gJ2luc2VydCcgaW1tZWRpYXRlbHkgcmV0dXJucyB0aGUgaW5zZXJ0ZWQgZG9jdW1lbnQncyBuZXcgX2lkLlxuICAvLyBUaGUgb3RoZXJzIHJldHVybiB2YWx1ZXMgaW1tZWRpYXRlbHkgaWYgeW91IGFyZSBpbiBhIHN0dWIsIGFuIGluLW1lbW9yeVxuICAvLyB1bm1hbmFnZWQgY29sbGVjdGlvbiwgb3IgYSBtb25nby1iYWNrZWQgY29sbGVjdGlvbiBhbmQgeW91IGRvbid0IHBhc3MgYVxuICAvLyBjYWxsYmFjay4gJ3VwZGF0ZScgYW5kICdyZW1vdmUnIHJldHVybiB0aGUgbnVtYmVyIG9mIGFmZmVjdGVkXG4gIC8vIGRvY3VtZW50cy4gJ3Vwc2VydCcgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCBrZXlzICdudW1iZXJBZmZlY3RlZCcgYW5kLCBpZiBhblxuICAvLyBpbnNlcnQgaGFwcGVuZWQsICdpbnNlcnRlZElkJy5cbiAgLy9cbiAgLy8gT3RoZXJ3aXNlLCB0aGUgc2VtYW50aWNzIGFyZSBleGFjdGx5IGxpa2Ugb3RoZXIgbWV0aG9kczogdGhleSB0YWtlXG4gIC8vIGEgY2FsbGJhY2sgYXMgYW4gb3B0aW9uYWwgbGFzdCBhcmd1bWVudDsgaWYgbm8gY2FsbGJhY2sgaXNcbiAgLy8gcHJvdmlkZWQsIHRoZXkgYmxvY2sgdW50aWwgdGhlIG9wZXJhdGlvbiBpcyBjb21wbGV0ZSwgYW5kIHRocm93IGFuXG4gIC8vIGV4Y2VwdGlvbiBpZiBpdCBmYWlsczsgaWYgYSBjYWxsYmFjayBpcyBwcm92aWRlZCwgdGhlbiB0aGV5IGRvbid0XG4gIC8vIG5lY2Vzc2FyaWx5IGJsb2NrLCBhbmQgdGhleSBjYWxsIHRoZSBjYWxsYmFjayB3aGVuIHRoZXkgZmluaXNoIHdpdGggZXJyb3IgYW5kXG4gIC8vIHJlc3VsdCBhcmd1bWVudHMuICAoVGhlIGluc2VydCBtZXRob2QgcHJvdmlkZXMgdGhlIGRvY3VtZW50IElEIGFzIGl0cyByZXN1bHQ7XG4gIC8vIHVwZGF0ZSBhbmQgcmVtb3ZlIHByb3ZpZGUgdGhlIG51bWJlciBvZiBhZmZlY3RlZCBkb2NzIGFzIHRoZSByZXN1bHQ7IHVwc2VydFxuICAvLyBwcm92aWRlcyBhbiBvYmplY3Qgd2l0aCBudW1iZXJBZmZlY3RlZCBhbmQgbWF5YmUgaW5zZXJ0ZWRJZC4pXG4gIC8vXG4gIC8vIE9uIHRoZSBjbGllbnQsIGJsb2NraW5nIGlzIGltcG9zc2libGUsIHNvIGlmIGEgY2FsbGJhY2tcbiAgLy8gaXNuJ3QgcHJvdmlkZWQsIHRoZXkganVzdCByZXR1cm4gaW1tZWRpYXRlbHkgYW5kIGFueSBlcnJvclxuICAvLyBpbmZvcm1hdGlvbiBpcyBsb3N0LlxuICAvL1xuICAvLyBUaGVyZSdzIG9uZSBtb3JlIHR3ZWFrLiBPbiB0aGUgY2xpZW50LCBpZiB5b3UgZG9uJ3QgcHJvdmlkZSBhXG4gIC8vIGNhbGxiYWNrLCB0aGVuIGlmIHRoZXJlIGlzIGFuIGVycm9yLCBhIG1lc3NhZ2Ugd2lsbCBiZSBsb2dnZWQgd2l0aFxuICAvLyBNZXRlb3IuX2RlYnVnLlxuICAvL1xuICAvLyBUaGUgaW50ZW50ICh0aG91Z2ggdGhpcyBpcyBhY3R1YWxseSBkZXRlcm1pbmVkIGJ5IHRoZSB1bmRlcmx5aW5nXG4gIC8vIGRyaXZlcnMpIGlzIHRoYXQgdGhlIG9wZXJhdGlvbnMgc2hvdWxkIGJlIGRvbmUgc3luY2hyb25vdXNseSwgbm90XG4gIC8vIGdlbmVyYXRpbmcgdGhlaXIgcmVzdWx0IHVudGlsIHRoZSBkYXRhYmFzZSBoYXMgYWNrbm93bGVkZ2VkXG4gIC8vIHRoZW0uIEluIHRoZSBmdXR1cmUgbWF5YmUgd2Ugc2hvdWxkIHByb3ZpZGUgYSBmbGFnIHRvIHR1cm4gdGhpc1xuICAvLyBvZmYuXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEluc2VydCBhIGRvY3VtZW50IGluIHRoZSBjb2xsZWN0aW9uLiAgUmV0dXJucyBpdHMgdW5pcXVlIF9pZC5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgIGluc2VydFxuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtPYmplY3R9IGRvYyBUaGUgZG9jdW1lbnQgdG8gaW5zZXJ0LiBNYXkgbm90IHlldCBoYXZlIGFuIF9pZCBhdHRyaWJ1dGUsIGluIHdoaWNoIGNhc2UgTWV0ZW9yIHdpbGwgZ2VuZXJhdGUgb25lIGZvciB5b3UuXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IFtjYWxsYmFja10gT3B0aW9uYWwuICBJZiBwcmVzZW50LCBjYWxsZWQgd2l0aCBhbiBlcnJvciBvYmplY3QgYXMgdGhlIGZpcnN0IGFyZ3VtZW50IGFuZCwgaWYgbm8gZXJyb3IsIHRoZSBfaWQgYXMgdGhlIHNlY29uZC5cbiAgICovXG4gIGluc2VydChkb2MsIGNhbGxiYWNrKSB7XG4gICAgLy8gTWFrZSBzdXJlIHdlIHdlcmUgcGFzc2VkIGEgZG9jdW1lbnQgdG8gaW5zZXJ0XG4gICAgaWYgKCFkb2MpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignaW5zZXJ0IHJlcXVpcmVzIGFuIGFyZ3VtZW50Jyk7XG4gICAgfVxuXG4gICAgLy8gW0ZJQkVSU11cbiAgICAvLyBUT0RPOiBSZW1vdmUgdGhpcyB3aGVuIDMuMCBpcyByZWxlYXNlZC5cbiAgICB3YXJuVXNpbmdPbGRBcGkoJ2luc2VydCcsIHRoaXMuX25hbWUsIHRoaXMuaW5zZXJ0LmlzQ2FsbGVkRnJvbUFzeW5jKTtcbiAgICB0aGlzLmluc2VydC5pc0NhbGxlZEZyb21Bc3luYyA9IGZhbHNlO1xuXG4gICAgLy8gTWFrZSBhIHNoYWxsb3cgY2xvbmUgb2YgdGhlIGRvY3VtZW50LCBwcmVzZXJ2aW5nIGl0cyBwcm90b3R5cGUuXG4gICAgZG9jID0gT2JqZWN0LmNyZWF0ZShcbiAgICAgIE9iamVjdC5nZXRQcm90b3R5cGVPZihkb2MpLFxuICAgICAgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMoZG9jKVxuICAgICk7XG5cbiAgICBpZiAoJ19pZCcgaW4gZG9jKSB7XG4gICAgICBpZiAoXG4gICAgICAgICFkb2MuX2lkIHx8XG4gICAgICAgICEodHlwZW9mIGRvYy5faWQgPT09ICdzdHJpbmcnIHx8IGRvYy5faWQgaW5zdGFuY2VvZiBNb25nby5PYmplY3RJRClcbiAgICAgICkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgJ01ldGVvciByZXF1aXJlcyBkb2N1bWVudCBfaWQgZmllbGRzIHRvIGJlIG5vbi1lbXB0eSBzdHJpbmdzIG9yIE9iamVjdElEcydcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IGdlbmVyYXRlSWQgPSB0cnVlO1xuXG4gICAgICAvLyBEb24ndCBnZW5lcmF0ZSB0aGUgaWQgaWYgd2UncmUgdGhlIGNsaWVudCBhbmQgdGhlICdvdXRlcm1vc3QnIGNhbGxcbiAgICAgIC8vIFRoaXMgb3B0aW1pemF0aW9uIHNhdmVzIHVzIHBhc3NpbmcgYm90aCB0aGUgcmFuZG9tU2VlZCBhbmQgdGhlIGlkXG4gICAgICAvLyBQYXNzaW5nIGJvdGggaXMgcmVkdW5kYW50LlxuICAgICAgaWYgKHRoaXMuX2lzUmVtb3RlQ29sbGVjdGlvbigpKSB7XG4gICAgICAgIGNvbnN0IGVuY2xvc2luZyA9IEREUC5fQ3VycmVudE1ldGhvZEludm9jYXRpb24uZ2V0KCk7XG4gICAgICAgIGlmICghZW5jbG9zaW5nKSB7XG4gICAgICAgICAgZ2VuZXJhdGVJZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChnZW5lcmF0ZUlkKSB7XG4gICAgICAgIGRvYy5faWQgPSB0aGlzLl9tYWtlTmV3SUQoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBPbiBpbnNlcnRzLCBhbHdheXMgcmV0dXJuIHRoZSBpZCB0aGF0IHdlIGdlbmVyYXRlZDsgb24gYWxsIG90aGVyXG4gICAgLy8gb3BlcmF0aW9ucywganVzdCByZXR1cm4gdGhlIHJlc3VsdCBmcm9tIHRoZSBjb2xsZWN0aW9uLlxuICAgIHZhciBjaG9vc2VSZXR1cm5WYWx1ZUZyb21Db2xsZWN0aW9uUmVzdWx0ID0gZnVuY3Rpb24ocmVzdWx0KSB7XG4gICAgICBpZiAoZG9jLl9pZCkge1xuICAgICAgICByZXR1cm4gZG9jLl9pZDtcbiAgICAgIH1cblxuICAgICAgLy8gWFhYIHdoYXQgaXMgdGhpcyBmb3I/P1xuICAgICAgLy8gSXQncyBzb21lIGl0ZXJhY3Rpb24gYmV0d2VlbiB0aGUgY2FsbGJhY2sgdG8gX2NhbGxNdXRhdG9yTWV0aG9kIGFuZFxuICAgICAgLy8gdGhlIHJldHVybiB2YWx1ZSBjb252ZXJzaW9uXG4gICAgICBkb2MuX2lkID0gcmVzdWx0O1xuXG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG5cbiAgICBjb25zdCB3cmFwcGVkQ2FsbGJhY2sgPSB3cmFwQ2FsbGJhY2soXG4gICAgICBjYWxsYmFjayxcbiAgICAgIGNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHRcbiAgICApO1xuXG4gICAgaWYgKHRoaXMuX2lzUmVtb3RlQ29sbGVjdGlvbigpKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSB0aGlzLl9jYWxsTXV0YXRvck1ldGhvZCgnaW5zZXJ0JywgW2RvY10sIHdyYXBwZWRDYWxsYmFjayk7XG4gICAgICByZXR1cm4gY2hvb3NlUmV0dXJuVmFsdWVGcm9tQ29sbGVjdGlvblJlc3VsdChyZXN1bHQpO1xuICAgIH1cblxuICAgIC8vIGl0J3MgbXkgY29sbGVjdGlvbi4gIGRlc2NlbmQgaW50byB0aGUgY29sbGVjdGlvbiBvYmplY3RcbiAgICAvLyBhbmQgcHJvcGFnYXRlIGFueSBleGNlcHRpb24uXG4gICAgdHJ5IHtcbiAgICAgIC8vIElmIHRoZSB1c2VyIHByb3ZpZGVkIGEgY2FsbGJhY2sgYW5kIHRoZSBjb2xsZWN0aW9uIGltcGxlbWVudHMgdGhpc1xuICAgICAgLy8gb3BlcmF0aW9uIGFzeW5jaHJvbm91c2x5LCB0aGVuIHF1ZXJ5UmV0IHdpbGwgYmUgdW5kZWZpbmVkLCBhbmQgdGhlXG4gICAgICAvLyByZXN1bHQgd2lsbCBiZSByZXR1cm5lZCB0aHJvdWdoIHRoZSBjYWxsYmFjayBpbnN0ZWFkLlxuICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5fY29sbGVjdGlvbi5pbnNlcnQoZG9jLCB3cmFwcGVkQ2FsbGJhY2spO1xuICAgICAgcmV0dXJuIGNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHQocmVzdWx0KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgICAgY2FsbGJhY2soZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IE1vZGlmeSBvbmUgb3IgbW9yZSBkb2N1bWVudHMgaW4gdGhlIGNvbGxlY3Rpb24uIFJldHVybnMgdGhlIG51bWJlciBvZiBtYXRjaGVkIGRvY3VtZW50cy5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgdXBkYXRlXG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge01vbmdvU2VsZWN0b3J9IHNlbGVjdG9yIFNwZWNpZmllcyB3aGljaCBkb2N1bWVudHMgdG8gbW9kaWZ5XG4gICAqIEBwYXJhbSB7TW9uZ29Nb2RpZmllcn0gbW9kaWZpZXIgU3BlY2lmaWVzIGhvdyB0byBtb2RpZnkgdGhlIGRvY3VtZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5tdWx0aSBUcnVlIHRvIG1vZGlmeSBhbGwgbWF0Y2hpbmcgZG9jdW1lbnRzOyBmYWxzZSB0byBvbmx5IG1vZGlmeSBvbmUgb2YgdGhlIG1hdGNoaW5nIGRvY3VtZW50cyAodGhlIGRlZmF1bHQpLlxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMudXBzZXJ0IFRydWUgdG8gaW5zZXJ0IGEgZG9jdW1lbnQgaWYgbm8gbWF0Y2hpbmcgZG9jdW1lbnRzIGFyZSBmb3VuZC5cbiAgICogQHBhcmFtIHtBcnJheX0gb3B0aW9ucy5hcnJheUZpbHRlcnMgT3B0aW9uYWwuIFVzZWQgaW4gY29tYmluYXRpb24gd2l0aCBNb25nb0RCIFtmaWx0ZXJlZCBwb3NpdGlvbmFsIG9wZXJhdG9yXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL3JlZmVyZW5jZS9vcGVyYXRvci91cGRhdGUvcG9zaXRpb25hbC1maWx0ZXJlZC8pIHRvIHNwZWNpZnkgd2hpY2ggZWxlbWVudHMgdG8gbW9kaWZ5IGluIGFuIGFycmF5IGZpZWxkLlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBbY2FsbGJhY2tdIE9wdGlvbmFsLiAgSWYgcHJlc2VudCwgY2FsbGVkIHdpdGggYW4gZXJyb3Igb2JqZWN0IGFzIHRoZSBmaXJzdCBhcmd1bWVudCBhbmQsIGlmIG5vIGVycm9yLCB0aGUgbnVtYmVyIG9mIGFmZmVjdGVkIGRvY3VtZW50cyBhcyB0aGUgc2Vjb25kLlxuICAgKi9cbiAgdXBkYXRlKHNlbGVjdG9yLCBtb2RpZmllciwgLi4ub3B0aW9uc0FuZENhbGxiYWNrKSB7XG4gICAgY29uc3QgY2FsbGJhY2sgPSBwb3BDYWxsYmFja0Zyb21BcmdzKG9wdGlvbnNBbmRDYWxsYmFjayk7XG5cbiAgICAvLyBXZSd2ZSBhbHJlYWR5IHBvcHBlZCBvZmYgdGhlIGNhbGxiYWNrLCBzbyB3ZSBhcmUgbGVmdCB3aXRoIGFuIGFycmF5XG4gICAgLy8gb2Ygb25lIG9yIHplcm8gaXRlbXNcbiAgICBjb25zdCBvcHRpb25zID0geyAuLi4ob3B0aW9uc0FuZENhbGxiYWNrWzBdIHx8IG51bGwpIH07XG4gICAgbGV0IGluc2VydGVkSWQ7XG4gICAgaWYgKG9wdGlvbnMgJiYgb3B0aW9ucy51cHNlcnQpIHtcbiAgICAgIC8vIHNldCBgaW5zZXJ0ZWRJZGAgaWYgYWJzZW50LiAgYGluc2VydGVkSWRgIGlzIGEgTWV0ZW9yIGV4dGVuc2lvbi5cbiAgICAgIGlmIChvcHRpb25zLmluc2VydGVkSWQpIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICEoXG4gICAgICAgICAgICB0eXBlb2Ygb3B0aW9ucy5pbnNlcnRlZElkID09PSAnc3RyaW5nJyB8fFxuICAgICAgICAgICAgb3B0aW9ucy5pbnNlcnRlZElkIGluc3RhbmNlb2YgTW9uZ28uT2JqZWN0SURcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2luc2VydGVkSWQgbXVzdCBiZSBzdHJpbmcgb3IgT2JqZWN0SUQnKTtcbiAgICAgICAgaW5zZXJ0ZWRJZCA9IG9wdGlvbnMuaW5zZXJ0ZWRJZDtcbiAgICAgIH0gZWxzZSBpZiAoIXNlbGVjdG9yIHx8ICFzZWxlY3Rvci5faWQpIHtcbiAgICAgICAgaW5zZXJ0ZWRJZCA9IHRoaXMuX21ha2VOZXdJRCgpO1xuICAgICAgICBvcHRpb25zLmdlbmVyYXRlZElkID0gdHJ1ZTtcbiAgICAgICAgb3B0aW9ucy5pbnNlcnRlZElkID0gaW5zZXJ0ZWRJZDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBbRklCRVJTXVxuICAgIC8vIFRPRE86IFJlbW92ZSB0aGlzIHdoZW4gMy4wIGlzIHJlbGVhc2VkLlxuICAgIHdhcm5Vc2luZ09sZEFwaSgndXBkYXRlJywgdGhpcy5fbmFtZSwgdGhpcy51cGRhdGUuaXNDYWxsZWRGcm9tQXN5bmMpO1xuICAgIHRoaXMudXBkYXRlLmlzQ2FsbGVkRnJvbUFzeW5jID0gZmFsc2U7XG5cbiAgICBzZWxlY3RvciA9IE1vbmdvLkNvbGxlY3Rpb24uX3Jld3JpdGVTZWxlY3RvcihzZWxlY3Rvciwge1xuICAgICAgZmFsbGJhY2tJZDogaW5zZXJ0ZWRJZCxcbiAgICB9KTtcblxuICAgIGNvbnN0IHdyYXBwZWRDYWxsYmFjayA9IHdyYXBDYWxsYmFjayhjYWxsYmFjayk7XG5cbiAgICBpZiAodGhpcy5faXNSZW1vdGVDb2xsZWN0aW9uKCkpIHtcbiAgICAgIGNvbnN0IGFyZ3MgPSBbc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zXTtcblxuICAgICAgcmV0dXJuIHRoaXMuX2NhbGxNdXRhdG9yTWV0aG9kKCd1cGRhdGUnLCBhcmdzLCB3cmFwcGVkQ2FsbGJhY2spO1xuICAgIH1cblxuICAgIC8vIGl0J3MgbXkgY29sbGVjdGlvbi4gIGRlc2NlbmQgaW50byB0aGUgY29sbGVjdGlvbiBvYmplY3RcbiAgICAvLyBhbmQgcHJvcGFnYXRlIGFueSBleGNlcHRpb24uXG4gICAgdHJ5IHtcbiAgICAgIC8vIElmIHRoZSB1c2VyIHByb3ZpZGVkIGEgY2FsbGJhY2sgYW5kIHRoZSBjb2xsZWN0aW9uIGltcGxlbWVudHMgdGhpc1xuICAgICAgLy8gb3BlcmF0aW9uIGFzeW5jaHJvbm91c2x5LCB0aGVuIHF1ZXJ5UmV0IHdpbGwgYmUgdW5kZWZpbmVkLCBhbmQgdGhlXG4gICAgICAvLyByZXN1bHQgd2lsbCBiZSByZXR1cm5lZCB0aHJvdWdoIHRoZSBjYWxsYmFjayBpbnN0ZWFkLlxuICAgICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24udXBkYXRlKFxuICAgICAgICBzZWxlY3RvcixcbiAgICAgICAgbW9kaWZpZXIsXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICAgIHdyYXBwZWRDYWxsYmFja1xuICAgICAgKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgICAgY2FsbGJhY2soZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFJlbW92ZSBkb2N1bWVudHMgZnJvbSB0aGUgY29sbGVjdGlvblxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1ldGhvZCByZW1vdmVcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gc2VsZWN0b3IgU3BlY2lmaWVzIHdoaWNoIGRvY3VtZW50cyB0byByZW1vdmVcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gW2NhbGxiYWNrXSBPcHRpb25hbC4gIElmIHByZXNlbnQsIGNhbGxlZCB3aXRoIGFuIGVycm9yIG9iamVjdCBhcyBpdHMgYXJndW1lbnQuXG4gICAqL1xuICByZW1vdmUoc2VsZWN0b3IsIGNhbGxiYWNrKSB7XG4gICAgc2VsZWN0b3IgPSBNb25nby5Db2xsZWN0aW9uLl9yZXdyaXRlU2VsZWN0b3Ioc2VsZWN0b3IpO1xuXG4gICAgY29uc3Qgd3JhcHBlZENhbGxiYWNrID0gd3JhcENhbGxiYWNrKGNhbGxiYWNrKTtcblxuICAgIGlmICh0aGlzLl9pc1JlbW90ZUNvbGxlY3Rpb24oKSkge1xuICAgICAgcmV0dXJuIHRoaXMuX2NhbGxNdXRhdG9yTWV0aG9kKCdyZW1vdmUnLCBbc2VsZWN0b3JdLCB3cmFwcGVkQ2FsbGJhY2spO1xuICAgIH1cblxuICAgIC8vIFtGSUJFUlNdXG4gICAgLy8gVE9ETzogUmVtb3ZlIHRoaXMgd2hlbiAzLjAgaXMgcmVsZWFzZWQuXG4gICAgd2FyblVzaW5nT2xkQXBpKCdyZW1vdmUnLCB0aGlzLl9uYW1lLCB0aGlzLnJlbW92ZS5pc0NhbGxlZEZyb21Bc3luYyk7XG4gICAgdGhpcy5yZW1vdmUuaXNDYWxsZWRGcm9tQXN5bmMgPSBmYWxzZTtcbiAgICAvLyBpdCdzIG15IGNvbGxlY3Rpb24uICBkZXNjZW5kIGludG8gdGhlIGNvbGxlY3Rpb24gb2JqZWN0XG4gICAgLy8gYW5kIHByb3BhZ2F0ZSBhbnkgZXhjZXB0aW9uLlxuICAgIHRyeSB7XG4gICAgICAvLyBJZiB0aGUgdXNlciBwcm92aWRlZCBhIGNhbGxiYWNrIGFuZCB0aGUgY29sbGVjdGlvbiBpbXBsZW1lbnRzIHRoaXNcbiAgICAgIC8vIG9wZXJhdGlvbiBhc3luY2hyb25vdXNseSwgdGhlbiBxdWVyeVJldCB3aWxsIGJlIHVuZGVmaW5lZCwgYW5kIHRoZVxuICAgICAgLy8gcmVzdWx0IHdpbGwgYmUgcmV0dXJuZWQgdGhyb3VnaCB0aGUgY2FsbGJhY2sgaW5zdGVhZC5cbiAgICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLnJlbW92ZShzZWxlY3Rvciwgd3JhcHBlZENhbGxiYWNrKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgICAgY2FsbGJhY2soZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH0sXG5cbiAgLy8gRGV0ZXJtaW5lIGlmIHRoaXMgY29sbGVjdGlvbiBpcyBzaW1wbHkgYSBtaW5pbW9uZ28gcmVwcmVzZW50YXRpb24gb2YgYSByZWFsXG4gIC8vIGRhdGFiYXNlIG9uIGFub3RoZXIgc2VydmVyXG4gIF9pc1JlbW90ZUNvbGxlY3Rpb24oKSB7XG4gICAgLy8gWFhYIHNlZSAjTWV0ZW9yU2VydmVyTnVsbFxuICAgIHJldHVybiB0aGlzLl9jb25uZWN0aW9uICYmIHRoaXMuX2Nvbm5lY3Rpb24gIT09IE1ldGVvci5zZXJ2ZXI7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IE1vZGlmeSBvbmUgb3IgbW9yZSBkb2N1bWVudHMgaW4gdGhlIGNvbGxlY3Rpb24sIG9yIGluc2VydCBvbmUgaWYgbm8gbWF0Y2hpbmcgZG9jdW1lbnRzIHdlcmUgZm91bmQuIFJldHVybnMgYW4gb2JqZWN0IHdpdGgga2V5cyBgbnVtYmVyQWZmZWN0ZWRgICh0aGUgbnVtYmVyIG9mIGRvY3VtZW50cyBtb2RpZmllZCkgIGFuZCBgaW5zZXJ0ZWRJZGAgKHRoZSB1bmlxdWUgX2lkIG9mIHRoZSBkb2N1bWVudCB0aGF0IHdhcyBpbnNlcnRlZCwgaWYgYW55KS5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgdXBzZXJ0XG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge01vbmdvU2VsZWN0b3J9IHNlbGVjdG9yIFNwZWNpZmllcyB3aGljaCBkb2N1bWVudHMgdG8gbW9kaWZ5XG4gICAqIEBwYXJhbSB7TW9uZ29Nb2RpZmllcn0gbW9kaWZpZXIgU3BlY2lmaWVzIGhvdyB0byBtb2RpZnkgdGhlIGRvY3VtZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5tdWx0aSBUcnVlIHRvIG1vZGlmeSBhbGwgbWF0Y2hpbmcgZG9jdW1lbnRzOyBmYWxzZSB0byBvbmx5IG1vZGlmeSBvbmUgb2YgdGhlIG1hdGNoaW5nIGRvY3VtZW50cyAodGhlIGRlZmF1bHQpLlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBbY2FsbGJhY2tdIE9wdGlvbmFsLiAgSWYgcHJlc2VudCwgY2FsbGVkIHdpdGggYW4gZXJyb3Igb2JqZWN0IGFzIHRoZSBmaXJzdCBhcmd1bWVudCBhbmQsIGlmIG5vIGVycm9yLCB0aGUgbnVtYmVyIG9mIGFmZmVjdGVkIGRvY3VtZW50cyBhcyB0aGUgc2Vjb25kLlxuICAgKi9cbiAgdXBzZXJ0KHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucywgY2FsbGJhY2spIHtcbiAgICBpZiAoIWNhbGxiYWNrICYmIHR5cGVvZiBvcHRpb25zID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjYWxsYmFjayA9IG9wdGlvbnM7XG4gICAgICBvcHRpb25zID0ge307XG4gICAgfVxuXG4gICAgLy8gW0ZJQkVSU11cbiAgICAvLyBUT0RPOiBSZW1vdmUgdGhpcyB3aGVuIDMuMCBpcyByZWxlYXNlZC5cbiAgICB3YXJuVXNpbmdPbGRBcGkoJ3Vwc2VydCcsIHRoaXMuX25hbWUsIHRoaXMudXBzZXJ0LmlzQ2FsbGVkRnJvbUFzeW5jKTtcbiAgICB0aGlzLnVwc2VydC5pc0NhbGxlZEZyb21Bc3luYyA9IGZhbHNlO1xuICAgIC8vIGNhdWdodCBoZXJlIGh0dHBzOi8vZ2l0aHViLmNvbS9tZXRlb3IvbWV0ZW9yL2lzc3Vlcy8xMjYyNlxuICAgIHRoaXMudXBkYXRlLmlzQ2FsbGVkRnJvbUFzeW5jID0gdHJ1ZTsgLy8gdG8gbm90IHRyaWdnZXIgb24gdGhlIG5leHQgY2FsbFxuICAgIHJldHVybiB0aGlzLnVwZGF0ZShcbiAgICAgIHNlbGVjdG9yLFxuICAgICAgbW9kaWZpZXIsXG4gICAgICB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIF9yZXR1cm5PYmplY3Q6IHRydWUsXG4gICAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICAgIH0sXG4gICAgICBjYWxsYmFja1xuICAgICk7XG4gIH0sXG5cbiAgLy8gV2UnbGwgYWN0dWFsbHkgZGVzaWduIGFuIGluZGV4IEFQSSBsYXRlci4gRm9yIG5vdywgd2UganVzdCBwYXNzIHRocm91Z2ggdG9cbiAgLy8gTW9uZ28ncywgYnV0IG1ha2UgaXQgc3luY2hyb25vdXMuXG4gIF9lbnN1cmVJbmRleChpbmRleCwgb3B0aW9ucykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoIXNlbGYuX2NvbGxlY3Rpb24uX2Vuc3VyZUluZGV4IHx8ICFzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUluZGV4KVxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW4gb25seSBjYWxsIGNyZWF0ZUluZGV4IG9uIHNlcnZlciBjb2xsZWN0aW9ucycpO1xuICAgIGlmIChzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUluZGV4KSB7XG4gICAgICBzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUluZGV4KGluZGV4LCBvcHRpb25zKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW1wb3J0IHsgTG9nIH0gZnJvbSAnbWV0ZW9yL2xvZ2dpbmcnO1xuICAgICAgTG9nLmRlYnVnKFxuICAgICAgICBgX2Vuc3VyZUluZGV4IGhhcyBiZWVuIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgdGhlIG5ldyAnY3JlYXRlSW5kZXgnIGluc3RlYWQke1xuICAgICAgICAgIG9wdGlvbnM/Lm5hbWVcbiAgICAgICAgICAgID8gYCwgaW5kZXggbmFtZTogJHtvcHRpb25zLm5hbWV9YFxuICAgICAgICAgICAgOiBgLCBpbmRleDogJHtKU09OLnN0cmluZ2lmeShpbmRleCl9YFxuICAgICAgICB9YFxuICAgICAgKTtcbiAgICAgIHNlbGYuX2NvbGxlY3Rpb24uX2Vuc3VyZUluZGV4KGluZGV4LCBvcHRpb25zKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IENyZWF0ZXMgdGhlIHNwZWNpZmllZCBpbmRleCBvbiB0aGUgY29sbGVjdGlvbi5cbiAgICogQGxvY3VzIHNlcnZlclxuICAgKiBAbWV0aG9kIGNyZWF0ZUluZGV4XG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge09iamVjdH0gaW5kZXggQSBkb2N1bWVudCB0aGF0IGNvbnRhaW5zIHRoZSBmaWVsZCBhbmQgdmFsdWUgcGFpcnMgd2hlcmUgdGhlIGZpZWxkIGlzIHRoZSBpbmRleCBrZXkgYW5kIHRoZSB2YWx1ZSBkZXNjcmliZXMgdGhlIHR5cGUgb2YgaW5kZXggZm9yIHRoYXQgZmllbGQuIEZvciBhbiBhc2NlbmRpbmcgaW5kZXggb24gYSBmaWVsZCwgc3BlY2lmeSBhIHZhbHVlIG9mIGAxYDsgZm9yIGRlc2NlbmRpbmcgaW5kZXgsIHNwZWNpZnkgYSB2YWx1ZSBvZiBgLTFgLiBVc2UgYHRleHRgIGZvciB0ZXh0IGluZGV4ZXMuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gQWxsIG9wdGlvbnMgYXJlIGxpc3RlZCBpbiBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL3JlZmVyZW5jZS9tZXRob2QvZGIuY29sbGVjdGlvbi5jcmVhdGVJbmRleC8jb3B0aW9ucylcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdGlvbnMubmFtZSBOYW1lIG9mIHRoZSBpbmRleFxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMudW5pcXVlIERlZmluZSB0aGF0IHRoZSBpbmRleCB2YWx1ZXMgbXVzdCBiZSB1bmlxdWUsIG1vcmUgYXQgW01vbmdvREIgZG9jdW1lbnRhdGlvbl0oaHR0cHM6Ly9kb2NzLm1vbmdvZGIuY29tL21hbnVhbC9jb3JlL2luZGV4LXVuaXF1ZS8pXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5zcGFyc2UgRGVmaW5lIHRoYXQgdGhlIGluZGV4IGlzIHNwYXJzZSwgbW9yZSBhdCBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL2NvcmUvaW5kZXgtc3BhcnNlLylcbiAgICovXG4gIGNyZWF0ZUluZGV4KGluZGV4LCBvcHRpb25zKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICghc2VsZi5fY29sbGVjdGlvbi5jcmVhdGVJbmRleClcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2FuIG9ubHkgY2FsbCBjcmVhdGVJbmRleCBvbiBzZXJ2ZXIgY29sbGVjdGlvbnMnKTtcbiAgICAvLyBbRklCRVJTXVxuICAgIC8vIFRPRE86IFJlbW92ZSB0aGlzIHdoZW4gMy4wIGlzIHJlbGVhc2VkLlxuICAgIHdhcm5Vc2luZ09sZEFwaShcbiAgICAgICdjcmVhdGVJbmRleCcsXG4gICAgICBzZWxmLl9uYW1lLFxuICAgICAgc2VsZi5jcmVhdGVJbmRleC5pc0NhbGxlZEZyb21Bc3luY1xuICAgICk7XG4gICAgc2VsZi5jcmVhdGVJbmRleC5pc0NhbGxlZEZyb21Bc3luYyA9IGZhbHNlO1xuICAgIHRyeSB7XG4gICAgICBzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUluZGV4KGluZGV4LCBvcHRpb25zKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoXG4gICAgICAgIGUubWVzc2FnZS5pbmNsdWRlcyhcbiAgICAgICAgICAnQW4gZXF1aXZhbGVudCBpbmRleCBhbHJlYWR5IGV4aXN0cyB3aXRoIHRoZSBzYW1lIG5hbWUgYnV0IGRpZmZlcmVudCBvcHRpb25zLidcbiAgICAgICAgKSAmJlxuICAgICAgICBNZXRlb3Iuc2V0dGluZ3M/LnBhY2thZ2VzPy5tb25nbz8ucmVDcmVhdGVJbmRleE9uT3B0aW9uTWlzbWF0Y2hcbiAgICAgICkge1xuICAgICAgICBpbXBvcnQgeyBMb2cgfSBmcm9tICdtZXRlb3IvbG9nZ2luZyc7XG5cbiAgICAgICAgTG9nLmluZm8oXG4gICAgICAgICAgYFJlLWNyZWF0aW5nIGluZGV4ICR7aW5kZXh9IGZvciAke3NlbGYuX25hbWV9IGR1ZSB0byBvcHRpb25zIG1pc21hdGNoLmBcbiAgICAgICAgKTtcbiAgICAgICAgc2VsZi5fY29sbGVjdGlvbi5fZHJvcEluZGV4KGluZGV4KTtcbiAgICAgICAgc2VsZi5fY29sbGVjdGlvbi5jcmVhdGVJbmRleChpbmRleCwgb3B0aW9ucyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAgIGBBbiBlcnJvciBvY2N1cnJlZCB3aGVuIGNyZWF0aW5nIGFuIGluZGV4IGZvciBjb2xsZWN0aW9uIFwiJHtzZWxmLl9uYW1lfTogJHtlLm1lc3NhZ2V9YFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfSxcblxuICBfZHJvcEluZGV4KGluZGV4KSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICghc2VsZi5fY29sbGVjdGlvbi5fZHJvcEluZGV4KVxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW4gb25seSBjYWxsIF9kcm9wSW5kZXggb24gc2VydmVyIGNvbGxlY3Rpb25zJyk7XG4gICAgc2VsZi5fY29sbGVjdGlvbi5fZHJvcEluZGV4KGluZGV4KTtcbiAgfSxcblxuICBfZHJvcENvbGxlY3Rpb24oKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICghc2VsZi5fY29sbGVjdGlvbi5kcm9wQ29sbGVjdGlvbilcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2FuIG9ubHkgY2FsbCBfZHJvcENvbGxlY3Rpb24gb24gc2VydmVyIGNvbGxlY3Rpb25zJyk7XG4gICAgc2VsZi5fY29sbGVjdGlvbi5kcm9wQ29sbGVjdGlvbigpO1xuICB9LFxuXG4gIF9jcmVhdGVDYXBwZWRDb2xsZWN0aW9uKGJ5dGVTaXplLCBtYXhEb2N1bWVudHMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKCFzZWxmLl9jb2xsZWN0aW9uLl9jcmVhdGVDYXBwZWRDb2xsZWN0aW9uKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnQ2FuIG9ubHkgY2FsbCBfY3JlYXRlQ2FwcGVkQ29sbGVjdGlvbiBvbiBzZXJ2ZXIgY29sbGVjdGlvbnMnXG4gICAgICApO1xuXG4gICAgLy8gW0ZJQkVSU11cbiAgICAvLyBUT0RPOiBSZW1vdmUgdGhpcyB3aGVuIDMuMCBpcyByZWxlYXNlZC5cbiAgICB3YXJuVXNpbmdPbGRBcGkoXG4gICAgICAnX2NyZWF0ZUNhcHBlZENvbGxlY3Rpb24nLFxuICAgICAgc2VsZi5fbmFtZSxcbiAgICAgIHNlbGYuX2NyZWF0ZUNhcHBlZENvbGxlY3Rpb24uaXNDYWxsZWRGcm9tQXN5bmNcbiAgICApO1xuICAgIHNlbGYuX2NyZWF0ZUNhcHBlZENvbGxlY3Rpb24uaXNDYWxsZWRGcm9tQXN5bmMgPSBmYWxzZTtcbiAgICBzZWxmLl9jb2xsZWN0aW9uLl9jcmVhdGVDYXBwZWRDb2xsZWN0aW9uKGJ5dGVTaXplLCBtYXhEb2N1bWVudHMpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIHRoZSBbYENvbGxlY3Rpb25gXShodHRwOi8vbW9uZ29kYi5naXRodWIuaW8vbm9kZS1tb25nb2RiLW5hdGl2ZS8zLjAvYXBpL0NvbGxlY3Rpb24uaHRtbCkgb2JqZWN0IGNvcnJlc3BvbmRpbmcgdG8gdGhpcyBjb2xsZWN0aW9uIGZyb20gdGhlIFtucG0gYG1vbmdvZGJgIGRyaXZlciBtb2R1bGVdKGh0dHBzOi8vd3d3Lm5wbWpzLmNvbS9wYWNrYWdlL21vbmdvZGIpIHdoaWNoIGlzIHdyYXBwZWQgYnkgYE1vbmdvLkNvbGxlY3Rpb25gLlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKi9cbiAgcmF3Q29sbGVjdGlvbigpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKCFzZWxmLl9jb2xsZWN0aW9uLnJhd0NvbGxlY3Rpb24pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2FuIG9ubHkgY2FsbCByYXdDb2xsZWN0aW9uIG9uIHNlcnZlciBjb2xsZWN0aW9ucycpO1xuICAgIH1cbiAgICByZXR1cm4gc2VsZi5fY29sbGVjdGlvbi5yYXdDb2xsZWN0aW9uKCk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgdGhlIFtgRGJgXShodHRwOi8vbW9uZ29kYi5naXRodWIuaW8vbm9kZS1tb25nb2RiLW5hdGl2ZS8zLjAvYXBpL0RiLmh0bWwpIG9iamVjdCBjb3JyZXNwb25kaW5nIHRvIHRoaXMgY29sbGVjdGlvbidzIGRhdGFiYXNlIGNvbm5lY3Rpb24gZnJvbSB0aGUgW25wbSBgbW9uZ29kYmAgZHJpdmVyIG1vZHVsZV0oaHR0cHM6Ly93d3cubnBtanMuY29tL3BhY2thZ2UvbW9uZ29kYikgd2hpY2ggaXMgd3JhcHBlZCBieSBgTW9uZ28uQ29sbGVjdGlvbmAuXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqL1xuICByYXdEYXRhYmFzZSgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKCEoc2VsZi5fZHJpdmVyLm1vbmdvICYmIHNlbGYuX2RyaXZlci5tb25nby5kYikpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2FuIG9ubHkgY2FsbCByYXdEYXRhYmFzZSBvbiBzZXJ2ZXIgY29sbGVjdGlvbnMnKTtcbiAgICB9XG4gICAgcmV0dXJuIHNlbGYuX2RyaXZlci5tb25nby5kYjtcbiAgfSxcbn0pO1xuXG4vLyBDb252ZXJ0IHRoZSBjYWxsYmFjayB0byBub3QgcmV0dXJuIGEgcmVzdWx0IGlmIHRoZXJlIGlzIGFuIGVycm9yXG5mdW5jdGlvbiB3cmFwQ2FsbGJhY2soY2FsbGJhY2ssIGNvbnZlcnRSZXN1bHQpIHtcbiAgcmV0dXJuIChcbiAgICBjYWxsYmFjayAmJlxuICAgIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpIHtcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICBjYWxsYmFjayhlcnJvcik7XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBjb252ZXJ0UmVzdWx0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNhbGxiYWNrKGVycm9yLCBjb252ZXJ0UmVzdWx0KHJlc3VsdCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2FsbGJhY2soZXJyb3IsIHJlc3VsdCk7XG4gICAgICB9XG4gICAgfVxuICApO1xufVxuXG4vKipcbiAqIEBzdW1tYXJ5IENyZWF0ZSBhIE1vbmdvLXN0eWxlIGBPYmplY3RJRGAuICBJZiB5b3UgZG9uJ3Qgc3BlY2lmeSBhIGBoZXhTdHJpbmdgLCB0aGUgYE9iamVjdElEYCB3aWxsIGdlbmVyYXRlZCByYW5kb21seSAobm90IHVzaW5nIE1vbmdvREIncyBJRCBjb25zdHJ1Y3Rpb24gcnVsZXMpLlxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAY2xhc3NcbiAqIEBwYXJhbSB7U3RyaW5nfSBbaGV4U3RyaW5nXSBPcHRpb25hbC4gIFRoZSAyNC1jaGFyYWN0ZXIgaGV4YWRlY2ltYWwgY29udGVudHMgb2YgdGhlIE9iamVjdElEIHRvIGNyZWF0ZVxuICovXG5Nb25nby5PYmplY3RJRCA9IE1vbmdvSUQuT2JqZWN0SUQ7XG5cbi8qKlxuICogQHN1bW1hcnkgVG8gY3JlYXRlIGEgY3Vyc29yLCB1c2UgZmluZC4gVG8gYWNjZXNzIHRoZSBkb2N1bWVudHMgaW4gYSBjdXJzb3IsIHVzZSBmb3JFYWNoLCBtYXAsIG9yIGZldGNoLlxuICogQGNsYXNzXG4gKiBAaW5zdGFuY2VOYW1lIGN1cnNvclxuICovXG5Nb25nby5DdXJzb3IgPSBMb2NhbENvbGxlY3Rpb24uQ3Vyc29yO1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIGluIDAuOS4xXG4gKi9cbk1vbmdvLkNvbGxlY3Rpb24uQ3Vyc29yID0gTW9uZ28uQ3Vyc29yO1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIGluIDAuOS4xXG4gKi9cbk1vbmdvLkNvbGxlY3Rpb24uT2JqZWN0SUQgPSBNb25nby5PYmplY3RJRDtcblxuLyoqXG4gKiBAZGVwcmVjYXRlZCBpbiAwLjkuMVxuICovXG5NZXRlb3IuQ29sbGVjdGlvbiA9IE1vbmdvLkNvbGxlY3Rpb247XG5cbi8vIEFsbG93IGRlbnkgc3R1ZmYgaXMgbm93IGluIHRoZSBhbGxvdy1kZW55IHBhY2thZ2Vcbk9iamVjdC5hc3NpZ24oTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGUsIEFsbG93RGVueS5Db2xsZWN0aW9uUHJvdG90eXBlKTtcblxuZnVuY3Rpb24gcG9wQ2FsbGJhY2tGcm9tQXJncyhhcmdzKSB7XG4gIC8vIFB1bGwgb2ZmIGFueSBjYWxsYmFjayAob3IgcGVyaGFwcyBhICdjYWxsYmFjaycgdmFyaWFibGUgdGhhdCB3YXMgcGFzc2VkXG4gIC8vIGluIHVuZGVmaW5lZCwgbGlrZSBob3cgJ3Vwc2VydCcgZG9lcyBpdCkuXG4gIGlmIChcbiAgICBhcmdzLmxlbmd0aCAmJlxuICAgIChhcmdzW2FyZ3MubGVuZ3RoIC0gMV0gPT09IHVuZGVmaW5lZCB8fFxuICAgICAgYXJnc1thcmdzLmxlbmd0aCAtIDFdIGluc3RhbmNlb2YgRnVuY3Rpb24pXG4gICkge1xuICAgIHJldHVybiBhcmdzLnBvcCgpO1xuICB9XG59XG5cbkFTWU5DX0NPTExFQ1RJT05fTUVUSE9EUy5mb3JFYWNoKG1ldGhvZE5hbWUgPT4ge1xuICBjb25zdCBtZXRob2ROYW1lQXN5bmMgPSBnZXRBc3luY01ldGhvZE5hbWUobWV0aG9kTmFtZSk7XG4gIE1vbmdvLkNvbGxlY3Rpb24ucHJvdG90eXBlW21ldGhvZE5hbWVBc3luY10gPSBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFRPRE86IEZpYmVycyByZW1vdmUgdGhpcyB3aGVuIHdlIHJlbW92ZSBmaWJlcnMuXG4gICAgICB0aGlzW21ldGhvZE5hbWVdLmlzQ2FsbGVkRnJvbUFzeW5jID0gdHJ1ZTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpc1ttZXRob2ROYW1lXSguLi5hcmdzKSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICB9O1xufSk7XG4iLCIvKipcbiAqIEBzdW1tYXJ5IEFsbG93cyBmb3IgdXNlciBzcGVjaWZpZWQgY29ubmVjdGlvbiBvcHRpb25zXG4gKiBAZXhhbXBsZSBodHRwOi8vbW9uZ29kYi5naXRodWIuaW8vbm9kZS1tb25nb2RiLW5hdGl2ZS8zLjAvcmVmZXJlbmNlL2Nvbm5lY3RpbmcvY29ubmVjdGlvbi1zZXR0aW5ncy9cbiAqIEBsb2N1cyBTZXJ2ZXJcbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIFVzZXIgc3BlY2lmaWVkIE1vbmdvIGNvbm5lY3Rpb24gb3B0aW9uc1xuICovXG5Nb25nby5zZXRDb25uZWN0aW9uT3B0aW9ucyA9IGZ1bmN0aW9uIHNldENvbm5lY3Rpb25PcHRpb25zIChvcHRpb25zKSB7XG4gIGNoZWNrKG9wdGlvbnMsIE9iamVjdCk7XG4gIE1vbmdvLl9jb25uZWN0aW9uT3B0aW9ucyA9IG9wdGlvbnM7XG59OyIsImV4cG9ydCBjb25zdCBub3JtYWxpemVQcm9qZWN0aW9uID0gb3B0aW9ucyA9PiB7XG4gIC8vIHRyYW5zZm9ybSBmaWVsZHMga2V5IGluIHByb2plY3Rpb25cbiAgY29uc3QgeyBmaWVsZHMsIHByb2plY3Rpb24sIC4uLm90aGVyT3B0aW9ucyB9ID0gb3B0aW9ucyB8fCB7fTtcbiAgLy8gVE9ETzogZW5hYmxlIHRoaXMgY29tbWVudCB3aGVuIGRlcHJlY2F0aW5nIHRoZSBmaWVsZHMgb3B0aW9uXG4gIC8vIExvZy5kZWJ1ZyhgZmllbGRzIG9wdGlvbiBoYXMgYmVlbiBkZXByZWNhdGVkLCBwbGVhc2UgdXNlIHRoZSBuZXcgJ3Byb2plY3Rpb24nIGluc3RlYWRgKVxuXG4gIHJldHVybiB7XG4gICAgLi4ub3RoZXJPcHRpb25zLFxuICAgIC4uLihwcm9qZWN0aW9uIHx8IGZpZWxkcyA/IHsgcHJvamVjdGlvbjogZmllbGRzIHx8IHByb2plY3Rpb24gfSA6IHt9KSxcbiAgfTtcbn07XG4iXX0=
